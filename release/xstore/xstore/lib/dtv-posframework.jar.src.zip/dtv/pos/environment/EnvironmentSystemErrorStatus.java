/*    */ package dtv.pos.environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvironmentSystemErrorStatus
/*    */ {
/*    */   private boolean _isError;
/*    */   
/*    */   public boolean isError() {
/* 20 */     return this._isError;
/*    */   }
/*    */   
/*    */   public void setError(boolean argIsError) {
/* 24 */     this._isError = argIsError;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\environment\EnvironmentSystemErrorStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */