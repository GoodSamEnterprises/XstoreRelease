/*    */ package dtv.pos.framework.form.design.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlankDetailModel
/*    */   extends AbstractDetailEditModel
/*    */ {
/*    */   public BlankDetailModel() {
/* 17 */     super(0, new String[0], new Class[0]);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\framework\form\design\model\BlankDetailModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */