package dtv.pos.framework.form.design;

import java.awt.Component;

public interface IFormComponentSelectionListener {
  void setSelectedFormComponent(Component paramComponent);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\framework\form\design\IFormComponentSelectionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */