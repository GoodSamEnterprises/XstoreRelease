package dtv.pos.framework.form.design.model;

import javax.swing.table.TableModel;

public interface PropertyEditTableModel extends TableModel {
  Class getCellClass(int paramInt1, int paramInt2);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\framework\form\design\model\PropertyEditTableModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */