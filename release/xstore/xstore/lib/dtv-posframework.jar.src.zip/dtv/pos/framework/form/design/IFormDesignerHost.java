package dtv.pos.framework.form.design;

import java.awt.Frame;

public interface IFormDesignerHost {
  void exit();
  
  Frame getFrame();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\framework\form\design\IFormDesignerHost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */