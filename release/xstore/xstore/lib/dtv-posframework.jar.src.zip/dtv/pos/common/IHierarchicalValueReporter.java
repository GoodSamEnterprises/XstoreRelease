package dtv.pos.common;

public interface IHierarchicalValueReporter<V, N, A> {
  V getHierarchicalValue(N paramN, A paramA);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\common\IHierarchicalValueReporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */