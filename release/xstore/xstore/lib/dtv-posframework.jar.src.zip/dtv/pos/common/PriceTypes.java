/*    */ package dtv.pos.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PriceTypes
/*    */ {
/* 14 */   REGULAR_PRICE, PROMO_PRICE, AIRPORT_PRICE, CLEARANCE_PRICE, LIST_PRICE;
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\common\PriceTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */