/*    */ package dtv.pos.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BusinessDateQualifier
/*    */ {
/* 15 */   ELIGIBLE_FOR_REGISTER_OPEN, BUSINESS_PERIOD_ENDED, STORE_CLOSED_DATE;
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\pos\common\BusinessDateQualifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */