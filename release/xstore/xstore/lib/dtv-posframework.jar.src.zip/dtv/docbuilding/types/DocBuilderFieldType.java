/*    */ package dtv.docbuilding.types;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DocBuilderFieldType
/*    */ {
/* 14 */   TEXT,
/* 15 */   METHOD,
/* 16 */   ITERATOR,
/* 17 */   SYSTEMPROPERTY,
/* 18 */   AGGREGATE;
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\docbuilding\types\DocBuilderFieldType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */