package dtv.docbuilding;

public interface IDocBuilderIteratorMember extends IDocBuilderSectionMember {}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\docbuilding\IDocBuilderIteratorMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */