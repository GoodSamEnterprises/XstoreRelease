package dtv.docbuilding.config;

import dtv.util.config.IConfigObject;

public interface ISectionMemberConfig extends IConfigObject {}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\docbuilding\config\ISectionMemberConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */