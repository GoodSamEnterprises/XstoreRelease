package dtv.docbuilding;

public interface IPageBreakElement extends IDocElement {
  int getPercentage();
  
  boolean isTextAppendable();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\docbuilding\IPageBreakElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */