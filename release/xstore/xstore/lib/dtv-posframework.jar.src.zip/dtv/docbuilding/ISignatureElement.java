package dtv.docbuilding;

import dtv.pos.iframework.hardware.AlignmentType;

public interface ISignatureElement extends IDocElement {
  AlignmentType getAlignment();
  
  String getContent();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\docbuilding\ISignatureElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */