package dtv.docbuilding.xml;

public interface IDocXmlStringParser {
  DocXmlRootElement convertXml(String paramString);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\docbuilding\xml\IDocXmlStringParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */