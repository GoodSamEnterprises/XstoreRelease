package dtv.logbuilder.model;

public interface IReprintModel extends ILoggableModel {}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\logbuilder\model\IReprintModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */