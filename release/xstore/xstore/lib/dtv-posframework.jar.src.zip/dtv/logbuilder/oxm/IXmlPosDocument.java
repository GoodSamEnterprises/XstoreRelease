package dtv.logbuilder.oxm;

import dtv.docbuilding.IPosDocument;

public interface IXmlPosDocument extends IPosDocument {
  String getXmlString();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\logbuilder\oxm\IXmlPosDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */