package dtv.logbuilder.oxm;

public interface IXmlBuilder {
  IXmlPosDocument buildXml(String paramString, Object paramObject);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-posframework.jar!\dtv\logbuilder\oxm\IXmlBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */