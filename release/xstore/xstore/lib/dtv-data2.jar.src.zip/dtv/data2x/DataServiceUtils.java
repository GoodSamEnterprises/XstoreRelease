/*     */ package dtv.data2x;
/*     */ 
/*     */ import dtv.util.DateUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.Date;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataServiceUtils
/*     */ {
/*  22 */   private static final Logger _logger = Logger.getLogger(DataServiceUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUndefinedNumber(int argValue) {
/*  33 */     return (argValue == Integer.MIN_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUndefinedNumber(Number argValue) {
/*  46 */     return (argValue == null || argValue.intValue() == Integer.MIN_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUndefinedNumber(String argValue) {
/*  59 */     return isUndefinedNumber(Long.valueOf(toLong(argValue)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date toDate(String argDateString, boolean argIncludeTime) {
/*  72 */     Date equivDate = null;
/*  73 */     if (!StringUtils.isEmpty(argDateString)) {
/*  74 */       equivDate = argIncludeTime ? DateUtils.parseIso(argDateString) : DateUtils.parseDate(argDateString);
/*     */     }
/*  76 */     return equivDate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDateString(Date argDate, boolean argIncludeTime) {
/*  90 */     String dateString = null;
/*  91 */     if (argDate != null) {
/*  92 */       dateString = argIncludeTime ? DateUtils.formatIsoDateTime(argDate) : DateUtils.format(argDate);
/*     */     }
/*  94 */     return dateString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt(Object argValue) {
/*     */     try {
/* 107 */       return Integer.valueOf(argValue.toString()).intValue();
/*     */     }
/* 109 */     catch (Exception ex) {
/* 110 */       _logger.debug("Could not parse [" + argValue + "] into an int.", ex);
/* 111 */       return Integer.MIN_VALUE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toLong(Object argValue) {
/*     */     try {
/* 125 */       return Long.valueOf(argValue.toString()).longValue();
/*     */     }
/* 127 */     catch (Exception ex) {
/* 128 */       _logger.debug("Could not parse [" + argValue + "] into a long.", ex);
/* 129 */       return -2147483648L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toObscuredString(Object argValue) {
/* 142 */     return toObscuredString(argValue, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toObscuredString(Object argValue, boolean argFullyObscure) {
/* 156 */     return argFullyObscure ? toObscuredString(argValue, 0, true) : toObscuredString(argValue, 4, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toObscuredString(Object argValue, int argExposeLength, boolean argExposeEnd) {
/* 172 */     String obscuredValue = null;
/*     */     
/* 174 */     if (argValue != null) {
/* 175 */       String valueString = argValue.toString();
/* 176 */       obscuredValue = valueString;
/*     */       
/* 178 */       int exposeLength = Math.min(argExposeLength, valueString.length());
/* 179 */       int obscureLength = valueString.length() - exposeLength;
/*     */       
/* 181 */       if (obscureLength > 0) {
/* 182 */         if (argExposeEnd) {
/* 183 */           obscuredValue = StringUtils.fill('*', obscureLength);
/* 184 */           if (exposeLength > 0) {
/* 185 */             obscuredValue = obscuredValue + valueString.substring(obscureLength);
/*     */           }
/*     */         } else {
/*     */           
/* 189 */           if (exposeLength > 0) {
/* 190 */             obscuredValue = valueString.substring(0, exposeLength);
/*     */           }
/* 192 */           obscuredValue = obscuredValue + StringUtils.fill('*', obscureLength);
/*     */         } 
/*     */       }
/*     */     } 
/* 196 */     return obscuredValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toSafeString(Object argValue) {
/* 207 */     return (argValue == null) ? null : String.valueOf(argValue);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\DataServiceUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */