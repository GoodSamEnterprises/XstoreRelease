package dtv.data2x.req;

import dtv.service.req.IServiceResponse;

public interface IUpdateResponse extends IServiceResponse {
  int getUpdatedCount();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\req\IUpdateResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */