package dtv.data2x.req;

import dtv.service.req.IServiceResponse;

public interface IPersistResponse extends IServiceResponse {}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\req\IPersistResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */