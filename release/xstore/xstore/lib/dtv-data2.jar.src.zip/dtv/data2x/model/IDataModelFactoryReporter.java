package dtv.data2x.model;

public interface IDataModelFactoryReporter {
  IDataModelFactory getDataModelFactory();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\model\IDataModelFactoryReporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */