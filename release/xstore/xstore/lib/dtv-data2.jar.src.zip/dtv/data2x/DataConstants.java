package dtv.data2x;

public class DataConstants {
  public static final int UNDEFINED_NUMBER = -2147483648;
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\DataConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */