/*     */ package dtv.data2x.impl.req;
/*     */ 
/*     */ import dtv.data2.access.IQueryKey;
/*     */ import dtv.data2.access.IQueryResult;
/*     */ import dtv.data2x.req.IQueryRequest;
/*     */ import dtv.servicex.impl.req.ServiceRequest;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryRequest<R extends IQueryResult>
/*     */   extends ServiceRequest
/*     */   implements IQueryRequest<R>
/*     */ {
/*  26 */   private static final Map<String, Object> _noQueryParams = Collections.emptyMap();
/*     */ 
/*     */   
/*     */   private final IQueryKey<? extends R> _queryKey;
/*     */ 
/*     */   
/*     */   private final Map<String, Object> _queryParams;
/*     */ 
/*     */   
/*     */   public QueryRequest(IQueryKey<? extends R> argQueryKey) {
/*  36 */     this(argQueryKey, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRequest(IQueryKey<? extends R> argQueryKey, Map<String, Object> argQueryParams) {
/*  47 */     this._queryParams = (argQueryParams == null) ? _noQueryParams : new HashMap<>(argQueryParams);
/*  48 */     this._queryKey = argQueryKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRequest(Map<String, Object> argQueryParams) {
/*  56 */     this(null, argQueryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object argObj) {
/*  62 */     if (argObj == this) {
/*  63 */       return true;
/*     */     }
/*  65 */     if (!(argObj instanceof QueryRequest)) {
/*  66 */       return false;
/*     */     }
/*  68 */     QueryRequest<?> other = (QueryRequest)argObj;
/*  69 */     return (new EqualsBuilder())
/*  70 */       .append(this._queryParams, other._queryParams)
/*  71 */       .append(this._queryKey, other._queryKey)
/*  72 */       .appendSuper(super.equals(argObj)).isEquals();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IQueryKey<? extends R> getQueryKey() {
/*  78 */     return this._queryKey;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getQueryParams() {
/*  84 */     return this._queryParams;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  90 */     return (new HashCodeBuilder(17, 37))
/*  91 */       .append(this._queryParams)
/*  92 */       .append(this._queryKey)
/*  93 */       .appendSuper(super.hashCode()).toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     return (new ToStringBuilder(this))
/* 100 */       .append("queryParams", this._queryParams)
/* 101 */       .append("queryKey", this._queryKey)
/* 102 */       .appendSuper(super.toString()).toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\QueryRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */