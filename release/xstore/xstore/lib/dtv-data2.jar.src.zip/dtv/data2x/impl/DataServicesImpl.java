/*     */ package dtv.data2x.impl;
/*     */ 
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IQueryResultList;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2x.IDataServices;
/*     */ import dtv.data2x.impl.req.PersistResponse;
/*     */ import dtv.data2x.impl.req.QueryResponse;
/*     */ import dtv.data2x.impl.req.RetrieveResponse;
/*     */ import dtv.data2x.impl.req.UpdateResponse;
/*     */ import dtv.data2x.req.IPersistRequest;
/*     */ import dtv.data2x.req.IPersistResponse;
/*     */ import dtv.data2x.req.IQueryRequest;
/*     */ import dtv.data2x.req.IRetrieveRequest;
/*     */ import dtv.data2x.req.IUpdateRequest;
/*     */ import dtv.data2x.req.IUpdateResponse;
/*     */ import dtv.service.ServiceException;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DataServicesImpl
/*     */   implements IDataServices
/*     */ {
/*     */   private static <T extends IDataModel> T setModelState(T argModel, boolean argDeep, int argState) {
/*  30 */     if (argDeep) {
/*     */       
/*  32 */       for (IPersistable persistable : DaoUtils.getPersistables(argModel)) {
/*  33 */         if (persistable instanceof IDataAccessObject) {
/*  34 */           ((IDataAccessObject)persistable).setObjectState(argState);
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  40 */       ((IDataModelImpl)argModel).getDAO().setObjectState(argState);
/*     */     } 
/*  42 */     return argModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R extends dtv.data2.access.IQueryResult, QOA extends dtv.data2x.req.IQueryResponse<R>> QOA browse(IQueryRequest<R> argRequest) {
/*     */     try {
/*  57 */       IQueryResultList iQueryResultList = DataFactory.getObjectByQuery(argRequest.getQueryKey(), argRequest.getQueryParams());
/*     */       
/*  59 */       return (QOA)new QueryResponse((List)iQueryResultList);
/*     */     }
/*  61 */     catch (ServiceException ex) {
/*  62 */       throw ex;
/*     */     }
/*  64 */     catch (Exception ex) {
/*  65 */       throw new ServiceException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IDataModel> T create(Class<T> argModelType) {
/*  72 */     IDataModel iDataModel = DataFactory.createObject(argModelType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     ((IDataModelImpl)iDataModel).getDAO().setObjectState(DaoState.INSERT_OR_UPDATE.intVal());
/*     */     
/*  80 */     return (T)iDataModel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IDataModel> T createClean(Class<T> argModelType) {
/*  86 */     T model = create(argModelType);
/*  87 */     return makeClean(model, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IDataModel> T createTransient(Class<T> argModelType) {
/*  93 */     return (T)DataFactory.createTransientObject(argModelType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IDataModel> T makeClean(T argModel, boolean argDeep) {
/*  99 */     return setModelState(argModel, argDeep, DaoState.CLEAN.intVal());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IDataModel> T makeDirty(T argModel, boolean argDeep) {
/* 105 */     return setModelState(argModel, argDeep, DaoState.INSERT_OR_UPDATE.intVal());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <M extends IDataModel> M makeTransient(M argModel) {
/* 111 */     DataFactory.makeTransient(argModel);
/* 112 */     return argModel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistResponse persist(IPersistRequest<? extends IPersistable> argRequest) {
/*     */     try {
/* 119 */       DataFactory.makePersistent(argRequest.getModelsToPersist());
/* 120 */       return (IPersistResponse)new PersistResponse();
/*     */     }
/* 122 */     catch (ServiceException ex) {
/* 123 */       throw ex;
/*     */     }
/* 125 */     catch (Exception ex) {
/* 126 */       throw new ServiceException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <ROA extends dtv.data2x.req.IRetrieveResponse<?>> ROA retrieve(IRetrieveRequest<? extends IObjectId> argRequest) {
/* 134 */     IDataModel result = DataFactory.getObjectById(argRequest.getModelId());
/* 135 */     return (ROA)new RetrieveResponse(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R extends dtv.data2.access.IQueryResult, QOA extends dtv.data2x.req.IQueryResponse<R>> QOA search(IQueryRequest<R> argRequest) {
/*     */     try {
/* 144 */       IQueryResultList iQueryResultList = DataFactory.getObjectByQuery(argRequest.getQueryKey(), argRequest.getQueryParams());
/*     */       
/* 146 */       return (QOA)new QueryResponse((List)iQueryResultList);
/*     */     }
/* 148 */     catch (ServiceException ex) {
/* 149 */       throw ex;
/*     */     }
/* 151 */     catch (Exception ex) {
/* 152 */       throw new ServiceException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IUpdateResponse update(IUpdateRequest argRequest) {
/*     */     try {
/* 160 */       int updateCount = DataFactory.executeQuery(argRequest.getQueryKey(), argRequest.getQueryParams());
/* 161 */       return (IUpdateResponse)new UpdateResponse(updateCount);
/*     */     }
/* 163 */     catch (ServiceException ex) {
/* 164 */       throw ex;
/*     */     }
/* 166 */     catch (Exception ex) {
/* 167 */       throw new ServiceException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\DataServicesImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */