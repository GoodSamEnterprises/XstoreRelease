/*    */ package dtv.data2x.impl.req;
/*    */ 
/*    */ import dtv.data2.access.IObjectId;
/*    */ import dtv.data2x.req.IRetrieveRequest;
/*    */ import dtv.servicex.impl.req.ServiceRequest;
/*    */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*    */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetrieveRequest<I extends IObjectId>
/*    */   extends ServiceRequest
/*    */   implements IRetrieveRequest<I>
/*    */ {
/*    */   private final I _dataModelId;
/*    */   
/*    */   public RetrieveRequest(I argDataModelId) {
/* 31 */     this._dataModelId = argDataModelId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object argObj) {
/* 37 */     if (argObj == this) {
/* 38 */       return true;
/*    */     }
/* 40 */     if (!(argObj instanceof RetrieveRequest)) {
/* 41 */       return false;
/*    */     }
/* 43 */     RetrieveRequest<?> other = (RetrieveRequest)argObj;
/* 44 */     return (new EqualsBuilder())
/* 45 */       .append(this._dataModelId, other._dataModelId)
/* 46 */       .appendSuper(super.equals(argObj)).isEquals();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public I getModelId() {
/* 52 */     return this._dataModelId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return (new HashCodeBuilder(17, 37))
/* 59 */       .append(this._dataModelId)
/* 60 */       .appendSuper(super.hashCode()).toHashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     return (new ToStringBuilder(this))
/* 67 */       .append("dataModelId", this._dataModelId)
/* 68 */       .appendSuper(super.toString()).toString();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\RetrieveRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */