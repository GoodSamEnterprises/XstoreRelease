/*    */ package dtv.data2x.impl.req;
/*    */ 
/*    */ import dtv.service.ServiceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoRecordsFoundException
/*    */   extends ServiceException
/*    */ {
/*    */   private static final long serialVersionUID = 4642053214166069535L;
/*    */   
/*    */   public NoRecordsFoundException(String argMessage) {
/* 27 */     super(argMessage);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NoRecordsFoundException(String argMessage, Throwable argCause) {
/* 37 */     super(argMessage, argCause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NoRecordsFoundException(Throwable argCause) {
/* 45 */     super(argCause);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\NoRecordsFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */