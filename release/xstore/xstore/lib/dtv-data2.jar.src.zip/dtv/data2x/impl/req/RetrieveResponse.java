/*    */ package dtv.data2x.impl.req;
/*    */ 
/*    */ import dtv.data2.access.IDataModel;
/*    */ import dtv.data2x.req.IRetrieveResponse;
/*    */ import dtv.servicex.impl.req.ServiceResponse;
/*    */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*    */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetrieveResponse<M extends IDataModel>
/*    */   extends ServiceResponse
/*    */   implements IRetrieveResponse<M>
/*    */ {
/*    */   private final M _retrieveResult;
/*    */   
/*    */   public RetrieveResponse() {
/* 29 */     this(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RetrieveResponse(M argRetrieveResult) {
/* 38 */     this._retrieveResult = argRetrieveResult;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object argObj) {
/* 44 */     if (argObj == this) {
/* 45 */       return true;
/*    */     }
/*    */     
/* 48 */     if (!(argObj instanceof RetrieveResponse)) {
/* 49 */       return false;
/*    */     }
/*    */     
/* 52 */     RetrieveResponse<?> other = (RetrieveResponse)argObj;
/* 53 */     return (new EqualsBuilder())
/* 54 */       .append(this._retrieveResult, other._retrieveResult)
/* 55 */       .appendSuper(super.equals(argObj)).isEquals();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public M getResult() {
/* 61 */     return this._retrieveResult;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 67 */     return (new HashCodeBuilder(17, 37))
/* 68 */       .append(this._retrieveResult)
/* 69 */       .appendSuper(super.hashCode()).toHashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return (new ToStringBuilder(this))
/* 76 */       .append("retrieveResult", this._retrieveResult)
/* 77 */       .appendSuper(super.toString()).toString();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\RetrieveResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */