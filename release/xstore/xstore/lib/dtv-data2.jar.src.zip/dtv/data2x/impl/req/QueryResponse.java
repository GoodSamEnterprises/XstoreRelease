/*    */ package dtv.data2x.impl.req;
/*    */ 
/*    */ import dtv.data2.access.IQueryResult;
/*    */ import dtv.data2x.req.IQueryResponse;
/*    */ import dtv.servicex.impl.req.ServiceResponse;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*    */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryResponse<R extends IQueryResult>
/*    */   extends ServiceResponse
/*    */   implements IQueryResponse<R>
/*    */ {
/*    */   private final List<R> _queryResults;
/*    */   
/*    */   public QueryResponse() {
/* 31 */     this(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QueryResponse(List<? extends R> argQueryResults) {
/* 40 */     List<R> noQueryResults = Collections.emptyList();
/* 41 */     this._queryResults = (argQueryResults == null) ? noQueryResults : new ArrayList<>(argQueryResults);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object argObj) {
/* 47 */     if (argObj == this) {
/* 48 */       return true;
/*    */     }
/* 50 */     if (!(argObj instanceof QueryResponse)) {
/* 51 */       return false;
/*    */     }
/* 53 */     QueryResponse<?> other = (QueryResponse)argObj;
/* 54 */     return (new EqualsBuilder())
/* 55 */       .append(this._queryResults, other._queryResults)
/* 56 */       .appendSuper(super.equals(argObj)).isEquals();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<? extends R> getResults() {
/* 62 */     return this._queryResults;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 68 */     return (new HashCodeBuilder(17, 37))
/* 69 */       .append(this._queryResults)
/* 70 */       .appendSuper(super.hashCode()).toHashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return (new ToStringBuilder(this))
/* 77 */       .append("queryResults", this._queryResults)
/* 78 */       .appendSuper(super.toString()).toString();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\QueryResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */