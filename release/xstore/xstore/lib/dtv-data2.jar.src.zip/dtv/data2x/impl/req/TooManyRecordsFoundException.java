/*    */ package dtv.data2x.impl.req;
/*    */ 
/*    */ import dtv.service.ServiceException;
/*    */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TooManyRecordsFoundException
/*    */   extends ServiceException
/*    */ {
/*    */   private static final long serialVersionUID = -131334987695368224L;
/*    */   private final int _maxRecords;
/*    */   
/*    */   public TooManyRecordsFoundException(String argMessage) {
/* 31 */     this(argMessage, -2147483648);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TooManyRecordsFoundException(String argMessage, int argMaxRecords) {
/* 41 */     super(argMessage);
/* 42 */     this._maxRecords = argMaxRecords;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TooManyRecordsFoundException(String argMessage, Throwable argCause) {
/* 52 */     this(argMessage, argCause, -2147483648);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TooManyRecordsFoundException(String argMessage, Throwable argCause, int argMaxRecords) {
/* 63 */     super(argMessage, argCause);
/* 64 */     this._maxRecords = argMaxRecords;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TooManyRecordsFoundException(Throwable argCause) {
/* 72 */     this(argCause, -2147483648);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TooManyRecordsFoundException(Throwable argCause, int argMaxRecords) {
/* 82 */     super(argCause);
/* 83 */     this._maxRecords = argMaxRecords;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaximumRecords() {
/* 91 */     return (this._maxRecords >= 0) ? this._maxRecords : -1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 97 */     return (new ToStringBuilder(this)).append("maxRecords", (this._maxRecords >= 0) ? Integer.valueOf(this._maxRecords) : "?").toString();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\TooManyRecordsFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */