package dtv.data2x.impl.req;

import dtv.data2x.req.IPersistResponse;
import dtv.servicex.impl.req.ServiceResponse;

public class PersistResponse extends ServiceResponse implements IPersistResponse {}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2x\impl\req\PersistResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */