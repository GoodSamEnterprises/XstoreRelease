/*    */ package dtv.data2.dataloader.filelocator;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.commons.io.filefilter.WildcardFileFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileExtensionFilter
/*    */   extends WildcardFileFilter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private boolean _invert = false;
/*    */   
/*    */   public FileExtensionFilter(String... argExtensions) {
/* 28 */     super(argExtensions);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean accept(File argFile) {
/* 34 */     if (argFile.isDirectory()) {
/* 35 */       return false;
/*    */     }
/*    */     
/* 38 */     boolean accepted = super.accept(argFile);
/* 39 */     return this._invert ? (!accepted) : accepted;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean accept(File argDir, String argFileName) {
/* 45 */     if ((new File(argDir, argFileName)).isDirectory()) {
/* 46 */       return false;
/*    */     }
/*    */     
/* 49 */     boolean accepted = super.accept(argDir, argFileName);
/* 50 */     return this._invert ? (!accepted) : accepted;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setInvert(boolean argInvert) {
/* 59 */     this._invert = argInvert;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\filelocator\FileExtensionFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */