/*     */ package dtv.data2.dataloader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigParameters
/*     */ {
/*     */   private String _dataFilePath;
/*     */   private String _dataSource;
/*     */   private int _recordsPerTransaction;
/*     */   private int _archiveDays;
/*     */   private String _archivePath;
/*     */   private boolean _processListFiles;
/*     */   private Long _organizationId;
/*     */   
/*     */   public int getArchiveDays() {
/*  27 */     return this._archiveDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArchivePath() {
/*  36 */     return this._archivePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataFileLocation() {
/*  45 */     return this._dataFilePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSource() {
/*  54 */     return this._dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getOrganizationId() {
/*  63 */     return this._organizationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getProcessListFiles() {
/*  72 */     return this._processListFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRecordsPerTransaction() {
/*  81 */     return this._recordsPerTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArchiveDays(int argArchiveDays) {
/*  90 */     this._archiveDays = argArchiveDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArchivePath(String argArchivePath) {
/*  99 */     this._archivePath = argArchivePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataFileLocation(String argDataFilePath) {
/* 108 */     this._dataFilePath = argDataFilePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(String argDataSource) {
/* 117 */     this._dataSource = argDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrganizationId(Long argOrganizationId) {
/* 126 */     this._organizationId = argOrganizationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessListFiles(boolean argProcessListFiles) {
/* 135 */     this._processListFiles = argProcessListFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecordsPerTransaction(int argRecordsPerTransaction) {
/* 144 */     this._recordsPerTransaction = argRecordsPerTransaction;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\ConfigParameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */