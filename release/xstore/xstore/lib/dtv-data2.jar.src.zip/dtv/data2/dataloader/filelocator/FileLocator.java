/*     */ package dtv.data2.dataloader.filelocator;
/*     */ 
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileLocator
/*     */   extends AbstractDataFileLocator
/*     */ {
/*  28 */   private static final Logger logger_ = LogManager.getLogger(FileLocator.class);
/*     */ 
/*     */   
/*     */   private static final String EXCLUSIONS_FILE_NAME = "readme.txt";
/*     */ 
/*     */   
/*     */   private static final String REORG_FILE_EXCLUSION = "*.reo";
/*     */ 
/*     */   
/*     */   public FileLocator(String argDataFilePath) {
/*  38 */     super(argDataFilePath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getDataFileDir() {
/*  53 */     File dataFile = getConfiguredDataFile();
/*  54 */     if (dataFile == null || dataFile.isDirectory()) {
/*  55 */       return dataFile;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     int lastSeperator = dataFile.getAbsolutePath().lastIndexOf(File.separatorChar);
/*     */     
/*  63 */     if (lastSeperator != -1) {
/*  64 */       File dataFileDir = new File(dataFile.getAbsolutePath().substring(0, lastSeperator));
/*  65 */       if (dataFileDir.exists() && dataFileDir.isDirectory()) {
/*  66 */         return dataFileDir;
/*     */       }
/*     */     } 
/*     */     
/*  70 */     logger_.warn("Could not determine dataFileDir for configured data file: {}", dataFile);
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<File> getDataFiles() {
/*  77 */     File dataFileDir = getDataFileDir();
/*  78 */     if (dataFileDir == null) {
/*  79 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  82 */     return getDataFiles(dataFileDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<File> getDataFiles(File argDataDir) {
/*  92 */     FileFilter filter = getFileExclusionFilter(argDataDir);
/*  93 */     File[] files = argDataDir.listFiles(filter);
/*     */     
/*  95 */     if (files == null || files.length == 0) {
/*  96 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  99 */     List<File> dataFiles = new ArrayList<>(files.length);
/*     */     
/* 101 */     for (File file : files) {
/* 102 */       if (!file.isDirectory()) {
/* 103 */         dataFiles.add(file);
/*     */       }
/*     */     } 
/*     */     
/* 107 */     return dataFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FileFilter getFileExclusionFilter(File argDataDir) {
/* 117 */     List<String> exclusions = new ArrayList<>();
/* 118 */     exclusions.add("summary.ini");
/*     */     
/* 120 */     File exclusionsFile = new File(argDataDir, "readme.txt");
/* 121 */     try (BufferedReader reader = new BufferedReader(new FileReader(exclusionsFile))) {
/*     */       
/* 123 */       String read = null;
/* 124 */       while ((read = reader.readLine()) != null) {
/* 125 */         if (StringUtils.isEmpty(read) || read.trim().startsWith("#")) {
/*     */           continue;
/*     */         }
/* 128 */         exclusions.add(read);
/*     */       } 
/*     */       
/* 131 */       String trickleProp = System.getProperty("dtv.dataloader.trickle", "false");
/* 132 */       boolean trickleMode = Boolean.valueOf(trickleProp).booleanValue();
/*     */       
/* 134 */       if (trickleMode) {
/* 135 */         exclusions.add("*.reo");
/*     */       }
/*     */     }
/* 138 */     catch (FileNotFoundException ex) {
/* 139 */       logger_.info("{} was not found.  No file exclusions will be processed.", "readme.txt");
/*     */     }
/* 141 */     catch (IOException ex) {
/* 142 */       logger_.error("An exception was caught attempting to read readme.txt exclusions file.", ex);
/*     */     } 
/*     */     
/* 145 */     FileExtensionFilter filter = new FileExtensionFilter(exclusions.<String>toArray(new String[exclusions.size()]));
/* 146 */     filter.setInvert(true);
/*     */     
/* 148 */     return (FileFilter)filter;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\filelocator\FileLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */