/*    */ package dtv.data2.dataloader.filelocator;
/*    */ 
/*    */ import dtv.data2.dataloader.DataLoaderEventLogger;
/*    */ import java.io.File;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataFileLocator
/*    */   implements IDataFileLocator
/*    */ {
/* 21 */   private static final Logger logger_ = Logger.getLogger(AbstractDataFileLocator.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private File dataFile_;
/*    */ 
/*    */   
/*    */   private String _dataFilePath;
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractDataFileLocator(String argDataFilePath) {
/* 33 */     this._dataFilePath = argDataFilePath;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected File getConfiguredDataFile() {
/* 42 */     if (this.dataFile_ != null) {
/* 43 */       return this.dataFile_;
/*    */     }
/*    */     try {
/* 46 */       this.dataFile_ = new File(getDataFilePath());
/*    */     }
/* 48 */     catch (Exception ex) {
/* 49 */       String msg = "Data file path is not properly configured for DataLoader. Dataloader will exit without loading data.";
/*    */       
/* 51 */       logger_.warn(msg, ex);
/* 52 */       DataLoaderEventLogger.warn(msg, ex);
/*    */     } 
/*    */     
/* 55 */     return this.dataFile_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getDataFilePath() {
/* 64 */     return this._dataFilePath;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isValidDataFile(File argFile) {
/* 74 */     if (argFile == null || !argFile.exists() || argFile.isDirectory()) {
/* 75 */       return false;
/*    */     }
/*    */     
/* 78 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\filelocator\AbstractDataFileLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */