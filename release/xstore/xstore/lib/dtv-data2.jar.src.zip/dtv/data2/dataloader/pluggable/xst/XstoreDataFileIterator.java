/*     */ package dtv.data2.dataloader.pluggable.xst;
/*     */ 
/*     */ import dtv.data2.access.DataModelFactory;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IQueryKey;
/*     */ import dtv.data2.access.QueryKey;
/*     */ import dtv.data2.access.impl.jdbc.IJDBCTableAdapter;
/*     */ import dtv.data2.access.impl.jdbc.JDBCAdapterMap;
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.dataloader.DataLoaderUtils;
/*     */ import dtv.data2.dataloader.config.DaoConfig;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfigHelper;
/*     */ import dtv.data2.dataloader.config.PersistableConfig;
/*     */ import dtv.data2.dataloader.config.RecordTypeConfig;
/*     */ import dtv.data2.dataloader.fileprocessing.DataFileProcessor;
/*     */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*     */ import dtv.data2.dataloader.fileprocessing.IFileLineParser;
/*     */ import dtv.data2.dataloader.fileprocessing.IFileLineParserFactory;
/*     */ import dtv.data2.dataloader.pluggable.AbstractDataFileIterator;
/*     */ import dtv.data2.dataloader.pluggable.AtomicPersistables;
/*     */ import dtv.data2.dataloader.pluggable.DataFileException;
/*     */ import dtv.data2.dataloader.pluggable.DataFileMetaData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ 
/*     */ public class XstoreDataFileIterator
/*     */   extends AbstractDataFileIterator<XstoreFileConfiguration>
/*     */ {
/*  33 */   private static final IQueryKey<Object[]> TRUNCATE_TABLE = (IQueryKey<Object[]>)new QueryKey("TRUNCATE_TABLE", Object[].class);
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private DataFileProcessor _processor;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IFileLineParserFactory _fileLineParserFactory;
/*     */ 
/*     */   
/*     */   private Iterator<FileLine> _fileLineIterator;
/*     */ 
/*     */ 
/*     */   
/*     */   public XstoreDataFileIterator(DataFileMetaData<XstoreFileConfiguration> argMetaData) {
/*  50 */     super(argMetaData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  56 */     this._processor.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IPersistable> getPersistablesFromFileLine(FileLine argLine) {
/*  66 */     switch (argLine.getActionType()) {
/*     */       case "TRUNCATE":
/*  68 */         return getTruncateTablePersistables(argLine);
/*     */       case "DELETE_BY_ORGANIZATION":
/*  70 */         return getDeleteByOrganizationPersistables(argLine);
/*     */     } 
/*     */     
/*  73 */     IFileLineParser lineParser = this._fileLineParserFactory.getFileLineParser(argLine.getRecordType());
/*  74 */     return lineParser.parse(argLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AtomicPersistables getNext() throws DataFileException {
/*  83 */     FileLine nextLine = null;
/*     */ 
/*     */     
/*     */     try {
/*  87 */       if (this._fileLineIterator == null) {
/*  88 */         this._fileLineIterator = (Iterator<FileLine>)this._processor.getSortedFileLineIterator(getMetaData().getFile());
/*     */       }
/*     */       
/*  91 */       AtomicPersistables persistablesFromOneLine = null;
/*     */       
/*  93 */       if (this._fileLineIterator.hasNext()) {
/*  94 */         nextLine = this._fileLineIterator.next();
/*     */ 
/*     */ 
/*     */         
/*  98 */         if (!nextLine.getIsInstructionValid()) {
/*  99 */           throw new DataFileException("Invalid instruction{Action|RecordType}", nextLine.toString());
/*     */         }
/*     */         
/* 102 */         List<IPersistable> persistables = getPersistablesFromFileLine(nextLine);
/* 103 */         persistablesFromOneLine = new AtomicPersistables(persistables, nextLine.toString());
/*     */       } 
/*     */       
/* 106 */       return persistablesFromOneLine;
/*     */     }
/* 108 */     catch (Exception ex) {
/* 109 */       throw new DataFileException(ex.getMessage(), ex, nextLine.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<IPersistable> getDAOsFromLine(FileLine argLine) {
/* 119 */     List<IPersistable> daos = new ArrayList<>();
/*     */     
/* 121 */     RecordTypeConfig recordConfig = DataLoaderConfigHelper.getDataLoaderConfig().getRecordType(argLine.getRecordType());
/*     */     
/* 123 */     for (PersistableConfig persistableConfig : recordConfig.getPersistables()) {
/* 124 */       if (persistableConfig instanceof DaoConfig) {
/* 125 */         daos.add(DataModelFactory.getDaoForDaoName(((DaoConfig)persistableConfig).getDaoName()));
/*     */       }
/*     */     } 
/*     */     
/* 129 */     return daos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<IPersistable> getDeleteByOrganizationPersistables(FileLine argLine) {
/* 138 */     List<IPersistable> deletePersistables = new ArrayList<>();
/* 139 */     List<IPersistable> daos = getDAOsFromLine(argLine);
/*     */     
/* 141 */     for (IPersistable dao : daos) {
/* 142 */       String tableName = getTableNameFromDAO(dao);
/* 143 */       IPersistable deleteByOrgQuery = DataLoaderUtils.getDeleteByOrganizationPersistable(tableName);
/*     */       
/* 145 */       deletePersistables.add(deleteByOrgQuery);
/*     */     } 
/*     */     
/* 148 */     return deletePersistables;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getTableNameFromDAO(IPersistable argDAO) {
/* 157 */     IJDBCTableAdapter tableAdapter = JDBCAdapterMap.getTableAdapter(argDAO.getClass().getName());
/* 158 */     return tableAdapter.getTableName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<IPersistable> getTruncateTablePersistables(FileLine argLine) {
/* 166 */     List<IPersistable> truncatePersistables = new ArrayList<>();
/* 167 */     List<IPersistable> daos = getDAOsFromLine(argLine);
/*     */     
/* 169 */     for (IPersistable dao : daos) {
/* 170 */       String tableName = getTableNameFromDAO(dao);
/*     */       
/* 172 */       Map<String, Object> queryParams = new HashMap<>();
/* 173 */       queryParams.put("argTableName", tableName);
/*     */       
/* 175 */       QueryRequest truncateQuery = new QueryRequest();
/* 176 */       truncateQuery.setQueryKey(TRUNCATE_TABLE);
/* 177 */       truncateQuery.setParams(queryParams);
/*     */       
/* 179 */       truncatePersistables.add(truncateQuery);
/*     */     } 
/*     */     
/* 182 */     return truncatePersistables;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\xst\XstoreDataFileIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */