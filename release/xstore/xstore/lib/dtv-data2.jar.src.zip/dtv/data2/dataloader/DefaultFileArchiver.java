/*     */ package dtv.data2.dataloader;
/*     */ 
/*     */ import dtv.data2.dataloader.filelocator.StatusFileFilter;
/*     */ import dtv.data2.dataloader.fileprocessing.DataFileProcessor;
/*     */ import dtv.util.CalendarField;
/*     */ import dtv.util.DateUtils;
/*     */ import dtv.util.FileUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.IOException;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFileArchiver
/*     */   implements IFileArchiver
/*     */ {
/*  32 */   private static final Logger _logger = Logger.getLogger(DataFileProcessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   private final Date _runDate = new Date();
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private ConfigParameters _configParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void archiveDataFile(File argFile, String argNewFileName) {
/*  54 */     archiveDataFile(argFile, false, argNewFileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean archiveStatusFiles() {
/*  69 */     String dataFilePath = this._configParameters.getDataFileLocation();
/*  70 */     File successFile = new File(dataFilePath, "success.dat");
/*  71 */     boolean isStatusFileArchived = false;
/*     */     
/*  73 */     if (successFile.exists()) {
/*  74 */       archiveDataFile(successFile, true, null);
/*  75 */       isStatusFileArchived = true;
/*     */     } 
/*     */     
/*  78 */     File failuresFile = new File(dataFilePath, "failures.dat");
/*     */     
/*  80 */     if (failuresFile.exists()) {
/*  81 */       archiveDataFile(failuresFile, true, null);
/*  82 */       isStatusFileArchived = true;
/*     */     } 
/*  84 */     return isStatusFileArchived;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void archiveSummaryFile() {
/*  93 */     String dataFilePath = this._configParameters.getDataFileLocation();
/*  94 */     File successFile = new File(dataFilePath, "summary.ini");
/*     */     
/*  96 */     if (successFile.exists()) {
/*  97 */       archiveDataFile(successFile, true, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUpArchives() {
/* 107 */     int archiveDays = this._configParameters.getArchiveDays();
/*     */     
/* 109 */     _logger.info("Cleaning up archive files that are older than " + archiveDays + " days...");
/*     */     
/* 111 */     String rootArchivePathName = this._configParameters.getArchivePath();
/* 112 */     File rootArchivePath = new File(rootArchivePathName);
/* 113 */     File[] files = rootArchivePath.listFiles();
/*     */     
/* 115 */     if (files != null) {
/* 116 */       Date oldestDate = DateUtils.dateAdd(CalendarField.DAY, -archiveDays, new Date());
/* 117 */       SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
/*     */       
/* 119 */       for (File archiveFile : files) {
/*     */ 
/*     */         
/* 122 */         if (archiveFile.isDirectory()) {
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 127 */             Date archiveDate = dateFormat.parse(archiveFile.getName());
/*     */             
/* 129 */             if (archiveDate.before(oldestDate)) {
/* 130 */               FileUtils.deleteTree(archiveFile);
/*     */             }
/*     */           }
/* 133 */           catch (ParseException ex) {
/* 134 */             _logger.warn("Encountered a directory in the archive path that does conform to the naming convention [" + archiveFile
/* 135 */                 .getName() + "]. It will not be touched.");
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUpStatusFiles() {
/* 152 */     String dataFilePath = this._configParameters.getDataFileLocation();
/* 153 */     File filePath = new File(dataFilePath);
/* 154 */     File[] statusFiles = filePath.listFiles((FileFilter)new StatusFileFilter());
/*     */     
/* 156 */     if (!filePath.exists()) {
/* 157 */       _logger.warn("Data file path [" + filePath.getAbsolutePath() + "] does not exist..");
/*     */       
/*     */       return;
/*     */     } 
/* 161 */     for (File statusFile : statusFiles) {
/* 162 */       boolean success = statusFile.delete();
/*     */       
/* 164 */       if (!success) {
/* 165 */         _logger.error("Unable to delete pre-existing status file [" + statusFile.getPath() + "].");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRunDateDirectory() {
/* 176 */     SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd_HHmmss");
/* 177 */     return format.format(this._runDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void archiveDataFile(File argFile, boolean argCopy, String argOptionalNewFilename) {
/* 188 */     boolean success = true;
/* 189 */     String runDateDir = getRunDateDirectory();
/* 190 */     File rootArchivePath = new File(this._configParameters.getArchivePath());
/*     */     
/* 192 */     if (!rootArchivePath.exists()) {
/* 193 */       success = rootArchivePath.mkdir();
/*     */     }
/*     */     
/* 196 */     if (!rootArchivePath.isDirectory()) {
/* 197 */       _logger.error("Archive path [" + rootArchivePath + "] either does not exist or is not a directory: data files will not be archived");
/*     */       
/* 199 */       success = false;
/*     */     } 
/*     */     
/* 202 */     if (success) {
/* 203 */       File archivePath = new File(rootArchivePath, runDateDir);
/*     */ 
/*     */       
/* 206 */       if (!archivePath.exists()) {
/* 207 */         success = archivePath.mkdir();
/*     */       }
/*     */       
/* 210 */       if (success) {
/* 211 */         String newName = (argOptionalNewFilename == null) ? argFile.getName() : argOptionalNewFilename;
/*     */ 
/*     */         
/* 214 */         File archiveFile = new File(archivePath, newName);
/*     */         
/* 216 */         if (argCopy) {
/*     */           try {
/* 218 */             FileUtils.copyFile(argFile, archiveFile);
/* 219 */             success = true;
/*     */           }
/* 221 */           catch (IOException ex) {
/* 222 */             success = false;
/*     */           } 
/*     */         } else {
/*     */           
/* 226 */           success = argFile.renameTo(archiveFile);
/*     */         } 
/*     */         
/* 229 */         if (!success)
/* 230 */           _logger.error("Unable to rename file for archiving.  Old name [" + argFile + "]. New name [" + archiveFile + "]."); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\DefaultFileArchiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */