/*    */ package dtv.data2.dataloader.valuetranslator;
/*    */ 
/*    */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*    */ import dtv.util.StringUtils;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringMapReplaceTranslator
/*    */   extends AbstractValueTranslator
/*    */   implements IValueTranslator
/*    */ {
/* 25 */   private static final Logger logger_ = Logger.getLogger(StringMapReplaceTranslator.class);
/*    */   
/*    */   private static final String PARAM_MAPPING = "Mapping";
/*    */   
/*    */   private static final String PARAM_PRESERVE = "PreserveNotFound";
/*    */   private static final String PARAM_SPLIT = "Split";
/* 31 */   protected final Map<String, String> map_ = new HashMap<>();
/*    */   
/* 33 */   private String splitString_ = "::";
/*    */ 
/*    */   
/*    */   private boolean preserveNotFound_ = true;
/*    */ 
/*    */   
/*    */   public void setParameter(String argName, String argValue) {
/* 40 */     if ("PreserveNotFound".equalsIgnoreCase(argName)) {
/* 41 */       this.preserveNotFound_ = ConfigUtils.toBoolean(argValue, this.preserveNotFound_).booleanValue();
/*    */     }
/* 43 */     else if ("Split".equalsIgnoreCase(argName)) {
/* 44 */       if (StringUtils.isEmpty(argValue)) {
/* 45 */         logger_.warn("Split is empty");
/*    */       } else {
/*    */         
/* 48 */         this.splitString_ = argValue.trim();
/*    */       }
/*    */     
/* 51 */     } else if ("Mapping".equalsIgnoreCase(argName)) {
/* 52 */       String[] values = argValue.trim().split(this.splitString_, 2);
/* 53 */       this.map_.put(values[0].trim(), values[1].trim());
/*    */     } else {
/*    */       
/* 56 */       super.setParameter(argName, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/* 63 */     String key = (argCurrentValue == null) ? "" : argCurrentValue.trim();
/* 64 */     String value = "";
/*    */     
/* 66 */     if (this.map_.containsKey(key)) {
/* 67 */       value = this.map_.get(key);
/*    */     }
/* 69 */     else if (this.preserveNotFound_) {
/* 70 */       value = key;
/*    */     } 
/*    */     
/* 73 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final String getSplitString() {
/* 81 */     return this.splitString_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final boolean isPreserveNotFound() {
/* 89 */     return this.preserveNotFound_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\StringMapReplaceTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */