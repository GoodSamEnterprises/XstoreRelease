/*     */ package dtv.data2.dataloader.pluggable;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFileIteratorLocatorFactoryBean
/*     */   implements FactoryBean<Object>, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   private Object _dataFileIteratorFactoryProxy;
/*  33 */   private Class<IDataFileIteratorFactory> _dataFileIteratorFactoryInterface = IDataFileIteratorFactory.class;
/*     */   
/*     */   private BeanFactory _beanFactory;
/*     */   
/*     */   private Properties _serviceMappings;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  41 */     this._dataFileIteratorFactoryProxy = Proxy.newProxyInstance(this._dataFileIteratorFactoryInterface.getClassLoader(), new Class[] { this._dataFileIteratorFactoryInterface }, new DataFileIteratorFactoryHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject() {
/*  48 */     return this._dataFileIteratorFactoryProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getObjectType() {
/*  54 */     return this._dataFileIteratorFactoryInterface;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/*  60 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory argBeanFactory) throws BeansException {
/*  67 */     this._beanFactory = argBeanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceMappings(Properties argServiceMappings) {
/*  76 */     this._serviceMappings = argServiceMappings;
/*     */   }
/*     */ 
/*     */   
/*     */   private class DataFileIteratorFactoryHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private DataFileIteratorFactoryHandler() {}
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       try {
/*  87 */         String beanName = getBeanName(args);
/*     */         
/*  89 */         return DataFileIteratorLocatorFactoryBean.this._beanFactory.getBean(beanName, new Object[] { args[0] });
/*     */       }
/*  91 */       catch (BeansException ex) {
/*  92 */         throw ex;
/*     */       } 
/*     */     }
/*     */     
/*     */     private String getBeanName(Object[] args) {
/*  97 */       String beanName = "";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       if (args[0] instanceof DataFileMetaData) {
/* 103 */         DataFileMetaData<?> md = (DataFileMetaData)args[0];
/* 104 */         beanName = md.getType();
/*     */ 
/*     */         
/* 107 */         if (DataFileIteratorLocatorFactoryBean.this._serviceMappings != null) {
/* 108 */           String mappedName = DataFileIteratorLocatorFactoryBean.this._serviceMappings.getProperty(beanName);
/*     */           
/* 110 */           if (mappedName != null) {
/* 111 */             beanName = mappedName;
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 116 */         throw new IllegalArgumentException("argument 0 is not a DataFileMetaData");
/*     */       } 
/*     */       
/* 119 */       return beanName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\DataFileIteratorLocatorFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */