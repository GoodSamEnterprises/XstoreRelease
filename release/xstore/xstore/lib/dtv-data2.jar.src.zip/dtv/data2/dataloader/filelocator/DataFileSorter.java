/*    */ package dtv.data2.dataloader.filelocator;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataFileSorter
/*    */ {
/*    */   @Deprecated
/*    */   public static final String REPLACE_FILE_EXTENSION = ".rep";
/*    */   public static final String REORGANIZE_FILE_EXTENSION = ".reo";
/*    */   
/*    */   public static boolean isReorganizeFile(File argFile) {
/* 32 */     String lowerCaseFile = argFile.getName().toLowerCase();
/* 33 */     return (lowerCaseFile.endsWith(".reo") || lowerCaseFile
/* 34 */       .endsWith(".rep"));
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\filelocator\DataFileSorter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */