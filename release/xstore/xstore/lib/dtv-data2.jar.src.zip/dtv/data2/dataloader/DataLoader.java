/*     */ package dtv.data2.dataloader;
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IPersistenceMgr;
/*     */ import dtv.data2.access.IQueryKey;
/*     */ import dtv.data2.dataloader.filelocator.FileLocator;
/*     */ import dtv.data2.dataloader.filelocator.IDataFileLocator;
/*     */ import dtv.data2.dataloader.filelocator.ListFileLocator;
/*     */ import dtv.data2.dataloader.fileprocessing.FileProcessingStats;
/*     */ import dtv.data2.dataloader.fileprocessing.IHasSourceData;
/*     */ import dtv.data2.dataloader.pluggable.AtomicPersistables;
/*     */ import dtv.data2.dataloader.pluggable.DataFileException;
/*     */ import dtv.data2.dataloader.pluggable.DataFileMetaData;
/*     */ import dtv.data2.dataloader.pluggable.IDataFileIterator;
/*     */ import dtv.data2.dataloader.pluggable.IDataFileTypeDetector;
/*     */ import dtv.data2.dataloader.pluggable.IFileNameSortingStrategy;
/*     */ import dtv.data2.dataloader.pluggable.StubDataFileIterator;
/*     */ import dtv.util.EndsWithNameFilter;
/*     */ import dtv.util.config.SystemPropertiesLoader;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*     */ 
/*     */ public class DataLoader {
/*  36 */   private static final Logger _logger = LogManager.getLogger(DataLoader.class);
/*     */   
/*     */   private static final String SPRING_DEFAULT_ACTIVE_PROFILES = "dataloader";
/*     */   private static final String ARCHIVED_FAILURE_EXTENSION = ".failed";
/*  40 */   private static final IQueryKey<?> _healthQuery = (IQueryKey<?>)new QueryKey("CHECK_HEALTH", Object.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ConfigurableApplicationContext _springContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*  52 */       (new SystemPropertiesLoader()).loadSystemProperties();
/*     */ 
/*     */       
/*  55 */       String springProfiles = System.getProperty("spring.profiles.active");
/*     */       
/*  57 */       if (springProfiles == null) {
/*  58 */         System.setProperty("spring.profiles.active", "dataloader");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  64 */       String[] files = ClassPathUtils.getDirectoryBasedConfigFileListRelativePaths("spring", (INameFilter)new EndsWithNameFilter(new String[] { ".xml" }));
/*     */ 
/*     */       
/*  67 */       _springContext = (ConfigurableApplicationContext)new ClassPathXmlApplicationContext(files);
/*     */       
/*  69 */       DataLoaderConfigHelper.getDataLoaderConfig();
/*     */     }
/*  71 */     catch (Exception ee) {
/*  72 */       _logger.fatal("Dataloader encounted an exception while attempting to load system properties.", ee);
/*     */       
/*  74 */       DataLoaderEventLogger.fatal("Dataloader encounted an exception while attempting to load system properties.", ee);
/*  75 */       System.exit(1);
/*     */     } 
/*     */     
/*  78 */     if (!isDBAvailable()) {
/*  79 */       _logger.fatal("No database connection available.");
/*  80 */       System.exit(1);
/*     */     } 
/*     */     
/*     */     try {
/*  84 */       DataLoader dataLoader = (DataLoader)_springContext.getBean(DataLoader.class);
/*  85 */       dataLoader.run(null);
/*     */     }
/*  87 */     catch (DataLoaderException ex) {
/*  88 */       _logger.error(ex.getMessage(), ex);
/*     */     } 
/*     */     
/*  91 */     System.exit(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean isDBAvailable() {
/*     */     try {
/* 101 */       DataFactory.getObjectByQuery(_healthQuery, new HashMap<>());
/*     */     }
/* 103 */     catch (Exception ex) {
/* 104 */       _logger.warn("Error interrogating online status of local DB: " + ex);
/* 105 */       return false;
/*     */     } 
/* 107 */     return true;
/*     */   }
/*     */ 
/*     */   
/* 111 */   private Map<IFileNameSortingStrategy, List<DataFileMetaData<?>>> _sortingStrategyMap = null;
/*     */ 
/*     */   
/* 114 */   private int numOfSuccesses = 0;
/*     */ 
/*     */   
/* 117 */   private int numOfFailures = 0;
/*     */   
/*     */   private IDataFileLocator _dataFileLocator;
/*     */   
/*     */   private List<IDataFileTypeDetector> _detectors;
/*     */   
/*     */   @Inject
/*     */   private ConfigParameters _configParameters;
/*     */   
/*     */   @Inject
/*     */   private IFileArchiver _fileArchiver;
/*     */   
/*     */   @Inject
/*     */   private IDataFileIteratorFactory _dataFileLoaderFactory;
/*     */   
/*     */   @Inject
/*     */   private IResultsWriter _resultsWriter;
/*     */   
/* 135 */   private String _optionalRunId = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataLoader() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataLoader(List<IDataFileTypeDetector> argDetectors) {
/* 148 */     this._detectors = argDetectors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDataFileLocator getDataFileLocator() {
/* 157 */     if (this._dataFileLocator == null) {
/* 158 */       if (this._configParameters.getProcessListFiles()) {
/* 159 */         this._dataFileLocator = (IDataFileLocator)new ListFileLocator(this._configParameters.getDataFileLocation());
/*     */       } else {
/*     */         
/* 162 */         this._dataFileLocator = (IDataFileLocator)new FileLocator(this._configParameters.getDataFileLocation());
/*     */       } 
/*     */     }
/*     */     
/* 166 */     return this._dataFileLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashMap<IFileNameSortingStrategy, List<DataFileMetaData<?>>> getMetaDataSortingMap(List<File> argDataFiles) {
/* 178 */     HashMap<IFileNameSortingStrategy, List<DataFileMetaData<?>>> sortingStrategyMap = new HashMap<>();
/*     */     
/* 180 */     if (argDataFiles != null) {
/* 181 */       for (File dataFile : argDataFiles) {
/* 182 */         boolean foundDetectorForFile = false;
/* 183 */         boolean didSkip = false;
/* 184 */         for (IDataFileTypeDetector detector : this._detectors) {
/* 185 */           DataFileMetaData<?> metaData = detector.detect(dataFile);
/*     */ 
/*     */           
/* 188 */           if (metaData != null) {
/* 189 */             foundDetectorForFile = true;
/* 190 */             if (!metaData.getSkipThisFile()) {
/*     */               
/* 192 */               List<DataFileMetaData<?>> listOfMetaData = sortingStrategyMap.get(detector.getFileNameSortingStrategy());
/* 193 */               if (listOfMetaData == null) {
/* 194 */                 listOfMetaData = new ArrayList<>();
/* 195 */                 sortingStrategyMap.put(detector.getFileNameSortingStrategy(), listOfMetaData);
/*     */               } 
/* 197 */               listOfMetaData.add(metaData);
/*     */               continue;
/*     */             } 
/* 200 */             didSkip = true;
/*     */           } 
/*     */         } 
/*     */         
/* 204 */         if (!foundDetectorForFile || didSkip) {
/* 205 */           _logger.warn(didSkip ? "Skipping the file: " : ("No detectors recognized this file: " + dataFile
/* 206 */               .getName()));
/* 207 */           FileProcessingStats stats = new FileProcessingStats();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 212 */           if (!foundDetectorForFile) {
/* 213 */             stats.failureCounter++;
/*     */           }
/* 215 */           this._resultsWriter.setFileBeingProcessed(dataFile.getName());
/* 216 */           this._resultsWriter.writeResultsSummary(stats);
/*     */         } 
/*     */       } 
/*     */     }
/* 220 */     return sortingStrategyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadData(List<File> argFilesToLoad) {
/*     */     List<File> dataFiles;
/*     */     String operationDescription;
/* 231 */     long startTime = System.currentTimeMillis();
/* 232 */     this._resultsWriter.start(this._optionalRunId, new Date(startTime));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     if (argFilesToLoad != null) {
/* 238 */       operationDescription = "DataLoader (processing specific file(s))";
/* 239 */       dataFiles = argFilesToLoad;
/* 240 */       logDataLoadStartSpecificFile(operationDescription, argFilesToLoad);
/*     */     } else {
/*     */       
/* 243 */       operationDescription = "DataLoader (scanning for newly effective files)";
/* 244 */       String argDataFilePath = this._configParameters.getDataFileLocation();
/* 245 */       File dataFilePath = new File(argDataFilePath);
/*     */       
/* 247 */       if (!dataFilePath.isDirectory()) {
/* 248 */         logInvalidDataFilePath(operationDescription, argDataFilePath);
/* 249 */         throw new DataLoaderException("An invalid data file path is configured [" + dataFilePath
/* 250 */             .getAbsolutePath() + "].");
/*     */       } 
/*     */ 
/*     */       
/* 254 */       dataFiles = getDataFileLocator().getDataFiles();
/*     */       
/* 256 */       int numberOfFiles = (dataFiles != null) ? dataFiles.size() : 0;
/* 257 */       logDataLoadStartDetectFiles(operationDescription, argDataFilePath, numberOfFiles);
/*     */     } 
/*     */ 
/*     */     
/* 261 */     this._sortingStrategyMap = getMetaDataSortingMap(dataFiles);
/*     */ 
/*     */     
/* 264 */     for (IFileNameSortingStrategy sortingStrategy : this._sortingStrategyMap.keySet()) {
/* 265 */       sortDataFiles(sortingStrategy, this._sortingStrategyMap.get(sortingStrategy));
/* 266 */       _logger.info("Sort files based on :" + sortingStrategy.getClass().getName());
/*     */       
/* 268 */       readDataFromFiles(this._sortingStrategyMap.get(sortingStrategy), operationDescription);
/*     */     } 
/*     */     
/* 271 */     logDataLoadEnd(operationDescription, startTime, this.numOfSuccesses, this.numOfFailures);
/* 272 */     this._resultsWriter.finish(this._optionalRunId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(List<File> argFilesToLoad) {
/* 281 */     run(argFilesToLoad, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(List<File> argFilesToLoad, String argOptionalRunID) {
/* 291 */     this._optionalRunId = argOptionalRunID;
/*     */     
/* 293 */     String trickleProp = System.getProperty("dtv.dataloader.trickle", "false");
/* 294 */     boolean trickleMode = Boolean.valueOf(trickleProp).booleanValue();
/*     */     
/* 296 */     if (trickleMode) {
/* 297 */       _logger.info("DataLoader is running in trickle mode.");
/*     */     }
/*     */     
/* 300 */     this._fileArchiver.cleanUpStatusFiles();
/*     */ 
/*     */     
/* 303 */     loadData(argFilesToLoad);
/*     */ 
/*     */ 
/*     */     
/* 307 */     if (this._fileArchiver.archiveStatusFiles()) {
/* 308 */       this._fileArchiver.archiveSummaryFile();
/*     */     }
/*     */     
/* 311 */     this._fileArchiver.cleanUpArchives();
/*     */     
/*     */     try {
/* 314 */       Thread.sleep(5000L);
/*     */     }
/* 316 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataFileLocator(IDataFileLocator argDataFileLocator) {
/* 327 */     this._dataFileLocator = argDataFileLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sortDataFiles(final IFileNameSortingStrategy argSortingStrategy, List<DataFileMetaData<?>> argMetaDataList) {
/* 339 */     Collections.sort(argMetaDataList, new Comparator<DataFileMetaData<?>>()
/*     */         {
/*     */           public int compare(DataFileMetaData<?> arg1, DataFileMetaData<?> arg2) {
/* 342 */             return argSortingStrategy.compare(arg1, arg2);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logDataFileResults(File argDataFile, int argSuccessCount, int argFailureCount, long startTime) {
/* 357 */     boolean success = (argFailureCount == 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     String successIndicator = " success_flag=" + success;
/*     */     
/* 364 */     long fileEndTime = System.currentTimeMillis();
/*     */     
/* 366 */     String msg = "Dataloader processed data file" + argDataFile + " in " + ((fileEndTime - startTime) / 1000L) + " seconds with " + (argSuccessCount + argFailureCount) + " persistables. Successful persistables: " + argSuccessCount + ". Failed persistables: " + argFailureCount + "." + successIndicator;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     Level l = success ? Level.INFO : Level.ERROR;
/* 372 */     DataLoaderEventLogger.log(l, msg);
/* 373 */     logInfo(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logDataFileStart(File dataFile) {
/* 382 */     DataLoaderEventLogger.setCurrentHeader(null, null);
/* 383 */     DataLoaderEventLogger.info("DataLoader processing data file: " + dataFile);
/* 384 */     logInfo("DataLoader processing data file: " + dataFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logDataLoadEnd(String argOperationDescription, long startTime, int argSuccessCount, int argFailureCount) {
/* 397 */     DataLoaderEventLogger.setCurrentHeader(null, null);
/* 398 */     long endTime = System.currentTimeMillis();
/*     */     
/* 400 */     String msg = argOperationDescription + " finished running in " + ((endTime - startTime) / 1000L) + " seconds. Processed " + (argSuccessCount + argFailureCount) + " total persistables. Successful persistables: " + argSuccessCount + ". Failed persistables: " + argFailureCount + ".";
/*     */ 
/*     */ 
/*     */     
/* 404 */     DataLoaderEventLogger.info(msg);
/*     */     
/* 406 */     boolean success = (argSuccessCount > 0 && argFailureCount == 0);
/* 407 */     logSuccess(msg, success);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logDataLoadStartDetectFiles(String argOperationDescription, String argDataFilePath, int argNumDataFiles) {
/* 420 */     String message = argOperationDescription + " started. Data file path: " + argDataFilePath + ". Number of datafiles to be processed: " + String.valueOf(argNumDataFiles);
/*     */     
/* 422 */     logInfo(message);
/* 423 */     DataLoaderEventLogger.info(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logDataLoadStartSpecificFile(String argOperationDescription, List<File> argFilesToLoad) {
/* 433 */     StringBuilder messageBuilder = new StringBuilder(argOperationDescription);
/* 434 */     messageBuilder.append(" started. " + argFilesToLoad.size() + " file(s) were specified for processing: ");
/*     */     
/* 436 */     for (File file : argFilesToLoad) {
/* 437 */       messageBuilder.append(file.getAbsolutePath());
/* 438 */       messageBuilder.append("; ");
/*     */     } 
/*     */     
/* 441 */     String message = messageBuilder.toString();
/* 442 */     logInfo(message);
/* 443 */     DataLoaderEventLogger.info(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logInfo(String argMsg) {
/* 452 */     if (_logger.isInfoEnabled()) {
/* 453 */       _logger.info(argMsg);
/*     */     } else {
/*     */       
/* 456 */       System.out.println(argMsg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logInvalidDataFilePath(String argDescription, String argDataFilePath) {
/* 467 */     String message = argDescription + " run. Data file path [" + argDataFilePath + "] must be a directory. No files will be processed.";
/*     */ 
/*     */     
/* 470 */     DataLoaderEventLogger.error(message);
/* 471 */     _logger.error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logSuccess(String argMsg, boolean argSuccess) {
/* 481 */     if (argSuccess) {
/* 482 */       this._resultsWriter.writeSuccess(argMsg);
/*     */     }
/*     */     
/* 485 */     logInfo(argMsg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readDataFromFiles(List<DataFileMetaData<?>> metaDataList, String operationDescription) {
/* 496 */     this.numOfSuccesses = 0;
/* 497 */     this.numOfFailures = 0;
/*     */     
/* 499 */     for (DataFileMetaData<?> metaData : metaDataList) {
/* 500 */       IDataFileIterator iDataFileIterator; long startTime = System.currentTimeMillis();
/* 501 */       File dataFile = metaData.getFile();
/*     */       
/* 503 */       this._resultsWriter.setFileBeingProcessed(dataFile.getName());
/* 504 */       logDataFileStart(dataFile);
/*     */       
/* 506 */       FileProcessingStats fileStats = new FileProcessingStats();
/*     */       
/* 508 */       StubDataFileIterator stubDataFileIterator = new StubDataFileIterator();
/*     */       try {
/* 510 */         iDataFileIterator = this._dataFileLoaderFactory.createDataFileIterator(metaData);
/*     */       }
/* 512 */       catch (BeansException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 518 */         fileStats.failureCounter++;
/* 519 */         _logger.error("SEVERE: Spring failed to initialize datafile iterator", (Throwable)e);
/*     */       } 
/*     */       
/* 522 */       fileStats = process(iDataFileIterator, fileStats);
/*     */       
/* 524 */       this.numOfSuccesses += fileStats.successCounter;
/* 525 */       this.numOfFailures += fileStats.failureCounter;
/*     */       
/*     */       try {
/* 528 */         iDataFileIterator.close();
/*     */       }
/* 530 */       catch (Throwable t) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 535 */         _logger.error("SEVERE: IDataFileIterator did not .close() cleanly after processing " + dataFile
/* 536 */             .getAbsolutePath(), t);
/* 537 */         fileStats.failureCounter++;
/*     */       } 
/*     */       
/* 540 */       this._resultsWriter.writeResultsSummary(fileStats);
/* 541 */       logDataFileResults(dataFile, fileStats.successCounter, fileStats.failureCounter, startTime);
/*     */       
/* 543 */       if (fileStats.failureCounter == 0) {
/* 544 */         this._fileArchiver.archiveDataFile(dataFile, null);
/*     */         continue;
/*     */       } 
/* 547 */       String archiveName = dataFile.getName().concat(".failed");
/* 548 */       this._fileArchiver.archiveDataFile(dataFile, archiveName);
/*     */     } 
/*     */ 
/*     */     
/* 552 */     if (metaDataList.size() > 0) {
/* 553 */       getDataFileLocator().cleanup();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private FileProcessingStats process(IDataFileIterator argDataFileIterator, FileProcessingStats stats) {
/* 559 */     Batch currentBatch = new Batch(this._configParameters.getRecordsPerTransaction());
/*     */     
/*     */     try {
/* 562 */       while (argDataFileIterator.hasNext()) {
/*     */         try {
/* 564 */           AtomicPersistables persistables = argDataFileIterator.next();
/*     */           
/* 566 */           currentBatch.addAtomicPersistables(persistables);
/*     */           
/* 568 */           if (currentBatch.isFull()) {
/* 569 */             PersistenceResult persistenceResult = savePersistablesToDatabase(currentBatch);
/* 570 */             stats.addPersistenceResult(persistenceResult);
/*     */ 
/*     */             
/* 573 */             currentBatch = new Batch(this._configParameters.getRecordsPerTransaction());
/*     */           }
/*     */         
/* 576 */         } catch (DataFileException ex) {
/* 577 */           stats.failureCounter++;
/*     */ 
/*     */           
/* 580 */           _logger.error(ex.getMessage());
/* 581 */           this._resultsWriter.writeFailure(ex.getMessage(), (IHasSourceData)ex);
/*     */ 
/*     */           
/* 584 */           stats.addProcessingException(ex);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 589 */       if (!currentBatch.isEmpty()) {
/* 590 */         PersistenceResult persistenceResult = savePersistablesToDatabase(currentBatch);
/* 591 */         stats.addPersistenceResult(persistenceResult);
/*     */       }
/*     */     
/* 594 */     } catch (Throwable t) {
/* 595 */       DataFileException unexpected = new DataFileException(t.toString(), t);
/*     */ 
/*     */       
/* 598 */       _logger.error(t);
/* 599 */       this._resultsWriter.writeFailure(unexpected.getMessage(), (IHasSourceData)unexpected);
/* 600 */       stats.addProcessingException(unexpected);
/*     */     } 
/*     */     
/* 603 */     return stats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PersistenceResult savePersistablesToDatabase(Batch argBatch) {
/* 611 */     PersistenceResult result = new PersistenceResult();
/* 612 */     IPersistenceMgr pmNoReplication = DataFactory.getInstance().getPersistenceMgr();
/* 613 */     pmNoReplication.setReplicationEnabled(false);
/*     */ 
/*     */     
/*     */     try {
/* 617 */       List<IPersistable> allPersistables = argBatch.getAllPersistables();
/*     */       
/* 619 */       DataFactory.makePersistent(allPersistables, pmNoReplication);
/*     */       
/* 621 */       result.successfulAtomicPersists = argBatch.getAtomicPersistablesList().size();
/* 622 */       _logger.debug("Successfully persisted a batch of daos with size: " + result.successfulAtomicPersists);
/*     */     }
/* 624 */     catch (Exception ex) {
/* 625 */       String msg = "An exception occurred while persisting a batch of daos. Attempting one atomic group of daos at a time...";
/*     */       
/* 627 */       _logger.warn(msg, ex);
/* 628 */       DataLoaderEventLogger.warn(msg, ex);
/*     */ 
/*     */       
/* 631 */       for (AtomicPersistables atomicPersistables : argBatch.getAtomicPersistablesList()) {
/*     */         
/*     */         try {
/* 634 */           DataFactory.makePersistent(atomicPersistables.getPersistables(), pmNoReplication);
/* 635 */           result.successfulAtomicPersists++;
/*     */         }
/* 637 */         catch (Exception ex2) {
/*     */           
/* 639 */           result.addPersistenceExceptionCount(ex2);
/*     */           
/* 641 */           if (_logger.isDebugEnabled()) {
/* 642 */             _logger.debug("An exception occurred while persisting: " + atomicPersistables, ex2);
/*     */           }
/*     */           
/* 645 */           this._resultsWriter.writeFailure(ex2.getMessage(), (IHasSourceData)atomicPersistables);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 650 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PersistenceResult
/*     */   {
/* 660 */     public int successfulAtomicPersists = 0;
/*     */ 
/*     */     
/* 663 */     public Map<Class<?>, Integer> exceptionCounts = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addPersistenceExceptionCount(Exception argException) {
/* 672 */       Class<?> causeClass = argException.getClass();
/*     */ 
/*     */       
/* 675 */       Integer exceptionCount = Integer.valueOf(this.exceptionCounts.containsKey(causeClass) ? (((Integer)this.exceptionCounts.get(causeClass)).intValue() + 1) : 1);
/* 676 */       this.exceptionCounts.put(causeClass, exceptionCount);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class Batch
/*     */   {
/*     */     private int _maxSize;
/*     */     
/* 685 */     private List<IPersistable> _allPersistables = new ArrayList<>();
/* 686 */     private List<AtomicPersistables> _atomicPersistablesList = new ArrayList<>();
/*     */     
/*     */     public Batch(int argMaxSize) {
/* 689 */       this._maxSize = argMaxSize;
/*     */     }
/*     */     
/*     */     public void addAtomicPersistables(AtomicPersistables argAtomicPersistables) {
/* 693 */       this._atomicPersistablesList.add(argAtomicPersistables);
/* 694 */       this._allPersistables.addAll(argAtomicPersistables.getPersistables());
/*     */     }
/*     */     
/*     */     public List<IPersistable> getAllPersistables() {
/* 698 */       return this._allPersistables;
/*     */     }
/*     */     
/*     */     public List<AtomicPersistables> getAtomicPersistablesList() {
/* 702 */       return this._atomicPersistablesList;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 706 */       return this._atomicPersistablesList.isEmpty();
/*     */     }
/*     */     
/*     */     public boolean isFull() {
/* 710 */       return (this._atomicPersistablesList.size() >= this._maxSize);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\DataLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */