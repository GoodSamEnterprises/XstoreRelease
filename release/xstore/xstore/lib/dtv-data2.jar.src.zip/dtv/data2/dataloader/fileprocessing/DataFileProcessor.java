/*     */ package dtv.data2.dataloader.fileprocessing;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.dataloader.DataLoaderEventLogger;
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfig;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfigHelper;
/*     */ import dtv.data2.dataloader.filelocator.DataFileSorter;
/*     */ import dtv.data2.dataloader.pluggable.DataFileException;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DataFileProcessor
/*     */ {
/*  33 */   private static final Logger logger_ = Logger.getLogger(DataFileProcessor.class);
/*     */   
/*  35 */   private static final String ENCODING = DataLoaderConfigHelper.getDataLoaderConfig().getCharacterEncoding();
/*     */   
/*     */   private static final String INVALID_INSTRUCTION_EXTENSION = "INVALID.INSTRUCTION";
/*  38 */   private final DataFileHeaderProcessor headerProcessor_ = new DataFileHeaderProcessor();
/*     */   
/*  40 */   private File currentFile_ = null;
/*     */   private char currentDelimiter_;
/*  42 */   private BufferedReader reader_ = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean delimiterDetectionAttempted_ = false;
/*     */ 
/*     */   
/*     */   private List<SplitFile> _splitFiles;
/*     */ 
/*     */   
/*     */   private SortedFileLineIterator _fileLineIterator;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistanceDefaults;
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/*  61 */     if (this._splitFiles != null) {
/*  62 */       cleanUpFiles((List)this._splitFiles);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUpDataFile(File argFile) {
/*  71 */     boolean success = cleanUpFiles(Arrays.asList(new File[] { argFile }));
/*  72 */     if (success) {
/*  73 */       logger_.info("Data file: " + argFile + " was successfully deleted.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cleanUpFiles(List<? extends File> argSplitFiles) {
/*  84 */     releaseCurrentFile();
/*  85 */     boolean successOk = false;
/*     */     
/*  87 */     for (File splitFile : argSplitFiles) {
/*     */       
/*     */       try {
/*  90 */         if (splitFile.exists()) {
/*  91 */           boolean success = splitFile.delete();
/*  92 */           if (success) {
/*  93 */             successOk = true;
/*     */             continue;
/*     */           } 
/*  96 */           logger_.warn("Failed to remove file: " + splitFile.getAbsolutePath() + " reason unknown.  Forcing GC and trying again");
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 101 */           System.gc();
/* 102 */           success = splitFile.delete();
/* 103 */           if (success) {
/* 104 */             successOk = true;
/*     */             continue;
/*     */           } 
/* 107 */           logger_.warn("Really failed to delete.  Waiting 2 seconds");
/* 108 */           Thread.currentThread().wait(2000L);
/* 109 */           success = splitFile.delete();
/* 110 */           logger_.warn("Last delete attempt result was " + success);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 115 */       catch (Exception ee) {
/* 116 */         if (logger_.isDebugEnabled()) {
/* 117 */           logger_.warn("Failed to remove file: " + splitFile.getAbsolutePath(), ee);
/*     */         } else {
/*     */           
/* 120 */           logger_.warn("Failed to remove file: " + splitFile.getAbsolutePath() + " " + ee);
/*     */         } 
/* 122 */         successOk = false;
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     return successOk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileLine getNextFileLine(SplitFile argSplitFile) {
/*     */     try {
/* 137 */       if (this.currentFile_ != argSplitFile) {
/* 138 */         this.currentFile_ = argSplitFile;
/* 139 */         if (this.reader_ != null) {
/* 140 */           this.reader_.close();
/*     */         }
/* 142 */         this.reader_ = new BufferedReader(new InputStreamReader(new FileInputStream(this.currentFile_), ENCODING));
/*     */       } 
/*     */       
/* 145 */       String line = this.reader_.readLine();
/*     */       
/* 147 */       if (line == null) {
/* 148 */         if (this.reader_ != null) {
/* 149 */           this.reader_.close();
/*     */         }
/* 151 */         return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 157 */       boolean instructionIsValid = !argSplitFile.getIsErrorFile();
/* 158 */       FileLine fileLine = new FileLine(line, this.currentDelimiter_, instructionIsValid);
/*     */       
/* 160 */       return fileLine;
/*     */     }
/* 162 */     catch (Exception ee) {
/* 163 */       logger_.error("An exception occurred while processing split file: " + argSplitFile, ee);
/* 164 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedFileLineIterator getSortedFileLineIterator(File argDataFile) {
/* 175 */     this._splitFiles = splitFile(argDataFile);
/* 176 */     this._fileLineIterator = new SortedFileLineIterator(this._splitFiles);
/*     */     
/* 178 */     return this._fileLineIterator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseCurrentFile() {
/* 185 */     if (this.reader_ != null) {
/*     */       try {
/*     */         try {
/* 188 */           this.reader_.close();
/*     */         } finally {
/*     */           
/* 191 */           this.reader_.close();
/*     */         }
/*     */       
/* 194 */       } catch (IOException e) {
/* 195 */         logger_.warn("Failed to close reader.", e);
/*     */       } 
/* 197 */       this.reader_ = null;
/*     */     } 
/*     */     
/* 200 */     if (this.currentFile_ != null) {
/* 201 */       this.currentFile_ = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<SplitFile> splitFile(File argDataFile) {
/* 213 */     this.currentDelimiter_ = Character.MIN_VALUE;
/* 214 */     this.delimiterDetectionAttempted_ = false;
/*     */     
/* 216 */     HeaderLine headerLine = null;
/* 217 */     Map<String, SplitFile> splitFiles = new HashMap<>();
/*     */     
/* 219 */     File dataFile = argDataFile;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(dataFile), ENCODING))) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       DataLoaderEventLogger.setCurrentHeader(this._persistanceDefaults, null);
/*     */       String line;
/* 231 */       while (reader.ready() && (line = reader.readLine()) != null) {
/*     */ 
/*     */ 
/*     */         
/* 235 */         if (StringUtils.isEmpty(line) || line.trim().startsWith("#")) {
/*     */           continue;
/*     */         }
/*     */         
/* 239 */         if (this.headerProcessor_.isHeaderLine(line)) {
/* 240 */           if (headerLine != null) {
/* 241 */             throw new DataLoaderException("More than one header was encountered in file [" + dataFile
/* 242 */                 .getAbsolutePath() + "]");
/*     */           }
/* 244 */           headerLine = this.headerProcessor_.processHeader(line);
/*     */           
/* 246 */           if (headerLine != null) {
/* 247 */             DataLoaderEventLogger.setCurrentHeader(this._persistanceDefaults, headerLine);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 252 */         if (!autoDetectDelimiter(line)) {
/* 253 */           logNoDelimiter(line);
/* 254 */           SplitFile invalidInstructionFile = splitFiles.get("INVALID.INSTRUCTION");
/*     */           
/* 256 */           if (invalidInstructionFile == null) {
/* 257 */             invalidInstructionFile = new SplitFile(argDataFile, "INVALID", "INSTRUCTION", ENCODING, true);
/* 258 */             splitFiles.put("INVALID.INSTRUCTION", invalidInstructionFile);
/*     */           } 
/*     */           
/* 261 */           invalidInstructionFile.writeLine(line);
/*     */           
/*     */           continue;
/*     */         } 
/*     */         try {
/* 266 */           ParsingUtils.Instruction instruction = ParsingUtils.getInstance().parseInstruction(line);
/*     */           
/* 268 */           String key = (new StringBuilder(32)).append(instruction.recordType).append(".").append(instruction.action).toString();
/*     */           
/* 270 */           SplitFile splitFile = splitFiles.get(key);
/*     */           
/* 272 */           if (splitFile == null) {
/* 273 */             splitFile = new SplitFile(argDataFile, instruction.recordType, instruction.action, ENCODING, false);
/*     */             
/* 275 */             splitFiles.put(key, splitFile);
/*     */           } 
/*     */           
/* 278 */           splitFile.writeLine(line);
/*     */         }
/* 280 */         catch (Exception ex) {
/* 281 */           SplitFile invalidInstructionFile = splitFiles.get("INVALID.INSTRUCTION");
/*     */           
/* 283 */           if (invalidInstructionFile == null) {
/* 284 */             invalidInstructionFile = new SplitFile(argDataFile, "INVALID", "INSTRUCTION", ENCODING, true);
/* 285 */             splitFiles.put("INVALID.INSTRUCTION", invalidInstructionFile);
/*     */           } 
/*     */           
/* 288 */           invalidInstructionFile.writeLine(line);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 295 */       if (DataFileSorter.isReorganizeFile(argDataFile)) {
/* 296 */         handleReorganizationDataFile(splitFiles, argDataFile);
/*     */       }
/*     */       
/* 299 */       return finishSplitFiles(splitFiles, headerLine);
/*     */     }
/* 301 */     catch (Exception ee) {
/* 302 */       closeSplitFilesWriter(splitFiles);
/* 303 */       handleSplitFileException(ee, argDataFile);
/*     */ 
/*     */       
/* 306 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean autoDetectDelimiter(String argFileLine) {
/* 315 */     boolean success = this.delimiterDetectionAttempted_;
/*     */     
/* 317 */     if (!this.delimiterDetectionAttempted_) {
/*     */       try {
/* 319 */         this.currentDelimiter_ = ParsingUtils.getInstance().determineDelimiterChar(argFileLine);
/*     */         
/* 321 */         logger_.info("Delimiter determined to be: " + this.currentDelimiter_ + " int value: " + this.currentDelimiter_);
/*     */         
/* 323 */         success = true;
/*     */       }
/* 325 */       catch (Exception ee) {
/* 326 */         logger_.warn("Exception occurred while trying to determine delimiter", ee);
/*     */         
/* 328 */         StringBuilder buf = new StringBuilder(128);
/* 329 */         buf.append("Dumping character values of line. ");
/*     */         
/* 331 */         for (int ii = 0; ii < argFileLine.length(); ii++) {
/* 332 */           buf.append("[").append(argFileLine.charAt(ii)).append(" int: ").append(argFileLine.charAt(ii))
/* 333 */             .append("] ");
/*     */         }
/* 335 */         logger_.warn(buf.toString());
/*     */         
/* 337 */         success = false;
/*     */       } 
/*     */       
/* 340 */       this.delimiterDetectionAttempted_ = true;
/*     */     } 
/*     */     
/* 343 */     return success;
/*     */   }
/*     */   
/*     */   private void closeSplitFilesWriter(Map<String, SplitFile> argSplitFiles) {
/* 347 */     Collection<SplitFile> filesCollection = argSplitFiles.values();
/* 348 */     List<SplitFile> files = new ArrayList<>(filesCollection);
/* 349 */     for (SplitFile file : files) {
/*     */       try {
/* 351 */         file.closeFileWriter();
/*     */       }
/* 353 */       catch (IOException ex) {
/* 354 */         logger_.warn("Error closing the split file writer.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<SplitFile> finishSplitFiles(Map<String, SplitFile> argSplitFiles, HeaderLine argHeaderLine) throws IOException {
/* 371 */     Collection<SplitFile> filesCollection = argSplitFiles.values();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     List<SplitFile> files = new ArrayList<>(filesCollection);
/* 380 */     Collections.sort(files, new SplitFileComparator());
/*     */     
/* 382 */     int totalLines = 0;
/*     */     
/* 384 */     for (SplitFile file : files) {
/* 385 */       file.finishedWriting();
/* 386 */       totalLines += file.getLineCount();
/*     */     } 
/*     */     
/* 389 */     if (argHeaderLine != null && argHeaderLine.getDeclaredLineCount() != null)
/*     */     {
/* 391 */       if (argHeaderLine.getDeclaredLineCount().intValue() != totalLines) {
/*     */         
/* 393 */         String msg = "Total file line count [" + totalLines + "] does not equal expected line count [" + argHeaderLine.getDeclaredLineCount() + "] as specified in header.";
/*     */         
/* 395 */         DataLoaderEventLogger.warn(msg);
/* 396 */         logger_.warn(msg);
/*     */       } 
/*     */     }
/*     */     
/* 400 */     return files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleReorganizationDataFile(Map<String, SplitFile> argSplitFiles, File argSourceDataFile) {
/* 414 */     if (this.currentDelimiter_ == '\000') {
/* 415 */       logger_.error("Delimiter must be set to process reorganization and replacement files.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 420 */     Set<String> recordTypeSet = new HashSet<>();
/*     */ 
/*     */     
/* 423 */     for (SplitFile splitFile : argSplitFiles.values()) {
/* 424 */       recordTypeSet.add(splitFile.getRecordType());
/*     */     }
/*     */ 
/*     */     
/* 428 */     for (String recordType : recordTypeSet) {
/*     */       
/* 430 */       String key = recordType + "." + "DELETE_BY_ORGANIZATION";
/*     */       
/* 432 */       if (argSplitFiles.get(key) == null) {
/* 433 */         SplitFile newSplitFile = new SplitFile(argSourceDataFile, recordType, "DELETE_BY_ORGANIZATION", ENCODING, false);
/*     */ 
/*     */         
/*     */         try {
/* 437 */           newSplitFile.writeLine(makeReorgOrReplaceCommandLine("DELETE_BY_ORGANIZATION", recordType));
/*     */         }
/* 439 */         catch (Exception e) {
/* 440 */           logger_.error("Exception occurred while trying to write operation:DELETE_BY_ORGANIZATION to split file.", e);
/*     */         } 
/*     */         
/* 443 */         argSplitFiles.put(key, newSplitFile);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleSplitFileException(Exception argException, File argDataFile) throws DataFileException {
/* 451 */     String msg = "An exception occurred while spliting datafile: [" + argDataFile + "]";
/* 452 */     logger_.error(msg, argException);
/* 453 */     DataLoaderEventLogger.error(msg, argException);
/* 454 */     throw new DataFileException(msg + argException.getMessage());
/*     */   }
/*     */   
/*     */   private void logNoDelimiter(String argCurrentLine) {
/* 458 */     String msg = "Bad line is being skipped because the delimiter could not be determined for the current file.";
/*     */ 
/*     */     
/* 461 */     logger_.warn("Bad line is being skipped because the delimiter could not be determined for the current file.\n" + argCurrentLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String makeReorgOrReplaceCommandLine(String argAction, String argRecordType) {
/* 473 */     StringBuilder command = (new StringBuilder(argAction)).append(this.currentDelimiter_).append(argRecordType);
/*     */ 
/*     */     
/* 476 */     if (argAction.equals("DELETE_BY_ORGANIZATION")) {
/* 477 */       command.append(this.currentDelimiter_)
/* 478 */         .append(System.getProperty("dtv.location.organizationId").toString());
/*     */     }
/* 480 */     return command.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class SortedFileLineIterator
/*     */     implements Iterator<FileLine>
/*     */   {
/*     */     private DataFileProcessor.SplitFileLineIterator _lineIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Iterator<SplitFile> _fileListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SortedFileLineIterator(List<SplitFile> argFiles) {
/* 503 */       this._fileListIterator = argFiles.iterator();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 509 */       if (this._lineIterator != null && this._lineIterator.hasNext()) {
/* 510 */         return true;
/*     */       }
/*     */       
/* 513 */       if (this._fileListIterator.hasNext()) {
/* 514 */         this._lineIterator = new DataFileProcessor.SplitFileLineIterator(this._fileListIterator.next());
/*     */         
/* 516 */         return this._lineIterator.hasNext();
/*     */       } 
/*     */       
/* 519 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public FileLine next() {
/* 525 */       if (this._lineIterator != null && this._lineIterator.hasNext()) {
/* 526 */         return this._lineIterator.next();
/*     */       }
/*     */       
/* 529 */       if (this._fileListIterator.hasNext()) {
/* 530 */         this._lineIterator = new DataFileProcessor.SplitFileLineIterator(this._fileListIterator.next());
/*     */         
/* 532 */         if (this._lineIterator.hasNext()) {
/* 533 */           return this._lineIterator.next();
/*     */         }
/*     */       } 
/*     */       
/* 537 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void remove() {
/* 543 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class SplitFileComparator
/*     */     implements Comparator<SplitFile>
/*     */   {
/*     */     public int compare(SplitFile arg1, SplitFile arg2) {
/* 556 */       int sort1 = 0;
/* 557 */       int sort2 = 0;
/*     */       
/* 559 */       if (!DataLoaderConfig.isRunSql(arg1.getActionType()) && !DataLoaderConfig.isRunSql(arg2.getActionType())) {
/* 560 */         sort1 = DataLoaderConfigHelper.getDataLoaderConfig().getRecordTypeSortOrder(arg1.getRecordType());
/* 561 */         sort2 = DataLoaderConfigHelper.getDataLoaderConfig().getRecordTypeSortOrder(arg2.getRecordType());
/*     */       } 
/*     */       
/* 564 */       if (sort1 != sort2) {
/* 565 */         return (sort1 < sort2) ? -1 : 1;
/*     */       }
/*     */       
/* 568 */       sort1 = DataLoaderConfigHelper.getDataLoaderConfig().getActionTypeSortOrder(arg1.getActionType());
/* 569 */       sort2 = DataLoaderConfigHelper.getDataLoaderConfig().getActionTypeSortOrder(arg2.getActionType());
/*     */       
/* 571 */       return (sort1 == sort2) ? 0 : ((sort1 < sort2) ? -1 : 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SplitFileLineIterator
/*     */     implements Iterator<FileLine>
/*     */   {
/* 578 */     private FileLine _nextLine = null;
/*     */     private final SplitFile _file;
/*     */     private boolean _needToGetNext = true;
/*     */     
/*     */     public SplitFileLineIterator(SplitFile argSplitFile) {
/* 583 */       this._file = argSplitFile;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 589 */       if (this._needToGetNext) {
/* 590 */         this._nextLine = DataFileProcessor.this.getNextFileLine(this._file);
/* 591 */         this._needToGetNext = false;
/*     */       } 
/*     */       
/* 594 */       return (this._nextLine != null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public FileLine next() {
/* 600 */       if (this._needToGetNext) {
/* 601 */         this._nextLine = DataFileProcessor.this.getNextFileLine(this._file);
/*     */       }
/* 603 */       this._needToGetNext = true;
/*     */       
/* 605 */       return this._nextLine;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 611 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\DataFileProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */