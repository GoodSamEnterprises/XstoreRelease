/*    */ package dtv.data2.dataloader.valuetranslator;
/*    */ 
/*    */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*    */ import dtv.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxLengthTranslator
/*    */   extends AbstractValueTranslator
/*    */ {
/*    */   private static final String PARAM_MAX_LENGTH = "length";
/* 20 */   private int _maxLength = Integer.MAX_VALUE;
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParameter(String argName, String argValue) {
/* 25 */     if ("length".equalsIgnoreCase(argName)) {
/* 26 */       this._maxLength = Integer.valueOf(argValue).intValue();
/*    */     } else {
/*    */       
/* 29 */       super.setParameter(argName, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/* 36 */     String translatedValue = argCurrentValue;
/*    */     
/* 38 */     if (this._maxLength > 0) {
/* 39 */       translatedValue = StringUtils.left(translatedValue, this._maxLength);
/*    */     }
/* 41 */     return translatedValue;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\MaxLengthTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */