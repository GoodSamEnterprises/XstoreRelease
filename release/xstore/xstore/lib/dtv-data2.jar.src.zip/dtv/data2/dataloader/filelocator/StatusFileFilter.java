/*    */ package dtv.data2.dataloader.filelocator;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusFileFilter
/*    */   implements FileFilter
/*    */ {
/*    */   public boolean accept(File argPathname) {
/* 24 */     boolean accepted = false;
/*    */     
/* 26 */     if (argPathname.isDirectory()) {
/* 27 */       accepted = false;
/*    */     }
/* 29 */     else if (argPathname.getName().startsWith("success.dat") || argPathname
/* 30 */       .getName().startsWith("failures.dat")) {
/* 31 */       accepted = true;
/*    */     } 
/*    */     
/* 34 */     return accepted;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\filelocator\StatusFileFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */