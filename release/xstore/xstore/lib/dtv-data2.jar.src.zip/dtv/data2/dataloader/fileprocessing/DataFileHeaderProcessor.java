/*     */ package dtv.data2.dataloader.fileprocessing;
/*     */ 
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfigHelper;
/*     */ import dtv.util.DateUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.xml.DomUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFileHeaderProcessor
/*     */ {
/*     */   public static final String HEADER_VERSION_1 = "@HEADER";
/*     */   public static final String HEADER_VERSION_2 = "<Header";
/*     */   private static final String LINE_COUNT_FIELD = "LINE_COUNT=";
/*     */   
/*     */   public HeaderLine extractHeaderLine(File argFile) {
/*  57 */     HeaderLine headerLine = null;
/*     */     
/*  59 */     String encoding = DataLoaderConfigHelper.getDataLoaderConfig().getCharacterEncoding();
/*  60 */     try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(argFile), encoding))) {
/*     */       String line;
/*     */ 
/*     */ 
/*     */       
/*  65 */       while (reader.ready() && (line = reader.readLine()) != null) {
/*  66 */         if (StringUtils.isEmpty(line) || line.trim().startsWith("#")) {
/*     */           continue;
/*     */         }
/*     */         
/*  70 */         if (isHeaderLine(line)) {
/*  71 */           headerLine = processHeader(line);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*  76 */     } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */     
/*  80 */     return headerLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHeaderLine(String argFileLine) {
/*  90 */     return (isHeaderVersion1(argFileLine) || isHeaderVersion2(argFileLine));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHeaderVersion1(String argFileLine) {
/* 100 */     return argFileLine.startsWith("@HEADER");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHeaderVersion2(String argFileLine) {
/* 110 */     return argFileLine.startsWith("<Header");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeaderLine processHeader(String argFileLine) {
/* 120 */     if (isHeaderVersion1(argFileLine)) {
/* 121 */       return processHeaderVersion1(argFileLine);
/*     */     }
/* 123 */     if (isHeaderVersion2(argFileLine)) {
/* 124 */       return processHeaderVersion2(argFileLine);
/*     */     }
/*     */     
/* 127 */     throw new DataLoaderException("file line does not appear to be a header. [" + argFileLine + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean getAttributeBooleanValue(Element argElement, String argAttributeName) throws Exception {
/* 133 */     String attribute = DomUtils.getAttributeValue(argElement, argAttributeName);
/*     */     
/* 135 */     if (!attribute.isEmpty()) {
/* 136 */       return Boolean.valueOf(Boolean.parseBoolean(attribute));
/*     */     }
/*     */     
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer getAttributeIntValue(Element argElement, String argAttributeName) throws Exception {
/* 145 */     String attribute = DomUtils.getAttributeValue(argElement, argAttributeName);
/*     */     
/* 147 */     if (!attribute.isEmpty()) {
/* 148 */       return Integer.valueOf(attribute);
/*     */     }
/*     */     
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getAttributeValue(Element argElement, String argAttributeName) {
/* 156 */     String attribute = DomUtils.getAttributeValue(argElement, argAttributeName);
/* 157 */     if (!attribute.isEmpty()) {
/* 158 */       return attribute;
/*     */     }
/*     */     
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HeaderLine processHeaderVersion1(String argFileLine) {
/*     */     try {
/* 168 */       if (argFileLine.indexOf("LINE_COUNT=") == -1) {
/* 169 */         throw new DataLoaderException("No Line Count specified in header.");
/*     */       }
/*     */       
/* 172 */       int LINE_COUNT_START = argFileLine.indexOf("LINE_COUNT=") + "LINE_COUNT=".length();
/*     */       
/* 174 */       StringBuilder lineCountString = new StringBuilder(4);
/*     */       
/* 176 */       int index = LINE_COUNT_START;
/*     */       
/* 178 */       while (index < argFileLine.length()) {
/* 179 */         char currentChar = argFileLine.charAt(index);
/* 180 */         if (Character.isDigit(currentChar)) {
/* 181 */           lineCountString.append(currentChar);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 186 */           index++;
/*     */         } 
/*     */       } 
/* 189 */       if (lineCountString.length() == 0) {
/* 190 */         throw new DataLoaderException("No Line Count specified in header.");
/*     */       }
/*     */       
/* 193 */       int lineCount = Integer.parseInt(lineCountString.toString());
/* 194 */       HeaderLine headerLine = new HeaderLine();
/* 195 */       headerLine.setDeclaredLineCount(Integer.valueOf(lineCount));
/* 196 */       return headerLine;
/*     */ 
/*     */     
/*     */     }
/* 200 */     catch (Exception ex) {
/* 201 */       String msg = "Current datafile header specifies invalid header. Header: [" + argFileLine + "]";
/* 202 */       throw new DataLoaderException(msg, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private HeaderLine processHeaderVersion2(String argFileLine) {
/*     */     try {
/* 208 */       Document doc = DomUtils.parseXml(argFileLine, new DomUtils.ParseOption[0]);
/* 209 */       Element headerElement = doc.getDocumentElement();
/*     */       
/* 211 */       HeaderLine headerLine = new HeaderLine();
/* 212 */       headerLine.setDeclaredLineCount(getAttributeIntValue(headerElement, "line_count"));
/* 213 */       headerLine.setDownloadId(getAttributeValue(headerElement, "download_id"));
/* 214 */       headerLine.setApplicationDate(DateUtils.parseDate(getAttributeValue(headerElement, "application_date")));
/* 215 */       headerLine.setTargetOrgNode(getAttributeValue(headerElement, "target_org_node"));
/* 216 */       headerLine.setDeploymentName(getAttributeValue(headerElement, "deployment_name"));
/* 217 */       headerLine.setDownloadTime(getAttributeValue(headerElement, "download_time"));
/* 218 */       headerLine.setApplyImmediately(getAttributeBooleanValue(headerElement, "apply_immediately"));
/* 219 */       return headerLine;
/*     */     }
/* 221 */     catch (Exception ex) {
/* 222 */       String msg = "Current datafile header specifies invalid header. Header: [" + argFileLine + "]";
/* 223 */       throw new DataLoaderException(msg, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\DataFileHeaderProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */