/*    */ package dtv.data2.dataloader.valuetranslator;
/*    */ 
/*    */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*    */ import dtv.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultValueTranslator
/*    */   extends AbstractValueTranslator
/*    */ {
/*    */   private static final String PARAM_DEFAULT_VALUE = "default";
/* 20 */   private String _defaultValue = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParameter(String argName, String argValue) {
/* 25 */     if ("default".equalsIgnoreCase(argName)) {
/* 26 */       this._defaultValue = argValue;
/*    */     } else {
/*    */       
/* 29 */       super.setParameter(argName, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/* 36 */     return StringUtils.isEmpty(argCurrentValue) ? 
/* 37 */       getValueForArgument(argCurrentValue, this._defaultValue, argCurrentLine) : argCurrentValue;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\DefaultValueTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */