package dtv.data2.dataloader.pluggable;

public interface IDataFileIteratorFactory {
  IDataFileIterator createDataFileIterator(DataFileMetaData<?> paramDataFileMetaData);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\IDataFileIteratorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */