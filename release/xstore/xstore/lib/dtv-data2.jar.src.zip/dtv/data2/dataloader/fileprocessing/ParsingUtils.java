/*     */ package dtv.data2.dataloader.fileprocessing;
/*     */ 
/*     */ import dtv.data2.dataloader.config.DataLoaderConfig;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfigHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParsingUtils
/*     */ {
/*  21 */   private static final ParsingUtils INSTANCE = new ParsingUtils();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParsingUtils getInstance() {
/*  29 */     return INSTANCE;
/*     */   }
/*     */   
/*  32 */   private final List<String> _actionTypesByLength = new ArrayList<>(DataLoaderConfig._actionTypes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParsingUtils() {
/*  41 */     Collections.sort(this._actionTypesByLength, new Comparator<String>()
/*     */         {
/*     */           public int compare(String argObj1, String argObj2)
/*     */           {
/*  45 */             return argObj2.length() - argObj1.length();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String determineDelimiter(String argFileLine) throws IllegalArgumentException {
/*  60 */     char delimiterChar = determineDelimiterChar(argFileLine);
/*  61 */     return Character.toString(delimiterChar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char determineDelimiterChar(String argFileLine) throws IllegalArgumentException {
/*  72 */     for (String actionType : this._actionTypesByLength) {
/*  73 */       if (argFileLine.startsWith(actionType)) {
/*  74 */         return argFileLine.charAt(actionType.length());
/*     */       }
/*     */     } 
/*     */     
/*  78 */     throw new IllegalArgumentException("Couldn't determine delimiter");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction parseInstruction(String argLine) throws IllegalArgumentException {
/*  90 */     char delimiterChar = determineDelimiterChar(argLine);
/*  91 */     String delimiter = Character.toString(delimiterChar);
/*  92 */     StringTokenizer tokens = new StringTokenizer(argLine, delimiter, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     String action = tokens.nextToken();
/*     */ 
/*     */     
/* 100 */     String recordType = DataLoaderConfig.isRunSql(action) ? action : tokens.nextToken();
/*     */     
/* 102 */     if (!DataLoaderConfigHelper.getDataLoaderConfig().isValidActionType(action)) {
/* 103 */       String msg = "Unknown action: [" + action + "]";
/* 104 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 107 */     if (!DataLoaderConfigHelper.getDataLoaderConfig().isValidRecordType(recordType)) {
/* 108 */       String msg = "Unknown record type: [" + recordType + "]";
/* 109 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 112 */     return new Instruction(action, recordType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Instruction
/*     */   {
/*     */     public final String action;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String recordType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Instruction(String argAction, String argRecordType) {
/* 138 */       this.action = argAction;
/* 139 */       this.recordType = argRecordType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\ParsingUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */