/*     */ package dtv.data2.dataloader;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.dataloader.pluggable.DeploymentInfo;
/*     */ import dtv.util.StringUtils;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.ThreadContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataLoaderEventLogger
/*     */ {
/*     */   private static final String BASE_CATEGORY = "dtv.xstore.dataloader";
/*  23 */   private static final Logger LOG = LogManager.getLogger("dtv.xstore.dataloader");
/*  24 */   private static ThreadLocal<Logger> currentEventLogger_ = new ThreadLocal<Logger>()
/*     */     {
/*     */       protected Logger initialValue() {
/*  27 */         return DataLoaderEventLogger.LOG;
/*     */       }
/*     */     };
/*  30 */   private static ThreadLocal<IPersistenceDefaults> _persistenceDefaults = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void error(CharSequence o) {
/*  39 */     log(Level.ERROR, o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void error(CharSequence o, Throwable t) {
/*  49 */     log(Level.ERROR, o, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fatal(CharSequence o) {
/*  58 */     log(Level.FATAL, o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fatal(CharSequence o, Throwable t) {
/*  68 */     log(Level.FATAL, o, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void info(CharSequence msg) {
/*  77 */     log(Level.INFO, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(Level argLevel, CharSequence argMsg) {
/*  87 */     log(argLevel, argMsg, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(Level argLevel, CharSequence argMsg, Throwable t) {
/*  98 */     Logger logger = getLogger();
/*  99 */     if (logger.isEnabled(argLevel)) {
/* 100 */       IPersistenceDefaults pd = _persistenceDefaults.get();
/* 101 */       if (pd != null) {
/* 102 */         ThreadContext.put("OrganizationId", String.valueOf(pd.getOrganizationId()));
/* 103 */         ThreadContext.put("RetailLocationId", String.valueOf(pd.getRetailLocationId()));
/* 104 */         ThreadContext.put("WorkstationId", String.valueOf(pd.getWorkstationId()));
/*     */       } 
/* 106 */       logger.log(argLevel, argMsg, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCurrentHeader(IPersistenceDefaults argPersistenceDefaults, DeploymentInfo argHeader) {
/* 117 */     _persistenceDefaults.set(argPersistenceDefaults);
/* 118 */     if (argHeader == null || StringUtils.isEmpty(argHeader.getDownloadId())) {
/* 119 */       currentEventLogger_.set(LOG);
/*     */     } else {
/*     */       
/* 122 */       currentEventLogger_
/* 123 */         .set(LogManager.getLogger("dtv.xstore.dataloader.download_id=" + argHeader.getDownloadId()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void warn(String msg) {
/* 133 */     log(Level.WARN, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void warn(String msg, Throwable t) {
/* 143 */     log(Level.WARN, msg, t);
/*     */   }
/*     */   
/*     */   private static Logger getLogger() {
/* 147 */     return currentEventLogger_.get();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\DataLoaderEventLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */