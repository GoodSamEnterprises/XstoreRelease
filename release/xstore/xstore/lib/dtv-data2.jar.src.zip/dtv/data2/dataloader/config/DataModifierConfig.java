/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataModifierConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 23 */   private final List<DataModifierParameterConfig> parameters_ = new ArrayList<>();
/* 24 */   private String className_ = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 32 */     return this.className_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<DataModifierParameterConfig> getParameters() {
/* 41 */     return this.parameters_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 47 */     if ("className".equalsIgnoreCase(argKey)) {
/* 48 */       this.className_ = argValue.toString();
/*    */     }
/* 50 */     else if ("Param".equalsIgnoreCase(argKey)) {
/* 51 */       this.parameters_.add((DataModifierParameterConfig)argValue);
/*    */     } else {
/*    */       
/* 54 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\DataModifierConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */