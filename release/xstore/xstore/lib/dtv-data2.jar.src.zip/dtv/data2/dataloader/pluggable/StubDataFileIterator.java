/*    */ package dtv.data2.dataloader.pluggable;
/*    */ 
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StubDataFileIterator
/*    */   implements IDataFileIterator
/*    */ {
/*    */   public void close() {}
/*    */   
/*    */   public DataFileMetaData<?> getMetaData() {
/* 24 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 30 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicPersistables next() throws DataFileException {
/* 37 */     throw new NoSuchElementException();
/*    */   }
/*    */   
/*    */   public void remove() {}
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\StubDataFileIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */