/*    */ package dtv.data2.dataloader.pluggable;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataFileMetaData<T>
/*    */ {
/*    */   private final File _file;
/*    */   private final String _type;
/*    */   private final boolean _fullReload;
/*    */   private final boolean _skipThisFile;
/*    */   private final T _cfgObject;
/*    */   private final DeploymentInfo _deploymentInfo;
/*    */   
/*    */   public DataFileMetaData(File argFile, String argType, boolean argFullReload, boolean argSkipThisFile, T argConfigObject, DeploymentInfo argDeploymentInfo) {
/* 37 */     this._file = argFile;
/* 38 */     this._type = argType;
/* 39 */     this._fullReload = argFullReload;
/* 40 */     this._skipThisFile = argSkipThisFile;
/* 41 */     this._cfgObject = argConfigObject;
/* 42 */     this._deploymentInfo = argDeploymentInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T getConfigObject() {
/* 51 */     return this._cfgObject;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DeploymentInfo getDeploymentInfo() {
/* 60 */     return this._deploymentInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public File getFile() {
/* 69 */     return this._file;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getIsFullReload() {
/* 78 */     return this._fullReload;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getSkipThisFile() {
/* 89 */     return this._skipThisFile;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getType() {
/* 98 */     return this._type;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\DataFileMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */