/*    */ package dtv.data2.dataloader.pluggable.xst;
/*    */ 
/*    */ import dtv.data2.dataloader.fileprocessing.HeaderLine;
/*    */ import dtv.data2.dataloader.fileprocessing.ParsingUtils;
/*    */ import dtv.data2.dataloader.pluggable.DataFileMetaData;
/*    */ import dtv.data2.dataloader.pluggable.DeploymentInfo;
/*    */ import dtv.data2.dataloader.pluggable.IDataFileTypeDetector;
/*    */ import dtv.data2.dataloader.pluggable.IFileNameSortingStrategy;
/*    */ import java.io.File;
/*    */ import javax.annotation.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XstoreFileTypeDetector
/*    */   implements IDataFileTypeDetector
/*    */ {
/*    */   @Resource(name = "xstoreFileNameSortingStrategy")
/*    */   private IFileNameSortingStrategy _fileNameSortingStrategy;
/*    */   
/*    */   public DataFileMetaData<XstoreFileConfiguration> detect(File argDataFile) {
/* 28 */     ProspectiveXstoreFile prospectiveFile = new ProspectiveXstoreFile(argDataFile);
/* 29 */     XstoreFileType detectedType = detectXstoreFileType(prospectiveFile);
/*    */ 
/*    */     
/* 32 */     if (detectedType == null) {
/* 33 */       return null;
/*    */     }
/*    */     
/* 36 */     boolean preTruncate = shouldTruncateBeforeLoading(argDataFile);
/*    */     
/* 38 */     HeaderLine headerLine = prospectiveFile.getHeaderLine();
/* 39 */     boolean shouldSkip = (headerLine != null) ? headerLine.isFutureApplicationDate() : false;
/*    */ 
/*    */     
/* 42 */     DataFileMetaData<XstoreFileConfiguration> metaData = new DataFileMetaData(argDataFile, detectedType.name(), preTruncate, shouldSkip, headerLine, (DeploymentInfo)headerLine);
/*    */     
/* 44 */     return metaData;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IFileNameSortingStrategy getFileNameSortingStrategy() {
/* 52 */     return this._fileNameSortingStrategy;
/*    */   }
/*    */   
/*    */   private XstoreFileType detectXstoreFileType(ProspectiveXstoreFile argFile) {
/* 56 */     String name = argFile.getName().toLowerCase();
/*    */     
/* 58 */     boolean isXadminFile = (name.startsWith("xadmin") && name.endsWith(".dat"));
/*    */ 
/*    */     
/* 61 */     if (name.endsWith(".rep") || name.endsWith(".reo") || isXadminFile) {
/* 62 */       return XstoreFileType.XSTORE_MNT;
/*    */     }
/*    */ 
/*    */     
/*    */     try {
/* 67 */       ParsingUtils.getInstance().parseInstruction(argFile.getFirstNonCommentLine());
/* 68 */       return XstoreFileType.XSTORE_MNT;
/*    */     }
/* 70 */     catch (Exception ex) {
/* 71 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean shouldTruncateBeforeLoading(File argDataFile) {
/* 76 */     String fileName = argDataFile.getName().toLowerCase();
/* 77 */     if (fileName.endsWith(".rep") || fileName.endsWith(".reo")) {
/* 78 */       return true;
/*    */     }
/*    */     
/* 81 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private enum XstoreFileType
/*    */   {
/* 90 */     XSTORE_MNT;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\xst\XstoreFileTypeDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */