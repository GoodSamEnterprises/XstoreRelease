/*     */ package dtv.data2.dataloader.filelocator;
/*     */ 
/*     */ import dtv.data2.dataloader.DataLoaderEventLogger;
/*     */ import dtv.util.FileUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListFileLocator
/*     */   extends AbstractDataFileLocator
/*     */ {
/*  28 */   private static final Logger logger_ = Logger.getLogger(ListFileLocator.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String LIST_FILE_EXTENTION = "*.lst";
/*     */ 
/*     */   
/*     */   private List<File> lstFiles_;
/*     */ 
/*     */ 
/*     */   
/*     */   public ListFileLocator(String argDataFilePath) {
/*  40 */     super(argDataFilePath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean anyListFilesPresent() {
/*  49 */     File dataFile = getConfiguredDataFile();
/*  50 */     List<File> files = getListFiles(dataFile);
/*  51 */     return !files.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/*  57 */     if (this.lstFiles_ == null || this.lstFiles_.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*  61 */     for (File listFile : this.lstFiles_) {
/*     */       try {
/*  63 */         boolean success = listFile.delete();
/*  64 */         if (success) {
/*  65 */           logger_.info("Deleted list file: " + listFile.getAbsolutePath());
/*     */           continue;
/*     */         } 
/*  68 */         logger_.warn("Failed to delete list file: " + listFile.getAbsolutePath() + " - reason UNKNOWN.");
/*     */         
/*  70 */         DataLoaderEventLogger.warn("Failed to delete list file: " + listFile.getAbsolutePath() + " - reason UNKNOWN.");
/*     */ 
/*     */       
/*     */       }
/*  74 */       catch (Exception ee) {
/*  75 */         logger_.warn("Failed to delete list file: " + listFile.getAbsolutePath() + " - due to exception.", ee);
/*     */ 
/*     */         
/*  78 */         DataLoaderEventLogger.warn("Failed to delete list file: " + listFile.getAbsolutePath() + " - due to exception.", ee);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<File> getDataFiles() {
/*  90 */     File dataFile = getConfiguredDataFile();
/*  91 */     if (dataFile == null || !dataFile.isDirectory()) {
/*  92 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/*  95 */     List<File> listFiles = getListFiles(dataFile);
/*  96 */     if (listFiles == null) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     return getDataFilesFromListFiles(listFiles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<File> getDataFilesFromListFiles(List<File> argLstFiles) {
/* 111 */     List<File> dataFiles = new ArrayList<>();
/*     */     
/* 113 */     for (File lstFile : argLstFiles) {
/*     */       try {
/* 115 */         String fileContents = FileUtils.loadFile(lstFile);
/*     */         
/* 117 */         if (StringUtils.isEmpty(fileContents)) {
/* 118 */           String msg = "List file: " + lstFile.getAbsolutePath() + " - was found to be empty and will not be processed";
/*     */           
/* 120 */           logger_.warn(msg);
/* 121 */           DataLoaderEventLogger.warn(msg);
/*     */           
/*     */           continue;
/*     */         } 
/* 125 */         String[] fileLines = fileContents.split("\n");
/*     */         
/* 127 */         if (fileLines == null || fileLines.length == 0) {
/* 128 */           String msg = "Unable to split : " + lstFile.getAbsolutePath() + " into LINES - this file will not be processed";
/*     */           
/* 130 */           logger_.warn(msg);
/* 131 */           DataLoaderEventLogger.warn(msg);
/*     */           
/*     */           continue;
/*     */         } 
/* 135 */         for (String lstFileLine : fileLines) {
/*     */           
/* 137 */           File dataFile = new File(getConfiguredDataFile().getAbsolutePath() + File.separatorChar + lstFileLine.trim());
/*     */           
/* 139 */           if (!dataFile.exists())
/*     */           {
/* 141 */             String msg = "Data file: " + dataFile + " does not exist and will be ignored. (from list file: " + lstFile.getAbsolutePath() + ")";
/* 142 */             logger_.warn(msg);
/* 143 */             DataLoaderEventLogger.warn(msg);
/*     */           
/*     */           }
/* 146 */           else if (dataFile.isDirectory())
/*     */           {
/*     */             
/* 149 */             String msg = "Supposed Data file: " + dataFile + " is actually a directory and will be ignored. (from list file: " + lstFile.getAbsolutePath();
/* 150 */             logger_.warn(msg);
/* 151 */             DataLoaderEventLogger.warn(msg);
/*     */           }
/*     */           else
/*     */           {
/* 155 */             dataFiles.add(dataFile);
/*     */           }
/*     */         
/*     */         } 
/* 159 */       } catch (Exception ee) {
/* 160 */         if (logger_.isDebugEnabled()) {
/* 161 */           logger_.warn("Could not load contents of list file: " + lstFile.getAbsolutePath() + " - this .lst file will not be processed.", ee);
/*     */         }
/*     */         else {
/*     */           
/* 165 */           logger_.warn("Could not load contents of list file: " + lstFile.getAbsolutePath() + " - this .lst file will not be processed." + ee);
/*     */         } 
/*     */ 
/*     */         
/* 169 */         DataLoaderEventLogger.warn("Could not load contents of list file: " + lstFile.getAbsolutePath() + " - this .lst file will not be processed." + ee);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 174 */     if (dataFiles.isEmpty()) {
/* 175 */       String msg = "No valid data files were found in list files: " + argLstFiles + " - the DataLoader will exit without loading any data.";
/*     */       
/* 177 */       logger_.warn(msg);
/* 178 */       DataLoaderEventLogger.warn(msg);
/* 179 */       return null;
/*     */     } 
/*     */     
/* 182 */     return dataFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<File> getListFiles(File argDataFileDir) {
/* 192 */     File[] files = argDataFileDir.listFiles(getFileFilter());
/* 193 */     List<File> lstFiles = Arrays.asList(files);
/*     */     
/* 195 */     this.lstFiles_ = lstFiles;
/* 196 */     return this.lstFiles_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FileFilter getFileFilter() {
/* 204 */     FileExtensionFilter filter = new FileExtensionFilter(new String[] { "*.lst" });
/* 205 */     return (FileFilter)filter;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\filelocator\ListFileLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */