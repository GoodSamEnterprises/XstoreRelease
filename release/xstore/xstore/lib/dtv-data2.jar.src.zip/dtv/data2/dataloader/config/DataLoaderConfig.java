/*     */ package dtv.data2.dataloader.config;
/*     */ 
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataLoaderConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*     */   public static final String PARAMETER_ORG_ID = "OrganizationId";
/*     */   public static final String PARAMETER_CHARACTER_ENCODING = "characterEncoding";
/*     */   public static final String ACTION_TRUNCATE = "TRUNCATE";
/*     */   public static final String ACTION_DELETE_BY_ORGANIZATION = "DELETE_BY_ORGANIZATION";
/*     */   public static final String ACTION_INSERT = "INSERT";
/*     */   public static final String ACTION_UPDATE = "UPDATE";
/*     */   public static final String ACTION_UPDATE_SELECT = "UPDATE_SELECT";
/*     */   public static final String ACTION_DELETE = "DELETE";
/*     */   public static final String ACTION_BEGIN_RUN_SQL = "BEGIN_RUN_SQL";
/*     */   public static final String ACTION_RUN_SQL = "RUN_SQL";
/*     */   public static final String ACTION_INSERT_ONLY = "INSERT_ONLY";
/*     */   public static final String SYS_PROP_FILE_LOCATION = "dtv.dataloader.DataFileLocation";
/*  66 */   public static final List<String> _actionTypes = Arrays.asList(new String[] { "TRUNCATE", "DELETE_BY_ORGANIZATION", "BEGIN_RUN_SQL", "DELETE", "INSERT", "UPDATE", "UPDATE_SELECT", "RUN_SQL", "INSERT_ONLY" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRunSql(String argActionType) {
/*  86 */     return ("RUN_SQL".equalsIgnoreCase(argActionType) || "BEGIN_RUN_SQL"
/*  87 */       .equalsIgnoreCase(argActionType));
/*     */   }
/*     */   
/*  90 */   private final List<RecordTypeConfig> _recordTypeList = new ArrayList<>(32);
/*  91 */   private final Map<String, RecordTypeConfig> _recordTypeMap = new HashMap<>(32);
/*  92 */   private final Map<String, String> _parameters = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActionTypeSortOrder(String argActionType) {
/* 101 */     if ("BEGIN_RUN_SQL".equalsIgnoreCase(argActionType)) {
/* 102 */       return Integer.MIN_VALUE;
/*     */     }
/* 104 */     if ("RUN_SQL".equalsIgnoreCase(argActionType)) {
/* 105 */       return Integer.MAX_VALUE;
/*     */     }
/* 107 */     return _actionTypes.indexOf(argActionType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharacterEncoding() {
/* 116 */     String value = this._parameters.get("characterEncoding");
/* 117 */     if (StringUtils.isEmpty(value)) {
/* 118 */       throw new DataLoaderException("Required parameter: characterEncoding was not found.  Check DataLoaderConfig.xml");
/*     */     }
/*     */     
/* 121 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getParameters() {
/* 130 */     return this._parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecordTypeConfig getRecordType(String argRecordType) {
/* 140 */     RecordTypeConfig recordType = this._recordTypeMap.get(argRecordType);
/*     */     
/* 142 */     if (recordType == null) {
/* 143 */       recordType = new RecordTypeConfig();
/* 144 */       recordType.setRecordTypeName(argRecordType);
/* 145 */       this._recordTypeMap.put(argRecordType, recordType);
/*     */     } 
/*     */     
/* 148 */     return recordType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<RecordTypeConfig> getRecordTypes() {
/* 157 */     return this._recordTypeList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRecordTypeSortOrder(String argRecordType) {
/* 167 */     RecordTypeConfig config = getRecordType(argRecordType);
/* 168 */     if (config != null) {
/* 169 */       return this._recordTypeList.indexOf(config);
/*     */     }
/*     */     
/* 172 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidActionType(String argActionType) {
/* 183 */     return _actionTypes.contains(argActionType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidRecordType(String argRecordType) {
/* 193 */     return (this._recordTypeMap.containsKey(argRecordType) || 
/* 194 */       isRunSql(argRecordType) || "XML_PERSISTABLES"
/* 195 */       .equals(argRecordType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 201 */     if ("RecordType".equalsIgnoreCase(argKey)) {
/* 202 */       this._recordTypeList.add((RecordTypeConfig)argValue);
/* 203 */       this._recordTypeMap.put(((RecordTypeConfig)argValue).getRecordTypeName(), (RecordTypeConfig)argValue);
/*     */     }
/* 205 */     else if ("Parameter".equalsIgnoreCase(argKey)) {
/* 206 */       this._parameters.put(((DataLoaderParameterConfig)argValue).getParameterName(), ((DataLoaderParameterConfig)argValue)
/* 207 */           .getParameterValue());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 221 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\DataLoaderConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */