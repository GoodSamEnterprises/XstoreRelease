/*     */ package dtv.data2.dataloader.fileprocessing;
/*     */ 
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SplitFile
/*     */   extends File
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String _encoding;
/*     */   private String recordType_;
/*     */   private String actionType_;
/*     */   private String sourceDataFileName;
/*     */   private BufferedWriter myWriter_;
/*  29 */   private int lineCount_ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isErrorFile_ = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SplitFile(File argDataFile, String argRecordType, String argAction, String argCharacterEncoding, boolean argIsErrorFile) {
/*  43 */     this((new StringBuilder(argDataFile.getAbsolutePath().length() + 32)).append(argDataFile.getAbsolutePath())
/*  44 */         .append('.').append(argRecordType).append('.').append(argAction).toString());
/*  45 */     setRecordType(argRecordType);
/*  46 */     setActionType(argAction);
/*  47 */     if (argDataFile != null) {
/*  48 */       setSourceDataFileName(argDataFile.getName());
/*     */     }
/*     */     
/*  51 */     this._encoding = argCharacterEncoding;
/*  52 */     this.isErrorFile_ = argIsErrorFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SplitFile(String argPathname) {
/*  61 */     super(argPathname);
/*     */     
/*     */     try {
/*  64 */       if (!exists()) {
/*  65 */         boolean success = createNewFile();
/*     */         
/*  67 */         if (!success) {
/*  68 */           throw new DataLoaderException("Could not create split file: " + this);
/*     */         }
/*     */       }
/*     */     
/*  72 */     } catch (Exception ee) {
/*  73 */       throw new DataLoaderException("An exception occurred while setting up split file: " + argPathname, ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeFileWriter() throws IOException {
/*  87 */     if (this.myWriter_ != null) {
/*     */       try {
/*  89 */         this.myWriter_.close();
/*     */       } finally {
/*     */         
/*  92 */         this.myWriter_ = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void finishedWriting() throws IOException {
/* 105 */     if (this.myWriter_ != null) {
/* 106 */       this.myWriter_.flush();
/* 107 */       this.myWriter_.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActionType() {
/* 117 */     return this.actionType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIsErrorFile() {
/* 126 */     return this.isErrorFile_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineCount() {
/* 135 */     return this.lineCount_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRecordType() {
/* 144 */     return this.recordType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceDataFileName() {
/* 153 */     return this.sourceDataFileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActionType(String argActionType) {
/* 162 */     this.actionType_ = argActionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecordType(String argRecordType) {
/* 171 */     this.recordType_ = argRecordType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceDataFileName(String argSourceDataFileName) {
/* 180 */     this.sourceDataFileName = argSourceDataFileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLine(String argLine) throws IOException {
/* 191 */     if (this.myWriter_ == null) {
/* 192 */       this.myWriter_ = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this), this._encoding));
/*     */     }
/* 194 */     this.myWriter_.write(argLine);
/* 195 */     this.myWriter_.write(10);
/*     */     
/* 197 */     this.lineCount_++;
/*     */     
/* 199 */     if (this.lineCount_ % 200 == 0)
/* 200 */       this.myWriter_.flush(); 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\SplitFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */