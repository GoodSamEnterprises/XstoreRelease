/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlStatementConfig
/*    */   extends PersistableConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String sqlString_;
/*    */   
/*    */   public String getSqlString() {
/* 27 */     return this.sqlString_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 33 */     if ("sql".equalsIgnoreCase(argKey)) {
/* 34 */       this.sqlString_ = argValue.toString();
/*    */     } else {
/*    */       
/* 37 */       super.setConfigObject(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\SqlStatementConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */