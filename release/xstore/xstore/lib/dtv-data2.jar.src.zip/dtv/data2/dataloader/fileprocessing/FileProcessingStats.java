/*    */ package dtv.data2.dataloader.fileprocessing;
/*    */ 
/*    */ import dtv.data2.dataloader.DataLoader;
/*    */ import dtv.data2.dataloader.pluggable.DataFileException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileProcessingStats
/*    */ {
/* 22 */   public int successCounter = 0;
/*    */ 
/*    */   
/* 25 */   public int failureCounter = 0;
/*    */ 
/*    */   
/* 28 */   public Map<Class<?>, Integer> exceptionCounts = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addPersistenceResult(DataLoader.PersistenceResult argPersistenceResult) {
/* 36 */     this.successCounter += argPersistenceResult.successfulAtomicPersists;
/*    */     
/* 38 */     for (Map.Entry<Class<?>, Integer> entry : (Iterable<Map.Entry<Class<?>, Integer>>)argPersistenceResult.exceptionCounts.entrySet()) {
/* 39 */       this.failureCounter += ((Integer)entry.getValue()).intValue();
/* 40 */       addExceptionCount(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addProcessingException(DataFileException argException) {
/* 51 */     Throwable cause = (argException.getCause() != null) ? argException.getCause() : (Throwable)argException;
/* 52 */     Class<?> causeClass = cause.getClass();
/*    */     
/* 54 */     addExceptionCount(causeClass, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   private void addExceptionCount(Class<?> argCauseClass, int argCount) {
/* 59 */     Integer exceptionCount = Integer.valueOf(this.exceptionCounts.containsKey(argCauseClass) ? (((Integer)this.exceptionCounts
/* 60 */         .get(argCauseClass)).intValue() + argCount) : argCount);
/*    */     
/* 62 */     this.exceptionCounts.put(argCauseClass, exceptionCount);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\FileProcessingStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */