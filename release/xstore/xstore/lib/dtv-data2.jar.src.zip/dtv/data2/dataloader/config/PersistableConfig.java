/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PersistableConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 21 */   private static final Collection<String> _ignoredFields = Arrays.asList(new String[] { "incrementalActive" });
/*    */   
/* 23 */   private final List<FieldConfig> fieldList_ = new ArrayList<>(20);
/*    */   
/*    */   private String actionApplicability_;
/* 26 */   private List<DataModifierConfig> applicabilityConditions_ = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getActionType() {
/* 34 */     return this.actionApplicability_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<DataModifierConfig> getApplicabilityConditions() {
/* 43 */     return this.applicabilityConditions_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<FieldConfig> getFields() {
/* 52 */     return this.fieldList_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 58 */     if ("Field".equalsIgnoreCase(argKey)) {
/* 59 */       this.fieldList_.add((FieldConfig)argValue);
/*    */     }
/* 61 */     else if ("action".equalsIgnoreCase(argKey)) {
/* 62 */       this.actionApplicability_ = argValue.toString();
/*    */     }
/* 64 */     else if ("ApplicabilityCondition".equalsIgnoreCase(argKey)) {
/* 65 */       if (this.applicabilityConditions_ == null) {
/* 66 */         this.applicabilityConditions_ = new ArrayList<>(2);
/*    */       }
/* 68 */       this.applicabilityConditions_.add((DataModifierConfig)argValue);
/*    */     }
/* 70 */     else if (!_ignoredFields.contains(argKey)) {
/* 71 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\PersistableConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */