/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.data2.dataloader.DataLoaderException;
/*    */ import dtv.data2.dataloader.fileprocessing.IFileLineParser;
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordTypeConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 23 */   private static final Collection<String> _ignoredFields = Arrays.asList(new String[] { "description" });
/*    */   
/*    */   private String recordTypeName_;
/*    */   private Class<IFileLineParser> fileLineParserClass_;
/* 27 */   private final List<PersistableConfig> persistableList_ = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<IFileLineParser> getFileLineParserClass() {
/* 35 */     return this.fileLineParserClass_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<PersistableConfig> getPersistables() {
/* 44 */     return this.persistableList_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRecordTypeName() {
/* 53 */     return this.recordTypeName_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 60 */     if ("name".equalsIgnoreCase(argKey)) {
/* 61 */       this.recordTypeName_ = argValue.toString();
/*    */     }
/* 63 */     else if ("fileLineParser".equalsIgnoreCase(argKey)) {
/*    */       try {
/* 65 */         this.fileLineParserClass_ = (Class)Class.forName(argValue.toString());
/*    */       }
/* 67 */       catch (Exception ex) {
/* 68 */         throw new DataLoaderException("An exception occurred while getting the fileLineParser class value: [" + argValue
/* 69 */             .toString() + "] source: [" + argValue.getSourceDescription() + "]", ex);
/*    */       }
/*    */     
/* 72 */     } else if (argValue instanceof PersistableConfig) {
/* 73 */       this.persistableList_.add((PersistableConfig)argValue);
/*    */     }
/* 75 */     else if (!_ignoredFields.contains(argKey)) {
/* 76 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRecordTypeName(String argRecordTypeName) {
/* 86 */     this.recordTypeName_ = argRecordTypeName;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\RecordTypeConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */