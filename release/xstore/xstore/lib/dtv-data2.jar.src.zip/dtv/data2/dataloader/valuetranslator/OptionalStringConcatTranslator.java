/*    */ package dtv.data2.dataloader.valuetranslator;
/*    */ 
/*    */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*    */ import dtv.util.StringUtils;
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionalStringConcatTranslator
/*    */   extends AbstractValueTranslator
/*    */   implements IValueTranslator
/*    */ {
/*    */   private static final String PARAM_SEPARATOR = "SEPARATOR";
/*    */   private static final String PARAM_ARG = "STRING.";
/*    */   private static final String PARAM_DEFAULT = "DEFAULT";
/* 43 */   private String separator_ = "";
/*    */ 
/*    */   
/* 46 */   private final Map<String, String> values_ = new TreeMap<>();
/*    */ 
/*    */   
/* 49 */   private String default_ = "";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParameter(String argName, String argValue) {
/* 62 */     if (argName.equalsIgnoreCase("SEPARATOR")) {
/* 63 */       this.separator_ = (argValue == null) ? "" : argValue;
/*    */     }
/* 65 */     else if (argName.equalsIgnoreCase("DEFAULT")) {
/* 66 */       this.default_ = (argValue == null) ? "" : argValue;
/*    */     }
/* 68 */     else if (argName.toUpperCase().startsWith("STRING.")) {
/* 69 */       this.values_.put(argName.trim().toUpperCase(), argValue);
/*    */     } else {
/*    */       
/* 72 */       super.setParameter(argName, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/* 79 */     StringBuilder output = new StringBuilder(this.values_.size() * (this.separator_.length() + 20));
/*    */     
/* 81 */     boolean appended = false;
/* 82 */     for (String mapValue : this.values_.values()) {
/* 83 */       String value = getValueForArgument(argCurrentValue, mapValue, argCurrentLine);
/* 84 */       if (!StringUtils.isEmpty(value)) {
/* 85 */         if (appended) {
/* 86 */           output.append(this.separator_);
/*    */         }
/* 88 */         output.append(value);
/* 89 */         appended = true;
/*    */       } 
/*    */     } 
/*    */     
/* 93 */     String returnValue = output.toString();
/* 94 */     if (StringUtils.isEmpty(returnValue)) {
/* 95 */       returnValue = this.default_;
/*    */     }
/* 97 */     return returnValue;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\OptionalStringConcatTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */