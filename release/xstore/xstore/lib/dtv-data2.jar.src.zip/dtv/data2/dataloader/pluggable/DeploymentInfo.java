/*     */ package dtv.data2.dataloader.pluggable;
/*     */ 
/*     */ import dtv.util.DateUtils;
/*     */ import java.util.Date;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeploymentInfo
/*     */ {
/*  19 */   private static final Logger logger_ = Logger.getLogger(DeploymentInfo.class);
/*     */   
/*     */   private String _downloadId;
/*     */   
/*     */   private Date _applicationDate;
/*     */   
/*     */   private String _targetOrgNode;
/*     */   
/*     */   private String _deploymentName;
/*     */   
/*     */   private String _downloadTime;
/*     */   
/*     */   private Boolean _applyImmediately;
/*     */   
/*     */   public Date getApplicationDate() {
/*  34 */     return this._applicationDate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getApplyImmediately() {
/*  43 */     return this._applyImmediately;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDeploymentName() {
/*  52 */     return this._deploymentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDownloadId() {
/*  61 */     return this._downloadId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDownloadTime() {
/*  70 */     return this._downloadTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTargetOrgNode() {
/*  79 */     return this._targetOrgNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFutureApplicationDate() {
/*  88 */     if (this._applicationDate == null) {
/*  89 */       logger_.debug("isFutureApplicationDate: application date is not set, returning false.");
/*  90 */       return false;
/*     */     } 
/*     */     
/*  93 */     Date now = new Date();
/*  94 */     return this._applicationDate.after(now);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationDate(Date argApplicationDate) {
/* 103 */     this._applicationDate = argApplicationDate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplyImmediately(Boolean argApplyImmediately) {
/* 112 */     this._applyImmediately = argApplyImmediately;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeploymentName(String argDeploymentName) {
/* 121 */     this._deploymentName = argDeploymentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDownloadId(String argDownloadId) {
/* 130 */     this._downloadId = argDownloadId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDownloadTime(String argDownloadPriority) {
/* 139 */     this._downloadTime = argDownloadPriority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetOrgNode(String argTarget) {
/* 148 */     this._targetOrgNode = argTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 154 */     String ss = "DeploymentInfo _downloadId=" + this._downloadId + " _applicationDate=";
/* 155 */     if (this._applicationDate != null) {
/* 156 */       ss = ss + DateUtils.format(this._applicationDate);
/*     */     } else {
/*     */       
/* 159 */       ss = ss + "null";
/*     */     } 
/* 161 */     if (this._deploymentName != null) {
/* 162 */       ss = ss + " _deploymentName=" + this._deploymentName;
/*     */     }
/* 164 */     return ss;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\DeploymentInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */