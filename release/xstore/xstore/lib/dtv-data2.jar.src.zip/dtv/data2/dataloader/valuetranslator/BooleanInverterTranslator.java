/*     */ package dtv.data2.dataloader.valuetranslator;
/*     */ 
/*     */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanInverterTranslator
/*     */   extends AbstractValueTranslator
/*     */   implements IValueTranslator
/*     */ {
/*  23 */   private static final String PARAM_NAME_FALSE = Boolean.FALSE.toString().trim().toUpperCase();
/*  24 */   private static final String PARAM_NAME_NULL = String.valueOf((Object)null).trim().toUpperCase();
/*  25 */   private static final String PARAM_NAME_TRUE = Boolean.TRUE.toString().trim().toUpperCase();
/*     */   
/*  27 */   private static final String TRUE = String.valueOf(1).trim().toUpperCase();
/*  28 */   private static final String FALSE = String.valueOf(0).trim().toUpperCase();
/*     */   
/*     */   private boolean isNullTrue_ = false;
/*  31 */   private final Collection<String> truthValues_ = new HashSet<>();
/*  32 */   private final Collection<String> falseValues_ = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanInverterTranslator() {
/*  38 */     this.truthValues_.add(TRUE);
/*  39 */     this.truthValues_.add("Y");
/*  40 */     this.falseValues_.add(FALSE);
/*  41 */     this.falseValues_.add("N");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String argName, String argValue) {
/*  65 */     String value = null;
/*  66 */     if (argValue != null) {
/*  67 */       value = argValue.trim().toUpperCase();
/*     */     }
/*  69 */     if (PARAM_NAME_FALSE.equalsIgnoreCase(argName)) {
/*  70 */       this.falseValues_.add(value);
/*     */     }
/*  72 */     else if (PARAM_NAME_NULL.equalsIgnoreCase(argName)) {
/*  73 */       this.isNullTrue_ = ConfigUtils.toBoolean(value).booleanValue();
/*     */     }
/*  75 */     else if (PARAM_NAME_TRUE.equalsIgnoreCase(argName)) {
/*  76 */       this.truthValues_.add(value);
/*     */     } else {
/*     */       
/*  79 */       super.setParameter(argName, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/* 108 */     boolean newValue = false;
/* 109 */     String currentValue = null;
/*     */ 
/*     */     
/* 112 */     if (StringUtils.isEmpty(argCurrentValue)) {
/* 113 */       currentValue = this.isNullTrue_ ? TRUE : FALSE;
/*     */     } else {
/*     */       
/* 116 */       currentValue = argCurrentValue.trim().toUpperCase();
/*     */     } 
/*     */ 
/*     */     
/* 120 */     if (this.falseValues_.contains(currentValue)) {
/* 121 */       newValue = false;
/*     */     }
/*     */ 
/*     */     
/* 125 */     if (this.truthValues_.contains(currentValue)) {
/* 126 */       newValue = true;
/*     */     }
/*     */ 
/*     */     
/* 130 */     newValue = !newValue;
/*     */ 
/*     */     
/* 133 */     return newValue ? TRUE : FALSE;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\BooleanInverterTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */