/*     */ package dtv.data2.dataloader.pluggable;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataFileIterator<T>
/*     */   implements IDataFileIterator
/*     */ {
/*     */   private final DataFileMetaData<T> _metaData;
/*     */   private boolean _needToGetNext = true;
/*     */   private ResultContainer _nextResultContainer;
/*     */   
/*     */   public AbstractDataFileIterator(DataFileMetaData<T> argMetaData) {
/*  29 */     this._metaData = argMetaData;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFileMetaData<T> getMetaData() {
/*  35 */     return this._metaData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() throws DataFileException {
/*  43 */     if (this._needToGetNext) {
/*  44 */       this._nextResultContainer = getNextResultContainer();
/*  45 */       this._needToGetNext = false;
/*     */     } 
/*     */     
/*  48 */     return (this._nextResultContainer != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AtomicPersistables next() throws DataFileException {
/*  55 */     if (this._needToGetNext) {
/*  56 */       this._nextResultContainer = getNextResultContainer();
/*     */     }
/*     */     
/*  59 */     this._needToGetNext = true;
/*     */     
/*  61 */     if (this._nextResultContainer == null) {
/*  62 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*  65 */     if (this._nextResultContainer._dataFileException != null) {
/*  66 */       throw this._nextResultContainer._dataFileException;
/*     */     }
/*     */     
/*  69 */     return this._nextResultContainer._persistables;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void remove() {
/*  75 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResultContainer getNextResultContainer() {
/*     */     try {
/*  92 */       AtomicPersistables next = getNext();
/*  93 */       return (next != null) ? new ResultContainer(next) : null;
/*     */     }
/*  95 */     catch (DataFileException ex) {
/*  96 */       return new ResultContainer(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract AtomicPersistables getNext() throws DataFileException;
/*     */   
/*     */   private class ResultContainer { public final AtomicPersistables _persistables;
/*     */     
/*     */     ResultContainer(AtomicPersistables argSuccessData) {
/* 105 */       this._persistables = argSuccessData;
/* 106 */       this._dataFileException = null;
/*     */     }
/*     */     public final DataFileException _dataFileException;
/*     */     ResultContainer(DataFileException argDataFileException) {
/* 110 */       this._persistables = null;
/* 111 */       this._dataFileException = argDataFileException;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\pluggable\AbstractDataFileIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */