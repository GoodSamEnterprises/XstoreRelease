/*     */ package dtv.data2.dataloader.config;
/*     */ 
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*  23 */   private static final Collection<String> _ignoredFields = Arrays.asList(new String[] { "dataType", "required", "size" });
/*     */   
/*     */   public static final String VARIABLE_CURRENT_DATE = "$currentDate";
/*     */   
/*     */   public static final String VARIABLE_CURRENT_DATE_TIMESTAMP = "$currentDateTimestamp";
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   private String fieldName_;
/*     */   
/*     */   private String fieldDataType_;
/*     */   
/*     */   private FieldValueSource fieldValueSource_;
/*     */   private String valueSpecifier_;
/*     */   private String default_;
/*     */   private int filePosition_;
/*     */   private int fileIntervalStart_;
/*     */   private int fileIntervalEnd_;
/*  41 */   private List<DataModifierConfig> valueTranslators_ = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDaoFieldName() {
/*  56 */     return this.fieldName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldDataType() {
/*  65 */     return this.fieldDataType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldDefault() {
/*  74 */     return this.default_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldValueSource getFieldValueSource() {
/*  83 */     return this.fieldValueSource_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileIntervalEnd() {
/*  92 */     return this.fileIntervalEnd_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileIntervalStart() {
/* 101 */     return this.fileIntervalStart_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFilePosition() {
/* 110 */     return this.filePosition_ - 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueSpecifier() {
/* 119 */     return this.valueSpecifier_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataModifierConfig> getValueTranslators() {
/* 128 */     return this.valueTranslators_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 134 */     if ("name".equalsIgnoreCase(argKey)) {
/*     */       
/* 136 */       this.fieldName_ = StringUtils.ensureFirstUpperCase(argValue.toString());
/*     */     }
/* 138 */     else if ("dataType".equalsIgnoreCase(argKey)) {
/*     */       
/* 140 */       this.fieldDataType_ = argValue.toString();
/*     */     
/*     */     }
/* 143 */     else if ("default".equalsIgnoreCase(argKey)) {
/*     */       
/* 145 */       this.default_ = argValue.toString();
/*     */     }
/* 147 */     else if ("ValueTranslator".equalsIgnoreCase(argKey)) {
/* 148 */       if (this.valueTranslators_ == null) {
/* 149 */         this.valueTranslators_ = new ArrayList<>(2);
/*     */       }
/* 151 */       this.valueTranslators_.add((DataModifierConfig)argValue);
/*     */     }
/* 153 */     else if ("filePosition".equalsIgnoreCase(argKey)) {
/* 154 */       if (this.fieldValueSource_ != null) {
/* 155 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field can only define one of the following: filePosition, sysProp, literal, variable Config source: " + 
/*     */             
/* 157 */             getSourceDescription());
/*     */       }
/*     */       
/* 160 */       this.fieldValueSource_ = FieldValueSource.FILE_POSITION;
/* 161 */       this.valueSpecifier_ = argValue.toString();
/*     */       
/*     */       try {
/* 164 */         this.filePosition_ = Integer.parseInt(this.valueSpecifier_);
/*     */       }
/* 166 */       catch (Exception ee) {
/* 167 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field defines a file position that is not an integer. Config source: " + 
/*     */             
/* 169 */             getSourceDescription(), ee);
/*     */       }
/*     */     
/*     */     }
/* 173 */     else if ("fileInterval".equals(argKey)) {
/* 174 */       if (this.fieldValueSource_ != null) {
/* 175 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field can only define one of the following: filePosition, sysProp, literal, variable,configParam Config source: " + 
/*     */             
/* 177 */             getSourceDescription());
/*     */       }
/*     */       
/* 180 */       this.fieldValueSource_ = FieldValueSource.FILE_INTERVAL;
/* 181 */       this.valueSpecifier_ = argValue.toString();
/*     */       
/*     */       try {
/* 184 */         String[] split = StringUtils.split(this.valueSpecifier_, '-');
/* 185 */         this.fileIntervalStart_ = Integer.parseInt(split[0]);
/* 186 */         if (split.length == 1) {
/* 187 */           this.fileIntervalEnd_ = this.fileIntervalStart_;
/*     */         } else {
/*     */           
/* 190 */           this.fileIntervalEnd_ = Integer.parseInt(split[1]);
/*     */         }
/*     */       
/* 193 */       } catch (Exception ee) {
/* 194 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field defines a file position that is not an integer. Config source: " + 
/*     */             
/* 196 */             getSourceDescription(), ee);
/*     */       }
/*     */     
/*     */     }
/* 200 */     else if ("sysProp".equals(argKey)) {
/* 201 */       if (this.fieldValueSource_ != null) {
/* 202 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field can only define one of the following: filePosition, sysProp, literal, variable,configParam Config source: " + 
/*     */             
/* 204 */             getSourceDescription());
/*     */       }
/*     */       
/* 207 */       this.fieldValueSource_ = FieldValueSource.SYSTEM_PROPERTY;
/* 208 */       this.valueSpecifier_ = argValue.toString();
/*     */     }
/* 210 */     else if ("configParam".equals(argKey)) {
/* 211 */       if (this.fieldValueSource_ != null) {
/* 212 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field can only define one of the following: filePosition, sysProp, literal, variable,configParam Config source: " + 
/*     */             
/* 214 */             getSourceDescription());
/*     */       }
/*     */       
/* 217 */       this.fieldValueSource_ = FieldValueSource.CONFIG_PARAMETER;
/* 218 */       this.valueSpecifier_ = argValue.toString();
/*     */     }
/* 220 */     else if ("literal".equals(argKey)) {
/* 221 */       if (this.fieldValueSource_ != null) {
/* 222 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field can only define one of the following: filePosition, sysProp, literal, variable,configParam Config source: " + 
/*     */             
/* 224 */             getSourceDescription());
/*     */       }
/*     */       
/* 227 */       this.fieldValueSource_ = FieldValueSource.LITERAL;
/* 228 */       this.valueSpecifier_ = argValue.toString();
/*     */     }
/* 230 */     else if ("variable".equals(argKey)) {
/* 231 */       if (this.fieldValueSource_ != null) {
/* 232 */         throw new DataLoaderException("DataLoaderConfig is misconfigured - a field can only define one of the following: filePosition, sysProp, literal, variable,configParam Config source: " + 
/*     */             
/* 234 */             getSourceDescription());
/*     */       }
/*     */       
/* 237 */       this.fieldValueSource_ = FieldValueSource.VARIABLE;
/* 238 */       this.valueSpecifier_ = argValue.toString();
/*     */     }
/* 240 */     else if (!_ignoredFields.contains(argKey)) {
/* 241 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum FieldValueSource
/*     */   {
/* 251 */     FILE_POSITION,
/*     */     
/* 253 */     FILE_INTERVAL,
/*     */     
/* 255 */     LITERAL,
/*     */     
/* 257 */     SYSTEM_PROPERTY,
/*     */     
/* 259 */     VARIABLE,
/*     */     
/* 261 */     CONFIG_PARAMETER;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\FieldConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */