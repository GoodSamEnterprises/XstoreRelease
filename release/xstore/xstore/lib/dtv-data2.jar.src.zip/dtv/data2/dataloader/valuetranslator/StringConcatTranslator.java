/*    */ package dtv.data2.dataloader.valuetranslator;
/*    */ 
/*    */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringConcatTranslator
/*    */   extends AbstractValueTranslator
/*    */ {
/*    */   private static final String PREFIX_STRING = "string.";
/* 23 */   private final Map<String, String> parameters_ = new HashMap<>(4);
/*    */   
/* 25 */   private final List<String> valuesToConcat_ = new ArrayList<>(4);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParameter(String argName, String argValue) {
/* 36 */     if (argName.startsWith("string.")) {
/* 37 */       this.parameters_.put(argName, argValue);
/*    */     } else {
/*    */       
/* 40 */       super.setParameter(argName, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/* 55 */     parseParameters(argCurrentValue, argCurrentLine);
/*    */     
/* 57 */     StringBuilder buff = new StringBuilder(32);
/*    */     
/* 59 */     for (String val : this.valuesToConcat_) {
/* 60 */       if (val == null) {
/* 61 */         return null;
/*    */       }
/*    */       
/* 64 */       buff.append(val);
/*    */     } 
/*    */ 
/*    */     
/* 68 */     return buff.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void parseParameters(String argCurrentValue, FileLine argCurrentLine) {
/* 78 */     for (int ii = 1;; ii++) {
/* 79 */       String key = (new StringBuilder("string.".length() + 2)).append("string.").append(ii).toString();
/* 80 */       String value = this.parameters_.get(key);
/*    */       
/* 82 */       if (value == null) {
/*    */         break;
/*    */       }
/*    */       
/* 86 */       this.valuesToConcat_.add(getValueForArgument(argCurrentValue, value, argCurrentLine));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\StringConcatTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */