/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DaoConfig
/*    */   extends PersistableConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 22 */   private static final Collection<String> _ignoredFields = Arrays.asList(new String[] { "suppress" });
/*    */ 
/*    */ 
/*    */   
/*    */   private String daoName_;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDaoName() {
/* 32 */     return this.daoName_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 38 */     if ("name".equalsIgnoreCase(argKey)) {
/* 39 */       this.daoName_ = argValue.toString();
/*    */     }
/* 41 */     else if (!_ignoredFields.contains(argKey)) {
/* 42 */       super.setConfigObject(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\DaoConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */