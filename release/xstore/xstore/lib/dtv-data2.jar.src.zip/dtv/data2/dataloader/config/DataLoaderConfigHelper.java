/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.util.config.ConfigHelper;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataLoaderConfigHelper
/*    */   extends ConfigHelper<DataLoaderConfig>
/*    */ {
/*    */   private static DataLoaderConfig dataLoaderConfig_;
/*    */   
/*    */   static {
/* 22 */     (new DataLoaderConfigHelper()).initialize();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DataLoaderConfig getDataLoaderConfig() {
/* 31 */     return dataLoaderConfig_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void hashRootConfigs() {
/* 37 */     super.hashRootConfigs();
/*    */     
/* 39 */     dataLoaderConfig_ = (DataLoaderConfig)getRootConfig();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getConfigFileName() {
/* 45 */     return "DataLoaderConfig";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected IConfigObject getConfigObject(String argTagName, String dtype, String argSourceDescription) {
/* 51 */     if ("DataLoaderConfig".equals(argTagName)) {
/* 52 */       return (IConfigObject)new DataLoaderConfig();
/*    */     }
/* 54 */     if ("Parameter".equals(argTagName)) {
/* 55 */       return (IConfigObject)new DataLoaderParameterConfig();
/*    */     }
/* 57 */     if ("RecordType".equals(argTagName)) {
/* 58 */       return (IConfigObject)new RecordTypeConfig();
/*    */     }
/* 60 */     if ("Dao".equals(argTagName)) {
/* 61 */       return (IConfigObject)new DaoConfig();
/*    */     }
/* 63 */     if ("Sql".equals(argTagName)) {
/* 64 */       return (IConfigObject)new SqlStatementConfig();
/*    */     }
/* 66 */     if ("Field".equals(argTagName)) {
/* 67 */       return (IConfigObject)new FieldConfig();
/*    */     }
/* 69 */     if ("ValueTranslator".equals(argTagName) || "ApplicabilityCondition"
/* 70 */       .equals(argTagName)) {
/* 71 */       return (IConfigObject)new DataModifierConfig();
/*    */     }
/* 73 */     if ("Param".equals(argTagName)) {
/* 74 */       return (IConfigObject)new DataModifierParameterConfig();
/*    */     }
/*    */     
/* 77 */     return super.getConfigObject(argTagName, dtype, argSourceDescription);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\DataLoaderConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */