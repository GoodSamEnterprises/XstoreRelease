/*     */ package dtv.data2.dataloader.fileprocessing;
/*     */ 
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfig;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.SystemPropertyConfigurationSource;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileLine
/*     */ {
/*     */   private static final int PRESERVE_TRAILING_BLANKS = -1;
/*  24 */   private static final String DEFAULT_RECORD_TYPE = System.getProperty("dtv.data2.dataloader.defaultRecordType");
/*     */   
/*  26 */   private static final String DEFAULT_ACTION_TYPE = System.getProperty("dtv.data2.dataloader.defaultActionType");
/*     */   
/*  28 */   private final List<String> fields_ = new ArrayList<>();
/*     */   
/*     */   private final String fileLine_;
/*     */   
/*     */   private final boolean isInstructionValid_;
/*     */   
/*     */   private String recordType_;
/*     */   private String actionType_;
/*     */   
/*     */   public FileLine(String argFileLine, char argDelimiter) {
/*  38 */     this(argFileLine, argDelimiter, true);
/*     */   }
/*     */   
/*     */   public FileLine(String argFileLine, char argDelimiter, boolean argIsInstructionValid) {
/*  42 */     Properties props = SystemPropertyConfigurationSource.getInstance().getProperties();
/*  43 */     this.fileLine_ = StringUtils.replaceVariables(argFileLine, props);
/*  44 */     this.isInstructionValid_ = argIsInstructionValid;
/*     */     
/*  46 */     this.recordType_ = DEFAULT_RECORD_TYPE;
/*  47 */     this.actionType_ = DEFAULT_ACTION_TYPE;
/*     */ 
/*     */ 
/*     */     
/*  51 */     if (this.isInstructionValid_) {
/*  52 */       tokenize(argDelimiter);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public FileLine(String argFileLine, Pattern argDelimiter) {
/*  61 */     this(argFileLine, argDelimiter, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public FileLine(String argFileLine, Pattern argDelimiter, boolean argIsInstructionValid) {
/*  69 */     Properties props = SystemPropertyConfigurationSource.getInstance().getProperties();
/*  70 */     this.fileLine_ = StringUtils.replaceVariables(argFileLine, props);
/*  71 */     this.isInstructionValid_ = argIsInstructionValid;
/*     */     
/*  73 */     this.recordType_ = DEFAULT_RECORD_TYPE;
/*  74 */     this.actionType_ = DEFAULT_ACTION_TYPE;
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (this.isInstructionValid_) {
/*  79 */       tokenize(argDelimiter);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActionType() {
/*  89 */     return this.actionType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldValue(int argOneBasedIndex) {
/*  99 */     return getFieldValueRaw(argOneBasedIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldValue(int argStart, int argEnd) {
/* 110 */     return this.fileLine_.substring(argStart, argEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFieldValueCount() {
/* 119 */     return this.fields_.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldValueRaw(int argOneBasedIndex) {
/* 129 */     if (argOneBasedIndex <= 0) {
/* 130 */       throw new DataLoaderException("getFieldValue takes a ONE based index, but [" + argOneBasedIndex + "] was passed.)");
/*     */     }
/*     */     
/* 133 */     return (argOneBasedIndex > this.fields_.size()) ? "" : this.fields_.get(argOneBasedIndex - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIsInstructionValid() {
/* 142 */     return this.isInstructionValid_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRecordType() {
/* 151 */     return this.recordType_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     return this.fileLine_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processField(String argFieldData, int argFieldIndex) {
/* 166 */     switch (argFieldIndex) {
/*     */       case 0:
/* 168 */         this.actionType_ = argFieldData;
/*     */         return;
/*     */       
/*     */       case 1:
/* 172 */         if (DataLoaderConfig.isRunSql(this.actionType_)) {
/* 173 */           this.recordType_ = this.actionType_;
/* 174 */           this.fields_.add(argFieldData);
/*     */         } else {
/*     */           
/* 177 */           this.recordType_ = argFieldData;
/*     */         } 
/*     */         return;
/*     */     } 
/* 181 */     this.fields_.add(argFieldData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void tokenize(char argDelimiter) {
/* 188 */     int startIndex = 0;
/* 189 */     int endIndex = 0;
/* 190 */     int fieldIndex = 0;
/* 191 */     while ((endIndex = this.fileLine_.indexOf(argDelimiter, startIndex)) != -1) {
/*     */       
/* 193 */       String field = this.fileLine_.substring(startIndex, endIndex);
/* 194 */       processField(field, fieldIndex++);
/*     */ 
/*     */       
/* 197 */       startIndex = endIndex + 1;
/*     */     } 
/*     */ 
/*     */     
/* 201 */     String lastField = this.fileLine_.substring(startIndex);
/* 202 */     if (fieldIndex > 0) {
/* 203 */       processField(lastField, fieldIndex++);
/*     */     }
/*     */     else {
/*     */       
/* 207 */       this.fields_.add(lastField);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   private void tokenize(Pattern argDelimiter) {
/* 216 */     String[] tokens = argDelimiter.split(this.fileLine_, -1);
/* 217 */     int counter = 0;
/* 218 */     if (tokens.length > 1) {
/* 219 */       for (String field : tokens) {
/* 220 */         processField(field, counter++);
/*     */       }
/*     */     } else {
/*     */       
/* 224 */       this.fields_.add(tokens[0]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\FileLine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */