/*     */ package dtv.data2.dataloader;
/*     */ 
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IQueryKey;
/*     */ import dtv.data2.access.QueryKey;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*     */ import dtv.util.DateUtils;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataLoaderUtils
/*     */ {
/*     */   public static final String DATALOADER = "DATALOADER";
/*     */   public static final String PARAM_FILE_POSITION = "filePosition=";
/*     */   public static final String PARAM_SYS_PROPERTY = "sysProp=";
/*     */   public static final String PARAM_LITERAL = "literal=";
/*  36 */   private static final IQueryKey<Object[]> DELETE_ALL_FROM_ORGANIZATION = (IQueryKey<Object[]>)new QueryKey("DELETE_ALL_FROM_ORGANIZATION", Object[].class);
/*     */ 
/*     */   
/*  39 */   private static final IQueryKey<Object[]> DELETE_EXTERNAL_SYS_FROM_ORGANIZATION = (IQueryKey<Object[]>)new QueryKey("DELETE_EXTERNAL_SYS_FROM_ORGANIZATION", Object[].class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPersistable getDeleteByExternalSystemFromOrganizationPersistable(String argTable, String externalSystem) {
/*  53 */     Map<String, Object> queryParams = new HashMap<>();
/*     */     
/*  55 */     queryParams.put("$argTableName", argTable);
/*  56 */     queryParams.put("argOrganizationId", System.getProperty("dtv.location.organizationId"));
/*  57 */     queryParams.put("argExternalSystem", externalSystem);
/*     */     
/*  59 */     QueryRequest deleteQuery = new QueryRequest();
/*  60 */     deleteQuery.setQueryKey(DELETE_EXTERNAL_SYS_FROM_ORGANIZATION);
/*  61 */     deleteQuery.setParams(queryParams);
/*     */     
/*  63 */     return (IPersistable)deleteQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPersistable getDeleteByOrganizationPersistable(String argTable) {
/*  74 */     Map<String, Object> queryParams = new HashMap<>();
/*     */     
/*  76 */     queryParams.put("$argTableName", argTable);
/*  77 */     queryParams.put("argDeleteOrgId", System.getProperty("dtv.location.organizationId"));
/*     */     
/*  79 */     QueryRequest deleteQuery = new QueryRequest();
/*  80 */     deleteQuery.setQueryKey(DELETE_ALL_FROM_ORGANIZATION);
/*  81 */     deleteQuery.setParams(queryParams);
/*     */     
/*  83 */     return (IPersistable)deleteQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getValueForValueSpecifier(String argValueSpecifier, FileLine argCurrentLine) {
/*  97 */     if (argValueSpecifier == null) {
/*  98 */       return null;
/*     */     }
/*     */     
/* 101 */     if (argValueSpecifier.startsWith("filePosition=")) {
/* 102 */       int filePosition = Integer.parseInt(argValueSpecifier.substring("filePosition=".length()));
/* 103 */       return argCurrentLine.getFieldValue(filePosition - 2);
/*     */     } 
/* 105 */     if (argValueSpecifier.startsWith("sysProp=")) {
/* 106 */       return System.getProperty(argValueSpecifier.substring("sysProp=".length()));
/*     */     }
/* 108 */     if (argValueSpecifier.startsWith("literal=")) {
/* 109 */       return argValueSpecifier.substring("literal=".length());
/*     */     }
/*     */     
/* 112 */     return argValueSpecifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stampDaoAuditFields(IDataAccessObject argDao, DaoState argDaoState) {
/* 123 */     Date newDate = DateUtils.getNewDate();
/*     */     
/* 125 */     if (argDaoState.isCreate()) {
/* 126 */       argDao.setCreateDate(newDate);
/* 127 */       argDao.setCreateUserId("DATALOADER");
/*     */     } 
/*     */     
/* 130 */     if (argDaoState.isUpdate()) {
/* 131 */       argDao.setUpdateDate(newDate);
/* 132 */       argDao.setUpdateUserId("DATALOADER");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\DataLoaderUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */