/*     */ package dtv.data2.dataloader.fileprocessing;
/*     */ 
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.DataModelFactory;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.impl.IHasIncrementalValues;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.data2.access.query.SqlQueryRequest;
/*     */ import dtv.data2.dataloader.ConfigParameters;
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.data2.dataloader.DataLoaderUtils;
/*     */ import dtv.data2.dataloader.applicability.IApplicabilityCondition;
/*     */ import dtv.data2.dataloader.config.DaoConfig;
/*     */ import dtv.data2.dataloader.config.DataLoaderConfigHelper;
/*     */ import dtv.data2.dataloader.config.DataModifierConfig;
/*     */ import dtv.data2.dataloader.config.DataModifierParameterConfig;
/*     */ import dtv.data2.dataloader.config.FieldConfig;
/*     */ import dtv.data2.dataloader.config.PersistableConfig;
/*     */ import dtv.data2.dataloader.config.RecordTypeConfig;
/*     */ import dtv.data2.dataloader.config.SqlStatementConfig;
/*     */ import dtv.data2.dataloader.valuetranslator.IValueTranslator;
/*     */ import dtv.util.DateUtils;
/*     */ import dtv.util.DtvDate;
/*     */ import dtv.util.StringUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DelimitedValueFileLineParser
/*     */   implements IFileLineParser
/*     */ {
/*  43 */   private static final Logger logger_ = Logger.getLogger(DelimitedValueFileLineParser.class);
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private ConfigParameters _configParameters;
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IPersistable> parse(FileLine argFileLine) {
/*  52 */     RecordTypeConfig recordConfig = DataLoaderConfigHelper.getDataLoaderConfig().getRecordType(argFileLine.getRecordType());
/*     */     
/*  54 */     List<PersistableConfig> persistableConfigs = recordConfig.getPersistables();
/*  55 */     List<IPersistable> persistables = new ArrayList<>(persistableConfigs.size());
/*     */     
/*  57 */     for (PersistableConfig persistableConfig : persistableConfigs) {
/*     */       IPersistable persistable;
/*     */ 
/*     */       
/*  61 */       if (persistableConfig.getActionType() != null) {
/*  62 */         if (persistableConfig.getActionType().equals("INSERT_ONLY")) {
/*     */           
/*  64 */           if (argFileLine.getActionType().equals("DELETE"))
/*     */           {
/*     */             continue;
/*     */           }
/*     */         }
/*  69 */         else if (!persistableConfig.getActionType().equals(argFileLine.getActionType())) {
/*     */           continue;
/*     */         } 
/*     */       }
/*     */       
/*  74 */       if (persistableConfig.getApplicabilityConditions() != null && 
/*  75 */         !processApplicabilityConditions(persistableConfig, argFileLine)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  86 */       if (persistableConfig instanceof DaoConfig) {
/*  87 */         persistable = getDao((DaoConfig)persistableConfig, argFileLine);
/*     */       }
/*  89 */       else if (persistableConfig instanceof SqlStatementConfig) {
/*  90 */         persistable = getSql((SqlStatementConfig)persistableConfig, argFileLine);
/*     */       } else {
/*     */         
/*  93 */         throw new DataLoaderException("Unknown config type: " + persistableConfig);
/*     */       } 
/*     */       
/*  96 */       if (persistable != null) {
/*  97 */         persistables.add(persistable);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     if (argFileLine.getActionType().equals("DELETE")) {
/* 107 */       Collections.reverse(persistables);
/*     */     }
/*     */     
/* 110 */     return persistables;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDaoState(IDataAccessObject argDao, String argActionType, DaoConfig argConfig) {
/* 121 */     DaoState state = null;
/*     */     
/* 123 */     if ("INSERT_ONLY".equals(argConfig.getActionType())) {
/* 124 */       state = DaoState.INSERT_ONLY;
/* 125 */       argDao.setObjectState(state.intVal());
/* 126 */       DataLoaderUtils.stampDaoAuditFields(argDao, state);
/*     */       
/*     */       return;
/*     */     } 
/* 130 */     if ("INSERT".equals(argActionType)) {
/* 131 */       state = DaoState.INSERT_OR_UPDATE;
/*     */     }
/* 133 */     else if ("INSERT_ONLY".equals(argActionType)) {
/* 134 */       state = DaoState.INSERT_ONLY;
/*     */     }
/* 136 */     else if ("UPDATE".equals(argActionType) || "UPDATE_SELECT".equals(argActionType)) {
/* 137 */       state = DaoState.UPDATED;
/*     */     }
/* 139 */     else if ("DELETE".equals(argActionType) || "TRUNCATE"
/* 140 */       .equals(argActionType) || "DELETE_BY_ORGANIZATION"
/* 141 */       .equals(argActionType)) {
/*     */       
/* 143 */       state = DaoState.DELETED;
/*     */     } else {
/*     */       
/* 146 */       throw new DataLoaderException("Unknown action type encountered: " + argActionType);
/*     */     } 
/*     */     
/* 149 */     argDao.setObjectState(state.intVal());
/* 150 */     DataLoaderUtils.stampDaoAuditFields(argDao, state);
/*     */   }
/*     */   
/*     */   protected String getValue(FieldConfig argConfig, FileLine argLine) {
/* 154 */     String value = null;
/*     */     
/* 156 */     if (FieldConfig.FieldValueSource.LITERAL == argConfig.getFieldValueSource())
/* 157 */     { value = argConfig.getValueSpecifier(); }
/*     */     
/* 159 */     else if (FieldConfig.FieldValueSource.VARIABLE == argConfig.getFieldValueSource())
/* 160 */     { if ("$currentDate".equals(argConfig.getValueSpecifier())) {
/*     */         
/* 162 */         value = String.valueOf((new DtvDate(DateUtils.clearTime((new Date()).getTime()))).getTimeSerializable());
/*     */ 
/*     */       
/*     */       }
/* 166 */       else if ("$currentDateTimestamp".equals(argConfig.getValueSpecifier())) {
/* 167 */         value = String.valueOf((new DtvDate()).getTimeSerializable());
/*     */       } else {
/*     */         
/* 170 */         throw new DataLoaderException("Unknown variable name specified: " + argConfig.getValueSpecifier());
/*     */       }
/*     */        }
/* 173 */     else if (FieldConfig.FieldValueSource.SYSTEM_PROPERTY == argConfig.getFieldValueSource())
/* 174 */     { value = System.getProperty(argConfig.getValueSpecifier());
/* 175 */       if (value == null) {
/* 176 */         logger_.warn("System propery " + argConfig.getValueSpecifier() + " value was null.  Config source: " + argConfig
/* 177 */             .getSourceDescription());
/*     */       } }
/*     */     
/* 180 */     else if (FieldConfig.FieldValueSource.CONFIG_PARAMETER == argConfig.getFieldValueSource())
/* 181 */     { String key = argConfig.getValueSpecifier();
/* 182 */       switch (key)
/*     */       { case "getOrganizationId":
/* 184 */           value = this._configParameters.getOrganizationId().toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 233 */           value = translateValue(value, argConfig, argLine);
/* 234 */           return value; }  try { Method configParamMethod = this._configParameters.getClass().getDeclaredMethod(key, new Class[0]); Object result = configParamMethod.invoke(this._configParameters, new Object[0]); value = result.toString(); } catch (ReflectiveOperationException ex) { logger_.error("Unable to access config parameter named " + argConfig.getValueSpecifier(), ex); }  } else if (FieldConfig.FieldValueSource.FILE_POSITION == argConfig.getFieldValueSource()) { int filePosition = argConfig.getFilePosition(); if (filePosition <= argLine.getFieldValueCount()) { String fileValue = argLine.getFieldValue(filePosition); if (!StringUtils.isEmpty(fileValue)) { value = fileValue.trim(); } else { value = argConfig.getFieldDefault(); }  }  if (null == value && filePosition > argLine.getFieldValueCount()) value = argConfig.getFieldDefault();  } else if (FieldConfig.FieldValueSource.FILE_INTERVAL == argConfig.getFieldValueSource()) { value = argLine.getFieldValue(argConfig.getFileIntervalStart(), argConfig.getFileIntervalEnd()); } else if (argConfig.getFieldValueSource() == null) { if (argConfig.getValueTranslators() == null) throw new DataLoaderException("A Field is misconfigured in dataloader config.  This field does not define a field value source (e.g. \"filePosition\", \"sysProp\") and also does not define any translators. A field must define value source or at least 1 translator to provide a value. COnfig Source: " + argConfig.getSourceDescription());  } else { throw new DataLoaderException("Unknown field value source specified: " + argConfig.getFieldValueSource()); }  value = translateValue(value, argConfig, argLine); return value;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean processApplicabilityConditions(PersistableConfig argPersistable, FileLine argCurrentLine) {
/* 239 */     boolean applicable = true;
/*     */     
/* 241 */     for (DataModifierConfig config : argPersistable.getApplicabilityConditions()) {
/* 242 */       IApplicabilityCondition condition = null;
/*     */       try {
/* 244 */         condition = (IApplicabilityCondition)Class.forName(config.getClassName()).newInstance();
/*     */       }
/* 246 */       catch (Exception ee) {
/* 247 */         throw new DataLoaderException("Could not instantiate class for applicability condition. Class name: [" + config
/* 248 */             .getClassName() + "]", ee);
/*     */       } 
/*     */       
/* 251 */       if (condition == null) {
/* 252 */         throw new DataLoaderException("condition should not be null at this point.");
/*     */       }
/*     */       
/* 255 */       List<DataModifierParameterConfig> params = config.getParameters();
/*     */       
/* 257 */       for (DataModifierParameterConfig param : params) {
/* 258 */         condition.setParameter(param.getParameterKey(), param.getParameterValue());
/*     */       }
/*     */       
/* 261 */       applicable = condition.isApplicable(argCurrentLine);
/*     */       
/* 263 */       if (!applicable) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 268 */     return applicable;
/*     */   }
/*     */   
/*     */   private IPersistable getDao(DaoConfig argConfig, FileLine argLine) {
/* 272 */     List<FieldConfig> fieldConfigs = argConfig.getFields();
/*     */     
/* 274 */     Map<String, String> values = new HashMap<>(fieldConfigs.size());
/* 275 */     for (FieldConfig fieldConfig : fieldConfigs) {
/* 276 */       values.put(fieldConfig.getDaoFieldName(), getValue(fieldConfig, argLine));
/*     */     }
/*     */     
/* 279 */     IDataAccessObject dao = null;
/*     */     
/* 281 */     if (argLine.getActionType().equals("UPDATE_SELECT")) {
/* 282 */       IObjectId id = DataModelFactory.getIdForDaoName(argConfig.getDaoName());
/* 283 */       DaoUtils.loadIDFromValueMap(id, values);
/* 284 */       IDataModelImpl model = (IDataModelImpl)DataFactory.getObjectById(id);
/*     */       
/* 286 */       if (model != null) {
/* 287 */         dao = model.getDAO();
/*     */       }
/*     */       
/* 290 */       values = replaceNullsWithValuesFromDAO(values, (IPersistable)dao);
/*     */     } else {
/*     */       
/* 293 */       dao = DataModelFactory.getDaoForDaoName(argConfig.getDaoName());
/*     */     } 
/*     */     
/* 296 */     setDaoState(dao, argLine.getActionType(), argConfig);
/*     */     
/* 298 */     if (dao != null) {
/* 299 */       dao.setValues(values);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 304 */     if (dao instanceof IHasIncrementalValues) {
/* 305 */       ((IHasIncrementalValues)dao).setIncrementalActive(false);
/*     */     }
/*     */     
/* 308 */     return (IPersistable)dao;
/*     */   }
/*     */   
/*     */   private IPersistable getSql(SqlStatementConfig argConfig, FileLine argLine) {
/* 312 */     SqlQueryRequest query = new SqlQueryRequest();
/* 313 */     query.setSqlStatement(argConfig.getSqlString());
/* 314 */     List<FieldConfig> fieldConfigs = argConfig.getFields();
/*     */     
/* 316 */     List<Object> params = new ArrayList(fieldConfigs.size());
/*     */     
/* 318 */     for (FieldConfig fieldConfig : fieldConfigs) {
/* 319 */       String rawValue = getValue(fieldConfig, argLine);
/*     */       
/* 321 */       Object objectValue = DaoUtils.getFieldValueForXmlString(
/* 322 */           JDBCHelper.getJDBCTypeForTypeName(fieldConfig.getFieldDataType()), rawValue);
/*     */       
/* 324 */       params.add(objectValue);
/*     */     } 
/*     */     
/* 327 */     query.setParams(params);
/* 328 */     return (IPersistable)query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getterFromKey(String argKey) {
/* 338 */     if (argKey == null || argKey.length() == 0) {
/* 339 */       return null;
/*     */     }
/*     */     
/* 342 */     return "get" + Character.toUpperCase(argKey.charAt(0)) + argKey
/* 343 */       .substring(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getValueFromDAO(String argKey, IPersistable argDao) {
/* 355 */     Class<? extends IPersistable> daoType = (Class)argDao.getClass();
/* 356 */     String currentValue = null;
/*     */ 
/*     */     
/* 359 */     try { Method getter = daoType.getMethod(getterFromKey(argKey), new Class[0]);
/*     */       
/* 361 */       if (getter != null) {
/* 362 */         Object currentValObj = getter.invoke(argDao, new Object[0]);
/*     */         
/* 364 */         if (currentValObj != null) {
/* 365 */           currentValue = currentValObj.toString();
/*     */         }
/*     */       }
/*     */        }
/*     */     
/* 370 */     catch (ReflectiveOperationException reflectiveOperationException) {  }
/* 371 */     catch (IllegalArgumentException illegalArgumentException) {}
/*     */     
/* 373 */     return currentValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> replaceNullsWithValuesFromDAO(Map<String, String> argValues, IPersistable argDao) {
/* 387 */     Map<String, String> meldedValues = new HashMap<>();
/*     */     
/* 389 */     for (String key : argValues.keySet()) {
/* 390 */       if (argValues.get(key) == null) {
/* 391 */         meldedValues.put(key, getValueFromDAO(key, argDao));
/*     */         continue;
/*     */       } 
/* 394 */       meldedValues.put(key, argValues.get(key));
/*     */     } 
/*     */ 
/*     */     
/* 398 */     return meldedValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String translateValue(String argRawValue, FieldConfig argConfig, FileLine argFileLine) {
/* 410 */     if (argConfig.getValueTranslators() == null) {
/* 411 */       return argRawValue;
/*     */     }
/*     */     
/* 414 */     String translatedValue = argRawValue;
/*     */     
/* 416 */     for (DataModifierConfig translatorConfig : argConfig.getValueTranslators()) {
/*     */ 
/*     */ 
/*     */       
/* 420 */       IValueTranslator translator = null;
/*     */       
/*     */       try {
/* 423 */         translator = (IValueTranslator)Class.forName(translatorConfig.getClassName()).newInstance();
/*     */       }
/* 425 */       catch (Exception ee) {
/* 426 */         if (StringUtils.isEmpty(translatorConfig.getClassName())) {
/* 427 */           throw new DataLoaderException("Could not load value translator - No Class name attribute was supplied for ValueTransltor field. Source: " + argConfig
/*     */               
/* 429 */               .getSourceDescription());
/*     */         }
/*     */         
/* 432 */         throw new DataLoaderException("Could not load value translator.", ee);
/*     */       } 
/*     */ 
/*     */       
/* 436 */       if (translator == null) {
/* 437 */         throw new DataLoaderException("translator should not be null at this point.  Source config: " + argConfig
/* 438 */             .getSourceDescription());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 444 */       for (DataModifierParameterConfig paramConfig : translatorConfig.getParameters()) {
/* 445 */         translator.setParameter(paramConfig.getParameterKey(), paramConfig.getParameterValue());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 451 */       translatedValue = translator.translate(translatedValue, argFileLine);
/*     */     } 
/*     */     
/* 454 */     return translatedValue;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\DelimitedValueFileLineParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */