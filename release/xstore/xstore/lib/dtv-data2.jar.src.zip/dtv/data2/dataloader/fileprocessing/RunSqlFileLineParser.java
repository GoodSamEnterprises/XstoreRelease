/*    */ package dtv.data2.dataloader.fileprocessing;
/*    */ 
/*    */ import dtv.data2.access.IPersistable;
/*    */ import dtv.data2.access.query.SqlQueryRequest;
/*    */ import dtv.data2.dataloader.DataLoaderException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RunSqlFileLineParser
/*    */   implements IFileLineParser
/*    */ {
/*    */   private static final String SYSTEM_PROPERTY_ENABLE_RUN_SQL = "dtv.dataloader.enableRunSql";
/*    */   
/*    */   protected static boolean isRunSqlEnabled() {
/* 32 */     return Boolean.getBoolean("dtv.dataloader.enableRunSql");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<IPersistable> parse(FileLine argFileLine) {
/* 39 */     List<IPersistable> persistables = new ArrayList<>();
/*    */     
/* 41 */     if (!isRunSqlEnabled()) {
/* 42 */       throw new DataLoaderException("The RUN_SQL action has been disabled for DataLoader. RecordType: " + argFileLine
/* 43 */           .getRecordType());
/*    */     }
/*    */     
/* 46 */     persistables.add(getSqlFromLine(argFileLine));
/*    */ 
/*    */     
/* 49 */     return persistables;
/*    */   }
/*    */   
/*    */   private IPersistable getSqlFromLine(FileLine argLine) {
/* 53 */     SqlQueryRequest query = new SqlQueryRequest();
/* 54 */     query.setSqlStatement(argLine.getFieldValue(1));
/* 55 */     return (IPersistable)query;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\RunSqlFileLineParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */