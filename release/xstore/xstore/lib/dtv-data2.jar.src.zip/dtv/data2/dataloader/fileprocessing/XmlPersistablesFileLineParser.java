/*    */ package dtv.data2.dataloader.fileprocessing;
/*    */ 
/*    */ import dtv.data2.access.DaoUtils;
/*    */ import dtv.data2.access.IDataAccessObject;
/*    */ import dtv.data2.access.IPersistable;
/*    */ import dtv.data2.access.impl.DaoState;
/*    */ import dtv.data2.dataloader.DataLoaderException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlPersistablesFileLineParser
/*    */   implements IFileLineParser
/*    */ {
/*    */   public List<IPersistable> parse(FileLine argFileLine) {
/* 30 */     String xml = argFileLine.getFieldValue(1);
/*    */     
/*    */     try {
/* 33 */       List<IPersistable> persistables = DaoUtils.getPersistablesForXml(xml);
/* 34 */       setDaosToInsertOrUpdate(argFileLine, persistables);
/* 35 */       return persistables;
/*    */     }
/* 37 */     catch (Exception ex) {
/* 38 */       throw new DataLoaderException("Cannot parse XML file line into persistables. xml: [" + xml + "]", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setDaosToInsertOrUpdate(FileLine argFileLine, List<IPersistable> argPersistables) {
/* 49 */     if (argPersistables == null || argPersistables.isEmpty()) {
/*    */       return;
/*    */     }
/*    */     
/* 53 */     if (!"INSERT".equals(argFileLine.getActionType())) {
/*    */       return;
/*    */     }
/*    */     
/* 57 */     for (IPersistable persistable : argPersistables) {
/* 58 */       if (persistable instanceof IDataAccessObject) {
/* 59 */         IDataAccessObject dao = (IDataAccessObject)persistable;
/*    */         
/* 61 */         if (DaoState.isNew(dao) || DaoState.isUpdated(dao))
/* 62 */           dao.setObjectState(DaoState.INSERT_OR_UPDATE.intVal()); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\fileprocessing\XmlPersistablesFileLineParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */