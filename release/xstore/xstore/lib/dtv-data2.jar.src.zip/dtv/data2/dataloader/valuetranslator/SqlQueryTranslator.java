/*     */ package dtv.data2.dataloader.valuetranslator;
/*     */ 
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.jdbc.JDBCDataSourceMgr;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.data2.dataloader.ConfigParameters;
/*     */ import dtv.data2.dataloader.DataLoaderException;
/*     */ import dtv.data2.dataloader.fileprocessing.FileLine;
/*     */ import dtv.util.StringUtils;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlQueryTranslator
/*     */   extends AbstractValueTranslator
/*     */ {
/*  33 */   private static final Logger logger_ = Logger.getLogger(SqlQueryTranslator.class);
/*     */   
/*  35 */   private final String PARAM_SQL = "sql";
/*  36 */   private final String PARAM_SQL_FIELD = "sql.field.";
/*  37 */   private final String PARAM_NULL_VALUE = "nullValue";
/*     */   
/*  39 */   private final Map<String, String> parameters_ = new HashMap<>(4);
/*     */   
/*     */   private String sql_;
/*  42 */   private final List<String> fieldValues = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private String nullValue_;
/*     */   
/*     */   @Inject
/*     */   private ConfigParameters _configParameters;
/*     */ 
/*     */   
/*     */   public void setParameter(String argName, String argValue) {
/*  52 */     if (this.parameters_.containsKey(argName)) {
/*  53 */       throw new DataLoaderException("Duplicate key detected for SqlQueryTranslator. Key=" + argName + " Value=" + argValue);
/*     */     }
/*     */     
/*  56 */     this.parameters_.put(argName, argValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String translate(String argCurrentValue, FileLine argCurrentLine) {
/*  62 */     String translatedValue = this.nullValue_;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     parseParameters(argCurrentValue, argCurrentLine);
/*  68 */     Connection connection = null;
/*  69 */     PreparedStatement statement = null;
/*  70 */     ResultSet results = null;
/*     */     
/*     */     try {
/*  73 */       connection = getConnection();
/*     */ 
/*     */ 
/*     */       
/*  77 */       statement = connection.prepareStatement(this.sql_);
/*     */       
/*  79 */       int counter = 1;
/*  80 */       for (String argument : this.fieldValues)
/*     */       {
/*  82 */         statement.setObject(counter++, getValueForArgument(argCurrentValue, argument, argCurrentLine));
/*     */       }
/*     */       
/*  85 */       statement.execute();
/*     */       
/*  87 */       results = statement.getResultSet();
/*     */       
/*  89 */       if (results.next()) {
/*  90 */         Object queryResult = results.getObject(1);
/*  91 */         if (queryResult instanceof Clob) {
/*  92 */           translatedValue = JDBCHelper.clobToString((Clob)queryResult);
/*     */         
/*     */         }
/*  95 */         else if (queryResult != null) {
/*  96 */           translatedValue = queryResult.toString();
/*     */         } 
/*     */ 
/*     */         
/* 100 */         if (StringUtils.isEmpty(translatedValue)) {
/* 101 */           translatedValue = this.nullValue_;
/*     */         }
/*     */       } 
/*     */       
/* 105 */       if (results.next()) {
/* 106 */         logger_.warn("SQL for SqlQueryTranslator returned more than one row, 1 row & 1 column result is expected for this translator. sql " + this.sql_);
/*     */       
/*     */       }
/*     */     }
/* 110 */     catch (Exception ee) {
/*     */ 
/*     */ 
/*     */       
/* 114 */       String msg = null;
/* 115 */       if (FailoverException.isFailover(ee)) {
/* 116 */         msg = "An unexpected failure occurred while execeuting sql [" + this.sql_ + "]";
/*     */       } else {
/*     */         
/* 119 */         msg = "Failed to execute sql  [" + this.sql_ + "]";
/*     */       } 
/* 121 */       logger_.warn(msg, ee);
/*     */     }
/*     */     finally {
/*     */       
/* 125 */       if (results != null) {
/*     */         try {
/* 127 */           results.close();
/*     */         }
/* 129 */         catch (SQLException e) {
/* 130 */           logger_.warn("An exception occurred while closing a result set", e);
/*     */         } 
/*     */       }
/* 133 */       if (statement != null) {
/*     */         try {
/* 135 */           statement.close();
/*     */         }
/* 137 */         catch (SQLException e) {
/* 138 */           logger_.warn("An exception occurred while closing a statement.", e);
/*     */         } 
/*     */       }
/* 141 */       if (connection != null) {
/*     */         try {
/* 143 */           connection.close();
/*     */         }
/* 145 */         catch (SQLException e) {
/* 146 */           logger_.warn("An exception occurred while closing a connection.", e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 151 */     return translatedValue;
/*     */   }
/*     */   
/*     */   private Connection getConnection() {
/* 155 */     String dataSourceName = this._configParameters.getDataSource();
/*     */     
/* 157 */     if (StringUtils.isEmpty(dataSourceName)) {
/* 158 */       throw new DataLoaderException("Could not get datasource name from dataloader config parameters");
/*     */     }
/*     */     
/* 161 */     return (Connection)JDBCDataSourceMgr.getInstance().getConnection(dataSourceName);
/*     */   }
/*     */   
/*     */   private void parseParameters(String argCurrentValue, FileLine argCurrentLine) {
/* 165 */     if (this.parameters_.isEmpty()) {
/* 166 */       throw new DataLoaderException("No paramters provided for SqlQueryTranslator.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     this.sql_ = this.parameters_.get("sql");
/*     */     
/* 174 */     if (StringUtils.isEmpty(this.sql_)) {
/* 175 */       throw new DataLoaderException("SqlQueryTranslator requires paramter \"sql\" to be set.  Parameters: " + this.parameters_);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     int fieldCounter = 1;
/* 183 */     String currentField = null;
/*     */     
/*     */     do {
/* 186 */       String key = (new StringBuilder(12)).append("sql.field.").append(fieldCounter++).toString();
/* 187 */       currentField = this.parameters_.get(key);
/* 188 */       if (currentField == null)
/* 189 */         continue;  this.fieldValues.add(currentField);
/*     */     
/*     */     }
/* 192 */     while (currentField != null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     this.nullValue_ = getValueForArgument(argCurrentValue, this.parameters_.get("nullValue"), argCurrentLine);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\valuetranslator\SqlQueryTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */