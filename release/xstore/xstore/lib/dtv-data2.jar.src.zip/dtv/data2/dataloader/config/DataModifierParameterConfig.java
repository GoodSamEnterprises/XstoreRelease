/*    */ package dtv.data2.dataloader.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataModifierParameterConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String parameterKey_;
/*    */   private String parameterValue_;
/*    */   
/*    */   public String getParameterKey() {
/* 29 */     return this.parameterKey_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getParameterValue() {
/* 38 */     return this.parameterValue_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 44 */     if ("key".equalsIgnoreCase(argKey)) {
/*    */       
/* 46 */       this.parameterKey_ = argValue.toString();
/*    */     }
/* 48 */     else if ("value".equalsIgnoreCase(argKey)) {
/* 49 */       this.parameterValue_ = argValue.toString();
/*    */     } else {
/*    */       
/* 52 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\config\DataModifierParameterConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */