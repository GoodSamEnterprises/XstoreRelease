/*     */ package dtv.data2.dataloader;
/*     */ 
/*     */ import dtv.data2.dataloader.fileprocessing.FileProcessingStats;
/*     */ import dtv.data2.dataloader.fileprocessing.IHasSourceData;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileResultsWriter
/*     */   implements IResultsWriter
/*     */ {
/*  30 */   private static final Logger _logger = Logger.getLogger(FileResultsWriter.class);
/*  31 */   private static final Logger _successLogger = Logger.getLogger("dtv.xstore.dataloader.SuccessFile");
/*  32 */   private static final Logger _failuresLogger = Logger.getLogger("dtv.xstore.dataloader.FailuresFile");
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private ConfigParameters _configParameters;
/*     */   
/*     */   private PrintWriter _summaryResults;
/*     */   
/*     */   private Date _runStartTime;
/*     */ 
/*     */   
/*     */   public void create() {
/*  44 */     String argDataFilePath = this._configParameters.getDataFileLocation();
/*  45 */     File f = new File(argDataFilePath + File.separator + "summary.ini");
/*     */     
/*     */     try {
/*  48 */       this._summaryResults = new PrintWriter(new FileWriter(f, false));
/*     */     }
/*  50 */     catch (IOException ex) {
/*  51 */       _logger.error("Could not create file", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void finish(String argOptionalRunID) {
/*  58 */     this._summaryResults.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileBeingProcessed(String argFileName) {
/*  65 */     this._summaryResults.println("[" + argFileName + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(String argOptionalRunID, Date argRunStartTime) {
/*  71 */     this._runStartTime = argRunStartTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFailure(String argMessage, IHasSourceData argFailure) {
/*  77 */     _failuresLogger.error("#" + argMessage);
/*     */     
/*  79 */     if (argFailure.getSourceData() != null) {
/*  80 */       for (String data : argFailure.getSourceData()) {
/*  81 */         _failuresLogger.error(data);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeResultsSummary(FileProcessingStats argStats) {
/*  89 */     this._summaryResults.println("rows=" + argStats.successCounter);
/*  90 */     this._summaryResults.println("failedRows=" + argStats.failureCounter);
/*  91 */     this._summaryResults.println("appliedDate=" + this._runStartTime.getTime());
/*     */     
/*  93 */     for (Map.Entry<Class<?>, Integer> entry : (Iterable<Map.Entry<Class<?>, Integer>>)argStats.exceptionCounts.entrySet()) {
/*  94 */       this._summaryResults
/*  95 */         .println("exception." + ((Class)entry.getKey()).getCanonicalName() + "=" + ((Integer)entry.getValue()).toString());
/*     */     }
/*     */     
/*  98 */     this._summaryResults.println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeSuccess(String argMessage) {
/* 104 */     if (_successLogger.isInfoEnabled())
/* 105 */       _successLogger.info(argMessage); 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataloader\FileResultsWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */