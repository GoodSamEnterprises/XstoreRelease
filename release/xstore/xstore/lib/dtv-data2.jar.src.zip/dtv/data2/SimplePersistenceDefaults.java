/*     */ package dtv.data2;
/*     */ 
/*     */ import dtv.util.CompositeObject;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePersistenceDefaults
/*     */   implements IPersistenceDefaults
/*     */ {
/*     */   private boolean _isTraining = false;
/*  22 */   private long _workstationId = -1L;
/*  23 */   private int _retailLocationId = -1;
/*  24 */   private String _currencyId = "USD";
/*  25 */   private long _organizationId = -1L;
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCurrencyId() {
/*  30 */     return this._currencyId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getOrganizationId() {
/*  36 */     return Long.valueOf(this._organizationId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CompositeObject.TwoPiece<String, String>> getOrgHierarchyAncestry() {
/*  42 */     return Arrays.asList((CompositeObject.TwoPiece<String, String>[])new CompositeObject.TwoPiece[] { CompositeObject.make("*", "*") });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRetailLocationId() {
/*  48 */     return Integer.valueOf(this._retailLocationId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserId() {
/*  54 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getWorkstationId() {
/*  60 */     return Long.valueOf(this._workstationId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTraining() {
/*  66 */     return this._isTraining;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrencyId(String argCurrencyId) {
/*  75 */     this._currencyId = argCurrencyId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrganizationId(long argOrganizationId) {
/*  84 */     this._organizationId = argOrganizationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRetailLocationId(int argRetailLocationId) {
/*  93 */     this._retailLocationId = argRetailLocationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTraining(boolean argIsTraining) {
/* 102 */     this._isTraining = argIsTraining;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkstationId(long argWorkstationId) {
/* 111 */     this._workstationId = argWorkstationId;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\SimplePersistenceDefaults.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */