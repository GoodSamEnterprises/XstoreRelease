/*    */ package dtv.data2.purge.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PurgeRootConfig
/*    */   extends AbstractParentConfig<PurgeGroupConfig>
/*    */ {
/*    */   public static final String CONFIG_NAME = "Root";
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public PurgeRootConfig() {
/* 24 */     super(PurgeGroupConfig.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 30 */     return "ROOT";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 36 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\purge\config\PurgeRootConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */