/*     */ package dtv.data2.purge.config;
/*     */ 
/*     */ import dtv.data2.purge.PurgeMetaData;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import dtv.util.config.ParameterConfig;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractParentConfig<C extends IPurgeConfig>
/*     */   extends AbstractConfig
/*     */   implements IPurgeParentConfig<C>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Class<? extends C> _childClass;
/*     */   private final Map<String, C> _childMap;
/*     */   
/*     */   public AbstractParentConfig(Class<? extends C> argChildClass) {
/*  34 */     this._childClass = argChildClass;
/*  35 */     this._childMap = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public C getChild(String argChildName) {
/*  41 */     return this._childMap.get(normalize(argChildName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<? extends C> getPrioritizedChildren() {
/*  47 */     List<? extends C> sortedChildren = new ArrayList<>(this._childMap.values());
/*  48 */     Collections.sort(sortedChildren);
/*     */     
/*  50 */     return sortedChildren;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/*  56 */     if (this._childClass.isAssignableFrom(argValue.getClass())) {
/*  57 */       IPurgeConfig iPurgeConfig = (IPurgeConfig)this._childClass.cast(argValue);
/*  58 */       this._childMap.put(normalize(iPurgeConfig.getName()), (C)iPurgeConfig);
/*     */     } else {
/*     */       
/*  61 */       super.setConfigObject(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PurgeMetaData callImpl() throws Exception {
/*  70 */     PurgeMetaData purgeData = new PurgeMetaData();
/*     */ 
/*     */ 
/*     */     
/*  74 */     for (IPurgeConfig iPurgeConfig : getPrioritizedChildren()) {
/*     */       
/*  76 */       cascadeParameters((C)iPurgeConfig);
/*  77 */       purgeData.add(iPurgeConfig.call());
/*     */     } 
/*  79 */     return purgeData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cascadeParameters(C argChild) {
/*  90 */     for (Map.Entry<? extends String, ? extends IConfigObject> param : getParameters().entrySet()) {
/*  91 */       ParameterConfig paramConfig = new ParameterConfig(param.getKey(), param.getValue());
/*     */       
/*  93 */       if (checkCascade(paramConfig, argChild)) {
/*  94 */         argChild.setParameter(paramConfig);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkCascade(ParameterConfig argParam, C argChild) {
/* 109 */     return (argChild.getParameterValue(argParam.getName()) == null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDisabledLogMessage(PurgeMetaData argPurgeData) {
/* 115 */     return "--- [" + getDescription() + "] DISABLED ---";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getStartLogMessage() {
/* 121 */     return "--- [" + getDescription() + "] STARTED ---";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSuccessLogMessage(PurgeMetaData argPurgeData) {
/* 127 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 129 */     sb.append("--- [" + getDescription() + "] TOTALS: ---\n");
/* 130 */     sb.append("\trecords = [" + argPurgeData.getRecordsPurged() + "]\n");
/* 131 */     sb.append("\ttables = [" + argPurgeData
/* 132 */         .getTablesPurged() + " / " + argPurgeData.getTablesTargeted() + "]\n");
/* 133 */     sb.append("\ttime = [" + argPurgeData.getPurgeTime() + "]\n");
/*     */     
/* 135 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\purge\config\AbstractParentConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */