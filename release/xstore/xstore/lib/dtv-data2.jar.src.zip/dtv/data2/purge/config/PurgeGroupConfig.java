/*    */ package dtv.data2.purge.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PurgeGroupConfig
/*    */   extends AbstractParentConfig<IPurgeConfig>
/*    */ {
/*    */   public static final String CONFIG_NAME = "Group";
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public PurgeGroupConfig() {
/* 25 */     super(IPurgeConfig.class);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\purge\config\PurgeGroupConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */