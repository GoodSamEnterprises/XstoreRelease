/*     */ package dtv.data2.purge;
/*     */ 
/*     */ import dtv.data2.purge.config.IPurgeConfig;
/*     */ import dtv.data2.purge.config.IPurgeParentConfig;
/*     */ import dtv.data2.purge.config.PurgeConfigHelper;
/*     */ import dtv.util.ClassPathUtils;
/*     */ import dtv.util.EndsWithNameFilter;
/*     */ import dtv.util.INameFilter;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import dtv.util.config.ParameterConfig;
/*     */ import dtv.util.config.StringConfig;
/*     */ import dtv.util.config.SystemPropertiesLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataPurger
/*     */   implements Callable<Void>
/*     */ {
/*  32 */   private static final Logger _logger = Logger.getLogger(DataPurger.class);
/*  33 */   private static final Collection<ParameterConfig> _argParameters = new ArrayList<>();
/*     */   
/*  35 */   private static String _argPurgeGroup = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SPRING_DEFAULT_ACTIVE_PROFILES = "datapurger";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _purgeGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/*  56 */     parseArgs(args);
/*     */     
/*  58 */     (new SystemPropertiesLoader()).loadSystemProperties();
/*     */ 
/*     */     
/*  61 */     String springProfiles = System.getProperty("spring.profiles.active");
/*     */     
/*  63 */     if (springProfiles == null) {
/*  64 */       System.setProperty("spring.profiles.active", "datapurger");
/*     */     }
/*     */     
/*  67 */     String[] files = ClassPathUtils.getDirectoryBasedConfigFileListRelativePaths("spring", (INameFilter)new EndsWithNameFilter(new String[] { ".xml" }));
/*     */ 
/*     */     
/*  70 */     try (ClassPathXmlApplicationContext null = new ClassPathXmlApplicationContext(files)) {
/*     */ 
/*     */       
/*  73 */       (new DataPurger(_argPurgeGroup)).call();
/*     */     } 
/*  75 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void parseArgs(String[] args) {
/*  80 */     for (int i = 0; i < args.length; i++) {
/*  81 */       String arg = args[i];
/*     */       
/*  83 */       if (!arg.startsWith("-")) {
/*  84 */         System.err.println("error: unexpected argument -- " + arg);
/*  85 */         printUsage();
/*  86 */         System.exit(1);
/*     */       } 
/*     */       
/*  89 */       if (arg.equals("-group")) {
/*  90 */         _argPurgeGroup = args[++i];
/*     */       }
/*     */       else {
/*     */         
/*  94 */         _argParameters.add(new ParameterConfig(arg.substring(1), (IConfigObject)new StringConfig(args[++i])));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void printUsage() {
/* 101 */     System.out.println("Usage: java " + DataPurger.class.getName() + "[-group <purge group>]");
/* 102 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataPurger(String argPurgeGroup) {
/* 115 */     this._purgeGroup = argPurgeGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws Exception {
/* 124 */     IPurgeParentConfig<?> purgeRoot = (IPurgeParentConfig)(new PurgeConfigHelper()).getRootConfig();
/* 125 */     IPurgeConfig purgeToRun = getPurgeToRun(purgeRoot);
/*     */     
/* 127 */     String description = purgeToRun.getDescription();
/*     */     
/* 129 */     _logger.info("**********************************************");
/* 130 */     _logger.info("***** START: Purge [" + description + "] *****");
/* 131 */     _logger.info("**********************************************");
/* 132 */     PurgeMetaData purgeData = (PurgeMetaData)purgeToRun.call();
/* 133 */     _logger.info("**********************************************");
/* 134 */     _logger.info("***** END: Purge [" + description + "]: Results = [" + purgeData + "] *****");
/* 135 */     _logger.info("**********************************************");
/*     */     
/* 137 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IPurgeConfig getPurgeToRun(IPurgeParentConfig<?> argPurgeRoot) {
/*     */     IPurgeConfig iPurgeConfig;
/* 148 */     IPurgeParentConfig<?> iPurgeParentConfig = argPurgeRoot;
/*     */     
/* 150 */     if (!StringUtils.isEmpty(this._purgeGroup)) {
/*     */       
/* 152 */       IPurgeConfig purgeGroupToRun = argPurgeRoot.getChild(this._purgeGroup);
/* 153 */       if (purgeGroupToRun != null) {
/* 154 */         iPurgeConfig = purgeGroupToRun;
/*     */       }
/*     */     } 
/*     */     
/* 158 */     for (ParameterConfig param : _argParameters) {
/* 159 */       iPurgeConfig.setParameter(param);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 164 */     iPurgeConfig.setEnabled(true);
/*     */     
/* 166 */     return iPurgeConfig;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\purge\DataPurger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */