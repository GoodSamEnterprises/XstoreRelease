/*     */ package dtv.data2.purge;
/*     */ 
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PurgeMetaData
/*     */ {
/*     */   public static PurgeMetaData makeFailure(Throwable argPurgeError) {
/*  22 */     PurgeMetaData purgeData = new PurgeMetaData();
/*  23 */     purgeData.setPurgeError(argPurgeError);
/*     */     
/*  25 */     return purgeData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PurgeMetaData makeSuccess(int argRecordsPurged, long argPurgeTime) {
/*  36 */     PurgeMetaData purgeData = new PurgeMetaData();
/*  37 */     purgeData.setRecordsPurged(argRecordsPurged);
/*  38 */     purgeData.setPurgeTime(argPurgeTime);
/*     */     
/*  40 */     return purgeData;
/*     */   }
/*     */   
/*  43 */   private int _recordsPurged = 0;
/*  44 */   private int _tablesPurged = 0;
/*  45 */   private int _tablesTargeted = 0;
/*     */   
/*  47 */   private long _purgeTime = 0L;
/*     */   
/*  49 */   private Throwable _purgeError = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(PurgeMetaData argPurgeData) {
/*  58 */     this._purgeTime += argPurgeData.getPurgeTime();
/*  59 */     this._recordsPurged += argPurgeData.getRecordsPurged();
/*  60 */     this._tablesPurged += argPurgeData.getTablesPurged();
/*  61 */     this._tablesTargeted += argPurgeData.getTablesTargeted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getPurgeError() {
/*  69 */     return this._purgeError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getPurgeTime() {
/*  77 */     return this._purgeTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRecordsPurged() {
/*  85 */     return this._recordsPurged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTablesPurged() {
/*  93 */     return this._tablesPurged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTablesTargeted() {
/* 101 */     return this._tablesTargeted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPurgeError(Throwable argPurgeError) {
/* 109 */     this._purgeError = argPurgeError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPurgeTime(long argPurgeTime) {
/* 117 */     this._purgeTime = argPurgeTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecordsPurged(int argRecordsPurged) {
/* 125 */     this._recordsPurged = argRecordsPurged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTablesPurged(int argTablesPurged) {
/* 133 */     this._tablesPurged = argTablesPurged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTablesTargeted(int argTablesTargeted) {
/* 142 */     this._tablesTargeted = argTablesTargeted;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return (new ToStringBuilder(this))
/* 149 */       .append("recordsPurged", getRecordsPurged())
/* 150 */       .append("tablesPurged", getTablesPurged())
/* 151 */       .append("tablesTargeted", getTablesTargeted())
/* 152 */       .append("purgeTime", getPurgeTime())
/* 153 */       .appendSuper(super.toString()).toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\purge\PurgeMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */