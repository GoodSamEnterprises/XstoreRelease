/*     */ package dtv.data2.purge.config;
/*     */ 
/*     */ import dtv.data2.purge.PurgeMetaData;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import dtv.util.config.ParameterConfig;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConfig
/*     */   extends AbstractParentConfig
/*     */   implements IPurgeConfig
/*     */ {
/*  28 */   private static final String CONFIG_NAME = normalize("Name");
/*  29 */   private static final String CONFIG_ORDER = normalize("Order");
/*  30 */   private static final String CONFIG_ENABLED = normalize("Enabled");
/*     */   private static final long serialVersionUID = 1L;
/*  32 */   private static final Logger _logger = Logger.getLogger(AbstractConfig.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String createLogTag(Object... argElements) {
/*  42 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  44 */     if (argElements != null && argElements.length > 0) {
/*  45 */       for (int i = 0; i < argElements.length - 1; i++) {
/*  46 */         sb.append(argElements[i]);
/*  47 */         sb.append("::");
/*     */       } 
/*  49 */       sb.append(argElements[argElements.length - 1]);
/*     */     } 
/*  51 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void log(String argMessage, boolean argError) {
/*  62 */     if (!StringUtils.isEmpty(argMessage)) {
/*  63 */       if (argError) {
/*  64 */         _logger.error(argMessage);
/*     */       } else {
/*     */         
/*  67 */         _logger.info(argMessage);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String normalize(String argValue) {
/*  80 */     return (argValue == null) ? null : argValue.trim().toUpperCase();
/*     */   }
/*     */   
/*  83 */   private final Map<String, IConfigObject> _parameters = new HashMap<>();
/*     */   
/*     */   private String _name;
/*     */   
/*     */   private int _order;
/*     */   
/*     */   private boolean _enabled;
/*     */ 
/*     */   
/*     */   public AbstractConfig() {
/*  93 */     this(null, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractConfig(int argOrder) {
/* 101 */     this(null, argOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractConfig(String argName) {
/* 109 */     this(argName, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractConfig(String argName, int argOrder) {
/* 120 */     this._name = argName;
/* 121 */     this._order = (argOrder < 0) ? Integer.MAX_VALUE : argOrder;
/* 122 */     this._enabled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PurgeMetaData call() throws Exception {
/* 130 */     PurgeMetaData purgeData = null;
/*     */     
/* 132 */     if (!isEnabled()) {
/* 133 */       purgeData = PurgeMetaData.makeSuccess(0, 0L);
/* 134 */       log(getDisabledLogMessage(purgeData), false);
/*     */     } else {
/*     */       
/* 137 */       log(getStartLogMessage(), false);
/*     */ 
/*     */       
/*     */       try {
/* 141 */         purgeData = callImpl();
/* 142 */         log(getSuccessLogMessage(purgeData), false);
/*     */       }
/* 144 */       catch (Exception ex) {
/* 145 */         purgeData = PurgeMetaData.makeFailure(ex);
/* 146 */         log(getFailureLogMessage(purgeData), true);
/*     */       } 
/*     */     } 
/* 149 */     return purgeData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(IPurgeConfig argOther) {
/* 157 */     return getOrder() - argOther.getOrder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object argObj) {
/* 163 */     if (argObj == this) {
/* 164 */       return true;
/*     */     }
/* 166 */     if (!(argObj instanceof AbstractConfig)) {
/* 167 */       return false;
/*     */     }
/* 169 */     AbstractConfig other = (AbstractConfig)argObj;
/* 170 */     return (new EqualsBuilder()).append(getName(), other.getName()).append(getOrder(), other.getOrder())
/* 171 */       .append(getParameters(), other.getParameters()).isEquals();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 177 */     return createLogTag(new Object[] { Integer.valueOf(getOrder()), getName() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 183 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 189 */     return this._order;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IConfigObject getParameterValue(String argParamName) {
/* 195 */     return this._parameters.get(normalize(argParamName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 201 */     return (new HashCodeBuilder(17, 37)).append(getName()).append(getOrder()).append(getParameters())
/* 202 */       .toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 208 */     return this._enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 214 */     String key = normalize(argKey);
/*     */     
/* 216 */     if (CONFIG_NAME.equals(key)) {
/* 217 */       this._name = argValue.toString();
/*     */     }
/* 219 */     else if (CONFIG_ORDER.equals(key)) {
/* 220 */       int configOrder = ConfigUtils.toInt(argValue);
/* 221 */       this._order = (configOrder < 0) ? Integer.MAX_VALUE : configOrder;
/*     */     }
/* 223 */     else if (CONFIG_ENABLED.equals(key)) {
/* 224 */       this._enabled = ConfigUtils.toBoolean(argValue);
/*     */     }
/* 226 */     else if (argValue instanceof ParameterConfig) {
/* 227 */       setParameter((ParameterConfig)argValue);
/*     */     } else {
/*     */       
/* 230 */       setParameter(new ParameterConfig(argKey, argValue));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean argEnabled) {
/* 237 */     this._enabled = argEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setParameter(ParameterConfig argParam) {
/* 244 */     ParameterConfig actualParam = handleParameter(argParam);
/*     */ 
/*     */     
/* 247 */     if (actualParam != null) {
/* 248 */       this._parameters.put(actualParam.getName(), actualParam.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 255 */     return (new ToStringBuilder(this))
/* 256 */       .append("name", getName())
/* 257 */       .append("priority", getOrder())
/* 258 */       .append("parameters", getParameters())
/* 259 */       .appendSuper(super.toString()).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDisabledLogMessage(PurgeMetaData argPurgeData) {
/* 279 */     StringBuilder sb = new StringBuilder(StringUtils.fill(" ", 8));
/* 280 */     sb.append("[-----]");
/* 281 */     sb.append(": purge disabled [");
/* 282 */     sb.append(getDescription() + "]");
/*     */     
/* 284 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFailureLogMessage(PurgeMetaData argPurgeData) {
/* 294 */     return "Purge FAILED [" + this + "]:" + argPurgeData.getPurgeError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<? extends String, ? extends IConfigObject> getParameters() {
/* 304 */     return this._parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getStartLogMessage() {
/* 314 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSuccessLogMessage(PurgeMetaData argPurgeData) {
/* 324 */     StringBuilder sb = new StringBuilder(StringUtils.fill(" ", 8));
/* 325 */     sb.append("[" + argPurgeData.getRecordsPurged());
/* 326 */     sb.append(" @ ");
/* 327 */     sb.append(argPurgeData.getPurgeTime() + " ms]");
/* 328 */     sb.append(": purge sucessful [");
/* 329 */     sb.append(getDescription() + "]");
/*     */     
/* 331 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParameterConfig handleParameter(ParameterConfig argParam) {
/* 344 */     return argParam;
/*     */   }
/*     */   
/*     */   protected abstract PurgeMetaData callImpl() throws Exception;
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\purge\config\AbstractConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */