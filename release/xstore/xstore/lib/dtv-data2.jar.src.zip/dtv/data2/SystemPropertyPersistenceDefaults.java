/*     */ package dtv.data2;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.CompositeObject;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemPropertyPersistenceDefaults
/*     */   implements IPersistenceDefaults
/*     */ {
/*  24 */   private static final Logger logger_ = Logger.getLogger(SystemPropertyPersistenceDefaults.class);
/*     */   
/*     */   private static final String SYS_PROP_ORG_ID = "dtv.xst.orgid";
/*     */   
/*     */   private static final String SYS_PROP_RTL_LOC_ID = "dtv.xst.rtllocid";
/*     */   
/*     */   private static final String SYS_PROP_WKSTN_ID = "dtv.xst.wkstnid";
/*     */   
/*     */   private static final String SYS_PROP_CURRENCY_ID = "dtv.xst.currencyid";
/*     */   
/*     */   private static final String DEFAULT_ORG_ID = "-1";
/*     */   
/*     */   private static final String DEFAULT_RTL_LOC_ID = "-1";
/*     */   
/*     */   private static final String DEFAULT_WKSTN_ID = "-1";
/*     */   
/*     */   private static final String DEFAULT_CURRENCY_ID = "USD";
/*     */   
/*     */   private Long orgId_;
/*     */   
/*     */   private Integer retailLocationId_;
/*     */   
/*     */   private Long workstationId_;
/*     */   
/*     */   private String _currencyId;
/*     */ 
/*     */   
/*     */   public String getCurrencyId() {
/*  52 */     if (this._currencyId != null) {
/*  53 */       return this._currencyId;
/*     */     }
/*     */     
/*  56 */     String prop = System.getProperty("dtv.xst.currencyid", "USD");
/*     */     
/*     */     try {
/*  59 */       this._currencyId = prop;
/*     */     }
/*  61 */     catch (Exception ex) {
/*  62 */       logger_.warn("Bad value: " + prop + " for property " + "dtv.xst.currencyid", ex);
/*  63 */       this._currencyId = "USD";
/*     */     } 
/*     */     
/*  66 */     return this._currencyId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getOrganizationId() {
/*  72 */     if (this.orgId_ != null) {
/*  73 */       return this.orgId_;
/*     */     }
/*     */     
/*  76 */     String prop = System.getProperty("dtv.xst.orgid", "-1");
/*     */     
/*     */     try {
/*  79 */       this.orgId_ = Long.valueOf(prop);
/*     */     }
/*  81 */     catch (Exception ee) {
/*  82 */       throw new DtxException("Could not parse required system property: dtv.xst.orgid VALUE GIVEN: " + prop + " -- the dtx framework cannot determine org id without this property when configured to use SystemPropertyPersistenceDefaults", ee);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  87 */     return this.orgId_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CompositeObject.TwoPiece<String, String>> getOrgHierarchyAncestry() {
/*  93 */     return Arrays.asList((CompositeObject.TwoPiece<String, String>[])new CompositeObject.TwoPiece[] { CompositeObject.make("*", "*") });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRetailLocationId() {
/*  99 */     if (this.retailLocationId_ != null) {
/* 100 */       return this.retailLocationId_;
/*     */     }
/*     */     
/* 103 */     String prop = System.getProperty("dtv.xst.rtllocid", "-1");
/*     */     
/*     */     try {
/* 106 */       this.retailLocationId_ = Integer.valueOf(prop);
/*     */     }
/* 108 */     catch (Exception ee) {
/* 109 */       logger_.warn("Bad value: " + prop + " for propery " + "dtv.xst.rtllocid", ee);
/* 110 */       this.retailLocationId_ = Integer.valueOf("-1");
/*     */     } 
/*     */     
/* 113 */     return this.retailLocationId_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserId() {
/* 119 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getWorkstationId() {
/* 125 */     if (this.workstationId_ != null) {
/* 126 */       return this.workstationId_;
/*     */     }
/*     */     
/* 129 */     String prop = System.getProperty("dtv.xst.wkstnid", "-1");
/*     */     
/*     */     try {
/* 132 */       this.workstationId_ = Long.valueOf(prop);
/*     */     }
/* 134 */     catch (Exception ee) {
/* 135 */       logger_.warn("Bad value: " + prop + " for propery " + "dtv.xst.wkstnid", ee);
/* 136 */       this.workstationId_ = Long.valueOf("-1");
/*     */     } 
/*     */     
/* 139 */     return this.workstationId_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTraining() {
/* 145 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\SystemPropertyPersistenceDefaults.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */