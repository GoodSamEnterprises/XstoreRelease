/*    */ package dtv.data2.security;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 22 */   private final Map<String, SecurityThreadContextConfig> threadContexts_ = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecurityThreadContextConfig getContext(String argName) {
/* 32 */     return this.threadContexts_.get(argName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 38 */     if (argValue instanceof SecurityThreadContextConfig) {
/* 39 */       SecurityThreadContextConfig newConfig = (SecurityThreadContextConfig)argValue;
/* 40 */       SecurityThreadContextConfig prevConfig = this.threadContexts_.get(newConfig.getName());
/* 41 */       newConfig.merge(prevConfig);
/* 42 */       this.threadContexts_.put(newConfig.getName(), newConfig);
/*    */     } else {
/*    */       
/* 45 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\security\SecurityConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */