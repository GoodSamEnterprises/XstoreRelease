/*     */ package dtv.data2.security;
/*     */ 
/*     */ import dtv.util.temp.InjectionHammer;
/*     */ import dtv.util.test.IIncidentReporter;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtvSecurityManager
/*     */ {
/*  17 */   private static final Logger _logger = Logger.getLogger(DtvSecurityManager.class);
/*     */   
/*     */   private static final DtvSecurityManager _instance;
/*  20 */   private static final boolean _allowAllAccess = Boolean.getBoolean("dtv.util.security.AccessWarnings.disable");
/*     */ 
/*     */   
/*     */   static {
/*  24 */     String className = System.getProperty(DtvSecurityManager.class.getName());
/*     */     
/*     */     try {
/*  27 */       instance = (DtvSecurityManager)Class.forName(className).newInstance();
/*     */     }
/*  29 */     catch (Throwable ex) {
/*  30 */       instance = new DtvSecurityManager();
/*     */     } 
/*  32 */     _instance = instance;
/*     */   }
/*     */   @Inject
/*     */   private IIncidentReporter _testHarness;
/*     */   
/*     */   static {
/*     */     DtvSecurityManager instance;
/*     */   }
/*     */   
/*     */   public static DtvSecurityManager getInstance() {
/*  42 */     return _instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtvSecurityManager() {
/*  52 */     InjectionHammer.forceAtInjectProcessing(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String argContext) {
/*  62 */     return isAllowed(argContext, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String argContext, boolean logException) {
/*  73 */     if (_allowAllAccess) {
/*  74 */       return true;
/*     */     }
/*     */     
/*  77 */     SecurityThreadContextConfig context = DtvSecurityConfigHelper.getInstance().getContext(argContext);
/*  78 */     if (context == null) {
/*  79 */       return true;
/*     */     }
/*     */     
/*  82 */     Throwable check = new Throwable("STACK TRACE");
/*  83 */     check.fillInStackTrace();
/*     */     
/*  85 */     boolean allowed = false;
/*  86 */     StackTraceElement ele = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     for (StackTraceElement elem : check.getStackTrace()) {
/*  95 */       if (context.allowed(elem)) {
/*  96 */         allowed = true;
/*     */         
/*     */         break;
/*     */       } 
/* 100 */       if (!context.ignored(elem) && ele == null) {
/* 101 */         ele = elem;
/*     */       }
/*     */     } 
/*     */     
/* 105 */     if (!allowed) {
/* 106 */       if (ele == null) {
/* 107 */         ele = check.getStackTrace()[0];
/*     */       }
/*     */       
/* 110 */       if (logException || this._testHarness.isRunning()) {
/* 111 */         _logger.warn("Illegal access [" + argContext + "] from " + ele
/* 112 */             .getClassName() + "#" + ele.getMethodName(), check);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 117 */       this._testHarness.reportIncident("Illegal access from UI Thread: " + argContext, this);
/*     */     } 
/* 119 */     return allowed;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\security\DtvSecurityManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */