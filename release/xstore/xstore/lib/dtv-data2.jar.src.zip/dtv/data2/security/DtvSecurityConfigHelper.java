/*    */ package dtv.data2.security;
/*    */ 
/*    */ import dtv.util.config.ConfigHelper;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import dtv.util.config.StringConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DtvSecurityConfigHelper
/*    */   extends ConfigHelper<SecurityConfig>
/*    */ {
/* 18 */   public static final String SYSTEM_PROPERTY = DtvSecurityConfigHelper.class.getName();
/*    */   
/*    */   private static DtvSecurityConfigHelper INSTANCE;
/*    */ 
/*    */   
/*    */   static {
/* 24 */     String className = System.getProperty(SYSTEM_PROPERTY);
/*    */     
/*    */     try {
/* 27 */       instance = (DtvSecurityConfigHelper)Class.forName(className).newInstance();
/*    */     }
/* 29 */     catch (Throwable ex) {
/* 30 */       instance = new DtvSecurityConfigHelper();
/*    */     } 
/* 32 */     instance.initialize();
/* 33 */     INSTANCE = instance;
/*    */   }
/*    */ 
/*    */   
/*    */   static {
/*    */     DtvSecurityConfigHelper instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public static DtvSecurityConfigHelper getInstance() {
/* 43 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IConfigObject getConfigObject(String argTagName, String argDtype, String argSourceDescription) {
/* 57 */     if ("Security".equalsIgnoreCase(argDtype)) {
/* 58 */       return (IConfigObject)new SecurityConfig();
/*    */     }
/* 60 */     if ("ThreadContext".equalsIgnoreCase(argDtype)) {
/* 61 */       return (IConfigObject)new SecurityThreadContextConfig();
/*    */     }
/* 63 */     if ("allow".equalsIgnoreCase(argDtype) || "deny"
/* 64 */       .equalsIgnoreCase(argDtype) || "ignore"
/* 65 */       .equalsIgnoreCase(argDtype)) {
/* 66 */       return (IConfigObject)new StringConfig();
/*    */     }
/*    */     
/* 69 */     return super.getConfigObject(argTagName, argDtype, argSourceDescription);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecurityThreadContextConfig getContext(String argName) {
/* 80 */     return ((SecurityConfig)getRootConfig()).getContext(argName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getConfigFileName() {
/* 86 */     return "SecurityConfig";
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\security\DtvSecurityConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */