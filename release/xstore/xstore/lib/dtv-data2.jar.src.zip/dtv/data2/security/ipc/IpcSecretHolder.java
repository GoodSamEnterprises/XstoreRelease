/*    */ package dtv.data2.security.ipc;
/*    */ 
/*    */ import dtv.data2.access.DataFactory;
/*    */ import dtv.data2.access.IQueryKey;
/*    */ import dtv.data2.access.ObjectNotFoundException;
/*    */ import dtv.data2.access.ObjectNotPresentException;
/*    */ import dtv.data2.access.QueryKey;
/*    */ import dtv.ipc.server.AbstractIpcSecretHolder;
/*    */ import dtv.ipc.server.DbPasswordLookupException;
/*    */ import dtv.ipc.server.DbPasswordLookupNoDatabaseException;
/*    */ import dtv.ipc.server.DbPasswordLookupNoRecordsException;
/*    */ import dtv.util.DateUtils;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import oracle.retail.xstore.passwd.totp.TotpSecretGenerator;
/*    */ import org.apache.logging.log4j.Level;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.message.EntryMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IpcSecretHolder
/*    */   extends AbstractIpcSecretHolder
/*    */ {
/* 27 */   private static final Logger LOG = LogManager.getLogger();
/* 28 */   private static final IQueryKey<IpcPasswordResult> LOOKUP_PASSWORD = (IQueryKey<IpcPasswordResult>)new QueryKey("IPC.LOOKUP_PASSWORD", IpcPasswordResult.class);
/*    */   
/* 30 */   private static final IQueryKey<Object[]> INSERT_PASSWORD = (IQueryKey<Object[]>)new QueryKey("IPC.INSERT_PASSWORD", Object[].class);
/*    */   
/* 32 */   private static final IQueryKey<Object[]> UPSERT_PASSWORD_LOCAL = (IQueryKey<Object[]>)new QueryKey("IPC.UPSERT_PASSWORD_LOCAL", Object[].class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void localPasswordSaveDb(String argPassword) {
/* 38 */     EntryMessage e = LOG.traceEntry("localPasswordSaveDb", new org.apache.logging.log4j.util.Supplier[0]);
/* 39 */     Map<String, Object> params = new HashMap<>();
/* 40 */     params.put("argPassword", argPassword);
/* 41 */     params.put("argCreateDate", DateUtils.getNewDate());
/* 42 */     params.put("argCreateUserId", "SYSTEM");
/*    */     try {
/* 44 */       DataFactory.getObjectByQuery(UPSERT_PASSWORD_LOCAL, params);
/*    */     }
/* 46 */     catch (ObjectNotFoundException ex) {
/* 47 */       LOG.catching(Level.WARN, (Throwable)ex);
/*    */     } 
/* 49 */     LOG.traceExit(e);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String lookupPasswordDb() throws DbPasswordLookupException {
/* 56 */     EntryMessage e = LOG.traceEntry("lookupPasswordDb", new org.apache.logging.log4j.util.Supplier[0]);
/*    */     try {
/* 58 */       String password = ((IpcPasswordResult)DataFactory.getObjectByQuery(LOOKUP_PASSWORD, null).get(0)).getPassword();
/* 59 */       LOG.traceExit(e);
/* 60 */       return password;
/*    */     }
/* 62 */     catch (ObjectNotPresentException ex) {
/* 63 */       throw (DbPasswordLookupNoRecordsException)LOG.throwing(new DbPasswordLookupNoRecordsException(ex));
/*    */     }
/* 65 */     catch (Exception ex) {
/* 66 */       throw (DbPasswordLookupNoDatabaseException)LOG.throwing(new DbPasswordLookupNoDatabaseException(ex));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String newPassword() {
/* 73 */     EntryMessage e = LOG.traceEntry("newPassword", new org.apache.logging.log4j.util.Supplier[0]);
/* 74 */     String pwd = (new TotpSecretGenerator()).generateTotpKey();
/* 75 */     Map<String, Object> params = new HashMap<>();
/* 76 */     params.put("argPassword", pwd);
/* 77 */     params.put("argCreateDate", DateUtils.getNewDate());
/* 78 */     params.put("argCreateUserId", "SYSTEM");
/*    */     try {
/* 80 */       DataFactory.getObjectByQuery(INSERT_PASSWORD, params);
/*    */     }
/* 82 */     catch (ObjectNotFoundException ex) {
/*    */ 
/*    */       
/* 85 */       LOG.catching(Level.INFO, (Throwable)ex);
/* 86 */       return localPasswordLookup();
/*    */     } 
/* 88 */     LOG.traceExit(e);
/* 89 */     return pwd;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\security\ipc\IpcSecretHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */