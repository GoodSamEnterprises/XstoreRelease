/*     */ package dtv.data2.security;
/*     */ 
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityThreadContextConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  23 */   private final Collection<String> allow_ = new HashSet<>();
/*  24 */   private final Collection<String> deny_ = new HashSet<>();
/*  25 */   private final Collection<String> ignore_ = new HashSet<>();
/*     */   
/*  27 */   private String name_ = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allowed(StackTraceElement argStackTraceElement) {
/*  36 */     String callingMethod = argStackTraceElement.getClassName() + "#" + argStackTraceElement.getMethodName();
/*  37 */     for (String s : this.deny_) {
/*  38 */       if (callingMethod.startsWith(s)) {
/*  39 */         return false;
/*     */       }
/*     */     } 
/*  42 */     for (String s : this.allow_) {
/*  43 */       if (callingMethod.startsWith(s)) {
/*  44 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  57 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ignored(StackTraceElement argStackTraceElement) {
/*  67 */     if (argStackTraceElement.getClassName().equals(DtvSecurityManager.class.getName())) {
/*  68 */       return true;
/*     */     }
/*     */     
/*  71 */     String callingMethod = argStackTraceElement.getClassName() + "#" + argStackTraceElement.getMethodName();
/*  72 */     for (String s : this.ignore_) {
/*  73 */       if (callingMethod.startsWith(s)) {
/*  74 */         return true;
/*     */       }
/*     */     } 
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(SecurityThreadContextConfig argOther) {
/*  86 */     if (argOther != null) {
/*  87 */       if (!argOther.getName().equals(getName())) {
/*  88 */         throw new IllegalArgumentException();
/*     */       }
/*  90 */       this.allow_.addAll(argOther.allow_);
/*  91 */       this.deny_.addAll(argOther.deny_);
/*  92 */       this.ignore_.addAll(argOther.ignore_);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/*  99 */     if ("allow".equalsIgnoreCase(argKey)) {
/* 100 */       this.allow_.add(argValue.toString());
/*     */     }
/* 102 */     else if ("deny".equalsIgnoreCase(argKey)) {
/* 103 */       this.deny_.add(argValue.toString());
/*     */     }
/* 105 */     else if ("ignore".equalsIgnoreCase(argKey)) {
/* 106 */       this.ignore_.add(argValue.toString());
/*     */     }
/* 108 */     else if ("name".equals(argKey)) {
/* 109 */       this.name_ = argValue.toString();
/*     */     } else {
/*     */       
/* 112 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\security\SecurityThreadContextConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */