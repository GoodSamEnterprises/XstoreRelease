/*     */ package dtv.data2;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLExceptionScrubber
/*     */ {
/*     */   private static final String SCRUB_LOGIN_EXPR = "(?:login failed for user)";
/*     */   private static final String SCRUB_DRIVER_EXPR = "(?:No suitable driver found for)";
/*     */   private static final String SCRUB_URL_EXPR = "(?:sql exception occurred.*Url:)";
/*     */   private static final String SCRUBBED_ERROR_MSG = "[REDACTED]";
/*     */   private static final Pattern _scrubPattern;
/*     */   
/*     */   static {
/*  34 */     String scrubPhrases = "((" + "(?:login failed for user)" + "|" + "(?:No suitable driver found for)" + "|" + "(?:sql exception occurred.*Url:)" + ")\\s*)";
/*     */     
/*  36 */     _scrubPattern = Pattern.compile(scrubPhrases + ".+", 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SQLException scrub(SQLException argEx) {
/*  47 */     return (argEx instanceof ScrubbingException) ? argEx : new ScrubbingException(argEx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String scrub(String argMessage) {
/*  57 */     if (argMessage == null) {
/*  58 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     return _scrubPattern.matcher(argMessage).replaceFirst("$1[REDACTED]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ScrubbingException
/*     */     extends SQLException
/*     */   {
/*     */     private static final long serialVersionUID = -2424320619798452338L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     private static final Pattern _toStringPattern = Pattern.compile(ScrubbingException.class.getName(), 18);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ScrubbingException(SQLException argEx) {
/*  96 */       super(SQLExceptionScrubber.scrub(argEx.getMessage()), argEx.getSQLState(), argEx.getErrorCode(), argEx.getCause());
/*     */       
/*  98 */       if (argEx.getNextException() != null) {
/*  99 */         setNextException(SQLExceptionScrubber.scrub(argEx.getNextException()));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void printStackTrace(PrintStream argStream) {
/* 107 */       super.printStackTrace(new ScrubbingStream(argStream));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void printStackTrace(PrintWriter argWriter) {
/* 114 */       super.printStackTrace(new ScrubbingWriter(argWriter));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 122 */       return _toStringPattern.matcher(super.toString()).replaceAll(SQLException.class.getName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private class ScrubbingStream
/*     */       extends PrintStream
/*     */     {
/*     */       ScrubbingStream(PrintStream argDelegate) {
/* 134 */         super(argDelegate);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void print(String argString) {
/* 140 */         super.print(SQLExceptionScrubber.scrub(argString));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private class ScrubbingWriter
/*     */       extends PrintWriter
/*     */     {
/*     */       ScrubbingWriter(PrintWriter argDelegate) {
/* 153 */         super(argDelegate);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void print(String argString) {
/* 159 */         super.print(SQLExceptionScrubber.scrub(argString));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\SQLExceptionScrubber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */