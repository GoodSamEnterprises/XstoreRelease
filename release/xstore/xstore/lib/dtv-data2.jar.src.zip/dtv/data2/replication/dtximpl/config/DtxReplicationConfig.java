/*    */ package dtv.data2.replication.dtximpl.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DtxReplicationConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String TAG_REPLICATION_QUEUE = "ReplicationQueue";
/*    */   private static final String TAG_SERVICE = "service";
/*    */   private DtxReplicationQueueConfig repQueueConfig_;
/* 26 */   private final Map<String, DtxReplicationServiceConfig> services_ = new HashMap<>(8);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DtxReplicationQueueConfig getReplicationQueueConfig() {
/* 35 */     return this.repQueueConfig_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DtxReplicationServiceConfig[] getServices() {
/* 44 */     return (DtxReplicationServiceConfig[])this.services_.values().toArray((Object[])new DtxReplicationServiceConfig[this.services_.size()]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 50 */     if ("service".equalsIgnoreCase(argKey)) {
/* 51 */       DtxReplicationServiceConfig val = (DtxReplicationServiceConfig)argValue;
/* 52 */       this.services_.put(val.getName(), val);
/*    */     }
/* 54 */     else if ("ReplicationQueue".equalsIgnoreCase(argKey)) {
/* 55 */       this.repQueueConfig_ = (DtxReplicationQueueConfig)argValue;
/*    */     } else {
/*    */       
/* 58 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\DtxReplicationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */