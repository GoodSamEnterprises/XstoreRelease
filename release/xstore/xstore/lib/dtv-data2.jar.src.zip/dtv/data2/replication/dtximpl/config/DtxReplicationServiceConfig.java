/*     */ package dtv.data2.replication.dtximpl.config;
/*     */ 
/*     */ import dtv.data2.replication.ReplicationConfigException;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxReplicationServiceConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  25 */   private final List<ServiceConditionConfig> conditions_ = new ArrayList<>(5);
/*  26 */   private final List<ServiceSubscriberConfig> subscribers_ = new ArrayList<>();
/*     */   
/*  28 */   private String name_ = null;
/*  29 */   private String expireAfter_ = null;
/*  30 */   private ServiceDestinationConfig destination_ = null;
/*     */ 
/*     */   
/*     */   private boolean enabled_ = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ServiceConditionConfig> getConditions() {
/*  38 */     return this.conditions_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceDestinationConfig getDestination() {
/*  46 */     return this.destination_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getExpireAfter() {
/*  55 */     if (StringUtils.isEmpty(this.expireAfter_)) {
/*  56 */       return 0L;
/*     */     }
/*     */     
/*     */     try {
/*  60 */       return Long.parseLong(this.expireAfter_);
/*     */     }
/*  62 */     catch (Exception ee) {
/*  63 */       throw new ReplicationConfigException("Unknown value specified for expireAfter tag: " + this.expireAfter_, ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  75 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ServiceSubscriberConfig> getSubscribers() {
/*  83 */     return this.subscribers_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  91 */     return this.enabled_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExpireImediately() {
/* 100 */     return (!StringUtils.isEmpty(this.expireAfter_) && "immediately".equalsIgnoreCase(this.expireAfter_.trim()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNeverExpires() {
/* 109 */     if (StringUtils.isEmpty(this.expireAfter_) || "never".equalsIgnoreCase(this.expireAfter_.trim())) {
/* 110 */       return true;
/*     */     }
/* 112 */     if (isExpireImediately()) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     return (getExpireAfter() == 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 124 */     if ("name".equalsIgnoreCase(argKey)) {
/* 125 */       this.name_ = argValue.toString();
/*     */     }
/* 127 */     else if ("enabled".equalsIgnoreCase(argKey)) {
/* 128 */       this.enabled_ = ConfigUtils.toBoolean(argValue);
/*     */     }
/* 130 */     else if (argValue instanceof ServiceConditionConfig) {
/* 131 */       this.conditions_.add((ServiceConditionConfig)argValue);
/*     */     }
/* 133 */     else if (argValue instanceof ServiceDestinationConfig) {
/* 134 */       this.destination_ = (ServiceDestinationConfig)argValue;
/*     */     }
/* 136 */     else if ("subscriber".equalsIgnoreCase(argKey)) {
/* 137 */       this.subscribers_.add((ServiceSubscriberConfig)argValue);
/*     */     }
/* 139 */     else if ("expireAfter".equalsIgnoreCase(argKey)) {
/* 140 */       this.expireAfter_ = argValue.toString();
/*     */     } else {
/*     */       
/* 143 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpireAfter(String argExpireAfter) {
/* 153 */     this.expireAfter_ = argExpireAfter;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\DtxReplicationServiceConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */