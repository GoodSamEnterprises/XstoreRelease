/*     */ package dtv.data2.replication.dtximpl;
/*     */ 
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.replication.ReplicationException;
/*     */ import dtv.data2.replication.dtximpl.condition.AbstractReplicationCondition;
/*     */ import dtv.data2.replication.dtximpl.config.ServiceSubscriberConfig;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.IDtxReplicationDispatcher;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxReplicationService
/*     */ {
/*     */   private static final String SUBSCRIBE_TO_ALL = "*";
/*  31 */   private final List<AbstractReplicationCondition> conditions_ = new ArrayList<>(2);
/*     */   
/*     */   private String serviceName_;
/*     */   
/*     */   private String currentDataSource_;
/*     */   private IDtxReplicationDispatcher dispatcher_;
/*     */   private List<ServiceSubscriberConfig> subscribers_;
/*  38 */   private long subscribersExpireAfter_ = 0L;
/*     */ 
/*     */   
/*     */   private boolean subscribersExpireImmediately_ = false;
/*     */ 
/*     */   
/*     */   private boolean subscribersNeverExpire_ = false;
/*     */ 
/*     */   
/*     */   private boolean enabled_ = true;
/*     */ 
/*     */   
/*     */   public void addCondition(AbstractReplicationCondition argCondition) {
/*  51 */     this.conditions_.add(argCondition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDtxReplicationDispatcher.DispatchResult dispatch(ReplicationTransaction argReplicationTransaction) {
/*  70 */     if (argReplicationTransaction == null) {
/*  71 */       throw new ReplicationException("dispatch cannot accept NULL argReplicationLog on service: " + 
/*  72 */           getServiceName());
/*     */     }
/*     */     
/*  75 */     if (!getEnabled()) {
/*  76 */       return IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */     }
/*     */     
/*  79 */     if (this.dispatcher_ == null) {
/*  80 */       throw new ReplicationException("Attempt was made to dispatch replication data while service: " + 
/*  81 */           getServiceName() + " has no dispatcher assigned.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  86 */     return this.dispatcher_.dispatch(argReplicationTransaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCurrentDataSource() {
/*  96 */     return this.currentDataSource_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getEnabled() {
/* 105 */     return this.enabled_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServiceName() {
/* 129 */     return this.serviceName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ServiceSubscriberConfig> getSubscribers() {
/* 138 */     return this.subscribers_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSubscribersExpireAfter() {
/* 147 */     return this.subscribersExpireAfter_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSubscribersExpireImmediately() {
/* 156 */     return this.subscribersExpireImmediately_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSubscribersNeverExpire() {
/* 165 */     return this.subscribersNeverExpire_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isApplicable(Object argToTest) {
/* 175 */     if (!getEnabled()) {
/* 176 */       return false;
/*     */     }
/*     */     
/* 179 */     String persistableId = null;
/*     */     
/* 181 */     if (argToTest instanceof QueryRequest) {
/* 182 */       persistableId = ((QueryRequest)argToTest).getQueryKey();
/*     */     }
/* 184 */     else if (argToTest instanceof String) {
/* 185 */       persistableId = argToTest.toString();
/*     */     } else {
/*     */       
/* 188 */       persistableId = argToTest.getClass().getName();
/*     */     } 
/*     */     
/* 191 */     boolean applicable = false;
/* 192 */     boolean excluded = false;
/*     */     
/* 194 */     for (ServiceSubscriberConfig subscriber : this.subscribers_) {
/* 195 */       if ("*".equalsIgnoreCase(subscriber.getSubscriberName()) || persistableId
/* 196 */         .startsWith(subscriber.getSubscriberName())) {
/*     */         
/* 198 */         if (!subscriber.isExcluded()) {
/* 199 */           applicable = true;
/*     */           continue;
/*     */         } 
/* 202 */         excluded = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     if (applicable && !excluded) {
/*     */ 
/*     */ 
/*     */       
/* 212 */       for (AbstractReplicationCondition c : this.conditions_) {
/* 213 */         if (!c.isCurrentlyMet(this, argToTest)) {
/* 214 */           return false;
/*     */         }
/*     */       } 
/* 217 */       return true;
/*     */     } 
/*     */     
/* 220 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTargeted(String argDataSourceName) {
/* 232 */     return (this.dispatcher_ != null && this.dispatcher_.isTargeted(argDataSourceName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentDataSource(String argCurrentDataSource) {
/* 242 */     this.currentDataSource_ = argCurrentDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDestination(IDtxReplicationDispatcher argDispatcher) {
/* 251 */     if (argDispatcher == null) {
/* 252 */       throw new ReplicationException("addDispatcher cannot accept NULL argDispatcher");
/*     */     }
/* 254 */     this.dispatcher_ = argDispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean argEnabled) {
/* 263 */     this.enabled_ = argEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceName(String argServiceName) {
/* 272 */     this.serviceName_ = argServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubscribers(List<ServiceSubscriberConfig> argSubscribers) {
/* 281 */     this.subscribers_ = argSubscribers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubscribersExpireAfter(long argSubscribersExpireAfter) {
/* 290 */     this.subscribersExpireAfter_ = argSubscribersExpireAfter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubscribersExpireImmediately(boolean argSubscribersExpireImmediately) {
/* 299 */     this.subscribersExpireImmediately_ = argSubscribersExpireImmediately;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubscribersNeverExpire(boolean argSubscribersNeverExpire) {
/* 308 */     this.subscribersNeverExpire_ = argSubscribersNeverExpire;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 314 */     return (new ToStringBuilder(this)).append(this.serviceName_).toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\DtxReplicationService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */