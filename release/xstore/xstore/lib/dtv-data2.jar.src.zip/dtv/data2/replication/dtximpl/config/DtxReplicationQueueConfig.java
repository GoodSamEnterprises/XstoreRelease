/*     */ package dtv.data2.replication.dtximpl.config;
/*     */ 
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxReplicationQueueConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int DEFAULT_CYCLE_INTERVAL = 10000;
/*     */   private static final int DEFAULT_MAX_RECRORDS = 50;
/*     */   private static final int DEFAULT_FAILURE_COUNT_RESET_INTERVAL = 600000;
/*     */   private static final int DEFAULT_ERROR_NOTIFICATION_CYCLES = 180;
/*     */   private String dataSource_;
/*     */   private int cycleInterval_;
/*     */   private int maxRecsPerCycle_;
/*  29 */   private int offlineFailureCountResetInterval_ = 600000;
/*  30 */   private int errorNotificationCycles_ = 180;
/*     */   
/*  32 */   private long workstationStart_ = -1L;
/*  33 */   private long workstationEnd_ = -1L;
/*     */   
/*  35 */   private final List<RelegationLevelConfig> relegationLevels_ = new ArrayList<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCycleInterval() {
/*  43 */     return this.cycleInterval_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSource() {
/*  52 */     return this.dataSource_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorNotificationCycles() {
/*  61 */     return this.errorNotificationCycles_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxRecsPerCycle() {
/*  70 */     return this.maxRecsPerCycle_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOfflineFailureCountResetInterval() {
/*  79 */     return this.offlineFailureCountResetInterval_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<RelegationLevelConfig> getRelegationLevels() {
/*  88 */     return this.relegationLevels_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getWorkstationEnd() {
/*  97 */     return this.workstationEnd_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getWorkstationStart() {
/* 106 */     return this.workstationStart_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 114 */     if ("dataSource".equalsIgnoreCase(argKey)) {
/* 115 */       this.dataSource_ = argValue.toString();
/*     */     }
/* 117 */     else if ("cycleInterval".equalsIgnoreCase(argKey)) {
/* 118 */       this.cycleInterval_ = ConfigUtils.toInt(argValue, 10000);
/*     */     }
/* 120 */     else if ("errorNotificationCycles".equalsIgnoreCase(argKey)) {
/* 121 */       this.errorNotificationCycles_ = ConfigUtils.toInt(argValue, 180);
/*     */     }
/* 123 */     else if ("maxRecsPerCycle".equalsIgnoreCase(argKey)) {
/* 124 */       this.maxRecsPerCycle_ = ConfigUtils.toInt(argValue, 50);
/*     */     }
/* 126 */     else if ("offlineFailureCountResetInterval".equalsIgnoreCase(argKey)) {
/* 127 */       this.offlineFailureCountResetInterval_ = ConfigUtils.toInt(argValue, 600000);
/*     */     }
/* 129 */     else if ("workstationStart".equalsIgnoreCase(argKey)) {
/* 130 */       this.workstationStart_ = ConfigUtils.toLong(argValue);
/*     */     }
/* 132 */     else if ("workstationEnd".equalsIgnoreCase(argKey)) {
/* 133 */       this.workstationEnd_ = ConfigUtils.toLong(argValue);
/*     */     }
/* 135 */     else if (argValue instanceof RelegationLevelConfig) {
/* 136 */       this.relegationLevels_.add((RelegationLevelConfig)argValue);
/*     */     } else {
/*     */       
/* 139 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\DtxReplicationQueueConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */