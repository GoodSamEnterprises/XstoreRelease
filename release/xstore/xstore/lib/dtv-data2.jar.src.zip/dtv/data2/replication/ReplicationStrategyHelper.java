/*    */ package dtv.data2.replication;
/*    */ 
/*    */ import dtv.util.StringUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicationStrategyHelper
/*    */ {
/* 17 */   private static final Logger logger_ = Logger.getLogger(ReplicationStrategyHelper.class);
/*    */   
/*    */   private static final String PROP_ENABLED = "dtv.data2.replication.enabled";
/*    */   
/*    */   private static final String PROP_STRATEGY = "dtv.data2.replication.strategy";
/*    */   
/*    */   private static final String DEFAULT_STRATEGY = "dtv.data2.replication.dtximpl.DtxReplicationStrategy";
/*    */   
/*    */   private static IReplicationStrategy currentStrategy_;
/*    */ 
/*    */   
/*    */   public static void disableReplication() {
/* 29 */     initialize(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IReplicationStrategy getReplicationStategy() {
/* 38 */     return currentStrategy_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void initialize() {
/*    */     try {
/* 46 */       String prop = System.getProperty("dtv.data2.replication.enabled", "OFF").trim();
/* 47 */       if (StringUtils.isEmpty(prop)) {
/* 48 */         prop = "OFF";
/*    */       }
/* 50 */       initialize(!"OFF".equalsIgnoreCase(prop));
/*    */     }
/* 52 */     catch (Exception ee) {
/* 53 */       String msg = "Static init error.";
/* 54 */       logger_.error(msg, ee);
/* 55 */       throw new ReplicationConfigException(msg, ee);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void initialize(boolean argReplicationEnabled) {
/* 65 */     String strategy = null;
/*    */     try {
/* 67 */       if (argReplicationEnabled) {
/* 68 */         strategy = System.getProperty("dtv.data2.replication.strategy", "dtv.data2.replication.dtximpl.DtxReplicationStrategy");
/* 69 */         currentStrategy_ = (IReplicationStrategy)Class.forName(strategy).newInstance();
/*    */       } else {
/*    */         
/* 72 */         currentStrategy_ = null;
/*    */       }
/*    */     
/* 75 */     } catch (Exception ex) {
/* 76 */       String msg = "An unexpected error occurred while instantiating replication strategy: " + strategy + ". Replication will not be available.";
/*    */ 
/*    */       
/* 79 */       logger_.error(msg, ex);
/* 80 */       throw new ReplicationConfigException(msg, ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isReplicationEnabled() {
/* 90 */     return (currentStrategy_ != null);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\ReplicationStrategyHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */