/*     */ package dtv.data2.replication.dtximpl;
/*     */ 
/*     */ import dtv.data2.access.impl.PersistenceStrategyFactory;
/*     */ import dtv.data2.replication.ReplicationException;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationConfigHelper;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationServiceConfig;
/*     */ import dtv.data2.replication.dtximpl.config.ServiceConditionConfig;
/*     */ import dtv.data2.replication.dtximpl.config.ServiceDestinationConfig;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.DataSourceDispatcher;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.DataSourceListDispatcher;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.ForwardingDispatcher;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.IDtxReplicationDispatcher;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxReplicationServiceFactory
/*     */ {
/*     */   private Map<String, DtxReplicationServiceConfig> serviceConfigs_;
/*     */   private List<DtxReplicationService> serviceTemplates_;
/*     */   @Inject
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */   
/*     */   public synchronized List<String> getApplicableServices(String argCurrentDataSource, Object argToTest, List<String> argExcludedDataSources) {
/*  40 */     List<String> applicableList = new ArrayList<>(this.serviceConfigs_.size());
/*     */     
/*  42 */     for (DtxReplicationService service : this.serviceTemplates_) {
/*  43 */       service.setCurrentDataSource(argCurrentDataSource);
/*     */       
/*  45 */       if (service.isApplicable(argToTest)) {
/*  46 */         boolean applicable = true;
/*     */ 
/*     */ 
/*     */         
/*  50 */         if (argExcludedDataSources != null) {
/*  51 */           for (String excludedDS : argExcludedDataSources) {
/*  52 */             if (service.isTargeted(excludedDS)) {
/*  53 */               applicable = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*  59 */         if (applicable) {
/*  60 */           applicableList.add(service.getServiceName());
/*     */         }
/*     */       } 
/*     */     } 
/*  64 */     return applicableList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplicationTransaction getNewTransaction(String argServiceName) {
/*  74 */     DtxReplicationService serviceTemplate = null;
/*     */     
/*  76 */     for (DtxReplicationService service : this.serviceTemplates_) {
/*  77 */       if (argServiceName.equals(service.getServiceName())) {
/*  78 */         serviceTemplate = service;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  83 */     if (serviceTemplate == null) {
/*  84 */       throw new ReplicationException("Attempt was made to retieve unknown replication service for name: " + argServiceName);
/*     */     }
/*     */ 
/*     */     
/*  88 */     ReplicationTransaction trans = new ReplicationTransaction();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     trans.setOrganizationId(ReplicationQueueAccessor.getInstance().getOrganizationId());
/*  95 */     trans.setRetailLocationId(ReplicationQueueAccessor.getInstance().getRetailLocationId());
/*  96 */     trans.setWorkstationId(ReplicationQueueAccessor.getInstance().getWorkstationId());
/*  97 */     trans.setCreatedTime(ReplicationUniqueTimestampFactory.getInstance().getCurrentTime());
/*  98 */     trans.setNewTransaction(true);
/*  99 */     trans.setServiceName(argServiceName);
/*     */     
/* 101 */     if (serviceTemplate.getSubscribersNeverExpire()) {
/* 102 */       trans.setNeverExpires(true);
/*     */     }
/* 104 */     else if (serviceTemplate.getSubscribersExpireImmediately()) {
/* 105 */       trans.setExpiresImmediately(true);
/*     */     } else {
/*     */       
/* 108 */       trans.setExpiresAfter(serviceTemplate.getSubscribersExpireAfter());
/*     */     } 
/*     */     
/* 111 */     return trans;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxReplicationService getService(String argServiceName) {
/* 121 */     return getService(null, argServiceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxReplicationService getService(String argCurrentDataSource, String argServiceName) {
/*     */     ForwardingDispatcher forwardingDispatcher;
/* 132 */     if (StringUtils.isEmpty(argServiceName)) {
/* 133 */       throw new ReplicationException("Cannot get service for null or empty service name");
/*     */     }
/*     */     
/* 136 */     DtxReplicationServiceConfig config = this.serviceConfigs_.get(argServiceName);
/*     */     
/* 138 */     if (config == null) {
/* 139 */       throw new ReplicationException("Attempt was made to retrieve unknown replication service for name: " + argServiceName);
/*     */     }
/*     */ 
/*     */     
/* 143 */     DtxReplicationService service = new DtxReplicationService();
/* 144 */     service.setEnabled(config.isEnabled());
/* 145 */     service.setServiceName(config.getName());
/* 146 */     service.setSubscribers(config.getSubscribers());
/* 147 */     service.setCurrentDataSource(argCurrentDataSource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (config.isNeverExpires()) {
/* 154 */       service.setSubscribersNeverExpire(true);
/*     */     
/*     */     }
/* 157 */     else if (config.isExpireImediately()) {
/* 158 */       service.setSubscribersExpireImmediately(true);
/*     */     } else {
/*     */       
/* 161 */       service.setSubscribersExpireAfter(config.getExpireAfter());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     for (ServiceConditionConfig con : config.getConditions()) {
/* 170 */       service.addCondition(con.getCondition());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     ServiceDestinationConfig destinationConfig = config.getDestination();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (StringUtils.isEmpty(destinationConfig.getType())) {
/* 182 */       throw new ReplicationException("Replication service " + service.getServiceName() + " does not properly define a destination. destination type is null or empty");
/*     */     }
/*     */ 
/*     */     
/* 186 */     IDtxReplicationDispatcher dispatcher = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     if ("DataSource".equals(destinationConfig.getType())) {
/* 193 */       String dataSourceName = destinationConfig.getDataSourceName();
/* 194 */       DataSourceDispatcher dataSourceDispatcher = new DataSourceDispatcher(dataSourceName, this._persistenceStrategyFactory);
/*     */     }
/* 196 */     else if ("DataSourceList".equals(destinationConfig.getType())) {
/* 197 */       List<String> dataSourceList = new ArrayList<>();
/*     */       
/* 199 */       for (String dataSourceName : destinationConfig.getDataSourceList()) {
/* 200 */         dataSourceList.add(dataSourceName);
/*     */       }
/*     */       
/* 203 */       DataSourceListDispatcher dataSourceListDispatcher = new DataSourceListDispatcher(dataSourceList, this._persistenceStrategyFactory);
/*     */     }
/* 205 */     else if ("DataSourceForwarding".equals(destinationConfig.getType())) {
/*     */       
/* 207 */       forwardingDispatcher = new ForwardingDispatcher(destinationConfig.getDataSourceName(), destinationConfig.getDestinationServiceName());
/*     */     } else {
/*     */       
/* 210 */       throw new ReplicationException("Unknown destination type: " + destinationConfig.getType());
/*     */     } 
/*     */     
/* 213 */     service.setDestination((IDtxReplicationDispatcher)forwardingDispatcher);
/* 214 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 221 */     DtxReplicationServiceConfig[] serviceConfigsArray = DtxReplicationConfigHelper.getServiceConfigs();
/*     */     
/* 223 */     this.serviceTemplates_ = new ArrayList<>(serviceConfigsArray.length);
/* 224 */     this.serviceConfigs_ = new HashMap<>(serviceConfigsArray.length);
/*     */     
/* 226 */     for (DtxReplicationServiceConfig config : serviceConfigsArray) {
/*     */       
/* 228 */       if (config.isEnabled()) {
/* 229 */         this.serviceConfigs_.put(config.getName(), config);
/* 230 */         this.serviceTemplates_.add(getService(null, config.getName()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReplicationCandidate(String argCurrentDataSource, Object argToTest, List<String> argExcludedDataSources) {
/* 246 */     return !getApplicableServices(argCurrentDataSource, argToTest, argExcludedDataSources).isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\DtxReplicationServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */