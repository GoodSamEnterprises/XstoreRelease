/*     */ package dtv.data2.replication.dtximpl.dispatcher;
/*     */ 
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.PersistenceStrategyFactory;
/*     */ import dtv.data2.access.impl.remote.AbstractHttpDatasource;
/*     */ import dtv.data2.access.impl.remote.servlet.ServletPersistenceStrategy;
/*     */ import dtv.data2.access.pm.PersistenceManagerStatus;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.access.transaction.DataSourceTransactionManager;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import dtv.data2.replication.dtximpl.ReplicationTransaction;
/*     */ import dtv.util.DateUtils;
/*     */ import dtv.util.DtvDate;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceDispatcher
/*     */   implements IDtxReplicationDispatcher
/*     */ {
/*  40 */   private static final Logger auditLogger_ = Logger.getLogger("REPLICATION_AUDIT_LOG");
/*  41 */   private static final Logger successJournalLogger_ = Logger.getLogger("dtv.data2.replication.journal");
/*     */ 
/*     */ 
/*     */   
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private String _dataSourceName;
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSourceDispatcher(String argDataSourceName, PersistenceStrategyFactory argPersistenceStrategyFactory) {
/*  54 */     this(argPersistenceStrategyFactory);
/*  55 */     this._dataSourceName = argDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSourceDispatcher(PersistenceStrategyFactory argPersistenceStrategyFactory) {
/*  64 */     this._persistenceStrategyFactory = argPersistenceStrategyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IDtxReplicationDispatcher.DispatchResult dispatch(ReplicationTransaction argReplicationLog) {
/*  70 */     return dispatchImpl(this._dataSourceName, argReplicationLog);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDestination() {
/*  76 */     return this._dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  82 */     return DataSourceFactory.isDataSourceEnabled(this._dataSourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTargeted(String argDataSourceName) {
/*  88 */     boolean isTargeted = StringUtils.equalsIgnoreCase(this._dataSourceName, argDataSourceName);
/*  89 */     return isTargeted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureDatasource(IPersistenceStrategy argStrategy) {
/*  99 */     if (argStrategy instanceof AbstractHttpDatasource) {
/* 100 */       ((AbstractHttpDatasource)argStrategy)
/* 101 */         .setTimeout(((AbstractHttpDatasource)argStrategy).getTimeout() * 2);
/*     */     }
/*     */ 
/*     */     
/* 105 */     if (argStrategy instanceof ServletPersistenceStrategy) {
/* 106 */       ((ServletPersistenceStrategy)argStrategy).setMessageType(ServletPersistenceStrategy.MessageType.REPLICATE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDtxReplicationDispatcher.DispatchResult dispatchImpl(String argDataSourceName, ReplicationTransaction argReplicationLog) {
/* 119 */     if (auditLogger_.isDebugEnabled()) {
/* 120 */       auditLogger_.debug("DataSourceDispather about to dispatch trans: " + argReplicationLog
/* 121 */           .getTransactionId() + " to datasource: " + argDataSourceName);
/*     */     }
/*     */     
/* 124 */     TransactionToken token = null;
/*     */     
/*     */     try {
/* 127 */       token = new TransactionToken(argReplicationLog.getTransactionId().hashCode());
/* 128 */       String timestamp = DateUtils.formatReplicationDate((Date)new DtvDate(argReplicationLog.getCreatedTime()));
/* 129 */       token.setProperty("TIMESTAMP_PROPERTY", timestamp);
/* 130 */       token.setProperty("WORKSTATION_ID_PROPERTY", 
/* 131 */           String.valueOf(argReplicationLog.getWorkstationId()));
/*     */       
/* 133 */       if (!DataSourceFactory.isDataSourceEnabled(argDataSourceName)) {
/* 134 */         auditLogger_.info("Data not replicated because datasource: " + argDataSourceName + " is disabled. Replication trans id: " + argReplicationLog
/* 135 */             .getTransactionId());
/*     */         
/* 137 */         return IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */       } 
/*     */       
/* 140 */       if (PersistenceManagerStatus.ONLINE != StatusMgr.getInstance().getDataSourceStatus(argDataSourceName)) {
/* 141 */         auditLogger_.info("Data not replicated because datasource: " + argDataSourceName + " is not online. Replication trans id: " + argReplicationLog
/* 142 */             .getTransactionId());
/*     */         
/* 144 */         return IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */       } 
/*     */ 
/*     */       
/* 148 */       DataSourceDescriptor dataSource = DataSourceFactory.getInstance().getDataSourceDescriptor(argDataSourceName);
/*     */ 
/*     */       
/* 151 */       IPersistenceStrategy _persistenceStrategy = this._persistenceStrategyFactory.createStrategy(dataSource, true);
/*     */       
/* 153 */       configureDatasource(_persistenceStrategy);
/* 154 */       List<IPersistable> persistables = argReplicationLog.getPersistables();
/*     */       
/* 156 */       for (IPersistable persistable : persistables) {
/* 157 */         _persistenceStrategy.makePersistent(token, persistable);
/*     */       }
/*     */       
/* 160 */       DataSourceTransactionManager.getInstance().commit(token);
/*     */       
/* 162 */       if (auditLogger_.isInfoEnabled()) {
/* 163 */         auditLogger_.info("----- Data Replicated OK to [" + argDataSourceName + "] Data: " + argReplicationLog
/* 164 */             .getPersistablesAsXml() + " replication trans id " + argReplicationLog
/* 165 */             .getTransactionId() + " replication service name: " + argReplicationLog
/* 166 */             .getServiceName());
/*     */       }
/*     */       
/* 169 */       if (successJournalLogger_.isInfoEnabled()) {
/* 170 */         successJournalLogger_.info(getSuccessJournalEntry(_persistenceStrategy, argReplicationLog));
/*     */       }
/*     */       
/* 173 */       return IDtxReplicationDispatcher.DispatchResult.DISPATCH_SUCCESSFUL;
/*     */     }
/* 175 */     catch (Exception ee) {
/* 176 */       if (token != null) {
/* 177 */         DataSourceTransactionManager.getInstance().rollback(token);
/*     */       }
/* 179 */       boolean offline = false;
/*     */ 
/*     */       
/* 182 */       if (!ReplicationPossibleFilter.getInstance().isReplicationPossible(ee)) {
/* 183 */         auditLogger_.warn("Data not replicated to datasource [" + argDataSourceName + "] because replication is impossible. Replication trans id: " + argReplicationLog
/*     */             
/* 185 */             .getTransactionId() + " Cause: " + ee.toString());
/*     */         
/* 187 */         return IDtxReplicationDispatcher.DispatchResult.DISPATCH_IMPOSSIBLE_TO_REPLICATE;
/*     */       } 
/*     */ 
/*     */       
/* 191 */       if (ee instanceof dtv.data2.access.exception.ServletFailoverException) {
/*     */ 
/*     */         
/* 194 */         offline = FailoverException.isFailover(new Exception(ee.getMessage()));
/*     */       } else {
/*     */         
/* 197 */         offline = FailoverException.isFailover(ee);
/*     */       } 
/* 199 */       if (offline) {
/* 200 */         if (auditLogger_.isDebugEnabled()) {
/* 201 */           auditLogger_.debug("Dispatch to datasource: [" + argDataSourceName + "] of trans: [" + argReplicationLog
/* 202 */               .getTransactionId() + "] FAILED b/c of Failover. " + ee.toString());
/*     */         }
/*     */         
/* 205 */         return IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */       } 
/*     */       
/* 208 */       auditLogger_
/* 209 */         .warn("An error occurred while attempting to dispatch to datasource: [" + argDataSourceName + "] " + ee
/* 210 */           .toString() + " replication trans id " + argReplicationLog.getTransactionId());
/*     */       
/* 212 */       return IDtxReplicationDispatcher.DispatchResult.DISPATCH_ERROR_FAILURE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSuccessJournalEntry(IPersistenceStrategy argStrategy, ReplicationTransaction argReplicationTrans) {
/* 228 */     String source = argReplicationTrans.getOrganizationId() + "::" + argReplicationTrans.getRetailLocationId() + "::" + argReplicationTrans.getWorkstationId();
/*     */     
/* 230 */     String entry = "<replication status=\"success\" timestamp=\"%s\" source=\"%s\" destination=\"%s\">%s</replication>";
/*     */ 
/*     */     
/* 233 */     return String.format(entry, new Object[] { DateUtils.formatIsoDateTime(new Date()), source, argStrategy
/* 234 */           .getDataSourceName(), argReplicationTrans.getPersistablesAsXml() });
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\dispatcher\DataSourceDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */