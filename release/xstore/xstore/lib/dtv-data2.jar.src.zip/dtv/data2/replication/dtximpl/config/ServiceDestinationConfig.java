/*     */ package dtv.data2.replication.dtximpl.config;
/*     */ 
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceDestinationConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String TAG_TYPE = "type";
/*     */   private static final String TAG_DATA_SOURCE_NAME = "dataSourceName";
/*     */   private static final String TAG_DATA_SOURCE_LIST = "dataSourceList";
/*     */   private static final String TAG_DESTINATION_SERVICE_NAME = "destinationService";
/*     */   private String type_;
/*     */   private String dataSourceName_;
/*     */   private List<String> dataSourceList_;
/*     */   private String destinationServiceName_;
/*     */   private String hostIp_;
/*     */   private int hostPort_;
/*     */   private String directory_;
/*     */   private int timeout_;
/*     */   
/*     */   public List<String> getDataSourceList() {
/*  45 */     return this.dataSourceList_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/*  54 */     return this.dataSourceName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDestinationServiceName() {
/*  63 */     return this.destinationServiceName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDirectory() {
/*  72 */     return this.directory_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHostIp() {
/*  81 */     return this.hostIp_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHostPort() {
/*  90 */     return this.hostPort_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeout() {
/*  99 */     return this.timeout_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 108 */     return this.type_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 114 */     if ("type".equalsIgnoreCase(argKey)) {
/* 115 */       this.type_ = argValue.toString();
/*     */     }
/* 117 */     else if ("dataSourceName".equalsIgnoreCase(argKey)) {
/* 118 */       this.dataSourceName_ = argValue.toString();
/*     */     }
/* 120 */     else if ("dataSourceList".equalsIgnoreCase(argKey)) {
/*     */       
/* 122 */       String list = argValue.toString();
/* 123 */       String[] divided = list.split(";");
/* 124 */       if (divided != null && divided.length > 0) {
/* 125 */         this.dataSourceList_ = new ArrayList<>(divided.length);
/* 126 */         for (int ii = 0; ii < divided.length; ii++) {
/* 127 */           this.dataSourceList_.add(divided[ii].trim());
/*     */         }
/*     */       }
/*     */     
/* 131 */     } else if ("destinationService".equalsIgnoreCase(argKey)) {
/* 132 */       this.destinationServiceName_ = argValue.toString();
/*     */     } else {
/*     */       
/* 135 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String argDataSourceName) {
/* 145 */     this.dataSourceName_ = argDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDestinationServiceName(String argDestinationServiceName) {
/* 154 */     this.destinationServiceName_ = argDestinationServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectory(String argDirectory) {
/* 163 */     this.directory_ = argDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHostIp(String argHostIp) {
/* 172 */     this.hostIp_ = argHostIp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHostPort(int argHostPort) {
/* 181 */     this.hostPort_ = argHostPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(int argTimeout) {
/* 190 */     this.timeout_ = argTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String argType) {
/* 199 */     this.type_ = argType;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\ServiceDestinationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */