/*     */ package dtv.data2.replication.dtximpl;
/*     */ 
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.replication.ReplicationException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationTransaction
/*     */ {
/*     */   private String serviceName_;
/*     */   private String transactionId_;
/*  26 */   private long organizationId_ = 0L;
/*  27 */   private int retailLocationId_ = 0;
/*  28 */   private long workstationId_ = 0L;
/*     */   
/*  30 */   private long createdTime_ = 0L;
/*  31 */   private long expiresAfter_ = 0L;
/*  32 */   private List<String> dataXmlStrings_ = new ArrayList<>();
/*     */   private boolean expireImmediately_ = false;
/*     */   private boolean neverExpires_ = false;
/*     */   private boolean newTransaction_ = true;
/*  36 */   private int failedOfflineAttempts_ = 0;
/*  37 */   private int failedErrorAttempts_ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDataAsXmlString(String argXmlString) {
/* 100 */     this.dataXmlStrings_.add(argXmlString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getCreatedTime() {
/* 110 */     return this.createdTime_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getExpiresAfter() {
/* 119 */     if (this.expireImmediately_) {
/* 120 */       throw new ReplicationException("Invalid call to getExpiresAfter().  expireImmediately_ is true,  so getExpiresAfter() is undefined.");
/*     */     }
/*     */ 
/*     */     
/* 124 */     if (this.neverExpires_) {
/* 125 */       throw new ReplicationException("Invalid call to getExpiresAfter().  neverExpires_ is true,  so getExpiresAfter() is undefined.");
/*     */     }
/*     */ 
/*     */     
/* 129 */     return this.expiresAfter_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getExpiresImmediately() {
/* 138 */     return this.expireImmediately_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFailedErrorAttempts() {
/* 147 */     return this.failedErrorAttempts_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFailedOfflineAttempts() {
/* 156 */     return this.failedOfflineAttempts_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getNeverExpires() {
/* 165 */     return this.neverExpires_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getNewTransaction() {
/* 174 */     return this.newTransaction_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getOrganizationId() {
/* 183 */     return this.organizationId_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IPersistable> getPersistables() {
/* 192 */     String dataXmlString = getPersistablesAsXml();
/* 193 */     String docType = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE ConfigData [ <!ENTITY tilde \"&#126;\"> ]>";
/*     */ 
/*     */     
/* 196 */     StringBuilder buff = new StringBuilder(docType.length() + dataXmlString.length() + 15);
/* 197 */     buff.append(docType);
/* 198 */     buff.append("<data>");
/* 199 */     buff.append(dataXmlString);
/* 200 */     buff.append("</data>");
/*     */     try {
/* 202 */       return DaoUtils.getPersistablesForXml(buff.toString());
/*     */     }
/* 204 */     catch (Exception ee) {
/* 205 */       throw new ReplicationException("An error occurred while parsing XML: " + dataXmlString, ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPersistablesAsXml() {
/* 215 */     StringBuilder builder = new StringBuilder();
/* 216 */     for (String xmlString : this.dataXmlStrings_) {
/* 217 */       builder.append(xmlString);
/*     */     }
/* 219 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRetailLocationId() {
/* 228 */     return this.retailLocationId_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServiceName() {
/* 237 */     return this.serviceName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransactionId() {
/* 248 */     return this.transactionId_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getWorkstationId() {
/* 257 */     return this.workstationId_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementErrorFailures() {
/* 264 */     this.failedErrorAttempts_++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementOfflineFailures() {
/* 271 */     this.failedOfflineAttempts_++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExpired() {
/* 281 */     if (this.neverExpires_) {
/* 282 */       return false;
/*     */     }
/*     */     
/* 285 */     if (this.expireImmediately_) {
/* 286 */       return true;
/*     */     }
/*     */     
/* 289 */     long now = System.currentTimeMillis();
/*     */     
/* 291 */     if (this.createdTime_ + this.expiresAfter_ < now) {
/* 292 */       return true;
/*     */     }
/*     */     
/* 295 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCreatedTime(long argDateTimeCreated) {
/* 306 */     this.createdTime_ = argDateTimeCreated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpiresAfter(long argExpiresAfter) {
/* 315 */     this.expiresAfter_ = argExpiresAfter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpiresImmediately(boolean argExpiresImmediately) {
/* 324 */     this.expireImmediately_ = argExpiresImmediately;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailedErrorAttempts(int argFailedErrorAttempts) {
/* 333 */     this.failedErrorAttempts_ = argFailedErrorAttempts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailedOfflineAttempts(int argFailedOfflineAttempts) {
/* 342 */     this.failedOfflineAttempts_ = argFailedOfflineAttempts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNeverExpires(boolean argNeverExpires) {
/* 351 */     if (argNeverExpires && this.expireImmediately_) {
/* 352 */       throw new ReplicationException("A replication transaction cannot never expire and immediately expireat the same time. " + this);
/*     */     }
/*     */     
/* 355 */     this.neverExpires_ = argNeverExpires;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNewTransaction(boolean argNewTransaction) {
/* 364 */     this.newTransaction_ = argNewTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrganizationId(long argOrganizationId) {
/* 373 */     this.organizationId_ = argOrganizationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRetailLocationId(int argRetailLocationId) {
/* 382 */     this.retailLocationId_ = argRetailLocationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceName(String argServiceName) {
/* 391 */     this.serviceName_ = argServiceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionId(String argTransactionId) {
/* 402 */     this.transactionId_ = argTransactionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkstationId(long argWorkstationId) {
/* 411 */     this.workstationId_ = argWorkstationId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 417 */     StringBuilder buf = new StringBuilder(512);
/*     */     
/* 419 */     buf.append(super.toString());
/* 420 */     buf.append(":");
/* 421 */     buf.append(this.organizationId_);
/* 422 */     buf.append(":");
/* 423 */     buf.append(this.serviceName_);
/* 424 */     buf.append(":");
/* 425 */     buf.append(new Date(this.createdTime_));
/* 426 */     buf.append(":");
/* 427 */     buf.append(getPersistablesAsXml());
/* 428 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\ReplicationTransaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */