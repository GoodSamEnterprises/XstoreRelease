/*    */ package dtv.data2.replication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicationConfigException
/*    */   extends ReplicationException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ReplicationConfigException(String argMessage) {
/* 24 */     super(argMessage);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReplicationConfigException(String argMessage, Throwable argCause) {
/* 35 */     super(argMessage, argCause);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\ReplicationConfigException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */