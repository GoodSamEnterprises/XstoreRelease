/*    */ package dtv.data2.replication.dtximpl.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicationEvent
/*    */ {
/*    */   private final ReplicationEventType eventType_;
/*    */   
/*    */   public ReplicationEvent(ReplicationEventType argReplicationEventType) {
/* 21 */     this.eventType_ = argReplicationEventType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReplicationEventType getEventType() {
/* 30 */     return this.eventType_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum ReplicationEventType
/*    */   {
/* 39 */     PROCESS_QUEUE,
/*    */     
/* 41 */     PROCESS_TRANSACTION,
/*    */     
/* 43 */     RESET_OFFLINE_FAILURE_COUNTS;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\event\ReplicationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */