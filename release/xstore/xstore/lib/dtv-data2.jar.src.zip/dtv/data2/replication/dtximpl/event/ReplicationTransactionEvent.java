/*    */ package dtv.data2.replication.dtximpl.event;
/*    */ 
/*    */ import dtv.data2.replication.dtximpl.ReplicationTransaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicationTransactionEvent
/*    */   extends ReplicationEvent
/*    */ {
/*    */   private final ReplicationTransaction replicationTrans_;
/*    */   
/*    */   public ReplicationTransactionEvent(ReplicationTransaction argReplicationTrans) {
/* 25 */     super(ReplicationEvent.ReplicationEventType.PROCESS_TRANSACTION);
/* 26 */     this.replicationTrans_ = argReplicationTrans;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReplicationTransaction getReplicationTransaction() {
/* 35 */     return this.replicationTrans_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\event\ReplicationTransactionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */