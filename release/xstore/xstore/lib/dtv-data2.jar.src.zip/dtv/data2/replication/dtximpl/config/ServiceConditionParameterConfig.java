/*    */ package dtv.data2.replication.dtximpl.config;
/*    */ 
/*    */ import dtv.data2.replication.ReplicationConfigException;
/*    */ import dtv.util.config.AbstractConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceConditionParameterConfig
/*    */   extends AbstractConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String TAG_KEY = "key";
/*    */   private static final String TAG_VALUE = "value";
/*    */   private String key_;
/*    */   private String value_;
/*    */   
/*    */   public String getKey() {
/* 33 */     return this.key_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 42 */     return this.value_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 48 */     if (argKey.equals("key")) {
/* 49 */       this.key_ = argValue.toString();
/*    */     }
/* 51 */     else if (argKey.equals("value")) {
/* 52 */       this.value_ = argValue.toString();
/*    */     } else {
/*    */       
/* 55 */       throw new ReplicationConfigException("unknown tag: " + argKey + " Value: " + argValue);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setValue(String arg0) {}
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\ServiceConditionParameterConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */