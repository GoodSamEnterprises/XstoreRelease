/*     */ package dtv.data2.replication.dtximpl.config;
/*     */ 
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.replication.ReplicationConfigException;
/*     */ import dtv.util.config.ConfigHelper;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxReplicationConfigHelper
/*     */   extends ConfigHelper<DtxReplicationConfig>
/*     */ {
/*     */   private static DtxReplicationServiceConfig[] services_;
/*     */   private static DtxReplicationQueueConfig repQueueConfig_;
/*     */   
/*     */   static {
/*  27 */     (new DtxReplicationConfigHelper()).initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DtxReplicationQueueConfig getReplicationQueueConfig() {
/*  36 */     return repQueueConfig_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DtxReplicationServiceConfig[] getServiceConfigs() {
/*  45 */     return services_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isReplication(DataSourceDescriptor argDescriptor) {
/*  56 */     return StringUtils.defaultString(argDescriptor.getName())
/*  57 */       .equalsIgnoreCase(getReplicationQueueConfig().getDataSource());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void hashRootConfigs() {
/*  63 */     super.hashRootConfigs();
/*     */     
/*  65 */     if (services_ != null) {
/*  66 */       throw new ReplicationConfigException("Service map is non null - attempt made to load ReplicationConfig more than once.");
/*     */     }
/*     */ 
/*     */     
/*  70 */     repQueueConfig_ = ((DtxReplicationConfig)getRootConfig()).getReplicationQueueConfig();
/*     */     
/*  72 */     services_ = ((DtxReplicationConfig)getRootConfig()).getServices();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getConfigFileName() {
/*  81 */     return "DtxReplicationConfig";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IConfigObject getConfigObject(String argTagName, String dtype, String argSourceDescription) {
/*  87 */     if ("DtxReplicationConfig".equalsIgnoreCase(argTagName)) {
/*  88 */       return (IConfigObject)new DtxReplicationConfig();
/*     */     }
/*  90 */     if ("service".equalsIgnoreCase(argTagName)) {
/*  91 */       return (IConfigObject)new DtxReplicationServiceConfig();
/*     */     }
/*  93 */     if ("destination".equalsIgnoreCase(argTagName)) {
/*  94 */       return (IConfigObject)new ServiceDestinationConfig();
/*     */     }
/*  96 */     if ("subscriber".equalsIgnoreCase(argTagName)) {
/*  97 */       return (IConfigObject)new ServiceSubscriberConfig();
/*     */     }
/*  99 */     if ("condition".equalsIgnoreCase(argTagName)) {
/* 100 */       return (IConfigObject)new ServiceConditionConfig();
/*     */     }
/* 102 */     if ("conditionParam".equalsIgnoreCase(argTagName)) {
/* 103 */       return (IConfigObject)new ServiceConditionParameterConfig();
/*     */     }
/* 105 */     if ("ReplicationQueue".equalsIgnoreCase(argTagName)) {
/* 106 */       return (IConfigObject)new DtxReplicationQueueConfig();
/*     */     }
/* 108 */     if ("relegationLevel".equalsIgnoreCase(argTagName)) {
/* 109 */       return (IConfigObject)new RelegationLevelConfig();
/*     */     }
/* 111 */     return super.getConfigObject(argTagName, dtype, argSourceDescription);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\DtxReplicationConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */