/*     */ package dtv.data2.replication.dtximpl;
/*     */ 
/*     */ import com.google.common.collect.LinkedListMultimap;
/*     */ import com.google.common.collect.ListMultimap;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.transaction.DataSourceTransactionManager;
/*     */ import dtv.data2.access.transaction.ITransactionalDataSource;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import dtv.data2.replication.IReplicationStrategy;
/*     */ import dtv.util.temp.InjectionHammer;
/*     */ import java.util.List;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxReplicationStrategy
/*     */   implements IReplicationStrategy
/*     */ {
/*     */   public static final String REPLICATION_AUDIT_LOG = "REPLICATION_AUDIT_LOG";
/*  32 */   private static final Logger auditLogger_ = Logger.getLogger("REPLICATION_AUDIT_LOG");
/*     */   
/*  34 */   private final Object transLock_ = new Object();
/*     */ 
/*     */ 
/*     */   
/*  38 */   ListMultimap<TransactionToken, ReplicationTransaction> replicationTransactions_ = (ListMultimap<TransactionToken, ReplicationTransaction>)LinkedListMultimap.create();
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private DtxReplicationServiceFactory serviceFactory_;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private ReplicationProcessor _replicationProcessor;
/*     */ 
/*     */   
/*     */   public DtxReplicationStrategy() {
/*  50 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DtxReplicationStrategy(boolean argStartProcessor) {
/*  59 */     InjectionHammer.forceAtInjectProcessing(this);
/*  60 */     if (argStartProcessor) {
/*  61 */       this._replicationProcessor.startProcessor();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase1(TransactionToken argTransToken) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase2(TransactionToken argTransToken) {
/*  74 */     auditLogger_.debug("BEGIN commitPhase2");
/*     */     
/*  76 */     List<ReplicationTransaction> trans = null;
/*     */     
/*  78 */     synchronized (this.transLock_) {
/*  79 */       auditLogger_.debug("getting list of transactions");
/*  80 */       trans = this.replicationTransactions_.removeAll(argTransToken);
/*     */       
/*  82 */       if (auditLogger_.isDebugEnabled()) {
/*  83 */         auditLogger_.debug("got list of " + trans.size() + " to replicate");
/*     */       }
/*     */     } 
/*     */     
/*  87 */     if (trans.isEmpty()) {
/*  88 */       auditLogger_.debug("nothing to commit?");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  95 */     if (auditLogger_.isDebugEnabled()) {
/*  96 */       auditLogger_.debug("dispatching " + trans.size() + " replication transactions to ReplicationProcessor");
/*     */     }
/*     */     
/*  99 */     for (ReplicationTransaction tran : trans) {
/* 100 */       this._replicationProcessor.enqueue(tran);
/*     */     }
/*     */     
/* 103 */     auditLogger_.debug("END commitPhase2");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 109 */     return "DtxReplicationStrategy";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReplicationCandidate(String argDataSourceName, Object argData, List<String> argExcludedDataSources) {
/* 118 */     boolean result = this.serviceFactory_.isReplicationCandidate(argDataSourceName, argData, argExcludedDataSources);
/*     */     
/* 120 */     if (auditLogger_.isDebugEnabled()) {
/* 121 */       auditLogger_.debug("Object " + argData.getClass().getName() + " replication candidate: " + result);
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replicateData(String argCurrentDataSource, TransactionToken argTransToken, IPersistable argData, List<String> argExcludedDataSources) {
/* 131 */     if (auditLogger_.isDebugEnabled()) {
/* 132 */       auditLogger_
/* 133 */         .debug("**** BEGIN replicateData. Current ds: " + argCurrentDataSource + " data: " + argData);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     List<ReplicationTransaction> existingTransactions = null;
/*     */     
/* 143 */     synchronized (this.transLock_) {
/* 144 */       existingTransactions = this.replicationTransactions_.get(argTransToken);
/*     */     } 
/*     */     
/* 147 */     if (existingTransactions.isEmpty()) {
/* 148 */       DataSourceTransactionManager.getInstance().registerDataSource(argTransToken, (ITransactionalDataSource)this);
/*     */     }
/*     */ 
/*     */     
/* 152 */     List<String> applicableServices = this.serviceFactory_.getApplicableServices(argCurrentDataSource, argData, argExcludedDataSources);
/*     */     
/* 154 */     if (auditLogger_.isDebugEnabled()) {
/* 155 */       auditLogger_
/* 156 */         .debug("Applicable services for " + argData.getClass().getName() + ": " + applicableServices);
/*     */     }
/*     */     
/* 159 */     for (String serviceName : applicableServices) {
/* 160 */       ReplicationTransaction trans = null;
/*     */       
/* 162 */       for (ReplicationTransaction t : existingTransactions) {
/* 163 */         if (serviceName.equals(t.getServiceName())) {
/* 164 */           trans = t;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 171 */       if (trans == null) {
/* 172 */         auditLogger_.debug("Begin create new trans");
/* 173 */         trans = this.serviceFactory_.getNewTransaction(serviceName);
/* 174 */         trans.setTransactionId(argTransToken.getValue());
/*     */         
/* 176 */         synchronized (this.transLock_) {
/* 177 */           this.replicationTransactions_.put(argTransToken, trans);
/*     */         } 
/*     */         
/* 180 */         auditLogger_.debug("End create new trans");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       if (auditLogger_.isDebugEnabled()) {
/* 188 */         auditLogger_
/* 189 */           .debug("adding argData " + argData.getClass().getName() + " to: " + trans.getTransactionId());
/*     */       }
/*     */       
/* 192 */       trans.addDataAsXmlString(argData.toXmlString());
/*     */     } 
/*     */     
/* 195 */     auditLogger_.debug("**** END replicateData");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(TransactionToken argTransToken) {
/* 201 */     auditLogger_.debug("BEGIN rollback");
/*     */ 
/*     */     
/* 204 */     synchronized (this.transLock_) {
/* 205 */       this.replicationTransactions_.removeAll(argTransToken);
/*     */     } 
/*     */     
/* 208 */     auditLogger_.debug("END rollback");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\DtxReplicationStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */