/*     */ package dtv.data2.replication.dtximpl.dispatcher;
/*     */ 
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.replication.dtximpl.ReplicationQueueAccessor;
/*     */ import dtv.data2.replication.dtximpl.ReplicationTransaction;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForwardingDispatcher
/*     */   implements IDtxReplicationDispatcher
/*     */ {
/*  25 */   private static final Logger auditLogger_ = Logger.getLogger("REPLICATION_AUDIT_LOG");
/*     */ 
/*     */ 
/*     */   
/*     */   private final String dataSourceToForwardTo_;
/*     */ 
/*     */   
/*     */   private final String destinationService_;
/*     */ 
/*     */ 
/*     */   
/*     */   public ForwardingDispatcher(String argDataSourceToForwardTo, String argDestinationService) {
/*  37 */     this.dataSourceToForwardTo_ = argDataSourceToForwardTo;
/*  38 */     this.destinationService_ = argDestinationService;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IDtxReplicationDispatcher.DispatchResult dispatch(ReplicationTransaction argReplicationLog) {
/*  44 */     if (auditLogger_.isDebugEnabled()) {
/*  45 */       auditLogger_.debug("Attempting dispatch of trans: " + argReplicationLog.getTransactionId() + " on ForwardingDispatcher. Destination datasource: " + this.dataSourceToForwardTo_ + ". Destination service: " + this.destinationService_);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     IDtxReplicationDispatcher.DispatchResult result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */     
/*     */     try {
/*  58 */       boolean success = ReplicationQueueAccessor.getInstance().addObjectRemote(argReplicationLog, this.dataSourceToForwardTo_, this.destinationService_);
/*     */ 
/*     */       
/*  61 */       if (success) {
/*  62 */         result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_SUCCESSFUL;
/*     */         
/*  64 */         if (auditLogger_.isInfoEnabled()) {
/*  65 */           auditLogger_
/*  66 */             .info("----- Data replicated: Replication eueue entry forwarded to queue on datasource: " + this.dataSourceToForwardTo_ + " Data: " + argReplicationLog
/*  67 */               .getPersistablesAsXml());
/*     */         }
/*     */       } else {
/*     */         
/*  71 */         result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */         
/*  73 */         if (auditLogger_.isDebugEnabled()) {
/*  74 */           auditLogger_.debug(" FAILURE Dispatch of trans: " + argReplicationLog.getTransactionId() + " on ForwardingDispatcher with destination datasource: " + this.dataSourceToForwardTo_ + ". Destination service: " + this.destinationService_ + " PROBLEM UNKNOWN! No exception thrown. ");
/*     */         
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*  80 */     catch (Exception ee) {
/*  81 */       if (FailoverException.isFailover(ee)) {
/*  82 */         result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*     */         
/*  84 */         if (auditLogger_.isDebugEnabled()) {
/*  85 */           auditLogger_.debug(" FAILURE Dispatch of trans: " + argReplicationLog.getTransactionId() + " on ForwardingDispatcher with destination datasource: " + this.dataSourceToForwardTo_ + ". Destination service: " + this.destinationService_ + " Due to FailoverException " + ee);
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/*  91 */         result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_ERROR_FAILURE;
/*     */         
/*  93 */         if (auditLogger_.isDebugEnabled()) {
/*  94 */           auditLogger_.debug(" FAILURE Dispatch of trans: " + argReplicationLog.getTransactionId() + " on ForwardingDispatcher with destination datasource: " + this.dataSourceToForwardTo_ + ". Destination service: " + this.destinationService_ + " Due to ERROR.", ee);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDestination() {
/* 107 */     return this.dataSourceToForwardTo_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 113 */     return DataSourceFactory.isDataSourceEnabled(this.dataSourceToForwardTo_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTargeted(String argDataSourceName) {
/* 121 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\dispatcher\ForwardingDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */