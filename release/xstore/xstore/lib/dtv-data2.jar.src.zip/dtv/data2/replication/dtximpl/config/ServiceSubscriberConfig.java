/*    */ package dtv.data2.replication.dtximpl.config;
/*    */ 
/*    */ import dtv.data2.replication.ReplicationException;
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceSubscriberConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String TAG_NAME = "name";
/*    */   private static final String TAG_EXCLUDE = "exclude";
/*    */   private String name_;
/*    */   private boolean exclude_ = false;
/*    */   
/*    */   public String getSubscriberName() {
/* 34 */     return this.name_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isExcluded() {
/* 43 */     return this.exclude_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 51 */     if ("name".equalsIgnoreCase(argKey)) {
/* 52 */       this.name_ = argValue.toString();
/*    */     }
/* 54 */     else if ("exclude".equalsIgnoreCase(argKey)) {
/*    */       
/* 56 */       if (argValue.toString().equals("true")) {
/* 57 */         this.exclude_ = true;
/*    */       }
/* 59 */       else if (argValue.toString().equals("false")) {
/* 60 */         this.exclude_ = false;
/*    */       } else {
/*    */         
/* 63 */         throw new ReplicationException("A bad value is configured for a replication service subscriber.  The exclude attribute must be a boolean value, but was: '" + argValue + "' Source: " + 
/*    */             
/* 65 */             getSourceDescription());
/*    */       } 
/*    */     } else {
/*    */       
/* 69 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "ServiceSubscriberConfig name: " + this.name_ + " exluded: " + this.exclude_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\config\ServiceSubscriberConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */