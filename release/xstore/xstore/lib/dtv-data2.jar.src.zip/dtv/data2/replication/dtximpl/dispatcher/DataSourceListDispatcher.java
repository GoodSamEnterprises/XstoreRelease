/*     */ package dtv.data2.replication.dtximpl.dispatcher;
/*     */ 
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.impl.PersistenceStrategyFactory;
/*     */ import dtv.data2.replication.ReplicationException;
/*     */ import dtv.data2.replication.dtximpl.ReplicationTransaction;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceListDispatcher
/*     */   extends DataSourceDispatcher
/*     */ {
/*     */   private final List<String> _myDataSourceList;
/*     */   
/*     */   public DataSourceListDispatcher(List<String> argDataSourceList, PersistenceStrategyFactory argPersistenceStrategyFactory) {
/*  33 */     super(argPersistenceStrategyFactory);
/*     */     
/*  35 */     if (argDataSourceList == null) {
/*  36 */       throw new ReplicationException("Cannot create DataSourceListDispatcher with null argDataSourceList.");
/*     */     }
/*     */ 
/*     */     
/*  40 */     this._myDataSourceList = argDataSourceList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDtxReplicationDispatcher.DispatchResult dispatch(ReplicationTransaction argReplicationTransaction) {
/*  55 */     IDtxReplicationDispatcher.DispatchResult result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE;
/*  56 */     boolean atLeastOneSuccess = false;
/*     */     
/*  58 */     for (String dataSourceName : this._myDataSourceList) {
/*  59 */       result = dispatchImpl(dataSourceName, argReplicationTransaction);
/*     */       
/*  61 */       if (IDtxReplicationDispatcher.DispatchResult.DISPATCH_SUCCESSFUL == result) {
/*  62 */         atLeastOneSuccess = true;
/*     */       }
/*     */     } 
/*     */     
/*  66 */     return atLeastOneSuccess ? IDtxReplicationDispatcher.DispatchResult.DISPATCH_SUCCESSFUL : result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDestination() {
/*  72 */     return this._myDataSourceList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  78 */     boolean enabled = false;
/*     */     
/*  80 */     for (String dataSource : this._myDataSourceList) {
/*  81 */       if (DataSourceFactory.isDataSourceEnabled(dataSource.toString())) {
/*  82 */         enabled = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  87 */     return enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTargeted(String argDataSourceName) {
/*  93 */     boolean isTargeted = false;
/*     */     
/*  95 */     for (String dataSourceName : this._myDataSourceList) {
/*  96 */       if (dataSourceName.equals(argDataSourceName)) {
/*  97 */         isTargeted = true;
/*     */       }
/*     */     } 
/*     */     
/* 101 */     return isTargeted;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\dispatcher\DataSourceListDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */