/*    */ package dtv.data2.replication.dtximpl.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicationProcessQueueEvent
/*    */   extends ReplicationEvent
/*    */ {
/*    */   private final int minFailures_;
/*    */   private final int maxFailures_;
/*    */   
/*    */   public ReplicationProcessQueueEvent(int argMinFailures, int argMaxFailures) {
/* 26 */     super(ReplicationEvent.ReplicationEventType.PROCESS_QUEUE);
/* 27 */     this.minFailures_ = argMinFailures;
/* 28 */     this.maxFailures_ = argMaxFailures;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaxFailures() {
/* 37 */     return this.maxFailures_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMinFailures() {
/* 46 */     return this.minFailures_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\event\ReplicationProcessQueueEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */