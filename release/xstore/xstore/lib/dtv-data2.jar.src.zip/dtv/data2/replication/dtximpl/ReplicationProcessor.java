/*     */ package dtv.data2.replication.dtximpl;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.status.IDataSourceStatusListener;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.replication.ReplicationConfigException;
/*     */ import dtv.data2.replication.ReplicationException;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationConfigHelper;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationServiceConfig;
/*     */ import dtv.data2.replication.dtximpl.config.RelegationLevelConfig;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.IDtxReplicationDispatcher;
/*     */ import dtv.data2.replication.dtximpl.event.ReplicationEvent;
/*     */ import dtv.data2.replication.dtximpl.event.ReplicationProcessQueueEvent;
/*     */ import dtv.data2.replication.dtximpl.event.ReplicationTransactionEvent;
/*     */ import java.util.List;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationProcessor
/*     */   extends Thread
/*     */   implements IDataSourceStatusListener
/*     */ {
/*  41 */   private static final Logger logger_ = Logger.getLogger(ReplicationProcessor.class);
/*  42 */   private static final Logger auditLogger_ = Logger.getLogger("REPLICATION_AUDIT_LOG");
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private DtxReplicationServiceFactory _replicationServiceFactory;
/*     */   
/*     */   @Inject
/*     */   protected ReplicationEventLogWriter _eventLogWriter;
/*     */   
/*  51 */   private final BlockingQueue<ReplicationEvent> replicationEventQueue_ = new LinkedBlockingQueue<>();
/*     */ 
/*     */   
/*  54 */   private final long cycleInterval_ = DtxReplicationConfigHelper.getReplicationQueueConfig().getCycleInterval();
/*     */   
/*     */   private Timer processQueueTimer_;
/*  57 */   private long lastQueueProcessCompleted_ = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean queueProcessActive_ = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _processorStarted = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatch(ReplicationTransaction argReplicationTrans) {
/*  75 */     if (auditLogger_.isDebugEnabled()) {
/*  76 */       auditLogger_.debug("dispatch() called with replication trans. Service: " + argReplicationTrans
/*  77 */           .getServiceName() + " Trans Id: " + argReplicationTrans.getTransactionId() + " New: " + argReplicationTrans
/*  78 */           .getNewTransaction());
/*     */     }
/*     */     
/*  81 */     if (argReplicationTrans.getNewTransaction()) {
/*  82 */       throw new ReplicationException("Invalid usage - NEW replication transactions should be adding by using enqueue. Service: " + argReplicationTrans
/*  83 */           .getServiceName() + " Trans Id: " + argReplicationTrans
/*  84 */           .getTransactionId());
/*     */     }
/*     */     
/*  87 */     this.replicationEventQueue_.add(new ReplicationTransactionEvent(argReplicationTrans));
/*     */     
/*  89 */     if (auditLogger_.isDebugEnabled()) {
/*  90 */       auditLogger_.debug("dispatch() finished adding trans to replicationEventQueue_. Service: " + argReplicationTrans
/*  91 */           .getServiceName() + " Trans Id: " + argReplicationTrans.getTransactionId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enqueue(ReplicationTransaction argReplicationTrans) {
/* 101 */     if (auditLogger_.isDebugEnabled()) {
/* 102 */       auditLogger_.debug("enqueue() called with replication trans. Service: " + argReplicationTrans
/* 103 */           .getServiceName() + " Trans Id: " + argReplicationTrans.getTransactionId() + " New: " + argReplicationTrans
/* 104 */           .getNewTransaction());
/*     */     }
/*     */     
/* 107 */     ReplicationQueueAccessor.getInstance().addObject(argReplicationTrans);
/*     */     
/* 109 */     if (auditLogger_.isDebugEnabled()) {
/* 110 */       auditLogger_.debug("enqueue() finished. Service: " + argReplicationTrans.getServiceName() + " Trans Id: " + argReplicationTrans
/* 111 */           .getTransactionId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notfiyOffline(String argDataSource) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyOnline(String argDataSource) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 130 */     auditLogger_.debug(Thread.currentThread().getName() + " thread running.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       try {
/* 138 */         auditLogger_.debug("----BEGIN MAIN LOOP Before replicationEventQueue_.take()----");
/*     */         
/* 140 */         ReplicationEvent event = this.replicationEventQueue_.take();
/*     */         
/* 142 */         auditLogger_.info("Event Queue Size: " + this.replicationEventQueue_.size());
/*     */         
/* 144 */         if (auditLogger_.isDebugEnabled()) {
/* 145 */           auditLogger_
/* 146 */             .debug("Taking ReplicationEvent from the queue. Event Type: " + event.getEventType().name() + " Record contained within the queue: " + this.replicationEventQueue_
/* 147 */               .contains(event));
/*     */         }
/*     */         
/* 150 */         if (ReplicationEvent.ReplicationEventType.PROCESS_TRANSACTION == event.getEventType()) {
/* 151 */           ReplicationTransaction trans = ((ReplicationTransactionEvent)event).getReplicationTransaction();
/*     */           
/* 153 */           if (auditLogger_.isDebugEnabled()) {
/* 154 */             auditLogger_.debug("BEGIN PROCESS_TRANSACTION service: " + trans.getServiceName() + " rep trans id: " + trans
/* 155 */                 .getTransactionId());
/*     */           }
/*     */           
/* 158 */           dispatchImpl(trans);
/*     */           
/* 160 */           if (auditLogger_.isDebugEnabled()) {
/* 161 */             auditLogger_.debug("FINISHED PROCESS_TRANSACTION for service: " + trans.getServiceName() + " rep trans id: " + trans
/* 162 */                 .getTransactionId());
/*     */           }
/*     */         }
/* 165 */         else if (ReplicationEvent.ReplicationEventType.PROCESS_QUEUE == event.getEventType()) {
/* 166 */           this.queueProcessActive_ = true;
/* 167 */           int min = ((ReplicationProcessQueueEvent)event).getMinFailures();
/* 168 */           int max = ((ReplicationProcessQueueEvent)event).getMaxFailures();
/*     */           
/* 170 */           for (DtxReplicationServiceConfig serviceConfig : DtxReplicationConfigHelper.getServiceConfigs()) {
/* 171 */             String serviceName = serviceConfig.getName();
/*     */             
/* 173 */             if (auditLogger_.isDebugEnabled()) {
/* 174 */               auditLogger_.debug("BEGIN PROCESS_QUEUE (" + serviceName + ") Min failures: " + min + ". Max failures: " + max + ".");
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 179 */             List<ReplicationTransaction> transactions = ReplicationQueueAccessor.getInstance().getReplicationTransactions(serviceName, min, max);
/*     */             
/* 181 */             if (auditLogger_.isDebugEnabled()) {
/* 182 */               auditLogger_.debug("FINISHED PROCESS_QUEUE (" + serviceName + ") Min failures: " + min + ". Max failures: " + max + ".");
/*     */             }
/*     */ 
/*     */             
/* 186 */             if (transactions != null && !transactions.isEmpty()) {
/* 187 */               this.queueProcessActive_ = true;
/*     */               
/* 189 */               auditLogger_.info("Publishing " + transactions
/* 190 */                   .size() + " records to the event queue (" + serviceName + ").");
/*     */               
/* 192 */               for (ReplicationTransaction trans : transactions) {
/* 193 */                 dispatch(trans);
/*     */               }
/*     */             } else {
/*     */               
/* 197 */               auditLogger_.debug("PROCESS_QUEUE (" + serviceName + ") *RETURNED NO QUEUE ENTRIES*");
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 202 */           throwIfUnknownType(event.getEventType());
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 208 */         if (this.queueProcessActive_ && this.replicationEventQueue_.isEmpty()) {
/* 209 */           this.lastQueueProcessCompleted_ = System.currentTimeMillis();
/* 210 */           if (auditLogger_.isDebugEnabled()) {
/* 211 */             auditLogger_.debug("Setting lastQueueProcessCompleted_ = " + this.lastQueueProcessCompleted_);
/*     */           }
/* 213 */           this.queueProcessActive_ = false;
/*     */         } 
/*     */         
/* 216 */         auditLogger_.debug("----END MAIN LOOP----");
/*     */       }
/* 218 */       catch (Exception ee) {
/* 219 */         logger_.error("Unpexpected exception caught in ReplicationProcessor main loop. We will attempt to continue.", ee);
/*     */         
/* 221 */         auditLogger_.error("Unpexpected exception caught in ReplicationProcessor main loop. We will attempt to continue.", ee);
/*     */       
/*     */       }
/* 224 */       catch (Error ee) {
/* 225 */         logger_.fatal("*** ERROR CAUGHT IN REPLICATION PROCESSOR THREAD. REPLICATION WILL NO LONGER FUNCTION.", ee);
/*     */         
/* 227 */         auditLogger_.fatal("*** ERROR CAUGHT IN REPLICATION PROCESSOR THREAD. REPLICATION WILL NO LONGER FUNCTION.", ee);
/*     */         
/* 229 */         throw ee;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startProcessor() {
/* 239 */     if (!this._processorStarted) {
/* 240 */       setName("Replication Processor");
/* 241 */       setPriority(4);
/*     */ 
/*     */       
/* 244 */       auditLogger_.debug("Starting Replication Processor thread.");
/*     */       
/* 246 */       start();
/*     */       
/* 248 */       auditLogger_
/* 249 */         .debug("Scheduling Replication Queue Process Timer to fire every " + this.cycleInterval_ + " ms.");
/*     */       
/* 251 */       this.processQueueTimer_ = new Timer("Replication Queue Process Timer", true);
/* 252 */       this.processQueueTimer_.schedule(new ProcessReplicationQueueTask(), this.cycleInterval_, this.cycleInterval_);
/*     */ 
/*     */       
/* 255 */       StatusMgr.getInstance().registerStatusListener(this);
/* 256 */       this._processorStarted = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void dispatchImpl(ReplicationTransaction argTrans) {
/* 261 */     ReplicationTransaction trans = argTrans;
/* 262 */     IDtxReplicationDispatcher.DispatchResult result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_ERROR_FAILURE;
/*     */     
/*     */     try {
/* 265 */       DtxReplicationService service = this._replicationServiceFactory.getService(trans.getServiceName());
/*     */ 
/*     */       
/* 268 */       result = service.dispatch(trans);
/*     */     }
/* 270 */     catch (RuntimeException|Error ex) {
/* 271 */       auditLogger_.fatal("REPLICATION PROCESSOR EXCEPTION", ex);
/* 272 */       this._eventLogWriter.writeRepQueueFailureEventLogEntry("FATAL", "REPLICATION PROCESSOR EXCEPTION", ex, argTrans
/* 273 */           .getWorkstationId());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     if (IDtxReplicationDispatcher.DispatchResult.DISPATCH_SUCCESSFUL == result) {
/* 281 */       if (auditLogger_.isDebugEnabled()) {
/* 282 */         auditLogger_.debug("Dispatch successful - removing trans: " + trans.getTransactionId() + " from the queue.");
/*     */       }
/*     */ 
/*     */       
/* 286 */       ReplicationQueueAccessor.getInstance().removeObject(trans);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 292 */       if (IDtxReplicationDispatcher.DispatchResult.DISPATCH_IMPOSSIBLE_TO_REPLICATE == result) {
/* 293 */         String persistableXml = trans.getPersistablesAsXml();
/* 294 */         if (StringUtils.countMatches(persistableXml, "<dao name=") == 1 && persistableXml
/* 295 */           .contains("name=\"EventLogEntry\"")) {
/* 296 */           logger_.warn("An event log entry is stuck in the replication queue. Can't take action.");
/* 297 */           result = IDtxReplicationDispatcher.DispatchResult.DISPATCH_ERROR_FAILURE;
/*     */         } else {
/*     */           
/* 300 */           logger_.warn("Impossible to replicate data. Service: [" + trans.getServiceName() + "]\n" + trans
/* 301 */               .getPersistablesAsXml());
/* 302 */           this._eventLogWriter.writeRepQueueNotPossibleEventLogEntry("WARN", "Impossible to replicate data. Service: " + trans
/* 303 */               .getServiceName() + "\n" + trans
/* 304 */               .getPersistablesAsXml(), argTrans
/* 305 */               .getWorkstationId());
/*     */           
/* 307 */           if (auditLogger_.isInfoEnabled()) {
/*     */             
/* 309 */             String msg = "Dispatch failed - not possible to replicate this data; no further attempts will be made for trans " + trans.getTransactionId() + " This replication trans will be removed from the queue.";
/*     */             
/* 311 */             auditLogger_.info(msg);
/*     */           } 
/*     */           
/* 314 */           ReplicationQueueAccessor.getInstance().removeObject(trans);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 319 */       if (trans.isExpired()) {
/* 320 */         if (auditLogger_.isInfoEnabled()) {
/* 321 */           auditLogger_.info("Dispatch failed - Removing transaction from the queue because it expired. " + trans
/* 322 */               .getTransactionId());
/*     */         }
/*     */         
/* 325 */         ReplicationQueueAccessor.getInstance().removeObject(trans);
/*     */       }
/*     */       else {
/*     */         
/* 329 */         if (IDtxReplicationDispatcher.DispatchResult.DISPATCH_ERROR_FAILURE == result) {
/* 330 */           trans.incrementErrorFailures();
/*     */         }
/* 332 */         else if (IDtxReplicationDispatcher.DispatchResult.DISPATCH_OFFLINE_FAILURE != result) {
/* 333 */           throw new ReplicationException("Unknown DispatchResult: " + result);
/*     */         } 
/*     */         
/* 336 */         if (auditLogger_.isDebugEnabled()) {
/* 337 */           auditLogger_
/* 338 */             .debug("Dispatch failed - Setting ERROR failure count to " + trans.getFailedErrorAttempts() + " for trans " + trans
/* 339 */               .getTransactionId() + " and service " + trans.getServiceName());
/*     */         }
/*     */         
/* 342 */         auditLogger_.debug("BEGIN existingTransactionFailed");
/* 343 */         ReplicationQueueAccessor.getInstance().existingTransactionFailed(result, trans);
/* 344 */         auditLogger_.debug("FNISHED existingTransactionFailed");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void throwIfUnknownType(ReplicationEvent.ReplicationEventType eventType) throws DtxException {
/* 351 */     if (ReplicationEvent.ReplicationEventType.RESET_OFFLINE_FAILURE_COUNTS != eventType) {
/* 352 */       String message = "Unknown replication event type: " + eventType;
/* 353 */       auditLogger_.warn(message);
/* 354 */       throw new DtxException(message);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ProcessReplicationQueueTask
/*     */     extends TimerTask
/*     */   {
/* 364 */     private ReplicationProcessor.RelegationLevel[] relegationLevels_ = null;
/* 365 */     private long cycleCount_ = 0L;
/*     */     
/*     */     ProcessReplicationQueueTask() {
/* 368 */       initRelegationLevels();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 374 */       if (enoughTimePassed()) {
/* 375 */         int[] minMax = getMinMaxFailures(this.cycleCount_++);
/*     */         
/* 377 */         if (ReplicationProcessor.auditLogger_.isDebugEnabled()) {
/* 378 */           ReplicationProcessor.auditLogger_
/* 379 */             .debug("BEGIN ProcessReplicationQueueTask adding ReplicationProcessQueueEvent Min failures " + minMax[0] + " Max " + minMax[1] + " cycle count: " + this.cycleCount_);
/*     */         }
/*     */ 
/*     */         
/* 383 */         ReplicationProcessor.this.replicationEventQueue_.add(new ReplicationProcessQueueEvent(minMax[0], minMax[1]));
/*     */         
/* 385 */         if (ReplicationProcessor.auditLogger_.isDebugEnabled()) {
/* 386 */           ReplicationProcessor.auditLogger_
/* 387 */             .debug("END ProcessReplicationQueueTask adding ReplicationProcessQueueEvent Min failures " + minMax[0] + " Max " + minMax[1] + " cycle count: " + this.cycleCount_);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean enoughTimePassed() {
/* 394 */       long NOW = System.currentTimeMillis();
/* 395 */       if (ReplicationProcessor.this.queueProcessActive_ || NOW - ReplicationProcessor.this.lastQueueProcessCompleted_ < ReplicationProcessor.this.cycleInterval_) {
/* 396 */         return false;
/*     */       }
/*     */       
/* 399 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     private int[] getMinMaxFailures(long argCycleCount) {
/* 404 */       if (this.relegationLevels_.length == 0) {
/* 405 */         return new int[] { -1, -1 };
/*     */       }
/*     */       
/* 408 */       if (argCycleCount > 0L) {
/* 409 */         ReplicationProcessor.RelegationLevel previousLevel = null;
/*     */ 
/*     */         
/* 412 */         for (ReplicationProcessor.RelegationLevel element : this.relegationLevels_) {
/* 413 */           if (argCycleCount % element.getRetryAfterCycles() == 0L) {
/* 414 */             if (previousLevel != null) {
/* 415 */               return new int[] { element.getFailedAttempts(), previousLevel.getFailedAttempts() };
/*     */             }
/*     */             
/* 418 */             return new int[] { element.getFailedAttempts(), -1 };
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 426 */           previousLevel = element;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 431 */       return new int[] { -1, this.relegationLevels_[this.relegationLevels_.length - 1]
/* 432 */           .getFailedAttempts() };
/*     */     }
/*     */ 
/*     */     
/*     */     private void initRelegationLevels() {
/*     */       try {
/* 438 */         List<? extends RelegationLevelConfig> levelConfigs = DtxReplicationConfigHelper.getReplicationQueueConfig().getRelegationLevels();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 445 */         int lastFailedAttempts = -1;
/* 446 */         int lastRetryAfter = -1;
/*     */         
/* 448 */         for (RelegationLevelConfig current : levelConfigs) {
/* 449 */           if (current.getFailAttempts() <= lastFailedAttempts) {
/* 450 */             throw new ReplicationConfigException("RelegationLevel failed attempts attribute must ascend for every entry made.  No duplicates.  Invalid failed attempts: " + current
/*     */                 
/* 452 */                 .getFailAttempts());
/*     */           }
/*     */           
/* 455 */           if (current.getRetryAfterCycles() <= lastRetryAfter) {
/* 456 */             throw new ReplicationConfigException("RelegationLevel retry after attribute must ascend for every entry made.  No duplicates.  Invalid retry after: " + current
/*     */                 
/* 458 */                 .getFailAttempts());
/*     */           }
/*     */           
/* 461 */           lastFailedAttempts = current.getFailAttempts();
/* 462 */           lastRetryAfter = current.getRetryAfterCycles();
/*     */         } 
/*     */         
/* 465 */         if (!levelConfigs.isEmpty()) {
/* 466 */           this.relegationLevels_ = new ReplicationProcessor.RelegationLevel[levelConfigs.size()];
/* 467 */           int counter = this.relegationLevels_.length - 1;
/*     */           
/* 469 */           for (RelegationLevelConfig config : levelConfigs) {
/* 470 */             this.relegationLevels_[counter--] = new ReplicationProcessor.RelegationLevel(config
/* 471 */                 .getFailAttempts(), config.getRetryAfterCycles());
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 476 */       catch (Throwable ex) {
/* 477 */         this.relegationLevels_ = new ReplicationProcessor.RelegationLevel[0];
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class RelegationLevel
/*     */   {
/*     */     private final int failedAttempts_;
/*     */     
/*     */     private final int retryAfterCycles_;
/*     */     
/*     */     public RelegationLevel(int argFailedAttempts, int argRetryAfterCycles) {
/* 490 */       if (argFailedAttempts < 0) {
/* 491 */         throw new ReplicationConfigException("Invalid value: " + argFailedAttempts + " for failed attempts.  Check relegation levels in replication config.");
/*     */       }
/*     */ 
/*     */       
/* 495 */       if (argRetryAfterCycles < 0) {
/* 496 */         throw new ReplicationConfigException("Invalid value: " + argRetryAfterCycles + " for retry cycles.  Check relegation levels in replication config.");
/*     */       }
/*     */ 
/*     */       
/* 500 */       this.failedAttempts_ = argFailedAttempts;
/* 501 */       this.retryAfterCycles_ = argRetryAfterCycles;
/*     */     }
/*     */     
/*     */     public int getFailedAttempts() {
/* 505 */       return this.failedAttempts_;
/*     */     }
/*     */     
/*     */     public int getRetryAfterCycles() {
/* 509 */       return this.retryAfterCycles_;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\ReplicationProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */