/*    */ package dtv.data2.replication.dtximpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicationUniqueTimestampFactory
/*    */ {
/* 14 */   private static ReplicationUniqueTimestampFactory _instance = new ReplicationUniqueTimestampFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ReplicationUniqueTimestampFactory getInstance() {
/* 22 */     return _instance;
/*    */   }
/*    */   
/* 25 */   private long _previousTimestamp = System.currentTimeMillis();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized long getCurrentTime() {
/* 35 */     long currentTime = System.currentTimeMillis();
/*    */     
/* 37 */     while (currentTime == this._previousTimestamp) {
/*    */       try {
/* 39 */         Thread.sleep(1L);
/* 40 */         currentTime = System.currentTimeMillis();
/*    */       }
/* 42 */       catch (InterruptedException interruptedException) {}
/*    */     } 
/*    */     
/* 45 */     this._previousTimestamp = currentTime;
/*    */     
/* 47 */     return currentTime;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\ReplicationUniqueTimestampFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */