/*    */ package dtv.data2.replication.dtximpl.dispatcher;
/*    */ 
/*    */ import dtv.data2.replication.dtximpl.ReplicationTransaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IDtxReplicationDispatcher
/*    */ {
/*    */   DispatchResult dispatch(ReplicationTransaction paramReplicationTransaction);
/*    */   
/*    */   Object getDestination();
/*    */   
/*    */   boolean isEnabled();
/*    */   
/*    */   boolean isTargeted(String paramString);
/*    */   
/*    */   public enum DispatchResult
/*    */   {
/* 54 */     DISPATCH_SUCCESSFUL,
/*    */     
/* 56 */     DISPATCH_OFFLINE_FAILURE,
/*    */     
/* 58 */     DISPATCH_ERROR_FAILURE,
/*    */     
/* 60 */     DISPATCH_IMPOSSIBLE_TO_REPLICATE;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\dispatcher\IDtxReplicationDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */