/*     */ package dtv.data2.replication.dtximpl;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.jdbc.DBConnection;
/*     */ import dtv.data2.access.impl.jdbc.JDBCDataSourceMgr;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.data2.replication.ReplicationException;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationConfigHelper;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationQueueConfig;
/*     */ import dtv.data2.replication.dtximpl.dispatcher.IDtxReplicationDispatcher;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.temp.InjectionHammer;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationQueueAccessor
/*     */ {
/*     */   public static final int UNSPECIFIED = -1;
/*     */   protected static final int MAX_RETRIES;
/*     */   protected static final int RETRY_WAIT;
/*     */   protected static final int NO_FAILS_LIMIT;
/*     */   protected static final int ERROR_NOTIFICATION_CYCLES;
/*     */   protected static final ReplicationQueueAccessor INSTANCE;
/*  55 */   private static final Logger logger_ = Logger.getLogger(ReplicationQueueAccessor.class);
/*  56 */   private static final Logger auditLogger_ = Logger.getLogger("REPLICATION_AUDIT_LOG");
/*     */   
/*  58 */   private static int currentErrorCycle_ = 0;
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected static final DtxReplicationQueueConfig _replicationQueueConfig = DtxReplicationConfigHelper.getReplicationQueueConfig(); @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */   
/*     */   static {
/*  66 */     MAX_RETRIES = Integer.getInteger("dtv.data2.replication.queue.maxretries", 4).intValue();
/*  67 */     RETRY_WAIT = Integer.getInteger("dtv.data2.replication.queue.retrywait", 3000).intValue();
/*  68 */     NO_FAILS_LIMIT = Integer.getInteger("dtv.data2.replication.queue.nofailslimit", 100).intValue();
/*  69 */     ERROR_NOTIFICATION_CYCLES = _replicationQueueConfig.getErrorNotificationCycles();
/*     */     
/*  71 */     String sysProp = System.getProperty("dtv.data2.replication.dtximpl.ReplicationQueueAccessor");
/*     */     
/*  73 */     ReplicationQueueAccessor instance = null;
/*  74 */     if (!StringUtils.isEmpty(sysProp)) {
/*     */       try {
/*  76 */         instance = (ReplicationQueueAccessor)Class.forName(sysProp).newInstance();
/*     */       }
/*  78 */       catch (Exception ee) {
/*  79 */         logger_.error("exception while loading customer implementation of ReplicationQueueAccessor", ee);
/*     */       } 
/*     */     }
/*     */     
/*  83 */     if (instance == null) {
/*  84 */       instance = new ReplicationQueueAccessor();
/*     */     }
/*  86 */     INSTANCE = instance;
/*     */   }
/*     */   @Inject
/*     */   protected ReplicationEventLogWriter _eventLogWriter;
/*     */   private final String myDataSource_;
/*     */   private final int maxRecordsPerCycle_;
/*     */   
/*     */   public static ReplicationQueueAccessor getInstance() {
/*  94 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ReplicationQueueAccessor() {
/* 113 */     InjectionHammer.forceAtInjectProcessing(this);
/*     */     
/* 115 */     String myDataSource = "Local";
/*     */     try {
/* 117 */       myDataSource = DtxReplicationConfigHelper.getReplicationQueueConfig().getDataSource();
/*     */     } finally {
/*     */       
/* 120 */       this.myDataSource_ = myDataSource;
/*     */     } 
/* 122 */     auditLogger_.info("Replication datasource is: " + this.myDataSource_);
/*     */     
/* 124 */     int maxRecordsPerCycle = 50;
/*     */     try {
/* 126 */       maxRecordsPerCycle = DtxReplicationConfigHelper.getReplicationQueueConfig().getMaxRecsPerCycle();
/*     */     } finally {
/*     */       
/* 129 */       this.maxRecordsPerCycle_ = maxRecordsPerCycle;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addObject(ReplicationTransaction argTransaction) {
/* 140 */     boolean SAVE_REQUIRED = true;
/*     */     
/*     */     try {
/* 143 */       boolean success = addObjectImpl(argTransaction, this.myDataSource_, null, true);
/* 144 */       if (!success)
/*     */       {
/*     */         
/* 147 */         String msg = "An unexpected error occurred while adding a transaction to the replication queue. No exception thrown, just failure reported. XML SQL data:\n" + argTransaction.getPersistablesAsXml();
/* 148 */         logger_.error(msg, new Throwable("STACK TRACE"));
/* 149 */         throw new ReplicationException(msg);
/*     */       }
/*     */     
/* 152 */     } catch (Exception ee) {
/* 153 */       logger_.error("Serious replication queue error - could not save save entry to replication queue. " + argTransaction
/* 154 */           .getPersistablesAsXml(), ee);
/* 155 */       if (ee instanceof RuntimeException) {
/* 156 */         throw (RuntimeException)ee;
/*     */       }
/*     */       
/* 159 */       throw new ReplicationException("An error occurred while saving to the replication queue.", ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addObjectRemote(ReplicationTransaction argTransaction, String argDataSource, String argDestinationService) {
/* 177 */     boolean SAVE_NOT_REQUIRED = false;
/*     */     
/* 179 */     return addObjectImpl(argTransaction, argDataSource, argDestinationService, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void existingTransactionFailed(IDtxReplicationDispatcher.DispatchResult argResult, ReplicationTransaction argTransaction) {
/* 189 */     auditLogger_.debug("BEGIN existingTransactionFailed");
/* 190 */     StringBuilder sql = new StringBuilder(176);
/* 191 */     sql.append("update ctl_replication_queue");
/* 192 */     switch (argResult) {
/*     */       case DISPATCH_OFFLINE_FAILURE:
/* 194 */         sql.append(" set offline_failures = offline_failures + 1");
/*     */         break;
/*     */       case DISPATCH_ERROR_FAILURE:
/* 197 */         sql.append(" set error_failures = error_failures + 1");
/*     */         break;
/*     */       default:
/* 200 */         throw new ReplicationException("Unknown DispatchResult: " + argResult);
/*     */     } 
/* 202 */     sql.append(" where organization_id = ? and rtl_loc_id = ? and wkstn_id = ? and db_trans_id = ? and service_name = ?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     try(Connection dbConnection = getConnection(); 
/* 209 */         PreparedStatement ps = dbConnection.prepareStatement(sql.toString())) {
/* 210 */       ps.setLong(1, argTransaction.getOrganizationId());
/* 211 */       ps.setLong(2, argTransaction.getRetailLocationId());
/* 212 */       ps.setLong(3, argTransaction.getWorkstationId());
/* 213 */       ps.setString(4, argTransaction.getTransactionId());
/* 214 */       ps.setString(5, argTransaction.getServiceName());
/* 215 */       auditLogger_.debug("BEGIN ps.execute() existingTransactionFailed");
/* 216 */       ps.execute();
/* 217 */       auditLogger_.debug("END ps.execute() existingTransactionFailed");
/*     */     }
/* 219 */     catch (Exception ee) {
/* 220 */       if (FailoverException.isFailover(ee)) {
/* 221 */         logger_.warn("Failed to update a failure count in replication queue for db trans id: " + argTransaction
/* 222 */             .getTransactionId() + " because of failover: " + ee);
/*     */       } else {
/*     */         
/* 225 */         logger_.warn("An unexpected error occurred while updating an entry from the replication log. db_trans_id = " + argTransaction
/*     */             
/* 227 */             .getTransactionId() + " service_name = " + argTransaction.getServiceName(), ee);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 232 */     auditLogger_.debug("END existingTransactionFailed");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ReplicationTransaction> getReplicationTransactions(int argMinFailureLevel, int argMaxFailureLevel) {
/* 246 */     return getReplicationTransactions(null, argMinFailureLevel, argMaxFailureLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ReplicationTransaction> getReplicationTransactions(String argServiceName, int argMinFailureLevel, int argMaxFailureLevel) {
/* 261 */     long workstationStart = _replicationQueueConfig.getWorkstationStart();
/* 262 */     long workstationEnd = _replicationQueueConfig.getWorkstationEnd();
/*     */     
/* 264 */     if (workstationStart > 0L && workstationEnd > 0L && workstationEnd > workstationStart) {
/* 265 */       List<ReplicationTransaction> list = new ArrayList<>();
/*     */       long workstationId;
/* 267 */       for (workstationId = workstationStart; workstationId <= workstationEnd; workstationId++) {
/*     */         
/* 269 */         List<ReplicationTransaction> transactions = getReplicationTransactions(argServiceName, argMinFailureLevel, argMaxFailureLevel, workstationId);
/* 270 */         if (transactions != null) {
/* 271 */           list.addAll(transactions);
/*     */         }
/*     */       } 
/*     */       
/* 275 */       return list;
/*     */     } 
/*     */     
/* 278 */     return getReplicationTransactions(argServiceName, argMinFailureLevel, argMaxFailureLevel, 
/* 279 */         getWorkstationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ReplicationTransaction> getReplicationTransactions(String argServiceName, int argMinFailureLevel, int argMaxFailureLevel, long argWorkstationId) {
/* 297 */     if (auditLogger_.isDebugEnabled()) {
/* 298 */       auditLogger_.debug("BEGIN getReplicationTransactions min: " + argMinFailureLevel + "max: " + argMaxFailureLevel);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     if (argMaxFailureLevel != -1 && argMinFailureLevel != -1 && argMaxFailureLevel < argMinFailureLevel)
/*     */     {
/* 308 */       throw new ReplicationException("Invalid min & max provided to getReplicationTransactions.  max < min. Min = " + argMinFailureLevel + " Max = " + argMaxFailureLevel);
/*     */     }
/*     */ 
/*     */     
/* 312 */     if (argMinFailureLevel < -1 || argMaxFailureLevel < -1) {
/* 313 */       throw new ReplicationException("Invalid min & max provided to getReplicationTransactions.  min or max is < -1. Min = " + argMinFailureLevel + " Max = " + argMaxFailureLevel);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 318 */     List<ReplicationTransaction> resultObjects = null;
/*     */     
/*     */     try {
/* 321 */       resultObjects = queryReplicationTransactions(argServiceName, argMinFailureLevel, argMaxFailureLevel, argWorkstationId);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 326 */       if (++currentErrorCycle_ % ERROR_NOTIFICATION_CYCLES == 0) {
/* 327 */         int errorFails_ = queryErrorFailureCount(argWorkstationId);
/* 328 */         if (errorFails_ > 0) {
/* 329 */           auditLogger_.error("REPLICATION ENTRIES WITH ERROR FAILURES: " + errorFails_);
/* 330 */           this._eventLogWriter.writeRepQueueFailureEventLogEntry("ERROR", "REPLICATION ENTRIES WITH ERROR FAILURES: " + errorFails_, argWorkstationId);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 338 */       int noFails_ = queryNonFailedRecCount(argWorkstationId);
/* 339 */       if (noFails_ > NO_FAILS_LIMIT) {
/* 340 */         auditLogger_.warn("PENDING REPLICATION RECORDS: " + noFails_);
/* 341 */         this._eventLogWriter.writeRepQueueNoFailureEventLogEntry("WARN", "PENDING REPLICATION RECORDS: " + noFails_, argWorkstationId);
/*     */       }
/*     */     
/*     */     }
/* 345 */     catch (Exception ee) {
/* 346 */       if (FailoverException.isFailover(ee)) {
/* 347 */         logger_.warn("A failover exception occured while querying the replication queue: " + ee.toString());
/*     */       } else {
/*     */         
/* 350 */         logger_.error("An unexpected error occured while querying the replication queue.", ee);
/* 351 */         this._eventLogWriter.writeRepQueueReadErrorEventLogEntry("ERROR", "ERROR OCCURRED WHILE QUERYING REP QUEUE", ee, argWorkstationId);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 356 */     if (auditLogger_.isDebugEnabled()) {
/* 357 */       String resultObjectCount = (resultObjects == null) ? "null" : String.valueOf(resultObjects.size());
/* 358 */       auditLogger_.debug("END getReplicationTransactions min: " + argMinFailureLevel + "max: " + argMaxFailureLevel + " Returning " + resultObjectCount + " replication entries");
/*     */     } 
/*     */ 
/*     */     
/* 362 */     return resultObjects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int queryNonFailedRecCount(long argWorkstationId) throws SQLException {
/* 374 */     int noFails = 0;
/* 375 */     try(Connection dbConnection = getConnection(); 
/* 376 */         PreparedStatement ps = dbConnection.prepareStatement("select count(*) from ctl_replication_queue where organization_id = ? and rtl_loc_id = ? and wkstn_id = ? and error_failures = 0 and offline_failures = 0")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 384 */       ps.setLong(1, getOrganizationId());
/* 385 */       ps.setInt(2, getRetailLocationId());
/* 386 */       ps.setLong(3, argWorkstationId);
/* 387 */       try (ResultSet results = ps.executeQuery()) {
/*     */         
/* 389 */         if (results != null) {
/* 390 */           while (results.next()) {
/* 391 */             noFails = results.getInt(1);
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 396 */     return noFails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ReplicationTransaction> queryReplicationTransactions(String argServiceName, int argMinFailureLevel, int argMaxFailureLevel, long argWorkstationId) throws SQLException {
/* 414 */     List<ReplicationTransaction> resultObjects = new ArrayList<>(this.maxRecordsPerCycle_);
/* 415 */     try (Connection dbConnection = getConnection()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 421 */       StringBuilder sql = new StringBuilder(192);
/*     */       
/* 423 */       sql.append("select organization_id, rtl_loc_id, wkstn_id, db_trans_id, service_name, date_time, expires_after, expires_immediately_flag, never_expires_flag, error_failures, replication_data from ctl_replication_queue where organization_id = ? and rtl_loc_id = ? and wkstn_id = ?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 431 */       if (argMinFailureLevel == argMaxFailureLevel) {
/* 432 */         if (argMaxFailureLevel != -1) {
/* 433 */           sql.append(" and error_failures = ").append(argMinFailureLevel);
/*     */         }
/*     */       } else {
/*     */         
/* 437 */         if (argMinFailureLevel > -1) {
/* 438 */           sql.append(" and error_failures >= ").append(argMinFailureLevel);
/*     */         }
/* 440 */         if (argMaxFailureLevel > -1) {
/* 441 */           sql.append(" and error_failures < ").append(argMaxFailureLevel);
/*     */         }
/*     */       } 
/* 444 */       if (argServiceName != null) {
/* 445 */         sql.append(" and service_name = ? ");
/*     */       }
/* 447 */       sql.append(" order by date_time asc");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 459 */       try (PreparedStatement ps = dbConnection.prepareStatement(sql.toString())) {
/*     */         
/* 461 */         ps.setMaxRows(this.maxRecordsPerCycle_);
/* 462 */         ps.setFetchSize(this.maxRecordsPerCycle_);
/*     */         
/* 464 */         ps.setLong(1, getOrganizationId());
/* 465 */         ps.setInt(2, getRetailLocationId());
/* 466 */         ps.setLong(3, argWorkstationId);
/* 467 */         if (argServiceName != null) {
/* 468 */           ps.setString(4, argServiceName);
/*     */         }
/* 470 */         auditLogger_.debug("BEGIN ps.executeQuery() getReplicationTransactions");
/* 471 */         try (ResultSet results = ps.executeQuery()) {
/* 472 */           auditLogger_.debug("END ps.executeQuery() getReplicationTransactions");
/* 473 */           if (results != null) {
/* 474 */             while (results.next()) {
/* 475 */               if (auditLogger_.isDebugEnabled()) {
/* 476 */                 auditLogger_.debug("BEGIN Process result " + (resultObjects.size() + 1));
/*     */               }
/* 478 */               ReplicationTransaction trans = new ReplicationTransaction();
/* 479 */               trans.setOrganizationId(results.getLong(1));
/* 480 */               trans.setRetailLocationId(results.getInt(2));
/* 481 */               trans.setWorkstationId(results.getLong(3));
/* 482 */               trans.setTransactionId(results.getString(4));
/* 483 */               trans.setServiceName(results.getString(5));
/* 484 */               trans.setCreatedTime(results.getLong(6));
/* 485 */               trans.setExpiresAfter(results.getLong(7));
/* 486 */               trans.setExpiresImmediately((results.getInt(8) != 0));
/* 487 */               trans.setNeverExpires((results.getInt(9) != 0));
/* 488 */               trans.setFailedErrorAttempts(results.getInt(10));
/* 489 */               trans.addDataAsXmlString(JDBCHelper.clobToString(results, 11));
/* 490 */               trans.setNewTransaction(false);
/*     */               
/* 492 */               resultObjects.add(trans);
/* 493 */               if (auditLogger_.isDebugEnabled()) {
/* 494 */                 auditLogger_.debug("END Process result " + resultObjects.size());
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 501 */     return resultObjects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeObject(ReplicationTransaction argTransaction) {
/* 510 */     if (auditLogger_.isDebugEnabled()) {
/* 511 */       auditLogger_.debug("BEGIN removeObject trans: " + argTransaction.getTransactionId());
/*     */     }
/*     */     
/* 514 */     int retries = 0;
/*     */     
/* 516 */     while (retries++ < MAX_RETRIES) {
/* 517 */       try(Connection dbConnection = getConnection(); 
/* 518 */           PreparedStatement ps = dbConnection.prepareStatement("delete from ctl_replication_queue where organization_id = ? and rtl_loc_id = ? and wkstn_id = ? and db_trans_id = ? and service_name = ?")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 526 */         ps.setLong(1, argTransaction.getOrganizationId());
/* 527 */         ps.setLong(2, argTransaction.getRetailLocationId());
/* 528 */         ps.setLong(3, argTransaction.getWorkstationId());
/* 529 */         ps.setString(4, argTransaction.getTransactionId());
/* 530 */         ps.setString(5, argTransaction.getServiceName());
/*     */         
/* 532 */         if (auditLogger_.isDebugEnabled()) {
/* 533 */           auditLogger_.debug("BEGIN ps.execute() removeObject trans: " + argTransaction.getTransactionId());
/*     */         }
/*     */         
/* 536 */         ps.execute();
/*     */         
/* 538 */         if (auditLogger_.isDebugEnabled()) {
/* 539 */           auditLogger_.debug("END ps.execute() removeObject trans: " + argTransaction.getTransactionId());
/*     */         }
/*     */ 
/*     */         
/* 543 */         if (ps != null) if (null != null) { try { ps.close(); } catch (Throwable throwable) { null.addSuppressed(throwable); }  } else { ps.close(); }  
/* 544 */       } catch (Exception ee) {
/*     */         
/* 546 */         auditLogger_.debug("removeObject exception caught " + ee + " retries: " + retries);
/*     */         
/* 548 */         if (FailoverException.isFailover(ee)) {
/*     */           try {
/* 550 */             Thread.sleep(RETRY_WAIT);
/*     */           }
/* 552 */           catch (Exception exception) {}
/*     */ 
/*     */           
/* 555 */           if (retries == MAX_RETRIES) {
/* 556 */             logger_.warn("Failed to delete replication from queue because queue datasource is offline. Transaction id: " + argTransaction
/*     */                 
/* 558 */                 .getTransactionId() + " Exception: " + ee);
/*     */           }
/*     */           continue;
/*     */         } 
/* 562 */         logger_.warn("An unexpected error occurred while removing an entry from the replication queue. db_trans_id = " + argTransaction
/*     */             
/* 564 */             .getTransactionId() + " service_name = " + argTransaction.getServiceName(), ee);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 571 */     if (auditLogger_.isDebugEnabled()) {
/* 572 */       auditLogger_.debug("END removeObject trans: " + argTransaction.getTransactionId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void resetOfflineFailureCounts() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void resetOfflineFailureCounts(long argWorkstationId) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean addObjectImpl(ReplicationTransaction argTransaction, String argDataSource, String destinationService, boolean argRequiredSave) {
/* 606 */     if (auditLogger_.isDebugEnabled()) {
/* 607 */       auditLogger_.debug("BEGIN addObjectImpl for trans: " + argTransaction.getTransactionId());
/*     */     }
/*     */     
/* 610 */     boolean done = false;
/* 611 */     int retries = 0;
/*     */     
/* 613 */     while (!done) {
/*     */       
/* 615 */       try(Connection dbConnection = getConnection(); 
/* 616 */           PreparedStatement ps = dbConnection.prepareStatement("insert into ctl_replication_queue (organization_id, rtl_loc_id, wkstn_id, db_trans_id, service_name, date_time, expires_after, expires_immediately_flag, never_expires_flag, offline_failures, error_failures, replication_data) values (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 626 */         ps.setLong(1, argTransaction.getOrganizationId());
/* 627 */         ps.setLong(2, argTransaction.getRetailLocationId());
/* 628 */         ps.setLong(3, argTransaction.getWorkstationId());
/* 629 */         ps.setString(4, argTransaction.getTransactionId());
/* 630 */         ps.setString(5, (destinationService == null) ? argTransaction.getServiceName() : destinationService);
/* 631 */         ps.setLong(6, argTransaction.getCreatedTime());
/*     */         
/* 633 */         if (!argTransaction.getExpiresImmediately() && !argTransaction.getNeverExpires() && argTransaction
/* 634 */           .getExpiresAfter() > 0L) {
/* 635 */           ps.setString(7, String.valueOf(argTransaction.getExpiresAfter()));
/*     */         } else {
/*     */           
/* 638 */           ps.setNull(7, 4);
/*     */         } 
/*     */         
/* 641 */         ps.setInt(8, argTransaction.getExpiresImmediately() ? 1 : 0);
/* 642 */         ps.setInt(9, argTransaction.getNeverExpires() ? 1 : 0);
/* 643 */         ps.setInt(10, argTransaction.getFailedErrorAttempts());
/* 644 */         ps.setString(11, argTransaction.getPersistablesAsXml());
/* 645 */         auditLogger_.debug("BEGIN addObjectImpl ps.execute() for INSERT");
/* 646 */         ps.execute();
/* 647 */         auditLogger_.debug("END addObjectImpl ps.execute() for INSERT - returning true");
/*     */         
/* 649 */         return true;
/*     */       }
/* 651 */       catch (Exception ee) {
/* 652 */         done = false;
/*     */         
/* 654 */         auditLogger_.debug("Exception caught during addObjectImpl " + ee);
/*     */         
/* 656 */         if (!FailoverException.isFailover(ee) || retries >= MAX_RETRIES) {
/* 657 */           if (argRequiredSave) {
/* 658 */             String str = "An unexpected error occurred while saving to the replication queue. Replication data may have been lost.";
/*     */             
/* 660 */             logger_.fatal(str, ee);
/* 661 */             throw new ReplicationException(str, ee);
/*     */           } 
/*     */           
/* 664 */           String msg = "Failed to save data to replication queue.";
/* 665 */           throw new ReplicationException(msg, ee);
/*     */         } 
/*     */ 
/*     */         
/* 669 */         retries++;
/* 670 */         if (logger_.isDebugEnabled()) {
/* 671 */           logger_.debug("Failover detected on replication queue datasource: [" + argDataSource + "], will retry (retry count: + " + retries + " MAX_RETRIES: " + MAX_RETRIES, ee);
/*     */         }
/*     */ 
/*     */         
/* 675 */         auditLogger_
/* 676 */           .debug("addObjectImpl will retry.  going to sleep " + RETRY_WAIT + " retries: " + retries);
/*     */         
/*     */         try {
/* 679 */           Thread.sleep(RETRY_WAIT);
/*     */         }
/* 681 */         catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 688 */     auditLogger_.warn("addObjectImpl could not save, preparing to throw.");
/* 689 */     throw new ReplicationException("Invalid state in ReplicationQueueAccessor - this code should NOT be hit - Replication queue entry NOT saved. Service:  " + argTransaction
/*     */         
/* 691 */         .getServiceName() + " Data: " + argTransaction
/* 692 */         .getPersistablesAsXml());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnection() {
/*     */     DBConnection dBConnection;
/* 702 */     Connection dbConnection = null;
/*     */     
/* 704 */     int retries = 0;
/*     */     
/* 706 */     while (dbConnection == null && retries++ < MAX_RETRIES) {
/*     */       try {
/* 708 */         dBConnection = JDBCDataSourceMgr.getInstance().getConnection(this.myDataSource_);
/*     */       }
/* 710 */       catch (Exception ee) {
/* 711 */         if (FailoverException.isFailover(ee)) {
/* 712 */           logger_.warn("A failover occurred while obtaining replication queue datasource. [" + this.myDataSource_ + "] " + ee);
/*     */           
/*     */           try {
/* 715 */             Thread.sleep(RETRY_WAIT);
/*     */           }
/* 717 */           catch (InterruptedException interruptedException) {}
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 722 */         String msg = "An exception occurred while obtaining the datasource used for the replication queue: [" + this.myDataSource_ + "].  This datasource MUST be enabled, available, and use JDBCPersistenceStrategy for replication to function.";
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 727 */         logger_.error(msg, ee);
/*     */         
/* 729 */         throw new ReplicationException(msg, ee);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 734 */     if (dBConnection == null) {
/* 735 */       throw new ReplicationException("Unable to obtain datasource for replication queue [" + this.myDataSource_ + "]");
/*     */     }
/*     */ 
/*     */     
/* 739 */     return (Connection)dBConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getOrganizationId() {
/* 748 */     return this._persistenceDefaults.getOrganizationId().longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getRetailLocationId() {
/* 757 */     return this._persistenceDefaults.getRetailLocationId().intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getWorkstationId() {
/* 766 */     return this._persistenceDefaults.getWorkstationId().longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int queryErrorFailureCount(long argWorkstationId) throws SQLException {
/* 779 */     int errorFails = 0;
/* 780 */     try(Connection dbConnection = getConnection(); 
/* 781 */         PreparedStatement ps = dbConnection.prepareStatement("select count(*) from ctl_replication_queue where organization_id = ? and rtl_loc_id = ? and wkstn_id = ? and error_failures > 0")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 788 */       ps.setLong(1, getOrganizationId());
/* 789 */       ps.setInt(2, getRetailLocationId());
/* 790 */       ps.setLong(3, argWorkstationId);
/* 791 */       try (ResultSet results = ps.executeQuery()) {
/* 792 */         if (results != null) {
/* 793 */           while (results.next()) {
/* 794 */             errorFails = results.getInt(1);
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 799 */     return errorFails;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\replication\dtximpl\ReplicationQueueAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */