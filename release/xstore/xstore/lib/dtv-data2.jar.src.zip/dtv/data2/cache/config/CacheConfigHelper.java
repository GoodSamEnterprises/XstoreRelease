/*    */ package dtv.data2.cache.config;
/*    */ 
/*    */ import dtv.util.config.BooleanConfig;
/*    */ import dtv.util.config.ConfigHelper;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import dtv.util.config.StringConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheConfigHelper
/*    */   extends ConfigHelper<CacheConfig>
/*    */ {
/*    */   private static CacheConfig cacheConfig_;
/*    */   
/*    */   static {
/* 22 */     (new CacheConfigHelper()).initialize();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CacheConfig getCacheConfig() {
/* 31 */     return cacheConfig_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CacheDefinitionConfig getCacheDefConfig(String argCacheId) {
/* 41 */     CacheDefinitionConfig cacheConfig = cacheConfig_.getCaches().get(argCacheId);
/* 42 */     if (cacheConfig != null) {
/* 43 */       return cacheConfig;
/*    */     }
/*    */     
/* 46 */     return cacheConfig_.getCaches().get("default-cache");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void hashRootConfigs() {
/* 53 */     super.hashRootConfigs();
/* 54 */     cacheConfig_ = (CacheConfig)getRootConfig();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getConfigFileName() {
/* 60 */     return "CacheConfig";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected IConfigObject getConfigObject(String argTagName, String dtype, String argSourceDescription) {
/* 66 */     if ("CacheConfig".equals(argTagName)) {
/* 67 */       return (IConfigObject)new CacheConfig();
/*    */     }
/* 69 */     if ("id".equals(argTagName) || "key"
/* 70 */       .equals(argTagName) || "value"
/* 71 */       .equals(argTagName) || "Impl"
/* 72 */       .equals(argTagName) || "CacheFilterRef"
/* 73 */       .equals(argTagName)) {
/* 74 */       return (IConfigObject)new StringConfig();
/*    */     }
/* 76 */     if ("clearable".equals(argTagName) || "cacheable"
/* 77 */       .equals(argTagName)) {
/* 78 */       return (IConfigObject)new BooleanConfig();
/*    */     }
/* 80 */     if ("GlobalProperties".equals(argTagName)) {
/* 81 */       return (IConfigObject)new GlobalPropertiesConfig();
/*    */     }
/* 83 */     if ("Cache".equals(argTagName)) {
/* 84 */       return (IConfigObject)new CacheDefinitionConfig();
/*    */     }
/* 86 */     if ("Property".equals(argTagName)) {
/* 87 */       return (IConfigObject)new CachePropertyConfig();
/*    */     }
/* 89 */     if ("CacheFilter".equals(argTagName)) {
/* 90 */       return (IConfigObject)new CacheFilterConfig();
/*    */     }
/* 92 */     if ("Object".equals(argTagName)) {
/* 93 */       return (IConfigObject)new FilterObjectConfig();
/*    */     }
/* 95 */     if ("WriteThroughCacheEnabled".equals(argTagName)) {
/* 96 */       return (IConfigObject)new BooleanConfig();
/*    */     }
/*    */     
/* 99 */     return super.getConfigObject(argTagName, dtype, argSourceDescription);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\config\CacheConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */