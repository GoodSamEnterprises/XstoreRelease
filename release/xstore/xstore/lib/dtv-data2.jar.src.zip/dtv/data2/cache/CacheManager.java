/*     */ package dtv.data2.cache;
/*     */ 
/*     */ import dtv.data2.cache.config.CacheConfigHelper;
/*     */ import dtv.data2.cache.impl.DummyCache;
/*     */ import dtv.util.StringUtils;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheManager
/*     */ {
/*     */   public static final String DEFAULT_CACHE_ID = "default-cache";
/*  27 */   private static final Logger logger_ = Logger.getLogger(CacheManager.class);
/*  28 */   private static final boolean DEBUG = logger_.isDebugEnabled();
/*     */   private static final CacheManager INSTANCE;
/*  30 */   private static final Map<String, ICache> registeredCaches_ = new HashMap<>();
/*     */   
/*     */   static {
/*  33 */     CacheManager temp = null;
/*     */     
/*     */     try {
/*  36 */       String className = System.getProperty("dtv.data2.cache.CacheManager", "dtv.data2.cache.CacheManager");
/*  37 */       temp = (CacheManager)Class.forName(className).newInstance();
/*  38 */       if (DEBUG) {
/*  39 */         logger_.debug("CacheManager initialized as: " + temp);
/*     */       }
/*     */     }
/*  42 */     catch (Exception ee) {
/*  43 */       logger_.error("Error created object for system property: dtv.data2.cache.CacheManager", ee);
/*  44 */       temp = new CacheManager();
/*     */     } finally {
/*     */       
/*  47 */       INSTANCE = temp;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor<ICache> permanentCacheConstructor_;
/*     */ 
/*     */   
/*     */   public static CacheManager getInstance() {
/*  57 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  75 */     if (DEBUG) {
/*  76 */       logger_.debug("begin clear()");
/*     */     }
/*  78 */     Set<String> cacheIds = null;
/*  79 */     synchronized (registeredCaches_) {
/*  80 */       cacheIds = registeredCaches_.keySet();
/*     */     } 
/*     */     
/*  83 */     if (DEBUG) {
/*  84 */       logger_.debug("Preparing to clear managed caches: " + cacheIds);
/*     */     }
/*     */     
/*  87 */     for (String cacheName : cacheIds) {
/*  88 */       clear(cacheName);
/*     */     }
/*  90 */     if (DEBUG) {
/*  91 */       logger_.debug("end clear()");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear(String argCacheId) {
/* 101 */     if (DEBUG) {
/* 102 */       logger_.debug("begin clear(String) for cache id [" + argCacheId + "] clearable: " + 
/* 103 */           CacheConfigHelper.getCacheDefConfig(argCacheId).isClearable());
/*     */     }
/* 105 */     if (CacheConfigHelper.getCacheDefConfig(argCacheId).isClearable()) {
/* 106 */       synchronized (registeredCaches_) {
/* 107 */         ICache cache = registeredCaches_.get(argCacheId);
/* 108 */         if (cache != null) {
/* 109 */           cache.clear();
/*     */         }
/*     */       } 
/*     */     }
/* 113 */     if (DEBUG) {
/* 114 */       logger_.debug("end clear(String) for cache id [" + argCacheId + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsCache(String argCacheId) {
/* 125 */     synchronized (registeredCaches_) {
/* 126 */       return registeredCaches_.containsKey(massageCacheId(argCacheId));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ICache getCache(String argCacheId) {
/* 136 */     return getCache(argCacheId, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ICache getCache(String argCacheId, boolean wrapWithFilteringCache) {
/* 146 */     if (DEBUG) {
/* 147 */       logger_.debug("Request made for cache id [" + argCacheId + "]");
/*     */     }
/*     */     
/* 150 */     synchronized (registeredCaches_) {
/* 151 */       DummyCache dummyCache; String cacheId = massageCacheId(argCacheId);
/* 152 */       if (DEBUG) {
/* 153 */         logger_.debug("Massaged cache id to [" + cacheId + "]");
/*     */       }
/*     */       
/* 156 */       if (registeredCaches_.containsKey(cacheId)) {
/* 157 */         ICache cache = registeredCaches_.get(cacheId);
/* 158 */         if (DEBUG) {
/* 159 */           logger_.debug("CacheManager initialized as: " + INSTANCE);
/*     */         }
/* 161 */         if (cache != null) {
/* 162 */           if (DEBUG) {
/* 163 */             logger_.debug("Cache [" + cacheId + "] already exists, returning existing version.");
/*     */           }
/* 165 */           return cache;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 171 */         ICache cache = CacheConfigHelper.getCacheDefConfig(cacheId).getCacheImpl().newInstance();
/* 172 */         if (wrapWithFilteringCache)
/*     */         {
/*     */           
/* 175 */           cache = new FilteringCache(cache);
/*     */         }
/* 177 */         if (DEBUG) {
/* 178 */           logger_.debug("Initializing Cache [" + cacheId + "]");
/*     */         }
/* 180 */         cache.init(cacheId);
/*     */       }
/* 182 */       catch (Exception ee) {
/* 183 */         logger_.error("An exception occurred while create instance of class: " + this.permanentCacheConstructor_, ee);
/*     */         
/* 185 */         dummyCache = new DummyCache();
/* 186 */         dummyCache.init(cacheId);
/*     */       } 
/* 188 */       registeredCaches_.put(cacheId, dummyCache);
/*     */       
/* 190 */       return (ICache)dummyCache;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ICache> getManagedCaches() {
/* 200 */     synchronized (registeredCaches_) {
/* 201 */       return new ArrayList<>(registeredCaches_.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 209 */     synchronized (registeredCaches_) {
/* 210 */       List<String> cacheKeys = new ArrayList<>(registeredCaches_.keySet());
/* 211 */       for (String cacheKey : cacheKeys) {
/* 212 */         ICache cache = registeredCaches_.remove(cacheKey);
/*     */         try {
/* 214 */           cache.destroy();
/*     */         }
/* 216 */         catch (Throwable t) {
/* 217 */           logger_.warn("Cache " + cache.getCacheId() + " could not be successfully destroyed.");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String massageCacheId(String argCacheId) {
/* 230 */     if (StringUtils.isEmpty(argCacheId)) {
/* 231 */       return "default-cache";
/*     */     }
/* 233 */     return argCacheId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class CacheAlreadyRegisteredException
/*     */     extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private CacheAlreadyRegisteredException(String message) {
/* 251 */       super(message);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\CacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */