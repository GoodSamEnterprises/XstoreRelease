/*     */ package dtv.data2.cache;
/*     */ 
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.cache.config.CacheConfigHelper;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteringCache
/*     */   implements ICache
/*     */ {
/*  25 */   private static final Logger logger_ = Logger.getLogger(CacheManager.class);
/*  26 */   private static final boolean DEBUG = logger_.isDebugEnabled();
/*     */ 
/*     */   
/*     */   private final ICache wrappedCache_;
/*     */ 
/*     */   
/*     */   private String[] filter_;
/*     */ 
/*     */ 
/*     */   
/*     */   public FilteringCache(ICache argWrappedCache) {
/*  37 */     this.wrappedCache_ = argWrappedCache;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  43 */     this.wrappedCache_.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  49 */     this.wrappedCache_.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object argKey) throws NotCachedException {
/*  57 */     if (isCacheable(argKey)) {
/*  58 */       return this.wrappedCache_.get(argKey);
/*     */     }
/*     */     
/*  61 */     if (DEBUG) {
/*  62 */       logger_
/*  63 */         .debug("get() from cache '" + getCacheId() + "' not attempted.  Key is not cacheable: " + argKey);
/*     */     }
/*  65 */     throw new NotCachedException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCacheId() {
/*  72 */     return this.wrappedCache_.getCacheId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSafely(Object argKey) {
/*  79 */     if (isCacheable(argKey)) {
/*  80 */       return this.wrappedCache_.getSafely(argKey);
/*     */     }
/*     */     
/*  83 */     if (DEBUG) {
/*  84 */       logger_
/*  85 */         .debug("get() from cache '" + getCacheId() + "' not attempted.  Key is not cacheable: " + argKey);
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusReport() {
/*  94 */     return this.wrappedCache_.getStatusReport();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(String argCacheId) {
/* 100 */     String filterId = CacheConfigHelper.getCacheDefConfig(argCacheId).getCacheFilterRef();
/* 101 */     if (DEBUG) {
/* 102 */       logger_.debug("FilteringSyncCache init() for cache id: " + argCacheId + " filter id: " + filterId);
/*     */     }
/*     */     
/* 105 */     if (!StringUtils.isEmpty(filterId)) {
/* 106 */       Map<String, Boolean> filterMap = CacheConfigHelper.getCacheConfig().getCacheFilter(filterId);
/* 107 */       if (filterMap != null) {
/* 108 */         List<String> filterList = new ArrayList<>();
/* 109 */         for (Map.Entry<String, Boolean> filterValue : filterMap.entrySet()) {
/* 110 */           if (((Boolean)filterValue.getValue()).booleanValue()) {
/* 111 */             filterList.add(filterValue.getKey());
/*     */           }
/*     */         } 
/* 114 */         String[] filter = filterList.<String>toArray(new String[filterList.size()]);
/* 115 */         Arrays.sort((Object[])filter);
/* 116 */         this.filter_ = filter;
/*     */       } else {
/*     */         
/* 119 */         this.filter_ = null;
/*     */       } 
/*     */     } 
/*     */     
/* 123 */     this.wrappedCache_.init(argCacheId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object argKey, Object argValue) {
/* 130 */     if (isCacheable(argKey)) {
/* 131 */       this.wrappedCache_.put(argKey, argValue);
/*     */     
/*     */     }
/* 134 */     else if (DEBUG) {
/* 135 */       logger_.debug("put() into cache '" + getCacheId() + "' not attempted.  Key is not cacheable. (Key: " + argKey + " Value: " + argValue + ")");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Object argKey) {
/* 144 */     if (isCacheable(argKey)) {
/* 145 */       this.wrappedCache_.remove(argKey);
/*     */     
/*     */     }
/* 148 */     else if (DEBUG) {
/* 149 */       logger_.debug("remove() from cache '" + 
/* 150 */           getCacheId() + "' not attempted.  Key is not cacheable: " + argKey);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCacheable(Object argKey) {
/* 161 */     if (this.filter_ == null) {
/* 162 */       if (DEBUG) {
/* 163 */         logger_.debug("Cache elegibility on cache " + getCacheId() + " is true for key:" + argKey + " (No filter is defined for this cache.)");
/*     */       }
/*     */       
/* 166 */       return true;
/*     */     } 
/*     */     
/* 169 */     int cacheIndex = -1;
/* 170 */     if (argKey instanceof String) {
/* 171 */       cacheIndex = Arrays.binarySearch((Object[])this.filter_, argKey);
/*     */     }
/* 173 */     else if (argKey instanceof QueryRequest) {
/* 174 */       cacheIndex = Arrays.binarySearch((Object[])this.filter_, ((QueryRequest)argKey).getQueryKey());
/*     */     } else {
/*     */       
/* 177 */       cacheIndex = Arrays.binarySearch((Object[])this.filter_, argKey.getClass().getName());
/*     */     } 
/* 179 */     if (DEBUG) {
/* 180 */       logger_.debug("Cache elibility on cache " + getCacheId() + " is " + ((cacheIndex >= 0) ? 1 : 0) + " for key: " + argKey + " (filter(s): " + this.filter_ + ")");
/*     */     }
/*     */     
/* 183 */     return (cacheIndex >= 0);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\FilteringCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */