/*    */ package dtv.data2.cache.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheFilterConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String KEY_ID = "id";
/*    */   private static final String KEY_FILTER_OBJECT = "Object";
/*    */   private String cacheFilterId_;
/* 27 */   private final Map<String, Boolean> cacheFilter_ = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Boolean> getCacheFilter() {
/* 35 */     return this.cacheFilter_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCacheFilterId() {
/* 44 */     return this.cacheFilterId_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 50 */     if ("id".equals(argKey)) {
/* 51 */       this.cacheFilterId_ = argValue.toString();
/*    */     }
/* 53 */     else if ("Object".equals(argKey)) {
/* 54 */       this.cacheFilter_.put(((FilterObjectConfig)argValue).getFilterId(), 
/* 55 */           Boolean.valueOf(((FilterObjectConfig)argValue).isCacheable()));
/*    */     } else {
/*    */       
/* 58 */       throw new RuntimeException("Unknown config object: " + argKey + " " + argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\config\CacheFilterConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */