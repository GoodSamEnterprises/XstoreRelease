package dtv.data2.cache;

import java.io.Serializable;

public class NullValue implements Serializable {
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\NullValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */