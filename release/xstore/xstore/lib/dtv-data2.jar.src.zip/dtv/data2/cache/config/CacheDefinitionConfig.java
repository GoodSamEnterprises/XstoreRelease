/*    */ package dtv.data2.cache.config;
/*    */ 
/*    */ import dtv.data2.cache.ICache;
/*    */ import dtv.data2.cache.impl.DummyCache;
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheDefinitionConfig
/*    */   extends AbstractParentConfig
/*    */ {
/* 21 */   private static final Logger logger_ = Logger.getLogger(CacheDefinitionConfig.class);
/*    */   
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   private static final String KEY_ID = "id";
/*    */   
/*    */   private static final String KEY_CLEARABLE = "clearable";
/*    */   
/*    */   private static final String KEY_IMPL = "Impl";
/*    */   
/*    */   private static final String KEY_FILTER_REF = "CacheFilterRef";
/*    */   
/*    */   private String cacheId_;
/*    */   
/*    */   private boolean clearable_;
/*    */   
/*    */   private Class<? extends ICache> cacheImpl_;
/*    */   private String cacheFilterRef_;
/*    */   
/*    */   public String getCacheFilterRef() {
/* 41 */     return this.cacheFilterRef_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCacheId() {
/* 50 */     return this.cacheId_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<? extends ICache> getCacheImpl() {
/* 59 */     return this.cacheImpl_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isClearable() {
/* 68 */     return this.clearable_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 75 */     if ("id".equals(argKey)) {
/* 76 */       this.cacheId_ = argValue.toString();
/*    */     }
/* 78 */     else if ("clearable".equals(argKey)) {
/* 79 */       this.clearable_ = ConfigUtils.toBoolean(argValue);
/*    */     }
/* 81 */     else if ("Impl".equals(argKey)) {
/*    */       try {
/* 83 */         this.cacheImpl_ = (Class)Class.forName(argValue.toString());
/*    */       }
/* 85 */       catch (Exception ee) {
/* 86 */         logger_.error("Excpetion occured while create class: " + argValue.toString(), ee);
/* 87 */         this.cacheImpl_ = (Class)DummyCache.class;
/*    */       }
/*    */     
/* 90 */     } else if ("CacheFilterRef".equals(argKey)) {
/* 91 */       this.cacheFilterRef_ = argValue.toString();
/*    */     } else {
/*    */       
/* 94 */       throw new RuntimeException("Unknown config object: " + argKey + " " + argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\config\CacheDefinitionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */