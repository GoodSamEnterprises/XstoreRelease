/*     */ package dtv.data2.cache;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCache
/*     */   implements ICache
/*     */ {
/*     */   protected static final String GLOBAL_CACHE_CONFIG_ID = "global";
/*  23 */   protected static final NullValue NULL_VALUE = new NullValue();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  28 */   protected static final NotCachedException NOT_CACHED_EXCEPTION = new NotCachedException();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String cacheId_;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   protected final Logger logger_ = Logger.getLogger(getClass());
/*     */ 
/*     */   
/*  41 */   protected final boolean DEBUG = this.logger_.isDebugEnabled();
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  46 */     if (this.DEBUG) {
/*  47 */       this.logger_.debug("begin clear() cache: " + getCacheId());
/*     */     }
/*  49 */     clearImpl();
/*  50 */     if (this.DEBUG) {
/*  51 */       this.logger_.debug("end clear() cache: " + getCacheId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  58 */     if (this.DEBUG) {
/*  59 */       this.logger_.debug("begin destroy() cache: " + getCacheId());
/*     */     }
/*  61 */     destroyImpl();
/*  62 */     if (this.DEBUG) {
/*  63 */       this.logger_.debug("end destroy() cache: " + getCacheId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object argKey) throws NotCachedException {
/*  71 */     if (this.DEBUG) {
/*  72 */       this.logger_.debug("begin get() on cache '" + getCacheId() + "' for key: " + argKey);
/*     */     }
/*  74 */     Object value = getImpl(argKey);
/*  75 */     if (value == null) {
/*  76 */       if (this.DEBUG) {
/*  77 */         this.logger_.debug("CACHE MISS: cache '" + getCacheId() + "' does not contain key: " + argKey);
/*     */       }
/*  79 */       throw NOT_CACHED_EXCEPTION;
/*     */     } 
/*     */     
/*  82 */     if (value instanceof NullValue) {
/*  83 */       if (this.DEBUG) {
/*  84 */         this.logger_.debug("CACHE HIT: cache '" + getCacheId() + "' contains key: " + argKey + " value: null");
/*     */       }
/*  86 */       return null;
/*     */     } 
/*     */     
/*  89 */     if (this.DEBUG) {
/*  90 */       this.logger_
/*  91 */         .debug("CACHE HIT: cache '" + getCacheId() + "' contains key: " + argKey + " value: " + value);
/*     */     }
/*  93 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCacheId() {
/* 101 */     return this.cacheId_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSafely(Object argKey) {
/* 107 */     if (this.DEBUG) {
/* 108 */       this.logger_.debug("begin get() on cache '" + getCacheId() + "' for key: " + argKey);
/*     */     }
/* 110 */     Object value = getImpl(argKey);
/* 111 */     if (this.DEBUG) {
/* 112 */       if (value == null) {
/* 113 */         this.logger_.debug("CACHE MISS: cache '" + getCacheId() + "' does not contain key: " + argKey);
/*     */       }
/* 115 */       else if (value instanceof NullValue) {
/* 116 */         this.logger_.debug("CACHE HIT: cache '" + getCacheId() + "' contains key: " + argKey + " value: null");
/*     */       } else {
/*     */         
/* 119 */         this.logger_.debug("CACHE HIT: cache '" + getCacheId() + "' contains key: " + argKey + " value: " + value);
/*     */       } 
/*     */     }
/* 122 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusReport() {
/* 128 */     return getClass().getName() + " cache id: [" + getCacheId() + "]\n" + getStatusDetails();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(String argCacheId) {
/* 134 */     setCacheId(argCacheId);
/* 135 */     if (this.DEBUG) {
/* 136 */       this.logger_.debug("begin init() cache: " + getCacheId());
/*     */     }
/* 138 */     initImpl(argCacheId);
/* 139 */     if (this.DEBUG) {
/* 140 */       this.logger_.debug("end init() cache: " + getCacheId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object argKey, Object argValue) {
/* 147 */     if (this.DEBUG) {
/* 148 */       this.logger_.debug("begin put() into cache '" + getCacheId() + "' argKey " + argKey + " value " + argValue);
/*     */     }
/* 150 */     putImpl(argKey, argValue);
/* 151 */     if (this.DEBUG) {
/* 152 */       this.logger_.debug("end put() into cache '" + getCacheId() + "' argKey " + argKey + " value " + argValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Object argKey) {
/* 159 */     if (this.DEBUG) {
/* 160 */       this.logger_.debug("begin remove() from cache '" + getCacheId() + "' for argKey: " + argKey);
/*     */     }
/* 162 */     removeImpl(argKey);
/* 163 */     if (this.DEBUG) {
/* 164 */       this.logger_.debug("end remove() from cache '" + getCacheId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheId(String argCacheId) {
/* 174 */     this.cacheId_ = argCacheId;
/*     */   }
/*     */   
/*     */   protected abstract void clearImpl();
/*     */   
/*     */   protected abstract void destroyImpl();
/*     */   
/*     */   protected abstract Object getImpl(Object paramObject);
/*     */   
/*     */   protected abstract String getStatusDetails();
/*     */   
/*     */   protected abstract void initImpl(String paramString);
/*     */   
/*     */   protected abstract void putImpl(Object paramObject1, Object paramObject2);
/*     */   
/*     */   protected abstract void removeImpl(Object paramObject);
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\AbstractCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */