/*     */ package dtv.data2.cache;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxCachingStrategy
/*     */ {
/*     */   private static Class<DtxCachingStrategy> class_;
/*     */   private static final String CACHE_NAME = "dtx-cache";
/*  25 */   private static final Logger logger_ = Logger.getLogger(DtxCachingStrategy.class);
/*  26 */   private static final boolean DEBUG = logger_.isDebugEnabled();
/*     */   
/*  28 */   private static ICache permanentCache_ = CacheManager.getInstance().getCache("dtx-cache");
/*     */   
/*     */   static {
/*     */     try {
/*  32 */       class_ = (Class)Class.forName(
/*  33 */           System.getProperty(DtxCachingStrategy.class.getName(), DtxCachingStrategy.class.getName()));
/*     */     }
/*  35 */     catch (Exception ee) {
/*  36 */       logger_.error("Failed to create class based on system property: " + DtxCachingStrategy.class.getName(), ee);
/*     */       
/*  38 */       class_ = DtxCachingStrategy.class;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DtxCachingStrategy getNewInstance() {
/*     */     try {
/*  49 */       return class_.newInstance();
/*     */     }
/*  51 */     catch (Exception ee) {
/*  52 */       logger_.error("Failed to instantiate class: " + class_, ee);
/*  53 */       return new DtxCachingStrategy();
/*     */     } 
/*     */   }
/*     */   
/*  57 */   private final Map<Object, Object> sessionCache_ = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object argKey) throws NotCachedException {
/*  76 */     Object result = this.sessionCache_.get(argKey);
/*  77 */     if (DEBUG) {
/*  78 */       logger_.debug("seacrh for key in session cache resulted in: " + result);
/*     */     }
/*     */     
/*  81 */     if (result == null) {
/*  82 */       result = permanentCache_.get(argKey);
/*     */       
/*  84 */       if (DEBUG) {
/*  85 */         logger_.debug("search for key in permanent cache resulted in: " + result);
/*     */       }
/*     */     } 
/*     */     
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object argKey, Object argValue) {
/*  99 */     if (DEBUG) {
/* 100 */       logger_.debug("adding to session cache.  key: " + argKey + " value: " + argValue);
/*     */     }
/* 102 */     this.sessionCache_.put(argKey, argValue);
/*     */     
/* 104 */     if (DEBUG) {
/* 105 */       logger_.debug("adding to permanent cache.  key: " + argKey + " value: " + argValue);
/*     */     }
/* 107 */     permanentCache_.put(argKey, argValue);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\DtxCachingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */