/*     */ package dtv.data2.cache.impl;
/*     */ 
/*     */ import com.google.common.cache.Cache;
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import dtv.data2.cache.AbstractCache;
/*     */ import dtv.data2.cache.ICache;
/*     */ import dtv.data2.cache.config.CacheConfigHelper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuavaCache
/*     */   extends AbstractCache
/*     */   implements ICache
/*     */ {
/*     */   private static final String CACHE_SHORT_NAME = "guavacache";
/*     */   private Cache<Object, Object> cacheStore_;
/*     */   
/*     */   protected void clearImpl() {
/*  33 */     this.cacheStore_.invalidateAll();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyImpl() {
/*  39 */     this.cacheStore_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getImpl(Object argKey) {
/*  45 */     return this.cacheStore_.getIfPresent(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getStatusDetails() {
/*  51 */     return "size = " + this.cacheStore_.size() + " " + this.cacheStore_.stats().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initImpl(String argCacheId) {
/*  59 */     Set<Map.Entry<String, String>> allProperties = CacheConfigHelper.getCacheConfig().getGlobalProperties().getProperties().entrySet();
/*  60 */     Map<String, String> effectiveProperties = new HashMap<>();
/*     */ 
/*     */     
/*  63 */     for (Map.Entry<String, String> entry : allProperties) {
/*  64 */       String[] splitKey = ((String)entry.getKey()).split("\\.");
/*  65 */       if (splitKey.length == 3 && splitKey[0].equals("guavacache") && splitKey[1]
/*  66 */         .equals("global")) {
/*  67 */         effectiveProperties.put(splitKey[2], entry.getValue());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  72 */     for (Map.Entry<String, String> entry : allProperties) {
/*  73 */       String[] splitKey = ((String)entry.getKey()).split("\\.");
/*  74 */       if (splitKey.length == 3 && splitKey[0].equals("guavacache") && splitKey[1].equals(getCacheId())) {
/*  75 */         effectiveProperties.put(splitKey[2], entry.getValue());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  80 */     CacheBuilder<Object, Object> cacheBuilder = setConfigValues(effectiveProperties);
/*     */ 
/*     */     
/*  83 */     this.cacheStore_ = cacheBuilder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putImpl(Object argKey, Object argValue) {
/*  89 */     this.cacheStore_.put(argKey, (argValue == null) ? NULL_VALUE : argValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeImpl(Object argKey) {
/*  95 */     this.cacheStore_.invalidate(argKey);
/*     */   }
/*     */   
/*     */   private CacheBuilder<Object, Object> setConfigValues(Map<String, String> cacheConfig) {
/*  99 */     CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();
/*     */     
/* 101 */     for (Map.Entry<String, String> entry : cacheConfig.entrySet()) {
/* 102 */       String key = ((String)entry.getKey()).trim();
/* 103 */       String value = ((String)entry.getValue()).trim();
/*     */       try {
/* 105 */         if (key.equals("InitialCapacity")) {
/* 106 */           builder.initialCapacity(Integer.parseInt(value)); continue;
/*     */         } 
/* 108 */         if (key.equals("MaxEntries")) {
/* 109 */           builder.maximumSize(Long.parseLong(value)); continue;
/*     */         } 
/* 111 */         if (key.equals("ConcurrencyFactor")) {
/* 112 */           builder.concurrencyLevel(Integer.parseInt(value)); continue;
/*     */         } 
/* 114 */         if (key.equals("TimeToLiveSeconds")) {
/* 115 */           builder.expireAfterWrite(Long.parseLong(value), TimeUnit.SECONDS); continue;
/*     */         } 
/* 117 */         if (key.equals("TimeToIdleSeconds")) {
/* 118 */           builder.expireAfterAccess(Long.parseLong(value), TimeUnit.SECONDS); continue;
/*     */         } 
/* 120 */         if (key.equals("WeakReferences")) {
/* 121 */           if (Boolean.valueOf(value).booleanValue())
/* 122 */             builder.weakValues(); 
/*     */           continue;
/*     */         } 
/* 125 */         if (key.equals("TrackStats")) {
/* 126 */           if (Boolean.valueOf(value).booleanValue()) {
/* 127 */             builder.recordStats();
/*     */           }
/*     */           continue;
/*     */         } 
/* 131 */         this.logger_.warn("Found unregognized config of " + key + " for region " + getCacheId() + ".  This config will be ignored.");
/*     */ 
/*     */       
/*     */       }
/* 135 */       catch (Exception e) {
/* 136 */         this.logger_.warn("An error occurred when parsing config of " + key + " with value " + value + " for region " + 
/* 137 */             getCacheId() + ".  This config will be ignored.");
/*     */       } 
/*     */     } 
/* 140 */     return builder;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\impl\GuavaCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */