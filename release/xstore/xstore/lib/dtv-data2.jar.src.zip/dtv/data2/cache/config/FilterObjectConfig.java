/*    */ package dtv.data2.cache.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterObjectConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String KEY_ID = "id";
/*    */   private static final String KEY_CACHEABLE = "cacheable";
/*    */   private String filterId_;
/*    */   private boolean cacheable_;
/*    */   
/*    */   public String getFilterId() {
/* 31 */     return this.filterId_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCacheable() {
/* 40 */     return this.cacheable_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 46 */     if ("id".equals(argKey)) {
/* 47 */       this.filterId_ = argValue.toString();
/*    */     }
/* 49 */     else if ("cacheable".equals(argKey)) {
/* 50 */       this.cacheable_ = ConfigUtils.toBoolean(argValue);
/*    */     } else {
/*    */       
/* 53 */       throw new RuntimeException("Unknown config object: " + argKey + " " + argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\config\FilterObjectConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */