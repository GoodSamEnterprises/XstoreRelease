/*     */ package dtv.data2.cache.impl;
/*     */ 
/*     */ import dtv.data2.cache.AbstractCache;
/*     */ import dtv.data2.cache.ICache;
/*     */ import dtv.data2.cache.config.CacheConfigHelper;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapCache
/*     */   extends AbstractCache
/*     */   implements ICache
/*     */ {
/*  26 */   protected String CACHE_SHORT_NAME = "mapcache";
/*     */ 
/*     */ 
/*     */   
/*     */   protected CacheType cacheType_;
/*     */ 
/*     */ 
/*     */   
/*  34 */   protected int initialCapacity_ = 10;
/*     */ 
/*     */   
/*  37 */   protected float loadFactor_ = 1.0F;
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected int maxCapacity_ = 100;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean accessOrder_ = true;
/*     */ 
/*     */   
/*  48 */   protected int concurrencyLevel_ = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Object, Object> cacheStore_;
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearImpl() {
/*  57 */     this.cacheStore_.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createBackingMap() {
/*  64 */     if (this.cacheType_.equals(CacheType.HASHMAP)) {
/*  65 */       this.cacheStore_ = Collections.synchronizedMap(new HashMap<>(this.initialCapacity_, this.loadFactor_));
/*     */     }
/*  67 */     else if (this.cacheType_.equals(CacheType.CONCURRENTHASHMAP)) {
/*  68 */       this.cacheStore_ = new ConcurrentHashMap<>(this.initialCapacity_, this.loadFactor_, this.concurrencyLevel_);
/*     */     }
/*     */     else {
/*     */       
/*  72 */       this.cacheStore_ = Collections.synchronizedMap(new SizeLimitedLinkedHashmap(this.initialCapacity_, this.maxCapacity_, this.loadFactor_, this.accessOrder_));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyImpl() {
/*  80 */     synchronized (this.cacheStore_) {
/*  81 */       this.cacheStore_ = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getImpl(Object argKey) {
/*  88 */     return this.cacheStore_.get(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getStatusDetails() {
/*  94 */     StringBuilder statusString = new StringBuilder();
/*  95 */     synchronized (this.cacheStore_) {
/*  96 */       if (this.cacheType_.equals(CacheType.CONCURRENTHASHMAP)) {
/*  97 */         statusString.append("Concurrency Factor = ").append(this.concurrencyLevel_).append(", ");
/*     */       }
/*  99 */       if (this.cacheType_.equals(CacheType.SIZELIMITEDLINKEDHASHMAP)) {
/* 100 */         statusString.append("Maximum Capacity = ").append(this.maxCapacity_).append(", ");
/* 101 */         statusString.append("Access Order = ").append(this.accessOrder_ ? "LRU" : "FIFO").append(", ");
/*     */       } 
/* 103 */       statusString.append("Load Factor = ").append(this.loadFactor_).append(", ");
/* 104 */       statusString.append("Initial Capacity = ").append(this.initialCapacity_).append(", ");
/* 105 */       statusString.append("Size = ").append(this.cacheStore_.size());
/*     */     } 
/* 107 */     return statusString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initImpl(String argCacheId) {
/* 115 */     Set<Map.Entry<String, String>> allProperties = CacheConfigHelper.getCacheConfig().getGlobalProperties().getProperties().entrySet();
/* 116 */     Map<String, String> effectiveProperties = new HashMap<>();
/*     */ 
/*     */     
/* 119 */     for (Map.Entry<String, String> entry : allProperties) {
/* 120 */       String[] splitKey = ((String)entry.getKey()).split("\\.");
/* 121 */       if (splitKey.length == 3 && splitKey[0].equals(this.CACHE_SHORT_NAME) && splitKey[1]
/* 122 */         .equals("global")) {
/* 123 */         effectiveProperties.put(splitKey[2], entry.getValue());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 128 */     for (Map.Entry<String, String> entry : allProperties) {
/* 129 */       String[] splitKey = ((String)entry.getKey()).split("\\.");
/* 130 */       if (splitKey.length == 3 && splitKey[0].equals(this.CACHE_SHORT_NAME) && splitKey[1].equals(getCacheId())) {
/* 131 */         effectiveProperties.put(splitKey[2], entry.getValue());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 136 */     setConfigValues(effectiveProperties);
/*     */ 
/*     */     
/* 139 */     createBackingMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putImpl(Object argKey, Object argValue) {
/* 145 */     this.cacheStore_.put(argKey, (argValue == null) ? NULL_VALUE : argValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeImpl(Object argKey) {
/* 151 */     this.cacheStore_.remove(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setConfigValues(Map<String, String> cacheConfig) {
/* 161 */     String cacheType = cacheConfig.remove("CacheType");
/* 162 */     if (cacheType != null && cacheType.equals("HashMap")) {
/* 163 */       this.cacheType_ = CacheType.HASHMAP;
/*     */     }
/* 165 */     else if (cacheType != null && cacheType.equals("ConcurrentHashMap")) {
/* 166 */       this.cacheType_ = CacheType.CONCURRENTHASHMAP;
/*     */     } else {
/*     */       
/* 169 */       if (cacheType != null && !cacheType.equals("SizeLimitedLinkedHashMap")) {
/* 170 */         this.logger_.warn("An unsupported cache type of " + cacheType + " was specified.  Falling back to a SizeLimitedLinkedHashMap");
/*     */       }
/*     */       
/* 173 */       this.cacheType_ = CacheType.SIZELIMITEDLINKEDHASHMAP;
/*     */     } 
/*     */ 
/*     */     
/* 177 */     for (Map.Entry<String, String> entry : cacheConfig.entrySet()) {
/* 178 */       String key = ((String)entry.getKey()).trim();
/* 179 */       String value = ((String)entry.getValue()).trim();
/*     */       try {
/* 181 */         if (key.equals("InitialCapacity")) {
/* 182 */           this.initialCapacity_ = Integer.parseInt(value); continue;
/*     */         } 
/* 184 */         if (key.equals("LoadFactor")) {
/* 185 */           this.loadFactor_ = Float.valueOf(value).floatValue(); continue;
/*     */         } 
/* 187 */         if (this.cacheType_.equals(CacheType.CONCURRENTHASHMAP) && key.equals("ConcurrencyFactor")) {
/* 188 */           this.concurrencyLevel_ = Integer.parseInt(value); continue;
/*     */         } 
/* 190 */         if (this.cacheType_.equals(CacheType.SIZELIMITEDLINKEDHASHMAP) && key.equals("MaxEntries")) {
/* 191 */           this.maxCapacity_ = Integer.parseInt(value); continue;
/*     */         } 
/* 193 */         if (this.cacheType_.equals(CacheType.SIZELIMITEDLINKEDHASHMAP) && key.equals("EvictionPolicy")) {
/* 194 */           if (value.equals("LRU")) {
/* 195 */             this.accessOrder_ = true; continue;
/*     */           } 
/* 197 */           if (value.equals("FIFO")) {
/* 198 */             this.accessOrder_ = false;
/*     */             continue;
/*     */           } 
/* 201 */           this.logger_.warn("Found unrecognized eviction policy of " + value + " for region " + getCacheId() + ".  Supported types are LRU, LFU, and FIFO.  Default eviction Policy (LRU) will be used.");
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 206 */         this.logger_.warn("Found unrecognized config of " + key + " for region " + getCacheId() + ".  This config will be ignored.");
/*     */ 
/*     */       
/*     */       }
/* 210 */       catch (Exception e) {
/* 211 */         this.logger_.warn("An error occurred when parsing config of " + key + " with value " + value + " for region " + 
/* 212 */             getCacheId() + ".  This config will be ignored.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected enum CacheType
/*     */   {
/* 223 */     HASHMAP,
/*     */     
/* 225 */     SIZELIMITEDLINKEDHASHMAP,
/*     */     
/* 227 */     CONCURRENTHASHMAP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class SizeLimitedLinkedHashmap
/*     */     extends LinkedHashMap<Object, Object>
/*     */   {
/*     */     private static final long serialVersionUID = 73717943498829748L;
/*     */ 
/*     */ 
/*     */     
/*     */     private int _maxEntries;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SizeLimitedLinkedHashmap(int argInitialCapacity, int argMaxCapacity, float argLoadFactor, boolean argAccessOrder) {
/* 246 */       super(argInitialCapacity, argLoadFactor, argAccessOrder);
/* 247 */       this._maxEntries = argMaxCapacity;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean removeEldestEntry(Map.Entry<Object, Object> eldest) {
/* 252 */       return (size() > this._maxEntries);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\impl\MapCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */