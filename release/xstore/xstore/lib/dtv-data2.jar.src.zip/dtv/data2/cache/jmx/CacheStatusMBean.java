/*    */ package dtv.data2.cache.jmx;
/*    */ 
/*    */ import dtv.data2.cache.CacheManager;
/*    */ import dtv.data2.cache.ICache;
/*    */ import dtv.data2.cache.config.CacheConfigHelper;
/*    */ import dtv.jmx.AbstractDtvMBean;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheStatusMBean
/*    */   extends AbstractDtvMBean
/*    */ {
/*    */   public String clearCaches() {
/* 28 */     CacheManager.getInstance().clear();
/* 29 */     return "Clear request made to CacheManager.";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCacheStatus() {
/* 38 */     List<ICache> caches = CacheManager.getInstance().getManagedCaches();
/*    */ 
/*    */ 
/*    */     
/* 42 */     StringBuilder buff = new StringBuilder(1024);
/* 43 */     tableHeader(buff);
/*    */     
/* 45 */     for (ICache cache : caches) {
/* 46 */       row(buff, cache);
/*    */     }
/*    */     
/* 49 */     tableFooter(buff);
/*    */     
/* 51 */     return buff.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startMBean() {}
/*    */ 
/*    */ 
/*    */   
/*    */   private String bold(String argElement) {
/* 61 */     return "<strong>" + argElement + "</strong>";
/*    */   }
/*    */   
/*    */   private String font(String argElement) {
/* 65 */     return "<font face=\"Arial,  Helvetica,  sans-serif\">" + argElement + "</font>";
/*    */   }
/*    */   
/*    */   private void row(StringBuilder argBuff, ICache argCache) {
/* 69 */     argBuff.append("<tr><td>").append(bold(argCache.getCacheId())).append("</td><td>")
/* 70 */       .append(argCache.getStatusReport()).append("</td><td>")
/* 71 */       .append(CacheConfigHelper.getCacheDefConfig(argCache.getCacheId()).getSourceDescription())
/* 72 */       .append("</td></tr>");
/*    */   }
/*    */   
/*    */   private void tableFooter(StringBuilder argDoc) {
/* 76 */     argDoc.append("  </table>");
/*    */   }
/*    */   
/*    */   private void tableHeader(StringBuilder argDoc) {
/* 80 */     argDoc.append("<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">");
/* 81 */     argDoc.append("  <tr bgcolor=\"#CCCCCC\"> ");
/* 82 */     argDoc.append("    <td>").append(font(bold("Cache Id"))).append("</td>");
/* 83 */     argDoc.append("    <td>").append(font(bold("Status"))).append("</td>");
/* 84 */     argDoc.append("    <td>").append(font(bold("Config"))).append("</td>");
/* 85 */     argDoc.append("  </tr>");
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\cache\jmx\CacheStatusMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */