/*    */ package dtv.data2.dataserver.config;
/*    */ 
/*    */ import dtv.data2.dataserver.IDataServerAction;
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstructionConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String NAME_TAG = "Name";
/* 28 */   private final List<IActionConfig> _actionConfigs = new ArrayList<>();
/* 29 */   private String _name = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object argObj) {
/* 34 */     if (argObj == this) {
/* 35 */       return true;
/*    */     }
/*    */     
/* 38 */     if (!(argObj instanceof InstructionConfig)) {
/* 39 */       return false;
/*    */     }
/*    */     
/* 42 */     InstructionConfig other = (InstructionConfig)argObj;
/* 43 */     return (new EqualsBuilder()).append(this._actionConfigs, other._actionConfigs).appendSuper(super.equals(argObj))
/* 44 */       .isEquals();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<IDataServerAction> getActions() throws Exception {
/* 56 */     List<IDataServerAction> actions = new ArrayList<>();
/*    */     
/* 58 */     for (IActionConfig actionConfig : this._actionConfigs) {
/* 59 */       actions.add(actionConfig.getAction());
/*    */     }
/*    */     
/* 62 */     return actions;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 70 */     return this._name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 76 */     return (new HashCodeBuilder(17, 37)).append(this._actionConfigs).appendSuper(super.hashCode()).toHashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 82 */     if ("Name".equalsIgnoreCase(argKey)) {
/* 83 */       this._name = argValue.toString();
/*    */     }
/* 85 */     else if (argValue instanceof IActionConfig) {
/* 86 */       IActionConfig actionConfig = (IActionConfig)argValue;
/* 87 */       this._actionConfigs.add(actionConfig);
/*    */     } 
/*    */     
/* 90 */     setClean();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\config\InstructionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */