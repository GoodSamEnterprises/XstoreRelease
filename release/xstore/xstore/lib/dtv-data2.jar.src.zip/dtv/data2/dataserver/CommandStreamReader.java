/*    */ package dtv.data2.dataserver;
/*    */ 
/*    */ import dtv.util.DtvThreadFactory;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.TimeoutException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandStreamReader
/*    */   implements Callable<String>
/*    */ {
/* 23 */   private final ExecutorService _executor = Executors.newSingleThreadExecutor((ThreadFactory)DtvThreadFactory.makeForDaemons("CommandStreamReader"));
/*    */ 
/*    */   
/*    */   private final InputStream stream_;
/*    */ 
/*    */   
/*    */   private boolean hasStarted_ = false;
/*    */ 
/*    */   
/*    */   public CommandStreamReader(InputStream argStream) {
/* 33 */     this.stream_ = argStream;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String call() throws Exception {
/* 41 */     this.hasStarted_ = true;
/* 42 */     BufferedReader r = new BufferedReader(new InputStreamReader(this.stream_));
/* 43 */     StringBuilder sb = new StringBuilder();
/*    */     String line;
/* 45 */     while ((line = r.readLine()) != null) {
/* 46 */       sb.append(line).append('\n');
/*    */     }
/* 48 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Future<String> start() {
/* 57 */     return this._executor.submit(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop() {
/* 65 */     this._executor.shutdown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void waitForBegin(long argMillis) throws TimeoutException, InterruptedException {
/* 78 */     long timeoutTime = System.currentTimeMillis() + argMillis;
/* 79 */     while (System.currentTimeMillis() < timeoutTime && !this.hasStarted_) {
/* 80 */       Thread.sleep(100L);
/*    */     }
/* 82 */     if (!this.hasStarted_)
/* 83 */       throw new TimeoutException(); 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\CommandStreamReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */