package dtv.data2.dataserver.config;

public class ConfigConstants {
  static final String CONFIG_PATH = "EnvironmentConfig";
  
  static final String CONFIG_MAPPINGS_FILE = "ConfigType.new";
  
  static final String CONFIG_MAPPINGS_FILE_DEFAULT = "ConfigType";
  
  static final String CATEGORY_INSTRUCTION = "Instruction";
  
  static final String CATEGORY_OPTIONS = "Options";
  
  static final String DEFAULT_OPTIONS_ID = "XSTORE";
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\config\ConfigConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */