/*     */ package dtv.data2.dataserver.config;
/*     */ 
/*     */ import dtv.data2.dataserver.IDataServerAction;
/*     */ import dtv.util.IHasParameters;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractActionConfig<C extends IDataServerAction>
/*     */   extends AbstractParameterizedConfig
/*     */   implements IActionConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  27 */   private static final Logger _logger = Logger.getLogger(AbstractActionConfig.class);
/*     */   
/*     */   private static final String ORDER_TAG = "Order";
/*     */   
/*     */   private static final String VALUE_TAG = "Value";
/*     */   
/*     */   private final Class<? extends C> _actionClass;
/*     */   
/*     */   private int _order;
/*     */   
/*     */   private String _value;
/*     */ 
/*     */   
/*     */   public AbstractActionConfig(Class<? extends C> argActionClass) {
/*  41 */     this._actionClass = argActionClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object argObj) {
/*  47 */     if (argObj == null) {
/*  48 */       return false;
/*     */     }
/*     */     
/*  51 */     if (!(argObj instanceof AbstractActionConfig)) {
/*  52 */       return false;
/*     */     }
/*     */     
/*  55 */     AbstractActionConfig other = (AbstractActionConfig)argObj;
/*  56 */     return (new EqualsBuilder()).append(getType(), other.getType()).append(getValue(), other.getValue())
/*  57 */       .append(getOrder(), other.getOrder()).append(getParameters(), other.getParameters())
/*  58 */       .appendSuper(super.equals(other)).isEquals();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C getAction() throws Exception {
/*     */     try {
/*  71 */       IDataServerAction iDataServerAction = (IDataServerAction)this._actionClass.newInstance();
/*  72 */       iDataServerAction.setOrder(getOrder());
/*  73 */       iDataServerAction.setValue(getValue());
/*  74 */       addParameters((IHasParameters)iDataServerAction);
/*     */       
/*  76 */       return (C)iDataServerAction;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  82 */     catch (InstantiationException iEx) {
/*  83 */       _logger.error("An error occurred instantiating the action [" + toString() + "]", iEx);
/*  84 */       throw iEx;
/*     */     }
/*  86 */     catch (IllegalAccessException iaEx) {
/*  87 */       _logger.error("Appropriate access was not obtained to instantiate the action [" + toString() + "]", iaEx);
/*     */       
/*  89 */       throw iaEx;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  99 */     return this._order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 108 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     return (new HashCodeBuilder(17, 37)).append(getType()).append(getOrder()).append(getValue())
/* 115 */       .append(getParameters()).appendSuper(super.hashCode()).toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 121 */     if ("Order".equalsIgnoreCase(argKey)) {
/* 122 */       this._order = ConfigUtils.toInt(argValue);
/*     */     }
/* 124 */     else if ("Value".equalsIgnoreCase(argKey)) {
/* 125 */       this._value = argValue.toString();
/*     */     } else {
/*     */       
/* 128 */       super.setConfigObject(argKey, argValue);
/*     */     } 
/*     */     
/* 131 */     setClean();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\config\AbstractActionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */