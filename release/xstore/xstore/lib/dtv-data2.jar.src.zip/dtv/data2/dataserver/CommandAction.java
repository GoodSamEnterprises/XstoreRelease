/*     */ package dtv.data2.dataserver;
/*     */ 
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandAction
/*     */   extends AbstractAction
/*     */ {
/*  29 */   private static final Logger _logger = Logger.getLogger(CommandAction.class);
/*     */ 
/*     */   
/*     */   private static final String DATABASE_CREDENTIALS_PARAM = "DatabaseCredentials";
/*     */   
/*     */   private static final String USER_COMMAND_PARAM = "userName";
/*     */   
/*     */   private static final String PASSWORD_COMMAND_PARAM = "password";
/*     */   
/*     */   private String _databaseUserName;
/*     */   
/*     */   private String _databasePassword;
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*  45 */       String imp = "impdp dtv/dtv directory=test_dir dumpfile=oraDbDump.dmp logfile=impdp_oraDb.log remap_schema=dtv:training table_exists_action=REPLACE";
/*     */ 
/*     */       
/*  48 */       Process p = Runtime.getRuntime().exec(imp);
/*  49 */       BufferedReader input = new BufferedReader(new InputStreamReader(p.getErrorStream()));
/*  50 */       StringBuilder output = new StringBuilder();
/*     */       String line;
/*  52 */       while ((line = input.readLine()) != null) {
/*  53 */         output.append(line);
/*  54 */         System.out.println(line);
/*     */       } 
/*     */       
/*  57 */       input.close();
/*  58 */       System.out.println("process exit value = " + p.exitValue());
/*     */     }
/*  60 */     catch (Exception err) {
/*  61 */       err.printStackTrace();
/*     */     } 
/*     */     
/*  64 */     System.exit(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String argName, Object argValue) {
/*  73 */     if ("DatabaseCredentials".equalsIgnoreCase(argName)) {
/*  74 */       String dataSource = argValue.toString();
/*  75 */       DataSourceDescriptor desc = DataSourceFactory.getInstance().getDataSourceDescriptor(dataSource);
/*  76 */       this._databaseUserName = desc.getProperties().getProperty("ConnectionUserName");
/*  77 */       this._databasePassword = desc.getProperties().getProperty("ConnectionPassword");
/*     */     } else {
/*     */       
/*  80 */       super.setParameter(argName, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object processImpl(Map<String, String> argParameters) throws Exception {
/*  89 */     boolean debugEnabled = _logger.isDebugEnabled();
/*  90 */     StringBuilder command = new StringBuilder(getValue());
/*     */ 
/*     */     
/*  93 */     argParameters.put("userName", this._databaseUserName);
/*  94 */     argParameters.put("password", this._databasePassword);
/*     */ 
/*     */     
/*  97 */     StringUtils.replaceVariables(command, argParameters);
/*     */ 
/*     */     
/* 100 */     Runtime runTime = Runtime.getRuntime();
/* 101 */     Process commandProcess = runTime.exec(command.toString());
/* 102 */     CommandStreamReader inputReader = new CommandStreamReader(commandProcess.getInputStream());
/* 103 */     CommandStreamReader errReader = new CommandStreamReader(commandProcess.getErrorStream());
/*     */     try {
/* 105 */       Future<String> input = inputReader.start();
/* 106 */       Future<String> err = errReader.start();
/*     */       try {
/* 108 */         inputReader.waitForBegin(5000L);
/* 109 */         errReader.waitForBegin(5000L);
/*     */       }
/* 111 */       catch (Exception ex) {
/* 112 */         _logger.warn("Error when starting a process input reader the exception is:", ex);
/*     */       } 
/*     */       
/* 115 */       int exitValue = commandProcess.waitFor();
/* 116 */       if (debugEnabled) {
/* 117 */         _logger.debug("Process output is:" + (String)input.get());
/* 118 */         _logger.debug("Process completed with exit value of [" + exitValue + "]");
/*     */       } 
/*     */       
/* 121 */       if (exitValue != 0)
/*     */       {
/* 123 */         throw new Exception((String)err.get());
/*     */       }
/*     */       
/* 126 */       return Integer.valueOf(exitValue);
/*     */     } finally {
/*     */       
/* 129 */       inputReader.stop();
/* 130 */       errReader.stop();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\CommandAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */