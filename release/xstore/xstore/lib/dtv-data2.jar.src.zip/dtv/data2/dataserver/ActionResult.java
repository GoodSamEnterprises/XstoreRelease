/*     */ package dtv.data2.dataserver;
/*     */ 
/*     */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionResult
/*     */ {
/*     */   private Throwable _processError;
/*     */   private boolean _successful;
/*     */   private long _processingTime;
/*     */   
/*     */   public static ActionResult makeFailure(Throwable argThrowable) {
/*  23 */     ActionResult failure = new ActionResult();
/*  24 */     failure._processError = argThrowable;
/*  25 */     failure._successful = false;
/*  26 */     return failure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ActionResult makeSuccess() {
/*  35 */     ActionResult success = new ActionResult();
/*  36 */     success._successful = true;
/*  37 */     return success;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object argObj) {
/*  52 */     if (argObj == null) {
/*  53 */       return false;
/*     */     }
/*     */     
/*  56 */     if (argObj == this) {
/*  57 */       return true;
/*     */     }
/*     */     
/*  60 */     if (!(argObj instanceof ActionResult)) {
/*  61 */       return false;
/*     */     }
/*     */     
/*  64 */     ActionResult other = (ActionResult)argObj;
/*  65 */     return (new EqualsBuilder()).append(isSuccess(), other.isSuccess()).append(getError(), other.getError())
/*  66 */       .append(getProcessingTime(), other.getProcessingTime()).appendSuper(super.equals(other)).isEquals();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getError() {
/*  75 */     return this._processError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  84 */     return this._processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getRootError() {
/*  93 */     Throwable rootError = this._processError;
/*     */     
/*  95 */     while (rootError.getCause() != null) {
/*  96 */       rootError = rootError.getCause();
/*     */     }
/*     */     
/*  99 */     return rootError;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 105 */     return (new HashCodeBuilder(17, 37)).append(isSuccess()).append(getError()).append(getProcessingTime())
/* 106 */       .appendSuper(super.hashCode()).toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuccess() {
/* 115 */     return this._successful;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessingTime(long argProcessingTime) {
/* 124 */     this._processingTime = argProcessingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return (new ToStringBuilder(this)).append("successful", isSuccess()).append("error", getError())
/* 131 */       .append("processingTime", getProcessingTime()).toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\ActionResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */