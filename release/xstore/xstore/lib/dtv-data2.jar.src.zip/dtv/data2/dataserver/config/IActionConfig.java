package dtv.data2.dataserver.config;

import dtv.data2.dataserver.IDataServerAction;

public interface IActionConfig {
  IDataServerAction getAction() throws Exception;
  
  String getType();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\config\IActionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */