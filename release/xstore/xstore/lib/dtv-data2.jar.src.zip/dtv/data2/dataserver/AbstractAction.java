/*     */ package dtv.data2.dataserver;
/*     */ 
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAction
/*     */   implements IDataServerAction
/*     */ {
/*  22 */   private static final Logger _logger = Logger.getLogger(AbstractAction.class);
/*  23 */   private int _processingOrder = 0;
/*     */   
/*     */   private String _value;
/*     */   
/*     */   private String _type;
/*     */   
/*     */   private String _ownerId;
/*     */   
/*     */   public int compareTo(IDataServerAction argOther) {
/*  32 */     return getOrder() - argOther.getOrder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  38 */     return this._processingOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  44 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  50 */     return (new HashCodeBuilder(17, 37)).append(this._type).append(this._processingOrder).append(this._value)
/*  51 */       .appendSuper(super.hashCode()).toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionResult process(Map<String, String> argParameters) {
/*  57 */     _logger.info("Processing " + toString());
/*     */     
/*  59 */     ActionResult result = null;
/*  60 */     long startTime = System.currentTimeMillis();
/*     */     
/*     */     try {
/*  63 */       processImpl(argParameters);
/*  64 */       result = ActionResult.makeSuccess();
/*     */     }
/*  66 */     catch (Exception ex) {
/*  67 */       result = ActionResult.makeFailure(ex);
/*     */     } finally {
/*     */       
/*  70 */       long processingTime = System.currentTimeMillis() - startTime;
/*  71 */       result.setProcessingTime(processingTime);
/*  72 */       String logMessage = toString() + "processed. Results = " + result;
/*     */       
/*  74 */       if (result.isSuccess()) {
/*  75 */         _logger.info(logMessage);
/*     */       } else {
/*     */         
/*  78 */         _logger.error(logMessage, result.getError());
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int argOrder) {
/*  88 */     this._processingOrder = argOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOwnerId(String argOwnerId) {
/*  94 */     this._ownerId = argOwnerId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String argName, Object argValue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String argType) {
/* 106 */     this._type = argType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String argValue) {
/* 112 */     this._value = argValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     StringBuilder builder = new StringBuilder("Action ");
/*     */     
/* 120 */     if (!StringUtils.isEmpty(this._ownerId)) {
/* 121 */       builder.append(this._ownerId + ":");
/*     */     }
/*     */     
/* 124 */     builder.append(this._type);
/* 125 */     builder.append(" [" + this._value + "] ");
/* 126 */     return builder.toString();
/*     */   }
/*     */   
/*     */   protected abstract Object processImpl(Map<String, String> paramMap) throws Exception;
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\AbstractAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */