/*     */ package dtv.data2.dataserver;
/*     */ 
/*     */ import dtv.data2.SQLExceptionScrubber;
/*     */ import dtv.data2.dataserver.config.ConfigHelper;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionProcessor
/*     */ {
/*     */   public static final String RESPONSE_TEXT_KEY = "responseText";
/*     */   public static final String PROCESSING_TIME_KEY = "processingTime";
/*     */   public static final String SUCCESSFUL_KEY = "successful";
/*     */   public static final String RESPONSE_TEXT_SUCCESS = "OK";
/*  33 */   private static String DIRECT_REPLACE_PREFIX = "$arg";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, String> getDirectReplaceFormattedParams(Map<String, String> argParams) {
/*  41 */     Map<String, String> formattedParams = new HashMap<>();
/*  42 */     if (argParams == null) {
/*  43 */       return formattedParams;
/*     */     }
/*  45 */     for (String key : argParams.keySet()) {
/*     */       
/*  47 */       String formattedKey = key.startsWith(DIRECT_REPLACE_PREFIX) ? key : (DIRECT_REPLACE_PREFIX + StringUtils.ensureFirstUpperCase(key));
/*     */       
/*  49 */       if (argParams.containsKey(key)) {
/*  50 */         formattedParams.put(formattedKey, argParams.get(key));
/*     */       }
/*     */     } 
/*     */     
/*  54 */     return formattedParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> processInstruction(String argInstructionKey, Map<String, String> argParameters) {
/*  65 */     Map<String, String> results = new HashMap<>();
/*  66 */     long totalProcessingTime = 0L;
/*     */     
/*     */     try {
/*  69 */       List<IDataServerAction> actions = ConfigHelper.getInstance().getActions(argInstructionKey);
/*  70 */       Collections.sort(actions);
/*     */       
/*  72 */       for (IDataServerAction action : actions) {
/*  73 */         ActionResult result = action.process(argParameters);
/*  74 */         totalProcessingTime += result.getProcessingTime();
/*     */         
/*  76 */         if (!result.isSuccess())
/*     */         {
/*     */           
/*  79 */           throw result.getRootError();
/*     */         }
/*     */       }
/*     */     
/*  83 */     } catch (Throwable th) {
/*  84 */       results.put("successful", Boolean.FALSE.toString());
/*     */ 
/*     */       
/*  87 */       results.put("responseText", SQLExceptionScrubber.scrub(th.toString()));
/*  88 */       results.put("processingTime", String.valueOf(totalProcessingTime));
/*  89 */       return results;
/*     */     } 
/*     */     
/*  92 */     results.put("successful", Boolean.TRUE.toString());
/*  93 */     results.put("responseText", "OK");
/*  94 */     results.put("processingTime", String.valueOf(totalProcessingTime));
/*     */     
/*  96 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> processInstruction(String argInstructionType, Map<String, String> argParameters, Map<String, String> argDirectReplaceParams) {
/* 110 */     Map<String, String> params = new HashMap<>();
/* 111 */     params.putAll(argParameters);
/* 112 */     params.putAll(getDirectReplaceFormattedParams(argDirectReplaceParams));
/*     */     
/* 114 */     return processInstruction(argInstructionType, params);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\InstructionProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */