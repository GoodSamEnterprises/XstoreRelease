/*    */ package dtv.data2.dataserver;
/*    */ 
/*    */ import dtv.data2.access.DefaultQueryResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataServerQueryResult
/*    */   extends DefaultQueryResult
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 28 */   private String _errorText = null;
/* 29 */   private int _returnValue = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getErrorText() {
/* 37 */     return this._errorText;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getReturnValue() {
/* 46 */     return this._returnValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setErrorText(String argErrorText) {
/* 55 */     this._errorText = argErrorText;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReturnValue(int argReturnValue) {
/* 64 */     this._returnValue = argReturnValue;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\DataServerQueryResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */