/*    */ package dtv.data2.dataserver.config;
/*    */ 
/*    */ import dtv.data2.dataserver.IDataServerAction;
/*    */ import dtv.util.config.ConfigHelper;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigHelper
/*    */   extends ConfigHelper<EnvironmentConfig>
/*    */ {
/* 22 */   private static final Logger _logger = Logger.getLogger(ConfigHelper.class);
/* 23 */   private static final boolean _debugEnabled = _logger.isDebugEnabled();
/*    */ 
/*    */ 
/*    */   
/*    */   private static ConfigHelper _configHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized ConfigHelper getInstance() {
/* 33 */     if (_configHelper == null) {
/* 34 */       ConfigHelper configHelper = new ConfigHelper();
/* 35 */       configHelper.initialize();
/* 36 */       _configHelper = configHelper;
/*    */     } 
/*    */     
/* 39 */     return _configHelper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<IDataServerAction> getActions(String argInstructionType) throws Exception {
/* 52 */     InstructionConfig instruction = ((EnvironmentConfig)getRootConfig()).getInstructionConfig(argInstructionType);
/* 53 */     List<IDataServerAction> actions = instruction.getActions();
/*    */     
/* 55 */     if (_debugEnabled) {
/* 56 */       _logger.debug("Requested instruction = [" + argInstructionType + "].  Returning actions: " + actions);
/*    */     }
/*    */     
/* 59 */     return actions;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OptionsConfig getEnvironmentOptions() {
/* 70 */     return getEnvironmentOptions("XSTORE");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OptionsConfig getEnvironmentOptions(String argOptionsType) {
/* 83 */     OptionsConfig config = ((EnvironmentConfig)getRootConfig()).getOptionsConfig(argOptionsType);
/* 84 */     return config;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getConfigFileName() {
/* 90 */     return "EnvironmentConfig";
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\config\ConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */