/*    */ package dtv.data2.dataserver.config;
/*    */ 
/*    */ import dtv.data2.dataserver.QueryAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryActionConfig
/*    */   extends AbstractActionConfig<QueryAction>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public QueryActionConfig() {
/* 23 */     super(QueryAction.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getType() {
/* 29 */     return "Query";
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\dataserver\config\QueryActionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */