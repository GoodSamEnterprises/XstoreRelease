/*    */ package dtv.data2.access.config.query;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuerySortConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 20 */   private String _sortField = null;
/* 21 */   private String _sortOrder = null;
/* 22 */   private String _requiredSort = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSortField() {
/* 30 */     return this._sortField;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSortOrder() {
/* 39 */     return this._sortOrder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String isRequiredSort() {
/* 48 */     return this._requiredSort;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 54 */     if ("field".equalsIgnoreCase(argKey)) {
/* 55 */       this._sortField = argValue.toString();
/*    */     }
/* 57 */     else if ("order".equalsIgnoreCase(argKey)) {
/* 58 */       this._sortOrder = argValue.toString();
/*    */     }
/* 60 */     else if ("required".equalsIgnoreCase(argKey)) {
/* 61 */       this._requiredSort = argValue.toString();
/*    */     } else {
/*    */       
/* 64 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\query\QuerySortConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */