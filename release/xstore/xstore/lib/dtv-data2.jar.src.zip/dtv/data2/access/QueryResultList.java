/*     */ package dtv.data2.access;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryResultList<C>
/*     */   extends AbstractList<C>
/*     */   implements IQueryResultList<C>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 38586867920957569L;
/*     */   private final Class<C> type_;
/*     */   private final long limit_;
/*     */   private final boolean isLimitReached_;
/*     */   
/*     */   public static <T> IQueryResultList<T> makeList(Object argObject, Class<T> argType) {
/*  36 */     if (argObject instanceof IQueryResultWrapper) {
/*  37 */       IQueryResultWrapper wrapper = (IQueryResultWrapper)argObject;
/*     */       
/*  39 */       return makeList(wrapper.getData(), argType, wrapper.getQueryLimit(), wrapper.isQueryLimitReached());
/*     */     } 
/*     */     
/*  42 */     return makeList(argObject, argType, Long.MAX_VALUE, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> IQueryResultList<T> makeList(Object argObject, Class<T> argType, long argLimit, boolean argLimitReached) {
/*  61 */     if (argObject == null) {
/*  62 */       return null;
/*     */     }
/*  64 */     if (argObject instanceof IQueryResultList) {
/*  65 */       IQueryResultList<?> l = (IQueryResultList)argObject;
/*  66 */       if (argType.isAssignableFrom(l.getResultClass())) {
/*  67 */         return (IQueryResultList<T>)argObject;
/*     */       }
/*     */     } 
/*     */     
/*  71 */     if (argObject instanceof Collection) {
/*  72 */       IQueryResultList<T> iQueryResultList = new QueryResultList<>(argType, argLimit, argLimitReached);
/*  73 */       Collection<Object> collection = (Collection<Object>)argObject;
/*  74 */       for (Object o : collection) {
/*  75 */         iQueryResultList.add((T)o);
/*     */       }
/*  77 */       return iQueryResultList;
/*     */     } 
/*  79 */     if (argObject instanceof Object[][]) {
/*  80 */       IQueryResultList<T> iQueryResultList = new QueryResultList<>(argType, argLimit, argLimitReached);
/*  81 */       Object[][] objs = (Object[][])argObject;
/*  82 */       for (Object[] o : objs) {
/*  83 */         iQueryResultList.add((T)o);
/*     */       }
/*  85 */       return iQueryResultList;
/*     */     } 
/*     */     
/*  88 */     IQueryResultList<T> results = new QueryResultList<>(argType, argLimit, argLimitReached);
/*  89 */     results.add((T)argObject);
/*  90 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Builder<T> newBuilder(Class<T> argType) {
/* 102 */     return new Builder<>(argType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private List<C> list_ = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryResultList(Class<C> argType) {
/* 117 */     this(argType, Long.MAX_VALUE, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryResultList(Class<C> argType, C[] obj) {
/* 127 */     this(argType, Long.MAX_VALUE, false, (obj == null) ? new ArrayList<>() : Arrays.<C>asList(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryResultList(Class<C> argType, Collection<C> col) {
/* 137 */     this(argType, Long.MAX_VALUE, false, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryResultList(Class<C> argType, long argLimit, boolean argLimitReached) {
/* 148 */     this.type_ = argType;
/* 149 */     this.list_ = Collections.checkedList(new ArrayList<>(), this.type_);
/* 150 */     this.limit_ = argLimit;
/* 151 */     this.isLimitReached_ = argLimitReached;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryResultList(Class<C> argType, long argLimit, boolean argLimitReached, Collection<C> col) {
/* 163 */     this.type_ = argType;
/* 164 */     this.list_ = Collections.checkedList(new ArrayList<>(col.size()), this.type_);
/* 165 */     this.list_.addAll(col);
/* 166 */     this.limit_ = argLimit;
/* 167 */     this.isLimitReached_ = argLimitReached;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryResultList(Class<C> argType, long argLimit, boolean argLimitReached, int argInitialCapacity) {
/* 179 */     this.type_ = argType;
/* 180 */     this.list_ = Collections.checkedList(new ArrayList<>(argInitialCapacity), this.type_);
/* 181 */     this.limit_ = argLimit;
/* 182 */     this.isLimitReached_ = argLimitReached;
/*     */   }
/*     */   
/*     */   private QueryResultList(Builder<C> argBuilder) {
/* 186 */     this.type_ = argBuilder.type_;
/* 187 */     this.list_ = argBuilder.list_;
/* 188 */     this.limit_ = argBuilder.limit_;
/* 189 */     this.isLimitReached_ = argBuilder.limitReached_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(C argO) {
/* 195 */     return this.list_.add(argO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int argIndex, C argElement) {
/* 201 */     this.list_.add(argIndex, argElement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends C> argC) {
/* 207 */     return this.list_.addAll(argC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int argIndex, Collection<? extends C> argC) {
/* 213 */     return this.list_.addAll(argIndex, argC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 219 */     this.list_.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object argO) {
/* 225 */     return this.list_.contains(argO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> argC) {
/* 231 */     return this.list_.containsAll(argC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public C get(int argIndex) {
/* 237 */     return this.list_.get(argIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getQueryLimit() {
/* 243 */     return this.limit_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<C> getResultClass() {
/* 249 */     return this.type_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Object argO) {
/* 255 */     return this.list_.indexOf(argO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 261 */     return this.list_.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isQueryLimitReached() {
/* 267 */     return this.isLimitReached_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<C> iterator() {
/* 273 */     return this.list_.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object argO) {
/* 279 */     return this.list_.lastIndexOf(argO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<C> listIterator() {
/* 285 */     return this.list_.listIterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<C> listIterator(int argIndex) {
/* 291 */     return this.list_.listIterator(argIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public C remove(int argIndex) {
/* 297 */     return this.list_.remove(argIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Object argO) {
/* 303 */     return this.list_.remove(argO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> argC) {
/* 309 */     return this.list_.removeAll(argC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> argC) {
/* 315 */     return this.list_.retainAll(argC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public C set(int argIndex, C argElement) {
/* 321 */     return this.list_.set(argIndex, argElement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 327 */     return this.list_.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<C> subList(int argFromIndex, int argToIndex) {
/* 333 */     return this.list_.subList(argFromIndex, argToIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 339 */     return this.list_.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] argA) {
/* 345 */     return this.list_.toArray(argA);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder<T>
/*     */   {
/*     */     private final Class<T> type_;
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<T> list_;
/*     */ 
/*     */ 
/*     */     
/* 361 */     private long limit_ = Long.MAX_VALUE;
/*     */     private boolean limitReached_ = false;
/*     */     
/*     */     private Builder(Class<T> argType) {
/* 365 */       this.type_ = argType;
/* 366 */       this.list_ = Collections.checkedList(new ArrayList<>(), this.type_);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> add(T argEntry) {
/* 376 */       this.list_.add(argEntry);
/* 377 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public QueryResultList<T> build() {
/* 386 */       return new QueryResultList<>(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> setLimit(long argLimit) {
/* 395 */       this.limit_ = argLimit;
/* 396 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder<T> setLimitReached(boolean argLimitReached) {
/* 405 */       this.limitReached_ = argLimitReached;
/* 406 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\QueryResultList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */