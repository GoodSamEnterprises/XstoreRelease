/*    */ package dtv.data2.access.config.pmtype;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceLocationConfig
/*    */   extends AbstractParentConfig
/*    */   implements Comparable<DataSourceLocationConfig>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String dataSourceName_;
/* 21 */   private int order_ = -1;
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(DataSourceLocationConfig argOther) {
/* 26 */     return this.order_ - argOther.order_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDataSourceName() {
/* 35 */     return this.dataSourceName_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 44 */     return this.order_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 50 */     if ("DataSourceName".equalsIgnoreCase(argKey)) {
/* 51 */       this.dataSourceName_ = argValue.toString();
/*    */     }
/* 53 */     else if ("Order".equalsIgnoreCase(argKey)) {
/* 54 */       this.order_ = ConfigUtils.toInt(argValue);
/*    */     } else {
/*    */       
/* 57 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOrder(int argOrder) {
/* 67 */     this.order_ = argOrder;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\pmtype\DataSourceLocationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */