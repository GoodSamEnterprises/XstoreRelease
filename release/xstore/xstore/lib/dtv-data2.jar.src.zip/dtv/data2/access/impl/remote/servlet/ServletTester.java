/*     */ package dtv.data2.access.impl.remote.servlet;
/*     */ 
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.util.Base64;
/*     */ import dtv.util.ByteArray;
/*     */ import dtv.util.zip.GZipUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletTester
/*     */ {
/*  25 */   private static final Logger _logger = Logger.getLogger(ServletTester.class);
/*     */   
/*     */   private static final String ENCODING_TYPE_UTF8 = "UTF8";
/*     */   
/*     */   private static final String ENCODING_GZIP = "encoded/gzip";
/*     */   
/*     */   private static final String ENCODING_PLAIN_TEXT = "text/plain";
/*     */   
/*     */   private static final String CONTENT_TYPE_KEY = "Content-Type";
/*     */   private static final String CONTENT_ENCODING = "Content-Encoding";
/*  35 */   private static int _msgCount = 0;
/*     */   private static final String HTTP_HEADER_PROP_ACCEPT = "Accept";
/*     */   private static final String HTTP_HEADER_PROP_USER_AGENT = "User-Agent";
/*     */   private static String _server;
/*     */   private static String _user;
/*     */   private static String _password;
/*     */   
/*     */   public static void main(String[] args) {
/*  43 */     if (args.length != 4) {
/*  44 */       _logger.error("Invalid arguments.  Try: ServletTester <server> <user> <password>");
/*  45 */       System.exit(-1);
/*     */     } 
/*  47 */     _server = args[0];
/*  48 */     _user = args[1];
/*  49 */     _password = args[2];
/*     */     
/*  51 */     String query = "<QueryRequest><QueryKey>SECURITY_GROUPS</QueryKey><Params><Param name=\"argOrganizationId\" type=\"LONG\">1</Param></Params></QueryRequest>";
/*     */ 
/*     */     
/*     */     try {
/*  55 */       long start = System.currentTimeMillis();
/*  56 */       byte[] requestBytes = stringToBytes(query);
/*     */       
/*  58 */       boolean valid = (new ServletTester()).sendHttpRequest(requestBytes);
/*  59 */       long end = System.currentTimeMillis();
/*  60 */       _logger.debug("getObjectByQuery result: " + valid + " and time " + (end - start));
/*  61 */       if (valid) {
/*  62 */         _logger.info("SUCCESS");
/*  63 */         System.exit(0);
/*     */       }
/*     */     
/*  66 */     } catch (Exception ex) {
/*  67 */       _logger.error("Caught exception running servlet tester", ex);
/*     */     } 
/*     */     
/*  70 */     _logger.error("ERROR");
/*  71 */     System.exit(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] stringToBytes(String argString) {
/*     */     try {
/*  82 */       return argString.getBytes("UTF8");
/*     */     }
/*  84 */     catch (Exception ee) {
/*  85 */       _logger.error("Unexpected error while encoding string: " + argString, ee);
/*  86 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String bytesToString(byte[] argBytes) {
/*     */     try {
/*  98 */       return new String(argBytes, "UTF8");
/*     */     }
/* 100 */     catch (Exception ee) {
/* 101 */       _logger.error("Unexpected error while converting bytes to string", ee);
/* 102 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addAuthentication(HttpURLConnection conn, String argUserName, String argPwd) {
/* 114 */     if (argUserName != null && !argUserName.trim().equals("")) {
/* 115 */       String s = argUserName + ":" + argPwd;
/* 116 */       s = Base64.byteArrayToBase64(s.getBytes());
/* 117 */       conn.setRequestProperty("Authorization", "Basic " + s);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String formatHeader(Map<String, List<String>> argHeader) {
/* 122 */     StringBuilder buff = new StringBuilder(512);
/* 123 */     for (String key : argHeader.keySet()) {
/* 124 */       for (String value : argHeader.get(key)) {
/* 125 */         buff.append(key).append("=").append(value).append("\n");
/*     */       }
/*     */     } 
/* 128 */     return buff.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean resendRequestAsObject() {
/*     */     try {
/* 136 */       Map<String, Object> parms = new HashMap<>();
/* 137 */       parms.put("argOrganizationId", Long.valueOf(1L));
/* 138 */       QueryRequest query = new QueryRequest("SECURITY_GROUPS", parms);
/*     */       
/* 140 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 141 */       ObjectOutputStream oos = new ObjectOutputStream(bos);
/* 142 */       oos.writeObject(query);
/* 143 */       return sendHttpRequest(GZipUtils.zip(bos.toByteArray()));
/*     */     }
/* 145 */     catch (Throwable ex) {
/* 146 */       _logger.error("Exception during run ", ex);
/*     */       
/* 148 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean sendHttpRequest(byte[] argRequest) throws Exception {
/* 154 */     int readTimeout = 30000;
/*     */     
/* 156 */     HttpURLConnection conn = null;
/* 157 */     OutputStream out = null;
/*     */     
/* 159 */     _msgCount++;
/* 160 */     if (_msgCount > 3) {
/* 161 */       _logger.warn("Too many messages have been sent");
/* 162 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 168 */       URL url = new URL(_server);
/*     */       
/* 170 */       conn = (HttpURLConnection)url.openConnection();
/* 171 */       conn.setFixedLengthStreamingMode(argRequest.length);
/* 172 */       conn.setDoOutput(true);
/* 173 */       conn.setDoInput(true);
/* 174 */       addAuthentication(conn, _user, _password);
/*     */       
/* 176 */       conn.setRequestProperty("Accept", "*/*");
/* 177 */       conn.setRequestProperty("User-Agent", "1::0::0::XCENTER_STATUS_CHECKER");
/* 178 */       conn.setRequestProperty("Content-Type", "text/plain");
/* 179 */       conn.setRequestProperty("Content-Encoding", "UTF8");
/* 180 */       conn.setReadTimeout(readTimeout);
/* 181 */       Map<String, List<String>> requestProps = conn.getRequestProperties();
/*     */       
/* 183 */       out = conn.getOutputStream();
/*     */       
/* 185 */       out.write(argRequest);
/* 186 */       out.flush();
/*     */       
/* 188 */       if (_logger.isDebugEnabled()) {
/* 189 */         String content = "";
/* 190 */         if (argRequest.length > 0) {
/* 191 */           content = new String(argRequest);
/*     */         }
/*     */         
/* 194 */         _logger.debug("HTTP Request URL: " + url + "\nHeader:\n" + formatHeader(requestProps) + content);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 199 */       return validateServletResponse(conn);
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 206 */         if (out != null) {
/* 207 */           out.close();
/* 208 */           out = null;
/*     */         }
/*     */       
/* 211 */       } catch (Exception ee) {
/* 212 */         if (_logger.isDebugEnabled()) {
/* 213 */           _logger.debug("Encountered an exception while closing our writer.", ee);
/*     */         }
/*     */       } 
/*     */       try {
/* 217 */         if (conn != null) {
/* 218 */           conn.disconnect();
/* 219 */           conn = null;
/*     */         }
/*     */       
/* 222 */       } catch (Exception ee) {
/* 223 */         _logger.debug("Encountered an exception while closing our HttpURLConnection.", ee);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateServletResponse(HttpURLConnection argConnection) throws Exception {
/* 231 */     InputStream in = null;
/*     */     
/*     */     try {
/* 234 */       in = argConnection.getInputStream();
/*     */       
/* 236 */       ByteArray response = null;
/*     */       
/* 238 */       int contentLength = argConnection.getContentLength();
/* 239 */       boolean contentLengthApplicable = (contentLength != -1);
/*     */       
/* 241 */       if (contentLengthApplicable) {
/* 242 */         response = new ByteArray(contentLength);
/*     */       } else {
/*     */         
/* 245 */         response = new ByteArray(2048);
/*     */       } 
/*     */ 
/*     */       
/*     */       int read;
/*     */       
/* 251 */       while ((read = in.read()) != -1) {
/* 252 */         response.append((byte)read);
/*     */       }
/*     */       
/* 255 */       if (contentLengthApplicable && response.length() < contentLength) {
/* 256 */         _logger.warn("We only read " + response.length() + " bytes,  but the content length was reported as: " + contentLength + "bytes. *BYTES MAY HAVE BEEN DROPPED!*");
/*     */       }
/*     */ 
/*     */       
/* 260 */       byte[] data = response.toArray();
/*     */       
/* 262 */       String encoding = argConnection.getContentEncoding();
/* 263 */       if ("encoded/gzip".equals(encoding))
/*     */       {
/* 265 */         return true;
/*     */       }
/* 267 */       if ("UTF8".equals(encoding) || encoding == null) {
/* 268 */         String result = bytesToString(data);
/* 269 */         if (ServletPersistenceStrategy.isObjectNotFound(result)) {
/* 270 */           result = result.toLowerCase();
/* 271 */           if (result.contains("no available datasources") || result.contains("lookup failed")) {
/* 272 */             return false;
/*     */           }
/*     */           
/* 275 */           return true;
/*     */         } 
/*     */ 
/*     */         
/* 279 */         if (result.contains("Could not deserialize or unzip request")) {
/* 280 */           return resendRequestAsObject();
/*     */         }
/*     */         
/* 283 */         _logger.info("failure response is " + result);
/* 284 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 288 */       _logger.warn("Unrecognized content encoding type from servlet: " + encoding + " response bytes as string: " + 
/* 289 */           bytesToString(data));
/* 290 */       return false;
/*     */     
/*     */     }
/* 293 */     catch (Exception ex) {
/* 294 */       _logger.warn("handling failure exception ", ex);
/* 295 */       return false;
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 302 */         if (in != null) {
/* 303 */           in.close();
/*     */         }
/*     */       }
/* 306 */       catch (Exception ee) {
/* 307 */         if (_logger.isDebugEnabled())
/* 308 */           _logger.debug("Encountered an exception while closing our reader.", ee); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\remote\servlet\ServletTester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */