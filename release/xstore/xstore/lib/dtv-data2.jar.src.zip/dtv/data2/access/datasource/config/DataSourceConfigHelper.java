/*    */ package dtv.data2.access.datasource.config;
/*    */ 
/*    */ import dtv.data2.access.config.common.AbstractDataConfigHelper;
/*    */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceConfigHelper
/*    */   extends AbstractDataConfigHelper<DataSourceSetConfig>
/*    */ {
/*    */   public Map<String, DataSourceDescriptor> getDataSourceDescriptors() {
/* 26 */     return ((DataSourceSetConfig)getRootConfig()).getDataSources();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getConfigFileName() {
/* 32 */     return "DataSourceConfig";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected IConfigObject getConfigObject(String argTagName, String argDtype, String argSourceDescription) {
/* 38 */     if ("DataSourceSet".equalsIgnoreCase(argDtype)) {
/* 39 */       return (IConfigObject)new DataSourceSetConfig();
/*    */     }
/* 41 */     if ("DataSource".equalsIgnoreCase(argDtype)) {
/* 42 */       return (IConfigObject)new DataSourceConfig();
/*    */     }
/* 44 */     if ("Ping".equalsIgnoreCase(argDtype)) {
/* 45 */       return (IConfigObject)new PingConfig();
/*    */     }
/*    */     
/* 48 */     return super.getConfigObject(argTagName, argDtype, argSourceDescription);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\datasource\config\DataSourceConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */