/*     */ package dtv.data2.access.exception;
/*     */ 
/*     */ import dtv.data2.SQLExceptionScrubber;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpecialActionException
/*     */   extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final String associatedDataSource_;
/*     */   
/*     */   public static String getFullExceptionString(Throwable argThrowable) {
/*  32 */     StringBuilder buff = new StringBuilder(128);
/*  33 */     Throwable cause = argThrowable;
/*     */     
/*  35 */     while (cause != null) {
/*  36 */       if (cause instanceof SQLException) {
/*  37 */         cause = SQLExceptionScrubber.scrub((SQLException)cause);
/*     */       }
/*     */       
/*  40 */       buff.append(cause.toString());
/*     */       
/*  42 */       if (cause instanceof SQLException) {
/*  43 */         SQLException nextException = ((SQLException)cause).getNextException();
/*  44 */         while (nextException != null) {
/*  45 */           buff.append(" Next SQL Exception --> ");
/*  46 */           buff.append(nextException.toString());
/*  47 */           nextException = nextException.getNextException();
/*     */         } 
/*     */       } 
/*     */       
/*  51 */       cause = cause.getCause();
/*  52 */       if (cause != null) {
/*  53 */         buff.append(" Caused by --> ");
/*     */       }
/*     */     } 
/*  56 */     return buff.toString().trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpecialActionException() {
/*  65 */     this.associatedDataSource_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpecialActionException(String argMessage, String argDataSource) {
/*  75 */     super(argMessage);
/*     */ 
/*     */     
/*  78 */     DataSourceFactory.getInstance().getDataSourceDescriptor(argDataSource);
/*  79 */     this.associatedDataSource_ = argDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpecialActionException(String argMessage, Throwable argCause, String argDataSource) {
/*  90 */     super(argMessage, argCause);
/*     */ 
/*     */     
/*  93 */     DataSourceFactory.getDataSourceDescriptor(argDataSource, argCause);
/*  94 */     this.associatedDataSource_ = argDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpecialActionException(Throwable argCause, String argDataSource) {
/* 104 */     super(argCause);
/*     */ 
/*     */     
/* 107 */     DataSourceFactory.getDataSourceDescriptor(argDataSource, argCause);
/* 108 */     this.associatedDataSource_ = argDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 117 */     return this.associatedDataSource_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isApplicable(Throwable argException) {
/* 127 */     if (argException == null) {
/* 128 */       return false;
/*     */     }
/*     */     
/* 131 */     if (argException.getClass().getName().equals(getClass().getName())) {
/* 132 */       return true;
/*     */     }
/*     */     
/* 135 */     ExceptionApplicableRule[] rules = getApplicableRules();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     String fullExceptionMessage = getFullExceptionString(argException);
/*     */     
/* 143 */     for (ExceptionApplicableRule rule : rules) {
/* 144 */       if (!rule.isExceptionClassPertinent() || 
/* 145 */         rule.getExceptionClass().getName().equals(argException.getClass().getName()))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 150 */         if (rule.getMessage() == null || fullExceptionMessage
/* 151 */           .toLowerCase().indexOf(rule.getMessage()) != -1)
/*     */         {
/*     */ 
/*     */           
/* 155 */           return rule.getMatchFoundResult(); }  } 
/*     */     } 
/* 157 */     return false;
/*     */   }
/*     */   
/*     */   abstract ExceptionApplicableRule[] getApplicableRules();
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\exception\SpecialActionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */