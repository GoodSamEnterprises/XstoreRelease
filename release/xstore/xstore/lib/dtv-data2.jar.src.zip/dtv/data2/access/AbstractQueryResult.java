/*    */ package dtv.data2.access;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractQueryResult
/*    */   implements IGenericQueryResult, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Map<Object, Object> _properties;
/* 21 */   private transient String _dataSource = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractQueryResult() {
/* 28 */     this._properties = new HashMap<>();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean containsKey(Object argPropertyName) {
/* 34 */     return this._properties.containsKey(argPropertyName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object get(Object argPropertyName) {
/* 40 */     return this._properties.get(argPropertyName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDataSource() {
/* 46 */     return this._dataSource;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final IObjectId getObjectId() {
/* 52 */     IObjectId objId = getObjectIdImpl();
/*    */     
/* 54 */     if (objId != null)
/*    */     {
/*    */ 
/*    */ 
/*    */       
/* 59 */       for (Map.Entry<Object, Object> property : this._properties.entrySet()) {
/* 60 */         objId.put(property.getKey(), property.getValue());
/*    */       }
/*    */     }
/* 63 */     return objId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<Object> iterator() {
/* 69 */     return this._properties.keySet().iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void put(Object argPropertyName, Object argValue) {
/* 75 */     this._properties.put(argPropertyName, argValue);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDataSource(String argDataSource) {
/* 81 */     this._dataSource = argDataSource;
/*    */   }
/*    */   
/*    */   protected abstract IObjectId getObjectIdImpl();
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\AbstractQueryResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */