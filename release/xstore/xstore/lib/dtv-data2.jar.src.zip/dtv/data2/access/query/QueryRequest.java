/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IPersistenceMgrType;
/*     */ import dtv.data2.access.IQueryKey;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.DtvDate;
/*     */ import dtv.util.EncodingHelper;
/*     */ import dtv.util.ObjectUtils;
/*     */ import dtv.util.XmlUtils;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringReader;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryRequest
/*     */   implements IPersistable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final boolean GZIP = true;
/*     */   public static final String XML_ELEMENT_NAME = "QueryRequest";
/*     */   private String queryKey_;
/*     */   private Map<String, Object> params_;
/*     */   private IPersistenceMgrType _pmType;
/*     */   
/*     */   public QueryRequest() {}
/*     */   
/*     */   public QueryRequest(String argQueryKey, Map<String, Object> argParams) {
/*  53 */     this(argQueryKey, argParams, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRequest(String argQueryKey, Map<String, Object> argParams, IPersistenceMgrType argPmType) {
/*  64 */     this.queryKey_ = argQueryKey;
/*  65 */     setParams(argParams);
/*  66 */     this._pmType = argPmType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object argObject) {
/*  72 */     if (argObject instanceof QueryRequest) {
/*  73 */       QueryRequest other = (QueryRequest)argObject;
/*  74 */       if (this.queryKey_.equals(other.queryKey_) && ObjectUtils.equivalent(this.params_, other.params_) && 
/*  75 */         ObjectUtils.equivalent(this._pmType, other.getPmType())) {
/*  76 */         return true;
/*     */       }
/*     */     } 
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getParams() {
/*  88 */     return this.params_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPmType() {
/*  98 */     return this._pmType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueryKey() {
/* 107 */     return this.queryKey_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 113 */     return this.queryKey_.hashCode() + ((this.params_ != null) ? this.params_.hashCode() : 0) + ((this._pmType != null) ? this._pmType
/* 114 */       .hashCode() : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParams(Map<String, Object> argParams) {
/*     */     Map<String, Object> params;
/* 124 */     if (argParams == null) {
/* 125 */       params = new HashMap<>(8);
/*     */     } else {
/*     */       
/* 128 */       params = argParams;
/*     */     } 
/*     */     
/* 131 */     DaoUtils.massageQueryParams(params, Long.getLong("dtv.location.organizationId"));
/* 132 */     this.params_ = params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueryKey(IQueryKey<?> argQueryKey) {
/* 141 */     this.queryKey_ = argQueryKey.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueryKey(String argQueryKey) {
/* 150 */     this.queryKey_ = argQueryKey;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 156 */     return getClass().getSimpleName() + " [QueryKey: {" + this.queryKey_ + "} {params: " + this.params_ + "} {pmType: " + this._pmType + "}]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toXmlString() {
/* 167 */     StringBuilder buf = new StringBuilder(512);
/*     */     
/* 169 */     buf.append("<QueryRequest>");
/* 170 */     buf.append("<QueryKey>").append(this.queryKey_).append("</QueryKey>");
/* 171 */     buf.append("<Params>");
/*     */     
/* 173 */     for (String key : this.params_.keySet()) {
/* 174 */       Object value = this.params_.get(key);
/* 175 */       ParamType type = getXmlType(value);
/* 176 */       buf.append("<Param name=\"").append(key).append("\" type=\"").append(type.name()).append("\">");
/* 177 */       buf.append(getXmlValue(type, value));
/* 178 */       buf.append("</Param>");
/*     */     } 
/* 180 */     buf.append("</Params>");
/* 181 */     buf.append("</QueryRequest>");
/*     */     
/* 183 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unmarshall(String argXmlString) {
/*     */     try {
/* 193 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 194 */       factory.setProperty("javax.xml.stream.supportDTD", Boolean.valueOf(false));
/* 195 */       XMLStreamReader reader = factory.createXMLStreamReader(new StringReader(argXmlString));
/*     */       try {
/* 197 */         while (reader.hasNext()) {
/*     */           
/* 199 */           int event = reader.next();
/* 200 */           if (event == 1 && reader.getLocalName().equals("QueryRequest")) {
/* 201 */             unmarshall(reader);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } finally {
/* 207 */         reader.close();
/*     */       }
/*     */     
/* 210 */     } catch (Exception ee) {
/* 211 */       throw new DtxException("An error occurred while parsing XML: " + argXmlString, ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unmarshall(XMLStreamReader argReader) throws XMLStreamException {
/* 225 */     Map<String, Object> params = new HashMap<>(8);
/* 226 */     while (argReader.hasNext()) {
/* 227 */       int eventType = argReader.next();
/* 228 */       if (eventType == 1) {
/*     */         
/* 230 */         if (argReader.getLocalName().equals("QueryKey")) {
/* 231 */           setQueryKey(argReader.getElementText()); continue;
/*     */         } 
/* 233 */         if (argReader.getLocalName().equals("Params"))
/*     */         {
/* 235 */           while (argReader.hasNext()) {
/* 236 */             eventType = argReader.nextTag();
/* 237 */             if (eventType == 1) {
/* 238 */               String name = null;
/* 239 */               ParamType type = null;
/*     */ 
/*     */               
/* 242 */               for (int i = 0; i < argReader.getAttributeCount(); i++) {
/* 243 */                 if (argReader.getAttributeLocalName(i).equals("name")) {
/* 244 */                   name = argReader.getAttributeValue(i);
/*     */                 }
/* 246 */                 else if (argReader.getAttributeLocalName(i).equals("type")) {
/* 247 */                   type = ParamType.valueOf(argReader.getAttributeValue(i));
/*     */                 } 
/*     */               } 
/*     */ 
/*     */               
/* 252 */               String rawValue = argReader.getElementText();
/* 253 */               params.put(name, getValueForQueryRequestXml(type, rawValue)); continue;
/*     */             } 
/* 255 */             if (eventType == 2) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */         }
/*     */         continue;
/*     */       } 
/* 262 */       if (eventType == 2) {
/*     */         
/* 264 */         setParams(params);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getValueForQueryRequestXml(ParamType argType, String argParam) {
/* 277 */     switch (argType) {
/*     */       case STRING:
/* 279 */         return argParam;
/*     */ 
/*     */ 
/*     */       
/*     */       case DATE:
/* 284 */         return DaoUtils.getFieldValueForXmlString(93, argParam);
/*     */       case BOOL:
/* 286 */         return Boolean.valueOf("1".equals(argParam));
/*     */       case INT:
/* 288 */         return Integer.valueOf(Integer.parseInt(argParam));
/*     */       case LONG:
/* 290 */         return Long.valueOf(Long.parseLong(argParam));
/*     */       case DECIMAL:
/* 292 */         return new BigDecimal(argParam);
/*     */       case CLASS:
/*     */         try {
/* 295 */           return EncodingHelper.decodeObject(argParam, true);
/*     */         }
/* 297 */         catch (Exception ee) {
/* 298 */           throw new DtxException("Failed to decode parameter: " + argParam + " For query requst: " + this, ee);
/*     */         } 
/*     */     } 
/*     */ 
/*     */     
/* 303 */     throw new DtxException("This point should not be reached. QueryRequst: " + this);
/*     */   }
/*     */   
/*     */   private ParamType getXmlType(Object argParam) {
/* 307 */     if (argParam instanceof String) {
/* 308 */       return ParamType.STRING;
/*     */     }
/* 310 */     if (argParam instanceof java.util.Date) {
/* 311 */       return ParamType.DATE;
/*     */     }
/* 313 */     if (argParam instanceof Boolean) {
/* 314 */       return ParamType.BOOL;
/*     */     }
/* 316 */     if (argParam instanceof Integer) {
/* 317 */       return ParamType.INT;
/*     */     }
/* 319 */     if (argParam instanceof Long) {
/* 320 */       return ParamType.LONG;
/*     */     }
/* 322 */     if (argParam instanceof BigDecimal) {
/* 323 */       return ParamType.DECIMAL;
/*     */     }
/*     */     
/* 326 */     return ParamType.CLASS;
/*     */   }
/*     */   
/*     */   private String getXmlValue(ParamType argType, Object argParam) {
/*     */     BigDecimal dec;
/* 331 */     switch (argType) {
/*     */       case STRING:
/* 333 */         return XmlUtils.toXmlSafe(argParam.toString());
/*     */       case DATE:
/* 335 */         return String.valueOf(((DtvDate)argParam).getTimeSerializable());
/*     */       case BOOL:
/* 337 */         return ((Boolean)argParam).booleanValue() ? "1" : "0";
/*     */       case INT:
/*     */       case LONG:
/* 340 */         return argParam.toString();
/*     */       case DECIMAL:
/* 342 */         dec = ((BigDecimal)argParam).stripTrailingZeros();
/* 343 */         return dec.toPlainString();
/*     */       case CLASS:
/*     */         try {
/* 346 */           return XmlUtils.toXmlSafe(EncodingHelper.encodeObject(argParam, true));
/*     */         }
/* 348 */         catch (Exception ee) {
/* 349 */           throw new DtxException("Failed to encode parameter: " + argParam + " For query requst: " + this, ee);
/*     */         } 
/*     */     } 
/*     */     
/* 353 */     throw new DtxException("This point should not be reached. QueryRequst: " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ParamType
/*     */   {
/* 362 */     STRING,
/*     */     
/* 364 */     DATE,
/*     */     
/* 366 */     BOOL,
/*     */     
/* 368 */     INT,
/*     */     
/* 370 */     LONG,
/*     */     
/* 372 */     DECIMAL,
/*     */     
/* 374 */     CLASS;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */