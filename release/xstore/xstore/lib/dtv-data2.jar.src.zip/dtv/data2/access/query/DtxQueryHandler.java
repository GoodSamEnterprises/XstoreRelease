/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.IJDBCPersistenceStrategy;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.jdbc.IJDBCTableAdapter;
/*     */ import dtv.data2.access.impl.jdbc.JDBCCall;
/*     */ import dtv.data2.access.impl.jdbc.JDBCPersistenceStrategy;
/*     */ import dtv.util.ObjectUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxQueryHandler
/*     */   implements IQueryHandler
/*     */ {
/*  30 */   private static final Logger logger_ = Logger.getLogger(DtxQueryHandler.class);
/*  31 */   private static final Logger queryDebugLogger_ = Logger.getLogger("DtxQueryDebugger");
/*     */ 
/*     */   
/*     */   private Properties props_;
/*     */ 
/*     */   
/*     */   private String sourceDescription_;
/*     */ 
/*     */   
/*     */   private ISqlQueryDecorator _queryDecorator;
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execute(IPersistenceStrategy argStrategy, Map<String, Object> argParameters, QueryToken argQueryToken) {
/*  45 */     if (!(argStrategy instanceof IJDBCPersistenceStrategy)) {
/*  46 */       throw new DtxException(getClass().getName() + " can only work with JDBCPersistenceStrategy currently. The strategy passed instead was; " + argStrategy);
/*     */     }
/*     */     
/*  49 */     Class<?> id = null;
/*  50 */     StringBuilder sql = null;
/*  51 */     List<Object> paramValueList = new ArrayList();
/*     */     
/*     */     try {
/*  54 */       id = getIdClass(argParameters);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  59 */       IJDBCPersistenceStrategy strat = (IJDBCPersistenceStrategy)argStrategy;
/*  60 */       IJDBCTableAdapter adapter = strat.getTableAdapter(id);
/*     */       
/*  62 */       String paramProp = this.props_.getProperty("Parameters");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  67 */       sql = new StringBuilder(1024);
/*  68 */       sql.append(adapter.getSelect());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       String joinTables = getImplicitJoinTables(this.props_, (Map)argParameters);
/*     */       
/*  76 */       if (joinTables != null && joinTables.length() > 0) {
/*  77 */         sql.append(", ");
/*  78 */         sql.append(joinTables);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       if (this.props_.getProperty("Filter") != null && this.props_.getProperty("WhereClause") == null) {
/*  85 */         throw new DtxException("Query: " + this.props_
/*  86 */             .getProperty("Name") + " defines a 'Filter' section, but not a 'WhereClause' section.  What was called 'Filter' under jdo queries is now called 'WhereClause', and should contain valid sql.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       String whereClause = this.props_.getProperty("WhereClause");
/*     */       
/*  97 */       if (!StringUtils.isEmpty(whereClause)) {
/*  98 */         sql.append(" ");
/*  99 */         sql.append(whereClause);
/*     */       } 
/*     */       
/* 102 */       StringBuilder param = new StringBuilder();
/* 103 */       if (paramProp != null) {
/* 104 */         param.append(paramProp);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       JDBCCall call = SqlQueryBuilder.getJDBCCall(argStrategy, sql.toString(), this.props_, argParameters);
/*     */       
/* 112 */       String callString = this._queryDecorator.decorateSql(call.getSqlString(), argStrategy, argParameters);
/* 113 */       sql = new StringBuilder(callString);
/*     */       
/* 115 */       paramValueList = call.getParams();
/*     */     }
/* 117 */     catch (Exception ee) {
/* 118 */       String idClass = (id != null) ? id.getName() : null;
/* 119 */       String msg = "An unexpected exception occurred while building the sql string and parameter list. id class = " + idClass + " sql = " + sql + " parameter list = " + paramValueList;
/*     */ 
/*     */       
/* 122 */       logger_.error(msg, ee);
/*     */       
/* 124 */       if (ee instanceof DtxException) {
/* 125 */         throw (DtxException)ee;
/*     */       }
/*     */       
/* 128 */       throw new DtxException(msg, ee);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     if (queryDebugLogger_.isDebugEnabled()) {
/* 136 */       queryDebugLogger_.debug("DTX Query: [" + this.props_.get("Name") + "] preparing to execute on datasource: " + argStrategy
/* 137 */           .getDataSourceName() + " (DtxQueryHandler)");
/* 138 */       queryDebugLogger_.debug("  [" + this.props_
/* 139 */           .get("Name") + "] sql to execute: " + SqlQueryBuilder.cleanSqlString(sql.toString()));
/* 140 */       queryDebugLogger_.debug("  [" + this.props_.get("Name") + "] parameter values: " + paramValueList);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     Object result = null;
/*     */     try {
/* 149 */       result = ((JDBCPersistenceStrategy)argStrategy).getModelsByQuery(sql.toString(), paramValueList, id, 
/* 150 */           SqlQueryExecutor.getMaxRecordValue(this.props_), argQueryToken);
/* 151 */       return result;
/*     */     } finally {
/*     */       
/* 154 */       if (queryDebugLogger_.isDebugEnabled()) {
/* 155 */         queryDebugLogger_.debug("  [" + this.props_.get("Name") + "] result: " + result);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getProperties() {
/* 163 */     return this.props_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceDescription() {
/* 169 */     return this.sourceDescription_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProperties) {
/* 175 */     this.props_ = argProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueryDecorator(ISqlQueryDecorator argQueryDecorator) {
/* 181 */     this._queryDecorator = argQueryDecorator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceDescription(String argSourceDescription) {
/* 187 */     this.sourceDescription_ = argSourceDescription;
/*     */   }
/*     */   
/*     */   private Class<?> getIdClass(Map<String, Object> argParams) {
/* 191 */     String className = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     Object classObject = ObjectUtils.coalesce(new Object[] { argParams.get("ClassName"), this.props_.get("ClassName"), this.props_.get("ResultClass") });
/*     */     
/* 198 */     if (classObject != null) {
/* 199 */       if (classObject instanceof Class) {
/* 200 */         className = ((Class)classObject).getName();
/*     */       } else {
/*     */         
/* 203 */         className = classObject.toString();
/*     */       } 
/*     */     }
/*     */     
/* 207 */     if (StringUtils.isEmpty(className)) {
/* 208 */       throw new DtxException("Could not determine candidate class for query: " + this.props_.get("Name") + ". 'ClassName' attribute was not specified in QueryConfig OR in the query parameters.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 213 */       return getClass().getClassLoader().loadClass(className);
/*     */     }
/* 215 */     catch (ClassNotFoundException ex) {
/* 216 */       String message = "Unable to find candidate class for query [" + this.props_.get("Name") + "]";
/* 217 */       logger_.error(message, ex);
/* 218 */       throw new DtxException(message, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getImplicitJoinTables(Properties argProperties, Map<? extends Object, ? extends Object> argParams) {
/* 239 */     String TABLE_PREFIX = "Tables.";
/*     */     
/* 241 */     List<Object> tables = new ArrayList();
/* 242 */     Set<Object> keys = argProperties.keySet();
/*     */     
/* 244 */     if (keys != null && !keys.isEmpty()) {
/*     */       
/* 246 */       Iterator<Object> it = keys.iterator();
/*     */       
/* 248 */       while (it.hasNext()) {
/* 249 */         String key = it.next().toString();
/* 250 */         if (key.startsWith("Tables.")) {
/* 251 */           String optionParm = key.substring("Tables.".length());
/*     */           
/* 253 */           Object present = argParams.get(optionParm);
/*     */           
/* 255 */           if (present != null) {
/* 256 */             tables.add(argProperties.get(key));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 261 */     StringBuilder tableClause = new StringBuilder(tables.size() * 12);
/*     */     
/* 263 */     for (int ii = 0; ii < tables.size(); ii++) {
/* 264 */       tableClause.append(tables.get(ii).toString());
/*     */       
/* 266 */       if (ii < tables.size() - 1) {
/* 267 */         tableClause.append(", ");
/*     */       }
/*     */     } 
/* 270 */     return tableClause.toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\DtxQueryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */