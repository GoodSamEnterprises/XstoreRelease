/*     */ package dtv.data2.access.impl.jdbc;
/*     */ 
/*     */ import dtv.data2.SQLExceptionScrubber;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.ObjectUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Clob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCHelper
/*     */ {
/*     */   private static final String QUOTE = "'";
/*  26 */   private static final Logger logger_ = Logger.getLogger(JDBCHelper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JDBCHelper instance_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private static final String[] WANRINGS_TO_IGNORE = new String[] { "truncate nanosecond values", "No row was found for FETCH, UPDATE or DELETE; or the result of a query is an empty table." };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     String className = System.getProperty(JDBCHelper.class.getName(), "dtv.data2.access.impl.jdbc.JDBCHelper");
/*     */     
/*     */     try {
/*  52 */       instance_ = (JDBCHelper)Class.forName(className).newInstance();
/*     */     }
/*  54 */     catch (Exception ex) {
/*  55 */       throw new DtxException("Unable to load JDBCHelper implementation: [" + className + "] controlled by system property: " + JDBCHelper.class
/*  56 */           .getName(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assignParameters(PreparedStatement argStatement, List<Object> argParams, List<Integer> argParamTypes) throws SQLException {
/*  73 */     if (argParams != null) {
/*     */ 
/*     */ 
/*     */       
/*  77 */       if (argParamTypes == null) {
/*  78 */         throw new DtxException("Invalid call made to assignParameters - argParamTypes must be supplied when argParams is non null, -- argParamTypes is null. argParams value: " + argParams);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  83 */       if (argParams.size() != argParamTypes.size()) {
/*  84 */         throw new DtxException("Invalid call made to assignParameters - the length of argParams (length=" + argParams
/*  85 */             .size() + ") must equal the length of of argParamTypes (length=" + argParamTypes
/*  86 */             .size() + ") argParams value: " + argParams + " argParamTypes value: " + argParamTypes);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       for (int i = 0; i < argParams.size(); i++) {
/*  94 */         Object param = argParams.get(i);
/*  95 */         int type = ((Integer)argParamTypes.get(i)).intValue();
/*  96 */         int field = i + 1;
/*  97 */         if (param == null) {
/*     */           try {
/*  99 */             argStatement.setNull(field, type);
/*     */           }
/* 101 */           catch (SQLException ee) {
/* 102 */             if (type == 2005) {
/* 103 */               argStatement.setNull(field, -1);
/*     */             } else {
/*     */               
/* 106 */               throw ee;
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 111 */         } else if (12 == type) {
/* 112 */           argStatement.setString(field, param.toString());
/*     */         }
/* 114 */         else if (4 == type) {
/* 115 */           argStatement.setInt(field, ((Integer)param).intValue());
/*     */         }
/* 117 */         else if (-5 == type) {
/* 118 */           argStatement.setLong(field, ((Long)param).longValue());
/*     */         }
/* 120 */         else if (-7 == type || 16 == type) {
/* 121 */           argStatement.setBoolean(field, ((Boolean)param).booleanValue());
/*     */         }
/* 123 */         else if (3 == type) {
/* 124 */           argStatement.setBigDecimal(field, (BigDecimal)param);
/*     */         }
/* 126 */         else if (param instanceof Timestamp) {
/* 127 */           argStatement.setTimestamp(field, (Timestamp)param);
/*     */         } else {
/*     */           
/* 130 */           argStatement.setObject(field, param);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String clobToString(Clob argClob) throws SQLException {
/* 147 */     if (argClob == null) {
/* 148 */       return null;
/*     */     }
/* 150 */     int WARNING_THESHOLD_100_MB = 100000000;
/*     */     
/* 152 */     long size = argClob.length();
/*     */     
/* 154 */     if (size > 2147483647L) {
/* 155 */       throw new DtxException("A HUGE Clob of length [" + size + "] was detected. clobToString() is not designed to handle such a large object and would certainly run the JVM out of memory if it were to try... First 50 bytes of the value: [" + argClob
/*     */ 
/*     */           
/* 158 */           .getSubString(1L, 50) + "]");
/*     */     }
/*     */     
/* 161 */     if (size > 100000000L) {
/* 162 */       logger_.warn("Very large clob object detected of length: [" + size + "] Processing this object may run the JVM out of memory.");
/*     */     }
/*     */     
/* 165 */     return argClob.getSubString(1L, (int)size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String clobToString(ResultSet argResultSet, int argPosition) throws SQLException {
/* 179 */     String stringResult = argResultSet.getString(argPosition);
/* 180 */     if (stringResult != null) {
/* 181 */       return stringResult;
/*     */     }
/* 183 */     Object objectValue = argResultSet.getObject(argPosition);
/*     */     
/* 185 */     if (objectValue == null) {
/* 186 */       return null;
/*     */     }
/* 188 */     if (objectValue instanceof Clob) {
/* 189 */       return clobToString((Clob)objectValue);
/*     */     }
/* 191 */     if (objectValue instanceof String) {
/* 192 */       return objectValue.toString();
/*     */     }
/*     */     
/* 195 */     throw new DtxException("Unknown object type returned for CLOB field: [" + 
/* 196 */         ObjectUtils.getClassNameFromObject(objectValue) + "] value: [" + objectValue + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JDBCHelper getInstance() {
/* 205 */     return instance_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getJDBCTypeForObject(Object theObject) {
/* 217 */     if (theObject == null) {
/* 218 */       return 0;
/*     */     }
/* 220 */     if (theObject instanceof Short || theObject instanceof Integer) {
/* 221 */       return 4;
/*     */     }
/* 223 */     if (theObject instanceof Double || theObject instanceof Float || theObject instanceof BigDecimal) {
/* 224 */       return 3;
/*     */     }
/* 226 */     if (theObject instanceof Long) {
/* 227 */       return -5;
/*     */     }
/* 229 */     if (theObject instanceof java.util.Date) {
/* 230 */       return 93;
/*     */     }
/* 232 */     if (theObject instanceof Boolean) {
/* 233 */       return -7;
/*     */     }
/* 235 */     if (theObject instanceof Byte) {
/* 236 */       return -2;
/*     */     }
/*     */     
/* 239 */     return 12;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getJDBCTypeForTypeName(String argTypeName) {
/* 252 */     if (argTypeName == null) {
/* 253 */       return 0;
/*     */     }
/* 255 */     if (argTypeName.equals("String")) {
/* 256 */       return 12;
/*     */     }
/* 258 */     if (argTypeName.equals("Short") || argTypeName.equals("Integer")) {
/* 259 */       return 4;
/*     */     }
/* 261 */     if (argTypeName.equals("Double") || argTypeName.equals("Float") || argTypeName.equals("BigDecimal")) {
/* 262 */       return 3;
/*     */     }
/* 264 */     if (argTypeName.equals("Long")) {
/* 265 */       return -5;
/*     */     }
/* 267 */     if (argTypeName.equals("Date")) {
/* 268 */       return 93;
/*     */     }
/* 270 */     if (argTypeName.equals("Boolean")) {
/* 271 */       return -7;
/*     */     }
/* 273 */     if (argTypeName.equals("Byte")) {
/* 274 */       return -2;
/*     */     }
/*     */     
/* 277 */     return 12;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Integer> getJDBCTypesForList(List<Object> argParams) {
/* 288 */     if (argParams == null) {
/* 289 */       return null;
/*     */     }
/* 291 */     List<Integer> types = new ArrayList<>(argParams.size());
/*     */     
/* 293 */     for (Object oo : argParams) {
/* 294 */       types.add(Integer.valueOf(getJDBCTypeForObject(oo)));
/*     */     }
/* 296 */     return types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean handleWarnings(String argSql, SQLWarning argWarning) {
/* 307 */     SQLWarning warning = argWarning;
/* 308 */     boolean hasWarnings = false;
/*     */     
/* 310 */     while (warning != null) {
/* 311 */       hasWarnings = true;
/*     */ 
/*     */       
/* 314 */       String msg = warning.getMessage();
/* 315 */       boolean ignore = false;
/*     */       
/* 317 */       for (String element : WANRINGS_TO_IGNORE) {
/* 318 */         if (msg.indexOf(element) != -1) {
/* 319 */           ignore = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 324 */       if (!ignore) {
/* 325 */         logger_.warn("A jdbc warning was generated while executing sql: " + argSql, warning);
/*     */       }
/* 327 */       warning = warning.getNextWarning();
/*     */     } 
/* 329 */     return hasWarnings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logSqlException(String argMessage, SQLException argException) {
/* 339 */     logger_.error("SQL EXCEPTION", SQLExceptionScrubber.scrub(argException));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toParameterString(String argValue) {
/* 353 */     if (argValue == null) {
/* 354 */       return argValue;
/*     */     }
/* 356 */     StringBuilder buff = new StringBuilder(argValue.length() + 2);
/* 357 */     buff.append("'").append(argValue.replace("'", "''")).append("'");
/*     */     
/* 359 */     return buff.toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JDBCHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */