/*    */ package dtv.data2.access.impl.daogen;
/*    */ 
/*    */ import dtv.data2.access.impl.SelectingImplFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigElementTables
/*    */ {
/* 18 */   private static List<String> _configElementTableNames = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized List<String> getTableNames() {
/* 27 */     if (_configElementTableNames == null) {
/* 28 */       _configElementTableNames = new ArrayList<>();
/* 29 */       Collection<String> configElementTables = new HashSet<>();
/*    */       
/* 31 */       IHasConfigElementTables tableClass = (IHasConfigElementTables)SelectingImplFactory.getImplClass(IHasConfigElementTables.class);
/* 32 */       if (tableClass != null) {
/* 33 */         configElementTables.addAll(tableClass.getConfigElementTables());
/*    */       }
/*    */       
/* 36 */       _configElementTableNames.addAll(configElementTables);
/*    */     } 
/*    */     
/* 39 */     return _configElementTableNames;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\ConfigElementTables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */