/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.AbstractPersistenceRule;
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.access.transaction.DataSourceTransactionManager;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.List;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataRedundancyRule
/*     */   extends AbstractPersistenceRule
/*     */ {
/*  39 */   private static final Logger _logger = Logger.getLogger(DataRedundancyRule.class);
/*     */ 
/*     */   
/*     */   private static final String PARAM_APPLIES_IN_TRAINING_MODE = "AppliesInTrainingMode";
/*     */   
/*     */   private boolean _applyInTrainingMode = false;
/*     */   
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */   
/*     */   @Inject
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */ 
/*     */   
/*     */   public DataRedundancyRule() {
/*  54 */     super(true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistable applyRule(PersistableMetaData argPersistableMetaData, Object argObject) {
/*  60 */     IPersistable persistable = argPersistableMetaData.getPersistable();
/*  61 */     String targetDataSourceName = getTargetDataSourceName();
/*     */ 
/*     */     
/*  64 */     if (DataSourceFactory.isDataSourceEnabled(targetDataSourceName) && 
/*  65 */       StatusMgr.getInstance().isOnline(targetDataSourceName)) {
/*     */ 
/*     */       
/*  68 */       DataSourceDescriptor dataSource = DataSourceFactory.getInstance().getDataSourceDescriptor(targetDataSourceName);
/*  69 */       IPersistenceStrategy strategy = this._persistenceStrategyFactory.createStrategy(dataSource, true);
/*     */       
/*  71 */       List<? extends IPersistable> persistables = DaoUtils.getPersistables(persistable);
/*  72 */       TransactionToken token = DataSourceTransactionManager.getInstance().startTransaction(null);
/*     */       
/*     */       try {
/*  75 */         for (IPersistable nextPersistable : persistables) {
/*  76 */           IDataAccessObject iDataAccessObject; if (nextPersistable instanceof IDataAccessObject) {
/*  77 */             iDataAccessObject = DaoUtils.cloneDao((IDataAccessObject)nextPersistable);
/*  78 */             iDataAccessObject.setPersistenceDefaults(this._persistenceDefaults);
/*  79 */             iDataAccessObject.setObjectState(DaoState.INSERT_OR_UPDATE.intVal());
/*     */           } 
/*  81 */           strategy.makePersistent(token, (IPersistable)iDataAccessObject);
/*     */         } 
/*     */         
/*  84 */         DataSourceTransactionManager.getInstance().commit(token);
/*     */       }
/*  86 */       catch (Exception ex) {
/*     */         
/*  88 */         _logger.error("Exception caught attempting to persist data via rule: " + getClass().getName(), ex);
/*  89 */         DataSourceTransactionManager.getInstance().rollback(token);
/*     */       } 
/*     */     } 
/*  92 */     return persistable;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isApplicable(PersistableMetaData argPersistableMetaData, Object argObject) {
/*     */     int i;
/*  98 */     IPersistable persistable = argPersistableMetaData.getPersistable();
/*     */     
/* 100 */     boolean applicable = false;
/*     */ 
/*     */     
/* 103 */     if (persistable instanceof IDataModel && "OBJECT_RETRIEVED"
/* 104 */       .equals(argPersistableMetaData.getPersistableAction()) && (this._applyInTrainingMode || 
/* 105 */       !this._persistenceDefaults.isTraining())) {
/*     */       
/* 107 */       String dataSource = ((IDataModel)persistable).getDataSource();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       applicable = matchesSourceDataSource(dataSource, true);
/* 113 */       i = applicable & (!matchesTargetDataSource(dataSource, true) ? 1 : 0);
/*     */     } 
/* 115 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String argName, IConfigObject argValue) {
/* 121 */     if ("AppliesInTrainingMode".equalsIgnoreCase(argName)) {
/* 122 */       this._applyInTrainingMode = Boolean.valueOf(argValue.toString()).booleanValue();
/*     */     } else {
/*     */       
/* 125 */       super.setParameter(argName, argValue);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\DataRedundancyRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */