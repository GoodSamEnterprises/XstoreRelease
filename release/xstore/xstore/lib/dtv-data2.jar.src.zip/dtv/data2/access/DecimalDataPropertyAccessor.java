/*    */ package dtv.data2.access;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecimalDataPropertyAccessor<T extends IHasDataProperty<? extends IDataProperty>>
/*    */   extends AbstractDataPropertyAccessor<T, BigDecimal>
/*    */ {
/*    */   public DecimalDataPropertyAccessor(Class<T> argParentType, String argKey) {
/* 24 */     super(argParentType, argKey);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BigDecimal getValue(T argParent) {
/* 33 */     return getValue(argParent, BigDecimal.ZERO);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BigDecimal getValue(T argParent, BigDecimal argDefault) {
/* 39 */     BigDecimal value = validParent(argParent).getDecimalProperty(getKey());
/* 40 */     if (value == null) {
/* 41 */       return argDefault;
/*    */     }
/* 43 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<BigDecimal> getValueType() {
/* 52 */     return BigDecimal.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(T argParent, BigDecimal argValue) {
/* 58 */     validParent(argParent).setDecimalProperty(getKey(), argValue);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\DecimalDataPropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */