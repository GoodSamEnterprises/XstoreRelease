/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IOverridableOrgHierarchyResult;
/*     */ import dtv.data2.access.IQueryResult;
/*     */ import dtv.util.CompositeObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LevelCodeLevelValueFilter
/*     */   implements IResultFilter
/*     */ {
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */   
/*     */   public Collection<? extends IQueryResult> filter(List<? extends IQueryResult> argResultsToFilter, Map<String, Object> argQueryParams) {
/*  34 */     final Map<String, Integer> prioritizedOrgNodes = new HashMap<>();
/*     */     
/*  36 */     List<IOverridableOrgHierarchyResult> sortedResults = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     if (argResultsToFilter.isEmpty() || 
/*  44 */       !(argResultsToFilter.get(0) instanceof IOverridableOrgHierarchyResult))
/*     */     {
/*  46 */       return argResultsToFilter;
/*     */     }
/*     */ 
/*     */     
/*  50 */     for (IQueryResult result : argResultsToFilter) {
/*  51 */       sortedResults.add((IOverridableOrgHierarchyResult)result);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     int priority = 1;
/*     */     
/*  60 */     if (argQueryParams.containsKey("orgNodeList")) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  65 */       List<String> orgNodeList = (List<String>)argQueryParams.get("orgNodeList");
/*     */       
/*  67 */       if (!CollectionUtils.isEmpty(orgNodeList)) {
/*  68 */         for (String orgNode : orgNodeList) {
/*  69 */           prioritizedOrgNodes.put(orgNode, Integer.valueOf(priority));
/*  70 */           priority++;
/*     */         } 
/*     */       }
/*     */     } else {
/*     */       
/*  75 */       for (CompositeObject.TwoPiece<String, String> orgNode : (Iterable<CompositeObject.TwoPiece<String, String>>)this._persistenceDefaults.getOrgHierarchyAncestry()) {
/*  76 */         String nodeString = (String)orgNode.a() + ":" + (String)orgNode.b();
/*  77 */         prioritizedOrgNodes.put(nodeString, Integer.valueOf(priority));
/*  78 */         priority++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  84 */     Collections.sort(sortedResults, new Comparator<IOverridableOrgHierarchyResult>()
/*     */         {
/*     */           public int compare(IOverridableOrgHierarchyResult argO1, IOverridableOrgHierarchyResult argO2) {
/*  87 */             String nodeString1 = argO1.getLevelCode() + ":" + argO1.getLevelValue();
/*  88 */             String nodeString2 = argO2.getLevelCode() + ":" + argO2.getLevelValue();
/*  89 */             Integer priority1 = (Integer)prioritizedOrgNodes.get(nodeString1);
/*  90 */             Integer priority2 = (Integer)prioritizedOrgNodes.get(nodeString2);
/*  91 */             priority1 = Integer.valueOf((priority1 == null) ? Integer.MIN_VALUE : priority1.intValue());
/*  92 */             priority2 = Integer.valueOf((priority2 == null) ? Integer.MIN_VALUE : priority2.intValue());
/*     */ 
/*     */             
/*  95 */             return -priority1.compareTo(priority2);
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     Map<IObjectId, IOverridableOrgHierarchyResult> filteredResults = new HashMap<>();
/*     */     
/* 104 */     for (IOverridableOrgHierarchyResult result : sortedResults) {
/* 105 */       filteredResults.put(result.getFilteringObjectId(), result);
/*     */     }
/*     */     
/* 108 */     return (Collection)filteredResults.values();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\LevelCodeLevelValueFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */