/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.pm.PersistenceManagerType;
/*     */ import dtv.data2.cache.CacheManager;
/*     */ import dtv.data2.cache.ICache;
/*     */ import dtv.data2.cache.NotCachedException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectManager
/*     */ {
/*     */   private static final String CACHE_NAME = "ObjectManager";
/*  24 */   private static final Logger logger_ = Logger.getLogger(ObjectManager.class);
/*     */   
/*  26 */   private static final IPersistenceMgrType PM_TYPE = (IPersistenceMgrType)PersistenceManagerType.forName("STORE_STANDARD");
/*     */   
/*     */   private static ObjectManager INSTANCE;
/*     */   
/*  30 */   public static final String SYSTEM_PROPERTY = ObjectManager.class.getName();
/*     */   protected ICache cache_;
/*     */   
/*     */   static {
/*  34 */     String className = System.getProperty(SYSTEM_PROPERTY);
/*     */     try {
/*  36 */       INSTANCE = (ObjectManager)Class.forName(className).newInstance();
/*     */     }
/*  38 */     catch (Exception ex) {
/*  39 */       logger_.warn("No accesible implementation defined in system properties. [" + className + "]");
/*  40 */       logger_.warn("Falling back on default implementation.");
/*  41 */       INSTANCE = new ObjectManager();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ObjectManager getInstance() {
/*  51 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectManager() {
/*  64 */     this.cache_ = CacheManager.getInstance().getCache("ObjectManager");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getManagedObject(IObjectId argObjectId) {
/*  75 */     if (argObjectId == null) {
/*  76 */       throw new DtxException("getManagedObject() cannot have null argObjectId");
/*     */     }
/*     */     
/*     */     try {
/*  80 */       return this.cache_.get(argObjectId);
/*     */     }
/*  82 */     catch (NotCachedException notCachedException) {
/*     */ 
/*     */ 
/*     */       
/*  86 */       Object retVal = null;
/*     */       try {
/*  88 */         retVal = DataFactory.getObjectById(argObjectId, PM_TYPE);
/*  89 */         if (retVal != null) {
/*  90 */           this.cache_.put(argObjectId, retVal);
/*     */         }
/*     */       }
/*  93 */       catch (ObjectNotFoundException objectNotFoundException) {}
/*     */ 
/*     */       
/*  96 */       return retVal;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void manageObject(IDataModel argDataModel) {
/* 105 */     if (argDataModel == null) {
/* 106 */       throw new NullPointerException("manageObject() cannot manage null argDataModel");
/*     */     }
/*     */     
/* 109 */     this.cache_.put(((IDataModelImpl)argDataModel).getObjectId(), argDataModel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unmanageObject(Object argId) {
/* 118 */     this.cache_.remove(argId);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\ObjectManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */