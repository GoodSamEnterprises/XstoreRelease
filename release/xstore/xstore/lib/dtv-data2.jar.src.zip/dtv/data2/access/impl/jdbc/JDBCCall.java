/*     */ package dtv.data2.access.impl.jdbc;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCCall
/*     */ {
/*     */   private String sqlString_;
/*     */   private List<Object> params_;
/*     */   private List<Integer> types_;
/*     */   private List<String> paramNames_;
/*     */   
/*     */   public List<String> getParamNames() {
/*  35 */     return this.paramNames_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> getParams() {
/*  44 */     return this.params_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSqlString() {
/*  53 */     return this.sqlString_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Integer> getTypes() {
/*  62 */     return this.types_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParamNames(List<String> argParamNames) {
/*  71 */     this.paramNames_ = argParamNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParams(List<Object> argParams) {
/*  80 */     this.params_ = argParams;
/*  81 */     checkIntegrity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlString(String argSqlString) {
/*  90 */     this.sqlString_ = argSqlString;
/*  91 */     checkIntegrity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypes(List<Integer> argTypes) {
/* 100 */     this.types_ = argTypes;
/* 101 */     checkIntegrity();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 107 */     StringBuilder val = new StringBuilder(64);
/*     */     
/* 109 */     val.append("sql: ").append("[");
/* 110 */     val.append(this.sqlString_);
/* 111 */     val.append("] params: ").append(this.params_);
/*     */     
/* 113 */     return val.toString();
/*     */   }
/*     */   
/*     */   private void checkIntegrity() {
/* 117 */     if (this.params_ != null && this.types_ != null && 
/* 118 */       this.params_.size() != this.types_.size())
/* 119 */       throw new DtxException("Class constraint of JDBCCall violated.  params_ and types_ must be equal in size when both non-null. params_: " + this.params_ + " types: " + this.types_); 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JDBCCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */