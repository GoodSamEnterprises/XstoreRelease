/*    */ package dtv.data2.access.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletFailoverException
/*    */   extends FailoverException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public static ServletFailoverException getNewException(String argMessage, String argDataSourceName) {
/* 29 */     return new ServletFailoverException(argMessage, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ServletFailoverException getNewException(Throwable argThrowable, String argDataSourceName) {
/* 40 */     return new ServletFailoverException(argThrowable, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ServletFailoverException(String argMessage, String argDataSourceName) {
/* 50 */     super(argMessage, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ServletFailoverException(Throwable argThrowable, String argDataSourceName) {
/* 60 */     super(argThrowable, argDataSourceName);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\exception\ServletFailoverException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */