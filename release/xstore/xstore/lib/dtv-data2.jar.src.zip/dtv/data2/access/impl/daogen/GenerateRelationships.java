/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.data2.access.IDataModelRelationship;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateRelationships
/*     */   implements Callable<Void>
/*     */ {
/*  27 */   private static final Logger logger_ = Logger.getLogger(GenerateRelationships.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final DaoGenHelper helper_;
/*     */ 
/*     */   
/*     */   private boolean orgHierarchyJoinRequired_ = false;
/*     */ 
/*     */ 
/*     */   
/*     */   GenerateRelationships(DaoGenHelper argHelper) {
/*  39 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  47 */     logger_.info("Generating relationships");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/*     */ 
/*     */       
/*  55 */       if (dtx.isCustomerExtension()) {
/*  56 */         dtx.getRelationships().add(getCustomerOverrideRelationship(dtx));
/*     */       }
/*     */       
/*  59 */       for (DtxRelationship rel : dtx.getRelationships()) {
/*  60 */         if (dtx.needsGeneration(null) || rel.getChild().needsGeneration(null)) {
/*  61 */           StringBuilder w = new StringBuilder(5120);
/*  62 */           getRelationshipDBAHeader(w, dtx, rel);
/*  63 */           getRelationshipSelect(w, dtx, rel);
/*  64 */           getRelationshipParent(w, dtx, rel);
/*  65 */           getIsOrgHierarchyJoinRequired(w);
/*  66 */           getRelationshipDBAFooter(w, dtx, rel);
/*     */           
/*  68 */           File f = new File(this.helper_.getOutPath() + this.helper_.getFilePath(dtx) + dtx.getName() + rel.getName() + "RelationshipDBA.java");
/*     */           
/*  70 */           this.helper_.getWriter().write(f, w.toString());
/*     */         } 
/*     */       } 
/*     */       
/*  74 */       if (dtx.isCustomerExtension()) {
/*  75 */         dtx.getRelationships().remove(dtx.getRelationships().size() - 1);
/*     */       }
/*     */     } 
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   private DtxRelationship getCustomerOverrideRelationship(DtxDefinition dtx) {
/*  82 */     DtxRelationship rel = new DtxRelationship();
/*  83 */     rel.setChild(dtx);
/*  84 */     rel.setParent(dtx.getExtends());
/*  85 */     rel.setDependent(true);
/*  86 */     rel.setName(dtx.getExtends().getName() + "Extension");
/*  87 */     rel.setType("One-One");
/*     */ 
/*     */ 
/*     */     
/*  91 */     DtxDefinition.DtxDaoField[] pk = dtx.getPrimaryKeyFieldsRaw();
/*     */     
/*  93 */     for (DtxDefinition.DtxDaoField field : pk) {
/*  94 */       rel.getClass(); DtxRelationship.DtxRelationshipField relField = new DtxRelationship.DtxRelationshipField(rel);
/*  95 */       relField.setParent(field.getName());
/*  96 */       relField.setChild(field.getName());
/*  97 */       rel.addField(relField);
/*     */ 
/*     */       
/* 100 */       if (dtx.getExtends().findField(field.getName()) == null) {
/* 101 */         dtx.getExtends().addField(field);
/*     */       }
/*     */     } 
/*     */     
/* 105 */     return rel;
/*     */   }
/*     */   
/*     */   private void getIsOrgHierarchyJoinRequired(StringBuilder w) {
/* 109 */     w.append("  @Override\n");
/* 110 */     w.append("  public boolean isOrgHierarchyJoinRequired() {\n    return ");
/*     */     
/* 112 */     w.append(this.orgHierarchyJoinRequired_);
/* 113 */     w.append(";\n");
/* 114 */     w.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void getRelationshipDBAFooter(StringBuilder w, DtxDefinition argDtx, DtxRelationship argRelationship) {
/* 119 */     w.append("  public List getParameterList() {\n    return _parameterList;\n  }\n\n");
/*     */ 
/*     */ 
/*     */     
/* 123 */     w.append("  public dtv.data2.access.IObjectId getChildObjectId() {\n");
/*     */     
/* 125 */     if (IDataModelRelationship.RelationshipType.ONE_TO_ONE.toString()
/* 126 */       .equalsIgnoreCase(argRelationship.getType())) {
/* 127 */       w.append("    return _childObjectId;\n");
/*     */     }
/*     */     else {
/*     */       
/* 131 */       w.append("    throw new dtv.data2.access.exception.DtxException(\"getChildObjectId() can only be called on ONE-ONE relationships. This is an invalid call for relationship adapter: \" + this.getClass().getName());\n");
/*     */     } 
/*     */ 
/*     */     
/* 135 */     w.append("  }\n");
/* 136 */     w.append("}\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void getRelationshipDBAHeader(StringBuilder w, DtxDefinition argDtx, DtxRelationship argRelationship) {
/* 142 */     w.append("package ");
/* 143 */     w.append(argDtx.getPackage());
/* 144 */     w.append(";\n\nimport java.util.ArrayList;\nimport java.util.List;\n\nimport dtv.data2.access.IDataAccessObject;\nimport dtv.data2.access.impl.jdbc.IJDBCRelationshipAdapter;\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     w.append(this.helper_.getClassCommentWithSuppressWarnings("Auto-generated DBA \n * DO NOT MANUALLY MODIFY THIS FILE.\n * ANY CHANGES WILL BE OVERWRITTEN BY REGENERATION!!"));
/*     */ 
/*     */ 
/*     */     
/* 155 */     w.append("public class ");
/* 156 */     w.append(argDtx.getName());
/* 157 */     w.append(argRelationship.getName());
/* 158 */     w.append("RelationshipDBA");
/* 159 */     w.append(" implements IJDBCRelationshipAdapter {\n\n");
/*     */     
/* 161 */     w.append(" private List<Object> _parameterList = new ArrayList<Object>(" + argRelationship
/* 162 */         .getFields().size() + ");\n\n");
/*     */     
/* 164 */     if (IDataModelRelationship.RelationshipType.ONE_TO_ONE.toString()
/* 165 */       .equalsIgnoreCase(argRelationship.getType())) {
/* 166 */       w.append("  " + argRelationship.getChild().getId() + " _childObjectId = null;\n\n");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getRelationshipParent(StringBuilder w, DtxDefinition argDtx, DtxRelationship argRelationship) {
/* 176 */     this.orgHierarchyJoinRequired_ = DaoGenOrgHierarchyHelper.isOrgHierarchical(argRelationship.getChild());
/*     */     
/* 178 */     w.append("  public void setParent(IDataAccessObject argDAO) {\n    ");
/*     */ 
/*     */     
/* 181 */     if (argDtx.isCustomerExtension()) {
/* 182 */       String parent = argDtx.getExtends().getPackage() + "." + argDtx.getExtends().getName() + "DAO";
/* 183 */       w.append(parent + " dao = (" + parent + ")argDAO;\n");
/*     */     } else {
/*     */       
/* 186 */       w.append(argDtx.getName() + "DAO dao = (" + argDtx.getName() + "DAO)argDAO;\n");
/*     */     } 
/*     */     
/* 189 */     if (IDataModelRelationship.RelationshipType.ONE_TO_ONE.toString()
/* 190 */       .equalsIgnoreCase(argRelationship.getType()))
/*     */     {
/* 192 */       w.append("    _childObjectId = new " + argRelationship.getChild().getId() + "();\n");
/*     */     }
/*     */     
/* 195 */     for (DtxRelationship.DtxRelationshipField field : argRelationship.getFields()) {
/* 196 */       if (!StringUtils.isEmpty(field.getParent())) {
/* 197 */         String fieldName = StringUtils.ensureFirstUpperCase(field.getParent());
/* 198 */         String childFieldName = StringUtils.ensureFirstUpperCase(field.getChild());
/*     */         
/* 200 */         if (this.orgHierarchyJoinRequired_ && DaoGenOrgHierarchyHelper.isOrgHierarchyRelationshipJoin(field))
/*     */         {
/*     */ 
/*     */           
/* 204 */           this.orgHierarchyJoinRequired_ = false;
/*     */         }
/*     */ 
/*     */         
/* 208 */         boolean isCharacterNonPkToPk = false;
/* 209 */         for (DtxDefinition.DtxDaoField childPkField : argRelationship.getChild().getPrimaryKeyFields()) {
/* 210 */           for (DtxDefinition.DtxDaoField parentNonPkField : argRelationship.getParent().getNonPkFields()) {
/* 211 */             if ("String".equalsIgnoreCase(parentNonPkField.getType()) && parentNonPkField
/* 212 */               .getName().equals(field.getParent()) && childPkField
/* 213 */               .getName().equals(field.getChild())) {
/* 214 */               isCharacterNonPkToPk = true;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 221 */         String getterCall = "dao.get" + fieldName + "()";
/* 222 */         if (isCharacterNonPkToPk) {
/* 223 */           w.append("    _parameterList.add(").append(getterCall)
/* 224 */             .append(" != null && dtv.data2.access.impl.PersistenceConstants.MANAGE_CASE ? ")
/* 225 */             .append(getterCall).append(".toUpperCase() : ").append(getterCall).append(");\n");
/*     */         } else {
/*     */           
/* 228 */           w.append("    _parameterList.add(").append(getterCall).append(");\n");
/*     */         } 
/*     */         
/* 231 */         if (IDataModelRelationship.RelationshipType.ONE_TO_ONE.toString()
/* 232 */           .equalsIgnoreCase(argRelationship.getType()))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 243 */           if (!argDtx.getName().equalsIgnoreCase("SaleReturnLineItem") || 
/* 244 */             !argRelationship.getName().equalsIgnoreCase("inventoryDocumentLineItem"))
/*     */           {
/* 246 */             w.append("    _childObjectId.set" + childFieldName + "(dao.get" + fieldName + "());\n");
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 252 */     w.append("  }\n\n");
/*     */   }
/*     */   
/*     */   private void getRelationshipSelect(StringBuilder w, DtxDefinition argDtx, DtxRelationship argRelationship) {
/* 256 */     w.append("  public String getSelect() {\n    return \"SELECT ");
/*     */ 
/*     */     
/* 259 */     if (IDataModelRelationship.RelationshipType.ONE_TO_ONE.toString()
/* 260 */       .equalsIgnoreCase(argRelationship.getType()) || IDataModelRelationship.RelationshipType.ONE_TO_MANY
/* 261 */       .toString()
/* 262 */       .equalsIgnoreCase(argRelationship.getType())) {
/*     */ 
/*     */ 
/*     */       
/* 266 */       DtxDefinition.DtxDaoField[] fields = argRelationship.getChild().getTopMostParent().getFields();
/*     */       
/* 268 */       for (int ii = 0; ii < fields.length; ii++) {
/* 269 */         w.append(fields[ii].getColumn());
/* 270 */         if (ii < fields.length - 1) {
/* 271 */           w.append(", ");
/*     */         }
/*     */       } 
/*     */       
/* 275 */       w.append(" FROM ");
/* 276 */       w.append(argRelationship.getChild().getTopMostParent().getTable());
/*     */       
/* 278 */       boolean whereWritten = false;
/*     */       
/* 280 */       for (DtxRelationship.DtxRelationshipField relField : argRelationship.getFields()) {
/* 281 */         if (whereWritten) {
/* 282 */           w.append(" AND ");
/*     */         } else {
/*     */           
/* 285 */           w.append(" WHERE ");
/* 286 */           whereWritten = true;
/*     */         } 
/*     */         
/* 289 */         w.append(argRelationship.getChild().getTopMostParent().getColumnForFieldName(relField.getChild()));
/* 290 */         w.append(" = ?");
/*     */       } 
/* 292 */       w.append("\";\n");
/*     */     }
/* 294 */     else if (DtxRelationship.ONE_ONE.equalsIgnoreCase(argRelationship.getType())) {
/*     */       
/* 296 */       DtxDefinition.DtxDaoField[] fields = argRelationship.getChild().getTopMostParent().getFields();
/*     */       
/* 298 */       for (int ii = 0; ii < fields.length; ii++) {
/* 299 */         w.append("a.");
/* 300 */         w.append(fields[ii].getColumn());
/* 301 */         if (ii < fields.length - 1) {
/* 302 */           w.append(", ");
/*     */         }
/*     */       } 
/* 305 */       w.append(" FROM ");
/* 306 */       w.append(argRelationship.getChild().getTopMostParent().getTable());
/* 307 */       w.append(" a, ");
/* 308 */       w.append(argRelationship.getTable());
/* 309 */       w.append(" b");
/*     */       
/* 311 */       boolean whereWritten = false;
/* 312 */       for (Iterator<?> iter = argRelationship.getFields().iterator(); iter.hasNext(); iter.next()) {
/* 313 */         if (whereWritten) {
/* 314 */           w.append(" AND ");
/*     */         } else {
/*     */           
/* 317 */           w.append(" WHERE ");
/* 318 */           whereWritten = true;
/*     */         } 
/*     */       } 
/* 321 */       w.append("\";\n");
/*     */     }
/* 323 */     else if (IDataModelRelationship.RelationshipType.MANY_TO_MANY.toString()
/* 324 */       .equalsIgnoreCase(argRelationship.getType())) {
/*     */ 
/*     */       
/* 327 */       DtxDefinition.DtxDaoField[] fields = argRelationship.getChild().getTopMostParent().getFields();
/*     */       
/* 329 */       for (int ii = 0; ii < fields.length; ii++) {
/* 330 */         w.append("a.");
/* 331 */         w.append(fields[ii].getColumn());
/* 332 */         if (ii < fields.length - 1) {
/* 333 */           w.append(", ");
/*     */         }
/*     */       } 
/* 336 */       w.append(" FROM ");
/* 337 */       w.append(argRelationship.getChild().getTopMostParent().getTable());
/* 338 */       w.append(" a, ");
/* 339 */       w.append(argRelationship.getTable());
/* 340 */       w.append(" b, ");
/* 341 */       w.append(argDtx.getTable());
/* 342 */       w.append(" c ");
/*     */       
/* 344 */       boolean whereWritten = false; int i;
/* 345 */       for (i = 0; i < argRelationship.getFields().size(); i++) {
/* 346 */         DtxRelationship.DtxRelationshipField relField = argRelationship.getField(i);
/*     */         
/* 348 */         if (whereWritten) {
/* 349 */           w.append(" AND ");
/*     */         } else {
/*     */           
/* 352 */           w.append(" WHERE ");
/* 353 */           whereWritten = true;
/*     */         } 
/* 355 */         if (relField.getChild() == null || relField.getChild().length() == 0) {
/* 356 */           w.append("c.");
/* 357 */           w.append(argDtx.getColumnForFieldName(relField.getParent()));
/* 358 */           w.append(" = ");
/*     */         } else {
/*     */           
/* 361 */           w.append("a.");
/* 362 */           w.append(argRelationship.getChild().getTopMostParent().getColumnForFieldName(relField.getChild()));
/* 363 */           w.append(" = ");
/*     */         } 
/*     */         
/* 366 */         if (relField.getValue() == null || relField.getValue().length() == 0) {
/* 367 */           w.append("b.");
/* 368 */           w.append(relField.getXrefField());
/*     */         } else {
/*     */           
/* 371 */           w.append("'");
/* 372 */           w.append(relField.getValue());
/* 373 */           w.append("'");
/*     */         } 
/*     */       } 
/*     */       
/* 377 */       for (i = 0; i < argRelationship.getFields().size(); i++) {
/* 378 */         DtxRelationship.DtxRelationshipField relField = argRelationship.getField(i);
/*     */         
/* 380 */         if (relField.getParent() != null && relField.getParent().length() > 0) {
/* 381 */           if (whereWritten) {
/* 382 */             w.append(" AND ");
/*     */           } else {
/*     */             
/* 385 */             w.append(" WHERE ");
/* 386 */             whereWritten = true;
/*     */           } 
/*     */           
/* 389 */           w.append("c.");
/* 390 */           w.append(argDtx.getColumnForFieldName(relField.getParent()));
/* 391 */           w.append(" = ?");
/*     */         } 
/*     */       } 
/*     */       
/* 395 */       w.append("\";\n");
/*     */     } else {
/*     */       
/* 398 */       logger_.error(argDtx.getSourceDtxFile().getName() + " ERROR: UNKNOWN RELATIONSHIP TYPE " + argRelationship
/* 399 */           .getType());
/*     */     } 
/*     */     
/* 402 */     w.append("\n  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateRelationships.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */