/*    */ package dtv.data2.access.exception;
/*    */ 
/*    */ import dtv.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExceptionApplicableRule
/*    */ {
/*    */   private final String message_;
/*    */   private final Class<?> exceptionClass_;
/*    */   private final boolean matchFoundResult_;
/*    */   
/*    */   ExceptionApplicableRule(String argMessage) {
/* 25 */     this(argMessage, null, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ExceptionApplicableRule(String argMessage, Class<?> argExceptionClass, boolean argMatchFoundResult) {
/* 36 */     if (argExceptionClass == null && StringUtils.isEmpty(argMessage)) {
/* 37 */       throw new DtxException("ExceptionApplicableRule cannot be created with null or empty argMessage AND null argExceptionClass. At least one of these arguments needs to be supplied.");
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 42 */     if (argMessage != null) {
/* 43 */       this.message_ = argMessage.toLowerCase();
/*    */     } else {
/*    */       
/* 46 */       this.message_ = null;
/*    */     } 
/*    */     
/* 49 */     this.exceptionClass_ = argExceptionClass;
/* 50 */     this.matchFoundResult_ = argMatchFoundResult;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 60 */     return this.message_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Class<?> getExceptionClass() {
/* 68 */     return this.exceptionClass_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean getMatchFoundResult() {
/* 76 */     return this.matchFoundResult_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isExceptionClassPertinent() {
/* 85 */     return (this.exceptionClass_ != null);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\exception\ExceptionApplicableRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */