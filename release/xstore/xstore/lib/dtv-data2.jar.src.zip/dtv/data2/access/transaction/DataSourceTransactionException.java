/*    */ package dtv.data2.access.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceTransactionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DataSourceTransactionException(String argDescription) {
/* 22 */     super(argDescription);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSourceTransactionException(String argDescription, Throwable argCause) {
/* 32 */     super(argDescription, argCause);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\transaction\DataSourceTransactionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */