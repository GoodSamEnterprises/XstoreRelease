/*     */ package dtv.data2.access.status;
/*     */ 
/*     */ import dtv.data2.access.config.pmtype.DataSourceLocationConfig;
/*     */ import dtv.data2.access.config.pmtype.PersistenceMgrTypeDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.jdbc.JDBCDataSourceMgr;
/*     */ import dtv.data2.access.pm.PersistenceManagerStatus;
/*     */ import dtv.data2.access.pm.PersistenceMgrTypeFactory;
/*     */ import dtv.data2.replication.ReplicationStrategyHelper;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationConfigHelper;
/*     */ import dtv.data2.replication.dtximpl.config.DtxReplicationServiceConfig;
/*     */ import dtv.data2.replication.dtximpl.config.ServiceConditionConfig;
/*     */ import dtv.data2.replication.dtximpl.config.ServiceSubscriberConfig;
/*     */ import dtv.jmx.AbstractDtvMBean;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceStatusMBean
/*     */   extends AbstractDtvMBean
/*     */ {
/*     */   private static final String PM_TYPES = "Pm Type";
/*     */   private static final String DATASOURCES = "Datasources";
/*     */   private static final String DATASOURCE = "Datasource Name";
/*     */   private static final String SOURCE = "Source";
/*     */   private static final String ONLINE = "Online";
/*     */   private static final String OFFLINE = "Offline";
/*     */   private static final String DISABLED = "Disabled";
/*     */   private static final String ONLINE_LOOKUP = "Online Lookup:";
/*     */   private static final String ONLINE_PERSISTENCE = "Online Persistence:";
/*     */   private static final String OFFLINE_LOOKUP = "Offline Lookup:";
/*     */   private static final String OFFLINE_PERSISTENCE = "Offline Persistence:";
/*     */   private static final String REPLICATION = "Replication Status";
/*     */   private static final String PM_TYPE_STATUSES = "PM Statuses";
/*     */   private static final String CONNECTION_POOL_STATUS = "Connection Pool Status";
/*     */   private static final String REPLICATION_MASTER_SWITCH = "Replcation Master Switch (system property dtv.data2.replication.enabled): ";
/*     */   private static final String BR = "<br>";
/*  64 */   private Map<String, String> dataSourceStatuses_ = null;
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private PersistenceMgrTypeFactory _persistenceMgrTypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceStatus() {
/*  75 */     this.dataSourceStatuses_ = new HashMap<>();
/*     */     
/*  77 */     StringBuilder doc = new StringBuilder(1024);
/*     */     
/*  79 */     dataSourceSummary(doc);
/*  80 */     connectionPoolSummary(doc);
/*  81 */     replicationStatus(doc);
/*     */     
/*  83 */     doc.append("<p align=\"center\">");
/*  84 */     doc.append(font(bold("PM Statuses"), 4));
/*  85 */     doc.append("</p>");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     tableHeader(doc, "Pm Type", "Datasources");
/*     */ 
/*     */     
/*  93 */     Collection<PersistenceMgrTypeDescriptor> pmTypes = this._persistenceMgrTypeFactory.getPersistenceMgrtTypeDescriptors();
/*     */     
/*  95 */     for (PersistenceMgrTypeDescriptor pm : pmTypes) {
/*     */ 
/*     */ 
/*     */       
/*  99 */       doc.append("<tr>").append("<td>").append(font(bold(pm.getName()))).append("</td>");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       doc.append("<td><p>");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 109 */       doc.append(font(bold("Online Lookup:"))).append("<br>");
/*     */       
/* 111 */       for (DataSourceLocationConfig onlineLookupLoc : pm.getOnlineLookupLocations()) {
/* 112 */         doc.append(font(onlineLookupLoc.getDataSourceName()) + " - " + 
/* 113 */             getDataSourceStatus(onlineLookupLoc.getDataSourceName())).append("<br>");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 119 */       doc.append(font(bold("Online Persistence:"))).append("<br>");
/*     */       
/* 121 */       for (DataSourceLocationConfig onlinePersistpLoc : pm.getOnlinePersistenceLocations()) {
/* 122 */         doc.append(font(onlinePersistpLoc.getDataSourceName()) + " - " + 
/* 123 */             getDataSourceStatus(onlinePersistpLoc.getDataSourceName())).append("<br>");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 129 */       doc.append(font(bold("Offline Lookup:"))).append("<br>");
/*     */       
/* 131 */       for (DataSourceLocationConfig offlineLookupLoc : pm.getOfflineLookupLocations()) {
/* 132 */         doc.append(font(offlineLookupLoc.getDataSourceName()) + " - " + 
/* 133 */             getDataSourceStatus(offlineLookupLoc.getDataSourceName())).append("<br>");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 139 */       doc.append(font(bold("Offline Persistence:"))).append("<br>");
/*     */       
/* 141 */       for (DataSourceLocationConfig offlinePersistLoc : pm.getOfflinePersistenceLocations()) {
/* 142 */         doc.append(font(offlinePersistLoc.getDataSourceName()) + " - " + 
/* 143 */             getDataSourceStatus(offlinePersistLoc.getDataSourceName())).append("<br>");
/*     */       }
/* 145 */       if (pm.getOfflineLookupLocations().size() > 0) {
/* 146 */         trimBR(doc);
/*     */       }
/*     */       
/* 149 */       doc.append("</td></tr>");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     tableFooter(doc);
/*     */     
/* 157 */     return doc.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startMBean() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private String bold(String argElement) {
/* 167 */     return "<strong>" + argElement + "</strong>";
/*     */   }
/*     */   
/*     */   private String color(String argElement, String argColor) {
/* 171 */     return "<font color=\"" + argColor + "\">" + argElement + "</font>";
/*     */   }
/*     */   
/*     */   private void connectionPoolSummary(StringBuilder argBuf) {
/* 175 */     StringBuilder doc = argBuf;
/*     */     
/* 177 */     doc.append("<p align=\"center\">");
/* 178 */     doc.append(font(bold("Connection Pool Status"), 4));
/* 179 */     doc.append("</p>");
/*     */     
/* 181 */     doc.append("<table width=\"400\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">");
/* 182 */     doc.append("  <tr> ");
/* 183 */     doc.append("    <td>");
/*     */     
/* 185 */     StringBuilder stats = (new StringBuilder(2048)).append(JDBCDataSourceMgr.getInstance().toString());
/* 186 */     StringUtils.replaceAll(stats, "\n", "<br>");
/* 187 */     StringUtils.replaceAll(stats, "\t", "&nbsp;&nbsp;");
/* 188 */     doc.append(stats);
/*     */     
/* 190 */     doc.append("  </td></tr></table>");
/* 191 */     doc.append("<br>");
/*     */   }
/*     */   
/*     */   private void dataSourceSummary(StringBuilder argBuf) {
/* 195 */     StringBuilder doc = argBuf;
/*     */     
/* 197 */     doc.append("<p align=\"center\">");
/* 198 */     doc.append(font(bold("Datasources"), 4));
/* 199 */     doc.append("</p>");
/*     */     
/* 201 */     tableHeader(argBuf, "Datasource Name", "Source");
/*     */ 
/*     */     
/* 204 */     Collection<DataSourceDescriptor> datasourcesCollection = DataSourceFactory.getInstance().getDataSourceDescriptors();
/*     */ 
/*     */     
/* 207 */     List<DataSourceDescriptor> datasources = getSortedDatasourceList(datasourcesCollection);
/*     */     
/* 209 */     for (DataSourceDescriptor datasource : datasources) {
/* 210 */       doc.append("<tr>").append("<td>").append(font(bold(datasource.getName())));
/* 211 */       doc.append("<br>");
/* 212 */       doc.append(getDataSourceStatus(datasource.getName(), true));
/* 213 */       doc.append("</td>");
/*     */       
/* 215 */       doc.append("<td>");
/* 216 */       doc.append(font(datasource.getSourceDescription()));
/* 217 */       doc.append("</td></tr>");
/*     */     } 
/* 219 */     tableFooter(argBuf);
/* 220 */     doc.append("<br>");
/*     */   }
/*     */   
/*     */   private String font(String argElement) {
/* 224 */     return "<font face=\"Arial,  Helvetica,  sans-serif\">" + argElement + "</font>";
/*     */   }
/*     */   
/*     */   private String font(String argElement, int size) {
/* 228 */     return "<font face=\"Arial,  Helvetica,  sans-serif\" size=\"" + size + "\">" + argElement + "</font>";
/*     */   }
/*     */   
/*     */   private String getDataSourceStatus(String argDataSourceName) {
/* 232 */     return getDataSourceStatus(argDataSourceName, false);
/*     */   }
/*     */   
/*     */   private String getDataSourceStatus(String argDataSourceName, boolean argIncludeOfflineCause) {
/* 236 */     if (this.dataSourceStatuses_.containsKey(argDataSourceName)) {
/* 237 */       return this.dataSourceStatuses_.get(argDataSourceName);
/*     */     }
/*     */     
/* 240 */     String status = null;
/*     */     
/* 242 */     boolean enabled = false;
/* 243 */     boolean inError = false;
/* 244 */     String errorString = null;
/*     */     
/*     */     try {
/* 247 */       enabled = DataSourceFactory.getInstance().getDataSourceDescriptor(argDataSourceName).isEnabled();
/*     */     }
/* 249 */     catch (Exception ee) {
/* 250 */       inError = true;
/* 251 */       errorString = ee.toString();
/*     */     } 
/*     */     
/* 254 */     if (inError) {
/* 255 */       status = red(bold(errorString));
/*     */     }
/* 257 */     else if (!enabled) {
/* 258 */       status = grey(bold("Disabled"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 265 */     else if (PersistenceManagerStatus.ONLINE == StatusMgr.getInstance()
/* 266 */       .getDataSourceStatus(argDataSourceName)) {
/*     */       
/* 268 */       status = green(bold("Online"));
/*     */     } else {
/*     */       
/* 271 */       status = red(bold("Offline"));
/*     */       
/* 273 */       if (argIncludeOfflineCause) {
/* 274 */         FailoverException ee = StatusMgr.getInstance().getOfflineCause(argDataSourceName);
/*     */         
/* 276 */         String cause = (ee != null) ? ee.toString() : "UNKNOWN";
/*     */         
/* 278 */         status = status + font(" - Offline Cause: " + cause);
/* 279 */         return status;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 284 */     this.dataSourceStatuses_.put(argDataSourceName, status);
/* 285 */     return status;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<DataSourceDescriptor> getSortedDatasourceList(Collection<DataSourceDescriptor> argDatasourceCollection) {
/* 291 */     List<DataSourceDescriptor> list = new ArrayList<>(argDatasourceCollection.size());
/*     */     
/* 293 */     for (DataSourceDescriptor dsd : argDatasourceCollection) {
/* 294 */       list.add(dsd);
/*     */     }
/*     */     
/* 297 */     Collections.sort(list, new Comparator<DataSourceDescriptor>()
/*     */         {
/*     */           
/*     */           public int compare(DataSourceDescriptor arg1, DataSourceDescriptor arg2)
/*     */           {
/* 302 */             if (arg1.isEnabled() != arg2.isEnabled()) {
/* 303 */               if (arg1.isEnabled()) {
/* 304 */                 return -1;
/*     */               }
/*     */               
/* 307 */               return 1;
/*     */             } 
/*     */ 
/*     */             
/* 311 */             return arg1.getName().compareTo(arg2.getName());
/*     */           }
/*     */         });
/*     */     
/* 315 */     return list;
/*     */   }
/*     */   
/*     */   private String green(String argElement) {
/* 319 */     return color(argElement, "#00CC00");
/*     */   }
/*     */   
/*     */   private String grey(String argElement) {
/* 323 */     return color(argElement, "#999999");
/*     */   }
/*     */   
/*     */   private String red(String argElement) {
/* 327 */     return color(argElement, "#FF0000");
/*     */   }
/*     */   
/*     */   private void replicationStatus(StringBuilder argBuf) {
/* 331 */     StringBuilder doc = argBuf;
/*     */     
/* 333 */     doc.append("<p align=\"center\">");
/*     */     
/* 335 */     doc.append(font(bold("Replication Status"), 4)).append("<br>");
/*     */     
/* 337 */     boolean on = ReplicationStrategyHelper.isReplicationEnabled();
/*     */     
/* 339 */     doc.append(font(bold("Replcation Master Switch (system property dtv.data2.replication.enabled): "), 2));
/* 340 */     doc.append("<b>" + (on ? green("" + on) : red("" + on)) + "</b>").append("<br>");
/* 341 */     doc.append("Replication Queue Datasource: <b>" + 
/* 342 */         DtxReplicationConfigHelper.getReplicationQueueConfig().getDataSource() + "</b>").append("<br>");
/*     */     
/* 344 */     doc.append("</p>");
/*     */     
/* 346 */     if (on && 
/* 347 */       ReplicationStrategyHelper.getReplicationStategy() instanceof dtv.data2.replication.dtximpl.DtxReplicationStrategy) {
/* 348 */       doc.append("<table width=\"400\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">");
/* 349 */       doc.append("  <tr> ");
/* 350 */       doc.append("    <td>");
/*     */       
/* 352 */       DtxReplicationServiceConfig[] serviceConfigs = DtxReplicationConfigHelper.getServiceConfigs();
/* 353 */       StringBuilder serviceReportBuilder = new StringBuilder(2048);
/*     */       
/* 355 */       for (DtxReplicationServiceConfig config : serviceConfigs) {
/* 356 */         if (config.isEnabled()) {
/* 357 */           serviceReportBuilder
/* 358 */             .append("Service: " + config.getName() + " enabled: " + config.isEnabled() + "<br>");
/*     */           
/* 360 */           if (config.getConditions() != null && config.getConditions().size() > 0) {
/* 361 */             for (ServiceConditionConfig conditionConfig : config.getConditions()) {
/* 362 */               serviceReportBuilder.append(" APPLICABLE when condition is met: " + conditionConfig + "<br>");
/*     */             }
/*     */           }
/*     */           
/* 366 */           serviceReportBuilder
/* 367 */             .append(" APPLICABLE for objects whose class begins with on of the following patterns: <br>");
/*     */           
/* 369 */           for (ServiceSubscriberConfig subscriber : config.getSubscribers()) {
/* 370 */             serviceReportBuilder.append(" " + subscriber + "<br>");
/*     */           }
/*     */           
/* 373 */           serviceReportBuilder.append("<br><br>");
/*     */         } 
/*     */       } 
/*     */       
/* 377 */       doc.append(font(serviceReportBuilder.toString()));
/* 378 */       doc.append("  </td></tr></table>");
/*     */     } 
/*     */     
/* 381 */     doc.append("<br>");
/*     */   }
/*     */   
/*     */   private void tableFooter(StringBuilder argDoc) {
/* 385 */     argDoc.append("  </table>");
/*     */   }
/*     */   
/*     */   private void tableHeader(StringBuilder argDoc, String argCol1, String argCol2) {
/* 389 */     argDoc.append("<table width=\"400\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">");
/* 390 */     argDoc.append("  <tr bgcolor=\"#CCCCCC\"> ");
/* 391 */     argDoc.append("    <td>").append(font(bold(argCol1))).append("</td>");
/* 392 */     argDoc.append("    <td>").append(font(bold(argCol2))).append("</td>");
/* 393 */     argDoc.append("  </tr>");
/*     */   }
/*     */   
/*     */   private void trimBR(StringBuilder argDoc) {
/* 397 */     argDoc.setLength(argDoc.length() - "<br>".length());
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\status\DataSourceStatusMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */