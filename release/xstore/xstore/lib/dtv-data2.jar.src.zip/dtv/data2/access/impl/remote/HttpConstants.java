package dtv.data2.access.impl.remote;

public class HttpConstants {
  public static final String CONTENT_TYPE_KEY = "Content-Type";
  
  public static final String CONTENT_ENCODING_KEY = "Content-Encoding";
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\remote\HttpConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */