/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.data2.access.AbstractPersistenceRule;
/*    */ import dtv.data2.access.DaoUtils;
/*    */ import dtv.data2.access.DataFactory;
/*    */ import dtv.data2.access.IDataModel;
/*    */ import dtv.data2.access.IPersistable;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PruneCleanTreesRule
/*    */   extends AbstractPersistenceRule
/*    */ {
/* 29 */   private static final Logger _logger = Logger.getLogger(PruneCleanTreesRule.class);
/*    */ 
/*    */   
/*    */   private static final String PARAM_OBJECT_ID = "ObjectId";
/*    */   
/* 34 */   private final Collection<String> _objectIdNames = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public IPersistable applyRule(PersistableMetaData argPersistableMetaData, Object argObject) {
/* 39 */     IDataModel rootModel = (IDataModel)argPersistableMetaData.getPersistable();
/* 40 */     IDataModel iDataModel1 = rootModel;
/*    */     
/* 42 */     if (this._objectIdNames.isEmpty()) {
/*    */ 
/*    */       
/* 45 */       if (!DaoUtils.isTreeDirty(rootModel))
/*    */       {
/* 47 */         _logger.debug("The entire tree rooted at [" + rootModel + "] is clean and will not be persisted.");
/* 48 */         DataFactory.makeTransient(rootModel);
/*    */       }
/*    */     
/*    */     } else {
/*    */       
/* 53 */       Collection<? extends DaoUtils.PersistableLink> hierarchy = DaoUtils.getAllPersistables(rootModel);
/*    */ 
/*    */ 
/*    */       
/* 57 */       for (String objectIdName : this._objectIdNames) {
/* 58 */         for (DaoUtils.PersistableLink persistableData : hierarchy) {
/*    */ 
/*    */           
/* 61 */           IDataModel model = (IDataModel)persistableData.getPersistable();
/*    */           
/* 63 */           if (objectIdName.equalsIgnoreCase(model.getObjectId().getClass().getName()) && 
/* 64 */             !DaoUtils.isTreeDirty(model)) {
/*    */ 
/*    */             
/* 67 */             _logger
/* 68 */               .debug("The entire subtree rooted at [" + model + "] is clean and will not be persisted.");
/* 69 */             DataFactory.makeTransient(model);
/*    */             
/* 71 */             if (persistableData.getParent() == null) {
/*    */               break;
/*    */             }
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     return (IPersistable)iDataModel1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isApplicable(PersistableMetaData argPersistableMetaData, Object argObject) {
/* 88 */     return (argPersistableMetaData.getPersistable() instanceof IDataModel && "OBJECT_PERSISTED"
/* 89 */       .equals(argPersistableMetaData.getPersistableAction()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParameter(String argName, IConfigObject argValue) {
/* 95 */     if ("ObjectId".equalsIgnoreCase(argName)) {
/* 96 */       this._objectIdNames.add(argValue.toString());
/*    */     } else {
/*    */       
/* 99 */       super.setParameter(argName, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\PruneCleanTreesRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */