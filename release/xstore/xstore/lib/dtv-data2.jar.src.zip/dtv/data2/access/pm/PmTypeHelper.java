/*     */ package dtv.data2.access.pm;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IPersistenceMgrType;
/*     */ import dtv.data2.access.IRunQueryKey;
/*     */ import dtv.data2.access.config.pmtype.DataSourceLocationConfig;
/*     */ import dtv.data2.access.config.pmtype.PersistenceMgrTypeDescriptor;
/*     */ import dtv.data2.access.config.query.QueryDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.AbstractPersistenceStrategy;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.PersistenceStrategyFactory;
/*     */ import dtv.data2.access.impl.config.PmTypeMappingConfigHelper;
/*     */ import dtv.data2.access.query.DtxQueryHandler;
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.access.query.SqlQueryRequest;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.util.ObjectUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PmTypeHelper {
/*  37 */   private static final Logger logger_ = Logger.getLogger(PmTypeHelper.class);
/*     */   private static final int ESTIMATED_QUERY_COUNT = 100;
/*  39 */   private static Map<String, IPersistenceMgrType> pmTypeCache_ = new HashMap<>(100);
/*     */ 
/*     */   
/*     */   private PmTypeMappingConfigHelper _cfg;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private PersistenceMgrTypeFactory _persistenceMgrTypeFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   protected PmTypeHelper(PmTypeMappingConfigHelper argCfg) {
/*  59 */     this._cfg = argCfg;
/*  60 */     this._cfg.initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PmStrategyInfo> getLookupStrategies(IObjectId argObjectId) {
/*  72 */     return getLookupStrategies(getPMTypeByObjectId((Class)argObjectId.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PmStrategyInfo> getLookupStrategies(IPersistenceMgrType argPmType) {
/*  84 */     List<PmStrategyInfo> online = getPrioritizedStratgies(argPmType, true, true);
/*  85 */     List<PmStrategyInfo> offline = getPrioritizedStratgies(argPmType, true, false);
/*     */     
/*  87 */     online.addAll(offline);
/*  88 */     return online;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PmStrategyInfo> getPersistenceStrategies(IObjectId argObjectId) {
/*  98 */     return getPersistenceStrategies(getPMTypeByObjectId((Class)argObjectId.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PmStrategyInfo> getPersistenceStrategies(IPersistable argPersistable) {
/* 108 */     return getPersistenceStrategies(getPMTypeForPersistable(argPersistable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PmStrategyInfo> getPersistenceStrategies(IPersistenceMgrType argPmType) {
/* 118 */     List<PmStrategyInfo> online = getPrioritizedStratgies(argPmType, false, true);
/* 119 */     List<PmStrategyInfo> offline = getPrioritizedStratgies(argPmType, false, false);
/*     */     
/* 121 */     online.addAll(offline);
/*     */     
/* 123 */     return online;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeByObject(Object argObject) {
/* 134 */     if (argObject == null) {
/* 135 */       throw new PmTypeDeterminationException("Cannot determine PM type for null object");
/*     */     }
/*     */     
/* 138 */     if (argObject instanceof IDataModel) {
/* 139 */       return getPMTypeByObjectId((Class)((IDataModel)argObject).getObjectId().getClass());
/*     */     }
/* 141 */     if (argObject instanceof Collection) {
/* 142 */       if (!((Collection)argObject).isEmpty()) {
/* 143 */         Object firstObject = ((Collection)argObject).iterator().next();
/* 144 */         if (firstObject instanceof IDataModel) {
/* 145 */           return getPMTypeByObject(firstObject);
/*     */         }
/*     */         
/* 148 */         throw new PmTypeDeterminationException("Cannot determine PM type for the given collection.  The collection must contain IDataModel's but has: " + firstObject
/*     */             
/* 150 */             .getClass().getName());
/*     */       } 
/*     */ 
/*     */       
/* 154 */       throw new PmTypeDeterminationException("Cannot determine PM type for an empty collection");
/*     */     } 
/*     */     
/* 157 */     if (argObject instanceof Object[]) {
/* 158 */       if (((Object[])argObject).length > 0) {
/* 159 */         Object firstObject = ((Object[])argObject)[0];
/* 160 */         if (firstObject instanceof IDataModel) {
/* 161 */           return getPMTypeByObject(firstObject);
/*     */         }
/*     */         
/* 164 */         throw new PmTypeDeterminationException("Cannot determine PM type for the given collection.  The collection must contain IDataModel's but has: " + firstObject
/*     */             
/* 166 */             .getClass().getName());
/*     */       } 
/*     */ 
/*     */       
/* 170 */       throw new PmTypeDeterminationException("Cannot determine PM type for an empty array");
/*     */     } 
/*     */     
/* 173 */     throw new PmTypeDeterminationException("Cannot determine PM type an unknown error occured.  This code should not be hit");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeByObjectId(Class<? extends Object> argObjectIdClass) {
/* 186 */     String pmTypeString = null;
/*     */     try {
/* 188 */       pmTypeString = this._cfg.getPMType(argObjectIdClass.getName());
/*     */     }
/* 190 */     catch (Exception ex) {
/* 191 */       if (ex instanceof PmTypeDeterminationException) {
/* 192 */         throw (RuntimeException)ex;
/*     */       }
/*     */       
/* 195 */       throw new PmTypeDeterminationException("Unable to determine PM type for id: " + argObjectIdClass
/* 196 */           .getName() + " see cause exception.", ex);
/*     */     } 
/*     */ 
/*     */     
/* 200 */     if (!StringUtils.isEmpty(pmTypeString)) {
/* 201 */       return PersistenceManagerType.forName(pmTypeString);
/*     */     }
/*     */     
/* 204 */     throw new PmTypeDeterminationException("Unable to determine PM type for id: " + argObjectIdClass
/* 205 */         .getName() + " retrieved null or empty PM type string.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeByObjectId(IObjectId argId) {
/* 216 */     return getPMTypeByObjectId((Class)argId.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeByObjectId(String argObjectIdClass) {
/* 228 */     if (StringUtils.isEmpty(argObjectIdClass)) {
/* 229 */       throw new DtxException("getPMTypeByObjectId cannot accept null or empty argObjectIdClass");
/*     */     }
/* 231 */     Class<?> clazz = null;
/*     */     
/*     */     try {
/* 234 */       clazz = Class.forName(argObjectIdClass);
/*     */     }
/* 236 */     catch (Exception ee) {
/* 237 */       throw new PmTypeDeterminationException("An exception occurred while attempting to get a class for class name: " + argObjectIdClass, ee);
/*     */     } 
/*     */     
/* 240 */     return getPMTypeByObjectId((Class)clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeByQueryKey(String argQueryKey, Map<?, ?> argParams) {
/* 256 */     PersistenceManagerType pmTypeCachced = (PersistenceManagerType)pmTypeCache_.get(argQueryKey);
/*     */     
/* 258 */     if (pmTypeCachced != null) {
/* 259 */       return pmTypeCachced;
/*     */     }
/* 261 */     QueryDescriptor queryDescriptor = DataFactory.getInstance().getQueryDescriptor(argQueryKey);
/*     */     
/* 263 */     if (queryDescriptor == null) {
/* 264 */       throw new DtxException("No query definition found for query key: [" + argQueryKey + "] Check QueryConfig.xml and related.");
/*     */     }
/*     */     
/* 267 */     IPersistenceMgrType pmType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     String pmTypeProperty = (String)queryDescriptor.getProperties().get("PMType");
/*     */     
/* 276 */     if (!StringUtils.isEmpty(pmTypeProperty)) {
/* 277 */       pmType = PersistenceManagerType.forName(pmTypeProperty);
/*     */     }
/*     */     
/* 280 */     if (pmType == null && DtxQueryHandler.class
/* 281 */       .getName().equals(queryDescriptor.getQueryHandler().getName())) {
/*     */ 
/*     */ 
/*     */       
/* 285 */       Properties props = queryDescriptor.getProperties();
/* 286 */       String objectIdString = (String)ObjectUtils.coalesce(new Object[] { props.get("ClassName"), props.get("ResultClass") });
/*     */       
/* 288 */       if (objectIdString == null)
/*     */       {
/*     */         
/* 291 */         if (argParams != null) {
/* 292 */           Object classNameValue = argParams.get("ClassName");
/*     */           
/* 294 */           if (classNameValue instanceof Class) {
/* 295 */             objectIdString = ((Class)classNameValue).getName();
/*     */           }
/* 297 */           else if (classNameValue instanceof String) {
/* 298 */             objectIdString = classNameValue.toString();
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 303 */       if (objectIdString != null) {
/* 304 */         pmType = getPMTypeByObjectId(objectIdString);
/*     */       }
/*     */     } 
/*     */     
/* 308 */     if (pmType == null) {
/* 309 */       PmTypeDeterminationException ex = new PmTypeDeterminationException("No persistence manager could be determined for query [" + argQueryKey + "]!");
/*     */       
/* 311 */       logger_.error("An error occured while determining PM type", ex);
/* 312 */       throw ex;
/*     */     } 
/*     */     
/* 315 */     pmTypeCache_.put(argQueryKey, pmType);
/*     */ 
/*     */     
/* 318 */     return pmType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeForPersistable(IPersistable argPersistable) {
/* 328 */     if (argPersistable == null) {
/* 329 */       throw new DtxException("getPersistenceStrategies cannot be called with null argPersistable");
/*     */     }
/* 331 */     if (argPersistable instanceof IDataModel) {
/* 332 */       return getPMTypeByObject(argPersistable);
/*     */     }
/* 334 */     if (argPersistable instanceof IDataAccessObject) {
/* 335 */       return getPMTypeByObjectId((Class)((IDataAccessObject)argPersistable).getObjectId().getClass());
/*     */     }
/* 337 */     if (argPersistable instanceof IRunQueryKey) {
/* 338 */       return getPMTypeByQueryKey(((IRunQueryKey)argPersistable).getQueryKey().getName(), ((IRunQueryKey)argPersistable)
/* 339 */           .getParams());
/*     */     }
/* 341 */     if (argPersistable instanceof SqlQueryRequest) {
/* 342 */       SqlQueryRequest request = (SqlQueryRequest)argPersistable;
/* 343 */       if (StringUtils.isEmpty(request.getPmType())) {
/* 344 */         throw new PmTypeDeterminationException("Cannot determine PM type for SqlQueryRequest because it does not define a pmType. " + argPersistable);
/*     */       }
/*     */ 
/*     */       
/* 348 */       return PersistenceManagerType.forName(request.getPmType());
/*     */     } 
/*     */     
/* 351 */     if (argPersistable instanceof QueryRequest) {
/* 352 */       if (((QueryRequest)argPersistable).getQueryKey() == null) {
/* 353 */         throw new PmTypeDeterminationException("Cannot determine PM type for QueryRequest because it does not define a query. " + argPersistable);
/*     */       }
/*     */       
/* 356 */       return getPMTypeByQueryKey(((QueryRequest)argPersistable).getQueryKey(), ((QueryRequest)argPersistable)
/* 357 */           .getParams());
/*     */     } 
/*     */     
/* 360 */     throw new DtxException("Implementation of IPeristable is not supported: " + argPersistable
/* 361 */         .getClass().getName() + " If this is dataloader running - a system property for loading the proper instance of PmTypeHelper may be missing.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isLoadPropertiesEnabled(Class<? extends Object> argObjectIdClass) {
/* 373 */     return this._cfg.isPMTypeLoadPropertiesEnabled(argObjectIdClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logPmTypeStatus(IPersistenceMgrType argPmType) {
/*     */     List<DataSourceLocationConfig> onlineLookup, offlineLookup, onlinePersistence, offlinePersistence;
/* 382 */     StringBuilder msg = new StringBuilder(1024);
/*     */     
/* 384 */     String trainingModeIndication = isTrainingMode() ? " IN TRAINING MODE." : "";
/*     */     
/* 386 */     msg.append("Logging status of PM type: " + argPmType + trainingModeIndication + "\n");
/*     */ 
/*     */     
/* 389 */     PersistenceMgrTypeDescriptor descriptor = this._persistenceMgrTypeFactory.getPersistenceMgrTypeDescriptor(argPmType);
/*     */     
/* 391 */     msg.append("Online Lookup Locations\n");
/*     */ 
/*     */     
/* 394 */     if (isTrainingMode()) {
/* 395 */       onlineLookup = descriptor.getTrainingLookupLocations();
/*     */     } else {
/*     */       
/* 398 */       onlineLookup = descriptor.getOnlineLookupLocations();
/*     */     } 
/*     */     
/* 401 */     for (DataSourceLocationConfig dataSource : onlineLookup) {
/* 402 */       msg.append(" ");
/* 403 */       msg.append(dataSource.getDataSourceName()).append(": ");
/*     */ 
/*     */       
/* 406 */       if (!DataSourceFactory.getInstance().getDataSourceDescriptor(dataSource.getDataSourceName()).isEnabled()) {
/*     */         
/* 408 */         msg.append("Disabled\n");
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 414 */       if (PersistenceManagerStatus.ONLINE == StatusMgr.getInstance()
/* 415 */         .getDataSourceStatus(dataSource.getDataSourceName())) {
/*     */         
/* 417 */         msg.append("Online\n");
/*     */         continue;
/*     */       } 
/* 420 */       msg.append("Offline\n");
/*     */     } 
/*     */     
/* 423 */     msg.append("Offline Lookup Locations\n");
/*     */ 
/*     */ 
/*     */     
/* 427 */     if (isTrainingMode()) {
/* 428 */       offlineLookup = new ArrayList<>(0);
/*     */     } else {
/*     */       
/* 431 */       offlineLookup = descriptor.getOfflineLookupLocations();
/*     */     } 
/*     */     
/* 434 */     for (DataSourceLocationConfig dataSource : offlineLookup) {
/* 435 */       msg.append(dataSource.getDataSourceName() + ": ");
/*     */ 
/*     */       
/* 438 */       if (!DataSourceFactory.getInstance().getDataSourceDescriptor(dataSource.getDataSourceName()).isEnabled()) {
/*     */         
/* 440 */         msg.append("Disabled\n");
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 446 */       if (PersistenceManagerStatus.ONLINE == StatusMgr.getInstance()
/* 447 */         .getDataSourceStatus(dataSource.getDataSourceName())) {
/*     */         
/* 449 */         msg.append("Online\n");
/*     */         continue;
/*     */       } 
/* 452 */       msg.append("Offline\n");
/*     */     } 
/*     */     
/* 455 */     msg.append("Online Persistence Locations\n");
/*     */ 
/*     */ 
/*     */     
/* 459 */     if (isTrainingMode()) {
/* 460 */       onlinePersistence = descriptor.getTrainingPersistenceLocations();
/*     */     } else {
/*     */       
/* 463 */       onlinePersistence = descriptor.getOnlinePersistenceLocations();
/*     */     } 
/*     */     
/* 466 */     for (DataSourceLocationConfig dataSource : onlinePersistence) {
/* 467 */       msg.append(dataSource.getDataSourceName() + ": ");
/*     */ 
/*     */       
/* 470 */       if (!DataSourceFactory.getInstance().getDataSourceDescriptor(dataSource.getDataSourceName()).isEnabled()) {
/*     */         
/* 472 */         msg.append("Disabled\n");
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 478 */       if (PersistenceManagerStatus.ONLINE == StatusMgr.getInstance()
/* 479 */         .getDataSourceStatus(dataSource.getDataSourceName())) {
/*     */         
/* 481 */         msg.append("Online\n");
/*     */         continue;
/*     */       } 
/* 484 */       msg.append("Offline\n");
/*     */     } 
/*     */     
/* 487 */     msg.append("Offline Persistence Locations\n");
/*     */ 
/*     */ 
/*     */     
/* 491 */     if (isTrainingMode()) {
/* 492 */       offlinePersistence = new ArrayList<>(0);
/*     */     } else {
/*     */       
/* 495 */       offlinePersistence = descriptor.getOfflinePersistenceLocations();
/*     */     } 
/*     */     
/* 498 */     for (DataSourceLocationConfig dataSource : offlinePersistence) {
/* 499 */       msg.append(dataSource.getDataSourceName() + ": ");
/*     */ 
/*     */       
/* 502 */       if (!DataSourceFactory.getInstance().getDataSourceDescriptor(dataSource.getDataSourceName()).isEnabled()) {
/*     */         
/* 504 */         msg.append("Disabled\n");
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 510 */       if (PersistenceManagerStatus.ONLINE == StatusMgr.getInstance()
/* 511 */         .getDataSourceStatus(dataSource.getDataSourceName())) {
/*     */         
/* 513 */         msg.append("Online\n");
/*     */         continue;
/*     */       } 
/* 516 */       msg.append("Offline\n");
/*     */     } 
/*     */     
/* 519 */     logger_.warn(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<PmStrategyInfo> getPrioritizedStratgies(IPersistenceMgrType argPmType, boolean argLookup, boolean argOnline) {
/* 536 */     PersistenceMgrTypeDescriptor descriptor = this._persistenceMgrTypeFactory.getPersistenceMgrTypeDescriptor(argPmType);
/* 537 */     List<DataSourceLocationConfig> locations = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 542 */     if (!isTrainingMode()) {
/* 543 */       if (argOnline) {
/* 544 */         if (argLookup) {
/* 545 */           locations = descriptor.getOnlineLookupLocations();
/*     */         } else {
/*     */           
/* 548 */           locations = descriptor.getOnlinePersistenceLocations();
/*     */         }
/*     */       
/*     */       }
/* 552 */       else if (argLookup) {
/* 553 */         locations = descriptor.getOfflineLookupLocations();
/*     */       } else {
/*     */         
/* 556 */         locations = descriptor.getOfflinePersistenceLocations();
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 567 */       if (!argOnline) {
/* 568 */         return new ArrayList<>(0);
/*     */       }
/*     */       
/* 571 */       if (argLookup) {
/* 572 */         locations = descriptor.getTrainingLookupLocations();
/*     */       } else {
/*     */         
/* 575 */         locations = descriptor.getTrainingPersistenceLocations();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 582 */     List<PmStrategyInfo> strategies = new ArrayList<>(locations.size());
/* 583 */     List<String> alreadyAdded = new ArrayList<>(locations.size());
/*     */     
/* 585 */     for (DataSourceLocationConfig dataSourceLocation : locations) {
/* 586 */       String dataSourceName = dataSourceLocation.getDataSourceName();
/*     */       
/* 588 */       if (DataSourceFactory.isDataSourceEnabled(dataSourceName))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 593 */         if (!alreadyAdded.contains(dataSourceName)) {
/*     */           
/* 595 */           DataSourceDescriptor dataSource = DataSourceFactory.getInstance().getDataSourceDescriptor(dataSourceName);
/* 596 */           IPersistenceStrategy strategy = this._persistenceStrategyFactory.createStrategy(dataSource, argOnline);
/*     */           
/* 598 */           if (strategy instanceof AbstractPersistenceStrategy) {
/* 599 */             ((AbstractPersistenceStrategy)strategy).setCurrentPmType(argPmType);
/*     */           }
/*     */           
/* 602 */           strategies.add(new PmStrategyInfo(strategy, StatusMgr.getInstance().isOnline(dataSourceName)));
/* 603 */           alreadyAdded.add(dataSourceName);
/*     */         } 
/*     */       }
/*     */     } 
/* 607 */     return strategies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isTrainingMode() {
/* 617 */     return this._persistenceDefaults.isTraining();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PmTypeHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */