/*     */ package dtv.data2.access.config.query;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.IHasSourceDescription;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryDescriptor
/*     */   implements IHasSourceDescription
/*     */ {
/*  21 */   private static final String[] NO_RESULT_FIELDS = new String[0];
/*     */ 
/*     */   
/*     */   private final String name_;
/*     */ 
/*     */   
/*     */   private final Properties props_;
/*     */ 
/*     */   
/*     */   private final Class<?> queryHandler_;
/*     */   
/*     */   private final String[] resultFields_;
/*     */   
/*     */   private final String[] resultFieldTypes_;
/*     */   
/*     */   private final String sourceDescription_;
/*     */   
/*     */   private Class<?> resultClass_;
/*     */   
/*     */   private String resultClassName_;
/*     */   
/*     */   private String _resultFilterName;
/*     */ 
/*     */   
/*     */   public QueryDescriptor(String argName, Class<?> argQueryHandler, Class<?> argResultClass, String[] argResultFields, Properties argProps, String argSourceDescription) {
/*  46 */     this(argName, argQueryHandler, argResultClass, argResultFields, (String[])null, argProps, argSourceDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryDescriptor(String argName, Class<?> argQueryHandler, Class<?> argResultClass, String[] argResultFields, String[] argResultFieldTypes, Properties argProps, String argSourceDescription) {
/*  64 */     this.name_ = argName;
/*  65 */     this.queryHandler_ = argQueryHandler;
/*  66 */     this.resultClass_ = argResultClass;
/*  67 */     this.resultFields_ = argResultFields;
/*  68 */     this.resultFieldTypes_ = argResultFieldTypes;
/*  69 */     this.props_ = argProps;
/*  70 */     this.sourceDescription_ = argSourceDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryDescriptor(String argName, Class<?> argQueryHandler, String argResultClassName, String[] argResultFields, Properties argProps, String argSourceDescription) {
/*  85 */     this(argName, argQueryHandler, argResultClassName, argResultFields, (String[])null, argProps, argSourceDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryDescriptor(String argName, Class<?> argQueryHandler, String argResultClassName, String[] argResultFields, String[] argResultFieldTypes, Properties argProps, String argSourceDescription) {
/* 103 */     this.name_ = argName;
/* 104 */     this.queryHandler_ = argQueryHandler;
/* 105 */     this.resultClassName_ = argResultClassName;
/* 106 */     this.resultFields_ = argResultFields;
/* 107 */     this.resultFieldTypes_ = argResultFieldTypes;
/* 108 */     this.props_ = argProps;
/* 109 */     this.sourceDescription_ = argSourceDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 117 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getProperties() {
/* 125 */     return this.props_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getQueryHandler() {
/* 133 */     return this.queryHandler_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getResultClass() {
/* 141 */     if (this.resultClass_ == null && 
/* 142 */       !StringUtils.isEmpty(this.resultClassName_)) {
/*     */       
/*     */       try {
/* 145 */         this.resultClass_ = Thread.currentThread().getContextClassLoader().loadClass(this.resultClassName_);
/*     */       }
/* 147 */       catch (Exception ex) {
/*     */         
/*     */         try {
/* 150 */           this.resultClass_ = getClass().getClassLoader().loadClass(this.resultClassName_);
/*     */         }
/* 152 */         catch (ClassNotFoundException ex2) {
/* 153 */           throw new DtxException("Unabled to load result class specified in QueryConfig: " + this.resultClassName_, ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 159 */     return this.resultClass_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getResultFields() {
/* 167 */     return (this.resultFields_ == null) ? NO_RESULT_FIELDS : this.resultFields_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getResultFieldTypes() {
/* 175 */     return (this.resultFieldTypes_ == null) ? NO_RESULT_FIELDS : this.resultFieldTypes_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResultFilter() {
/* 184 */     return this._resultFilterName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceDescription() {
/* 190 */     return this.sourceDescription_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultFilter(String argResultFilterName) {
/* 199 */     this._resultFilterName = argResultFilterName;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\query\QueryDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */