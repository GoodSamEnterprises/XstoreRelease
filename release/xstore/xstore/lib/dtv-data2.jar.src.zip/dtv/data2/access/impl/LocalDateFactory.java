/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.util.DtvDate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalDateFactory
/*    */   extends DaoDateFactory
/*    */ {
/*    */   public DtvDate newDate() {
/* 20 */     return new DtvDate();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\LocalDateFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */