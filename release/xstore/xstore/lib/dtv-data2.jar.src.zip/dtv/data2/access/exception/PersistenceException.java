/*    */ package dtv.data2.access.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistenceException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 742070005867398656L;
/*    */   
/*    */   public PersistenceException() {}
/*    */   
/*    */   public PersistenceException(String argMessage) {
/* 31 */     super(argMessage);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PersistenceException(String argMessage, Throwable argCause) {
/* 41 */     super(argMessage, argCause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PersistenceException(Throwable argCause) {
/* 51 */     super(argCause.getMessage(), argCause);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\exception\PersistenceException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */