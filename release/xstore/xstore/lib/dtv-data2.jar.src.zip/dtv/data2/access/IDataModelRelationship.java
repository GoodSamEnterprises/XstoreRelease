/*    */ package dtv.data2.access;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IDataModelRelationship
/*    */ {
/*    */   Class<? extends Object> getChild();
/*    */   
/*    */   String getIdentifier();
/*    */   
/*    */   IDataModel getParent();
/*    */   
/*    */   RelationshipType getType();
/*    */   
/*    */   boolean isPropertyRelationship();
/*    */   
/*    */   boolean isTransientRelationship();
/*    */   
/*    */   boolean isUseParentPm();
/*    */   
/*    */   void setParent(IDataModel paramIDataModel);
/*    */   
/*    */   public enum RelationshipType
/*    */   {
/* 75 */     MANY_TO_MANY("MANY-MANY"),
/*    */     
/* 77 */     ONE_TO_MANY("ONE-MANY"),
/*    */     
/* 79 */     ONE_TO_ONE("ONE-ONE");
/*    */     private final String toString_;
/*    */     
/*    */     RelationshipType(String s) {
/* 83 */       this.toString_ = s;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String toString() {
/* 89 */       return this.toString_;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\IDataModelRelationship.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */