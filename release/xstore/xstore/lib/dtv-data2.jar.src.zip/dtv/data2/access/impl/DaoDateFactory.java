/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.util.DtvDate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DaoDateFactory
/*    */ {
/* 17 */   public static final String SYSTEM_PROPERTY = DaoDateFactory.class.getName();
/*    */   
/*    */   private static DaoDateFactory INSTANCE;
/*    */ 
/*    */   
/*    */   static {
/* 23 */     String className = System.getProperty(SYSTEM_PROPERTY);
/*    */     
/*    */     try {
/* 26 */       instance = (DaoDateFactory)Class.forName(className).newInstance();
/*    */     }
/* 28 */     catch (Throwable ex) {
/* 29 */       instance = new GmtDateFactory();
/*    */     } 
/* 31 */     INSTANCE = instance;
/*    */   }
/*    */   
/*    */   static {
/*    */     DaoDateFactory instance;
/*    */   }
/*    */   
/*    */   public abstract DtvDate newDate();
/*    */   
/*    */   public static DaoDateFactory getInstance() {
/* 41 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\DaoDateFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */