/*     */ package dtv.data2.access.impl;
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IGenericQueryResult;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.ModelEventor;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.event.EventHandler;
/*     */ import dtv.event.EventManager;
/*     */ import dtv.event.Eventor;
/*     */ import dtv.event.handler.CascadingHandler;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public abstract class AbstractBaseDataModelImpl implements IDataModelImpl, IGenericQueryResult {
/*  28 */   protected static final Logger _logger = Logger.getLogger(AbstractBaseDataModelImpl.class);
/*     */   
/*     */   private static final long serialVersionUID = 418385730493988677L;
/*     */   
/*     */   protected transient Eventor _events;
/*     */   
/*     */   protected transient EventHandler _eventCascade;
/*     */   
/*     */   protected IDataAccessObject _daoImpl;
/*     */   
/*     */   protected transient IDataAccessObject _daoSavepoint;
/*     */   
/*     */   private final Map<Object, Object> _genericProperties;
/*     */ 
/*     */   
/*     */   protected static IDataAccessObject getOrthogonalDAO(AbstractBaseDataModelImpl model) {
/*  44 */     return model._daoImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private Set<IDataModel> _deletedObjectBag = null;
/*     */ 
/*     */   
/*     */   private boolean _rolledBack = false;
/*     */ 
/*     */   
/*     */   protected transient IPersistenceDefaults _persistenceDefaults;
/*     */ 
/*     */   
/*     */   protected transient EventManager _eventManager;
/*     */ 
/*     */   
/*     */   private transient boolean _postEventsForChanges = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractBaseDataModelImpl() {
/*  77 */     initDAO();
/*  78 */     this._genericProperties = new HashMap<>();
/*  79 */     initializePostEventForChanges();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitTransaction() {
/*  85 */     this._rolledBack = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object argKey) {
/*  91 */     return this._genericProperties.containsKey(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void externalizeToXml(StringBuilder argBuffer) {
/* 101 */     Stack<String> callStack = new Stack<>();
/* 102 */     callStack.push(getClass().getName());
/* 103 */     externalizeToXml(argBuffer, (Class)getClass(), callStack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object argKey) {
/* 109 */     return this._genericProperties.get(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<IDataModel> getAndClearDeletedObjects() {
/* 115 */     Set<IDataModel> returnVal = this._deletedObjectBag;
/* 116 */     this._deletedObjectBag = null;
/* 117 */     return returnVal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IDataAccessObject getDAO() {
/* 123 */     return this._daoImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSource() {
/* 129 */     return this._daoImpl.getOriginDataSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IObjectId getModelId() {
/* 138 */     return getObjectId();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IObjectId getObjectId() {
/* 144 */     return this._daoImpl.getObjectId();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getObjectIdAsString() {
/* 150 */     return (getObjectId() == null) ? null : getObjectId().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getThis() {
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(String argFieldId) throws IllegalArgumentException {
/* 164 */     if (StringUtils.isEmpty(argFieldId)) {
/* 165 */       throw new IllegalArgumentException("getValue cannot accept NULL or empty argFieldId! Model: " + 
/* 166 */           getClass().getName());
/*     */     }
/*     */     
/* 169 */     throw new IllegalArgumentException("Model: " + 
/* 170 */         getClass().getName() + " cannot handle field: " + argFieldId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValueSafe(String argFieldId) {
/*     */     try {
/* 178 */       return getValue(argFieldId);
/*     */     }
/* 180 */     catch (Exception ex) {
/* 181 */       _logger.debug("CAUGHT EXCEPTION", ex);
/*     */       
/*     */       try {
/* 184 */         return getClass().getMethod("get" + argFieldId, new Class[0]).invoke(this, new Object[0]);
/*     */       }
/* 186 */       catch (Exception exception) {
/* 187 */         _logger.debug("CAUGHT EXCEPTION", exception);
/*     */         
/* 189 */         return null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAlreadyRolledBack() {
/* 200 */     return this._rolledBack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNew() {
/* 206 */     return DaoState.isNew(this._daoImpl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Object> iterator() {
/* 212 */     return this._genericProperties.keySet().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Object argKey, Object argValue) {
/* 218 */     this._genericProperties.put(argKey, argValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollbackChanges() {
/* 224 */     if (this._daoSavepoint == null) {
/* 225 */       throw new DtxException("Cannot perform rollbackChanges - daoSavepoint_ is NULL.  Call startTransaction() first");
/*     */     }
/*     */     
/* 228 */     this._daoImpl = this._daoSavepoint;
/* 229 */     this._daoSavepoint = null;
/* 230 */     this._rolledBack = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDAO(IDataAccessObject argDAO) {
/* 236 */     this._daoImpl = argDAO;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(String argDataSource) {
/* 242 */     this._daoImpl.setOriginDataSource(argDataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDependencies(IPersistenceDefaults argPD, EventManager argEM) {
/* 248 */     this._persistenceDefaults = argPD;
/* 249 */     this._daoImpl.setPersistenceDefaults(argPD);
/* 250 */     this._eventManager = argEM;
/* 251 */     this._events = (Eventor)new ModelEventor(this, argEM);
/* 252 */     this._eventCascade = (EventHandler)new CascadingHandler(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectId(IObjectId argId) {
/* 258 */     this._daoImpl.setObjectId(argId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String argFieldId, Object argValue) {
/* 264 */     if (StringUtils.isEmpty(argFieldId)) {
/* 265 */       throw new IllegalArgumentException("setValue cannot accept NULL or empty argFieldId! Model: " + 
/* 266 */           getClass().getName());
/*     */     }
/*     */     
/* 269 */     throw new IllegalArgumentException("Model: " + 
/* 270 */         getClass().getName() + " cannot handle field: " + argFieldId + " value: " + argValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startTransaction() {
/*     */     try {
/* 278 */       this._daoSavepoint = (IDataAccessObject)this._daoImpl.clone();
/*     */     }
/* 280 */     catch (CloneNotSupportedException ee) {
/* 281 */       throw new DtxException("An unexpected error occurred while cloning " + this._daoImpl, ee);
/*     */     } 
/*     */     
/* 284 */     if (this._daoSavepoint == null) {
/* 285 */       throw new DtxException("An unexpected error occurred while cloning " + this._daoImpl + " result object is null");
/*     */     }
/*     */     
/* 288 */     this._rolledBack = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toXmlString() {
/* 294 */     throw new DtxException("toXmlString is not implemented for IDataModel.  This should be implemented, though, and it should replace the externalizeToXml methods.  Also, this should not implement IPersistable in the future.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addDeletedObject(IDataModel argObjectToDelete) {
/* 305 */     if (argObjectToDelete == null) {
/* 306 */       throw new DtxException("invalid call made to addDeletedObject() -- argObjectToDelete was null.");
/*     */     }
/* 308 */     IDataAccessObject dao = ((IDataModelImpl)argObjectToDelete).getDAO();
/*     */     
/* 310 */     if (DaoState.isNew(dao)) {
/*     */       return;
/*     */     }
/*     */     
/* 314 */     if (this._deletedObjectBag == null) {
/* 315 */       this._deletedObjectBag = new HashSet<>(4);
/*     */     }
/*     */     
/* 318 */     if (!this._deletedObjectBag.contains(argObjectToDelete)) {
/* 319 */       dao.setObjectState(DaoState.DELETED.intVal());
/* 320 */       this._deletedObjectBag.add(argObjectToDelete);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> List<T> changeToList(Object unchecked, Class<T> cls) {
/* 335 */     return Collections.checkedList((List<T>)unchecked, cls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPersistenceDefaults getPersistenceDefaults() {
/* 344 */     return this._persistenceDefaults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void initDAO();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean postEventsForChanges() {
/* 358 */     return this._postEventsForChanges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeDeletedObject(IDataModelImpl argObjectToRemove) {
/* 367 */     if (argObjectToRemove == null) {
/* 368 */       throw new DtxException("invalid call made to removeDeletedObject() -- argObjectToRemove was null.");
/*     */     }
/*     */     
/* 371 */     if (this._deletedObjectBag != null) {
/* 372 */       this._deletedObjectBag.remove(argObjectToRemove);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void externalizeToXml(StringBuilder argBuffer, Class<? extends AbstractBaseDataModelImpl> argClass, Stack<String> argCallStack) {
/* 379 */     if (argClass == AbstractBaseDataModelImpl.class) {
/*     */       return;
/*     */     }
/* 382 */     String className = argClass.getName();
/*     */     
/* 384 */     argBuffer.append("<");
/* 385 */     argBuffer.append(className);
/* 386 */     argBuffer.append(">");
/*     */     
/* 388 */     Field[] fields = argClass.getDeclaredFields();
/*     */     
/* 390 */     if (fields != null) {
/* 391 */       Object value = null;
/*     */       
/* 393 */       for (Field element : fields) {
/* 394 */         element.setAccessible(true);
/*     */         
/* 396 */         argBuffer.append("<");
/*     */         
/* 398 */         argBuffer.append(element.getName());
/* 399 */         argBuffer.append(">");
/*     */         
/*     */         try {
/* 402 */           value = element.get(this);
/*     */         }
/* 404 */         catch (IllegalArgumentException e) {
/* 405 */           _logger.warn("Illegal Argument", e);
/* 406 */           value = "IllegalArgumentException";
/*     */         }
/* 408 */         catch (IllegalAccessException e) {
/* 409 */           _logger.warn("Field " + element.getName() + " is not accessible.", e);
/* 410 */           value = "IllegalAccessException";
/*     */         } 
/*     */         
/* 413 */         if (value == null) {
/* 414 */           value = "null";
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 419 */         if (value instanceof AbstractBaseDataModelImpl && 
/* 420 */           !argCallStack.contains(value.getClass().getName())) {
/* 421 */           ((AbstractBaseDataModelImpl)value).externalizeToXml(argBuffer, argCallStack);
/*     */         }
/* 423 */         else if (value instanceof AbstractDAOImpl) {
/* 424 */           argBuffer.append(((AbstractDAOImpl)value).toXmlString());
/*     */         }
/* 426 */         else if (value instanceof Collection) {
/* 427 */           int counter = 0;
/*     */ 
/*     */           
/* 430 */           for (Iterator<?> it = ((Collection)value).iterator(); it.hasNext(); ) {
/* 431 */             argBuffer.append("<");
/* 432 */             argBuffer.append("CollectionValue");
/* 433 */             argBuffer.append(counter);
/* 434 */             argBuffer.append(">");
/*     */             
/* 436 */             Object target = it.next();
/* 437 */             if (target == null) {
/* 438 */               target = "null";
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 443 */             if (target instanceof AbstractBaseDataModelImpl && 
/* 444 */               !argCallStack.contains(target.getClass().getName())) {
/* 445 */               ((AbstractBaseDataModelImpl)target).externalizeToXml(argBuffer, argCallStack);
/*     */             }
/* 447 */             if (value instanceof AbstractDAOImpl) {
/* 448 */               argBuffer.append(((AbstractDAOImpl)value).toXmlString());
/*     */             } else {
/*     */               
/* 451 */               argBuffer.append("![CDATA[");
/* 452 */               argBuffer.append(target.toString());
/* 453 */               argBuffer.append("]]");
/*     */             } 
/*     */             
/* 456 */             argBuffer.append("</");
/* 457 */             argBuffer.append("CollectionValue");
/* 458 */             argBuffer.append(counter);
/* 459 */             argBuffer.append(">");
/*     */             
/* 461 */             counter++;
/*     */           } 
/*     */         } else {
/*     */           
/* 465 */           argBuffer.append("![CDATA[");
/* 466 */           argBuffer.append(value.toString());
/* 467 */           argBuffer.append("]]");
/*     */         } 
/*     */         
/* 470 */         argBuffer.append("</");
/* 471 */         argBuffer.append(element.getName());
/* 472 */         argBuffer.append(">");
/*     */       } 
/*     */     } 
/*     */     
/* 476 */     argBuffer.append("</");
/* 477 */     argBuffer.append(className);
/* 478 */     argBuffer.append(">");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void externalizeToXml(StringBuilder argBuffer, Stack<String> argCallStack) {
/* 485 */     argCallStack.push(getClass().getName());
/* 486 */     externalizeToXml(argBuffer, (Class)getClass(), argCallStack);
/* 487 */     argCallStack.pop();
/*     */   }
/*     */   
/*     */   private void initializePostEventForChanges() {
/* 491 */     this._postEventsForChanges = Boolean.getBoolean("dtv.data2.access.DataModel.enableEventPostingForChanges");
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream argStream) throws IOException, ClassNotFoundException {
/* 496 */     argStream.defaultReadObject();
/* 497 */     initializePostEventForChanges();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractBaseDataModelImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */