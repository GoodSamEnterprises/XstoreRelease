/*     */ package dtv.data2.access.impl.config;
/*     */ 
/*     */ import dtv.data2.access.pm.PmTypeDeterminationException;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.ConfigHelper;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PmTypeMappingConfigHelper
/*     */   extends ConfigHelper<PmTypeMappingSetConfig>
/*     */ {
/*     */   private static final int ESTIMATED_DAO_COUNT = 250;
/*     */   private Map<String, PmTypeMappingConfig> idClassMap_;
/*     */   
/*     */   public String getPMType(String argObjectIdClass) {
/*  33 */     if (StringUtils.isEmpty(argObjectIdClass)) {
/*  34 */       throw new PmTypeDeterminationException("argObjectIdClass was null or empty.  A value is required.");
/*     */     }
/*     */     
/*  37 */     PmTypeMappingConfig dmConfig = this.idClassMap_.get(argObjectIdClass);
/*     */     
/*  39 */     if (dmConfig == null) {
/*  40 */       throw new PmTypeDeterminationException("Unable to load PmTypeMapping config for id: " + argObjectIdClass + " -- make sure PmTypeMappingConfig was initialized properlyand contains a mapping for this class name.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  45 */     return dmConfig.getPmType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void hashRootConfigs() {
/*  51 */     super.hashRootConfigs();
/*     */     
/*  53 */     this.idClassMap_ = new HashMap<>(250);
/*     */     
/*  55 */     Collection<PmTypeMappingConfig> dms = getRootChildren(PmTypeMappingSetConfig.class);
/*  56 */     if (dms != null) {
/*  57 */       for (PmTypeMappingConfig dm : dms) {
/*  58 */         this.idClassMap_.put(dm.getIdClass(), dm);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isPMTypeLoadPropertiesEnabled(String argObjectIdClass) {
/*  70 */     if (StringUtils.isEmpty(argObjectIdClass)) {
/*  71 */       throw new PmTypeDeterminationException("argObjectIdClass was null or empty.  A value is required.");
/*     */     }
/*     */     
/*  74 */     PmTypeMappingConfig dmConfig = this.idClassMap_.get(argObjectIdClass);
/*     */     
/*  76 */     if (dmConfig == null) {
/*  77 */       throw new PmTypeDeterminationException("Unable to load PmTypeMapping config for id: " + argObjectIdClass + " -- make sure PmTypeMappingConfig was initialized properlyand contains a mapping for this class name.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  82 */     return dmConfig.isLoadPropertiesEnabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getConfigFileName() {
/*  91 */     return "PmTypeMappingConfig";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IConfigObject getConfigObject(String argTagName, String dtype, String argSourceDescription) {
/*  97 */     if ("PmTypeMappingSet".equalsIgnoreCase(dtype)) {
/*  98 */       return (IConfigObject)new PmTypeMappingSetConfig();
/*     */     }
/* 100 */     if ("PmTypeMapping".equalsIgnoreCase(dtype)) {
/* 101 */       return (IConfigObject)new PmTypeMappingConfig();
/*     */     }
/* 103 */     return super.getConfigObject(argTagName, dtype, argSourceDescription);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\config\PmTypeMappingConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */