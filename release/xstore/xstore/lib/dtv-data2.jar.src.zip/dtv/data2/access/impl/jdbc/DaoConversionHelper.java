/*    */ package dtv.data2.access.impl.jdbc;
/*    */ 
/*    */ import dtv.data2.access.IDataAccessObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class DaoConversionHelper
/*    */ {
/*    */   public static boolean isDaoConvertOnPkViolation(IDataAccessObject argDao) {
/* 24 */     return false;
/*    */   }
/*    */   
/*    */   private DaoConversionHelper() {
/* 28 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\DaoConversionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */