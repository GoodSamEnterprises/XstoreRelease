/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.AbstractPersistenceRule;
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.query.QueryResourceManager;
/*     */ import dtv.data2.access.query.QueryToken;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManageDataInTwoPlacesRule
/*     */   extends AbstractPersistenceRule
/*     */ {
/*  33 */   private static final Logger _logger = Logger.getLogger(ManageDataInTwoPlacesRule.class);
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */ 
/*     */   
/*     */   public ManageDataInTwoPlacesRule() {
/*  45 */     super(false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistable applyRule(PersistableMetaData argPersistableMetaData, Object argObject) {
/*  51 */     IPersistable persistable = argPersistableMetaData.getPersistable();
/*  52 */     IDataAccessObject dao = (IDataAccessObject)persistable;
/*     */     
/*  54 */     int currentSourceIndex = argPersistableMetaData.getDataSourcesVisited().size() - 1;
/*  55 */     String currentDataSource = argPersistableMetaData.getDataSourcesVisited().get(currentSourceIndex);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     if (!dao.isObjectStateRulesApplied() && !DaoState.isDeleted(dao) && 
/*  68 */       !StringUtils.equalsIgnoreCase(dao.getOriginDataSource(), currentDataSource))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  86 */       if (!DaoState.INSERT_OR_UPDATE.matches(dao)) {
/*  87 */         dao = DaoUtils.cloneDao(dao);
/*  88 */         dao.setPersistenceDefaults(this._persistenceDefaults);
/*  89 */         dao.setObjectState(DaoState.INSERT_OR_UPDATE.intVal());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (DaoState.INSERT_ONLY.matches(dao)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       DataSourceDescriptor dataSource = DataSourceFactory.getInstance().getDataSourceDescriptor(currentDataSource);
/* 102 */       IPersistenceStrategy strategy = this._persistenceStrategyFactory.createStrategy(dataSource, true);
/*     */       
/* 104 */       IDataModel result = null;
/*     */       
/* 106 */       QueryToken token = new QueryToken(dao.getObjectId(), getPMTypeByObjectId(dao.getObjectId().getClass()));
/*     */       try {
/* 108 */         result = strategy.getObjectById(dao.getObjectId(), token);
/*     */       }
/* 110 */       catch (Exception ex) {
/* 111 */         _logger.error("CAUGHT EXCEPTION", ex);
/*     */       } finally {
/*     */         
/* 114 */         QueryResourceManager.getInstance().closeQueryResources(token);
/*     */       } 
/* 116 */       dao = DaoUtils.cloneDao(dao);
/*     */       
/* 118 */       if (result == null) {
/* 119 */         dao.setObjectState(DaoState.NEW.intVal());
/* 120 */         dao.setObjectStateRulesApplied(true);
/*     */       } else {
/*     */         
/* 123 */         dao.setObjectState(DaoState.CLEAN.intVal());
/* 124 */         dao.setObjectStateRulesApplied(true);
/*     */       } 
/*     */     } 
/* 127 */     return (IPersistable)dao;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isApplicable(PersistableMetaData argPersistableMetaData, Object argObject) {
/* 133 */     return argPersistableMetaData.getPersistable() instanceof IDataAccessObject;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\ManageDataInTwoPlacesRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */