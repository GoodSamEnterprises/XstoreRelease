/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.util.crypto.DtvDecrypter;
/*    */ import dtv.util.crypto.DtvEncrypter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataModelImpl
/*    */   extends AbstractBaseDataModelImpl
/*    */ {
/*    */   private static final long serialVersionUID = 418385730493988677L;
/*    */   
/*    */   protected final String decryptField(String argEncryptionService, String value) {
/* 28 */     if (value == null) {
/* 29 */       return null;
/*    */     }
/* 31 */     return DtvDecrypter.getInstance(argEncryptionService).decryptIfEncrypted(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final String encryptField(String argEncryptionService, String value) {
/* 42 */     if (value == null) {
/* 43 */       return null;
/*    */     }
/* 45 */     return DtvEncrypter.getInstance(argEncryptionService).encrypt(value);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractDataModelImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */