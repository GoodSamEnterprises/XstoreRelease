/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.DataPropertyUtils;
/*     */ import dtv.data2.access.IDataProperty;
/*     */ import dtv.util.NumberUtils;
/*     */ import dtv.util.ObjectUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataModelPropertiesImpl
/*     */   extends AbstractDataModelImpl
/*     */   implements IDataProperty
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public boolean getBooleanValue(boolean argDefault) {
/*  31 */     BigDecimal value = getDecimalValue();
/*  32 */     return (value == null) ? argDefault : (!NumberUtils.isZero(value));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPropertyValue() {
/*  38 */     Object propertyValue = null;
/*  39 */     String valueType = getType();
/*     */     
/*  41 */     if (valueType == null) {
/*     */       
/*  43 */       propertyValue = ObjectUtils.coalesce((Object[])new Serializable[] { getStringValue(), getDecimalValue(), getDateValue() });
/*     */     }
/*  45 */     else if ("BOOLEAN".equalsIgnoreCase(valueType)) {
/*  46 */       propertyValue = Boolean.valueOf(getBooleanValue(false));
/*     */     }
/*  48 */     else if ("DATE".equalsIgnoreCase(valueType)) {
/*  49 */       propertyValue = getDateValue();
/*     */     }
/*  51 */     else if ("BIGDECIMAL".equalsIgnoreCase(valueType)) {
/*  52 */       propertyValue = getDecimalValue();
/*     */     }
/*  54 */     else if ("STRING".equalsIgnoreCase(valueType)) {
/*  55 */       propertyValue = getStringValue();
/*     */     } else {
/*     */       
/*  58 */       _logger.warn("Unknown property type [" + valueType + "] assigned to model [" + this + "]!");
/*     */     } 
/*  60 */     return propertyValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBooleanValue(boolean argValue) {
/*  66 */     setDecimalValue(argValue ? BigDecimal.ONE : BigDecimal.ZERO);
/*  67 */     setType("BOOLEAN");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyValue(Object argValue) {
/*  73 */     String valueType = getPropertyValueType(argValue);
/*     */     
/*  75 */     if ("BOOLEAN".equalsIgnoreCase(valueType)) {
/*  76 */       setBooleanValue(((Boolean)argValue).booleanValue());
/*     */     }
/*  78 */     else if ("DATE".equalsIgnoreCase(valueType)) {
/*  79 */       setDateValue((Date)argValue);
/*     */     }
/*  81 */     else if ("BIGDECIMAL".equalsIgnoreCase(valueType)) {
/*  82 */       setDecimalValue((BigDecimal)argValue);
/*     */     }
/*  84 */     else if ("STRING".equalsIgnoreCase(valueType)) {
/*  85 */       setStringValue((String)argValue);
/*     */     }
/*  87 */     else if (argValue != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       _logger.warn("Unknown property type [" + valueType + "] assigned to model [" + this + "].  Converting [" + argValue + "] to a string and assigning it as such,  though the calling client should be performing this conversion explicitly.");
/*     */ 
/*     */ 
/*     */       
/*  96 */       setStringValue(argValue.toString());
/*  97 */       valueType = "STRING";
/*     */     } 
/*  99 */     setType(valueType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPropertyValueType(Object argValue) {
/* 112 */     String valueType = null;
/*     */     
/* 114 */     if (argValue == null) {
/*     */ 
/*     */       
/* 117 */       valueType = getType();
/*     */       
/* 119 */       if (StringUtils.isEmpty(valueType)) {
/*     */         
/* 121 */         Object existingValue = getPropertyValue();
/* 122 */         valueType = DataPropertyUtils.getPropertyValueType(existingValue);
/*     */       } 
/*     */     } else {
/*     */       
/* 126 */       valueType = DataPropertyUtils.getPropertyValueType(argValue);
/*     */     } 
/* 128 */     return valueType;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractDataModelPropertiesImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */