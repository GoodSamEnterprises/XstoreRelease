/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.event.EventEnum;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateInterfaces
/*     */   implements Callable<Void>
/*     */ {
/*  28 */   private static final Logger logger_ = Logger.getLogger(GenerateInterfaces.class);
/*     */   
/*     */   private final DaoGenHelper helper_;
/*  31 */   private final String ee = EventEnum.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenerateInterfaces(DaoGenHelper argHelper) {
/*  39 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  47 */     logger_.info("Generating final interfaces");
/*  48 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/*  49 */       if (dtx.needsGeneration(null)) {
/*  50 */         StringBuilder w = new StringBuilder(5120);
/*     */         
/*  52 */         getInterfaceHeader(w, dtx);
/*  53 */         getInterfaceEventEnums(w, dtx);
/*  54 */         getInterfaceDaoMethods(w, dtx);
/*     */         
/*  56 */         if (!dtx.isProperties()) {
/*  57 */           getInterfaceExtensionMethods(w, dtx);
/*     */         }
/*     */         
/*  60 */         getInterfaceRelationshipMethods(w, dtx);
/*  61 */         getInterfaceTransactionMethods(w, dtx);
/*  62 */         getInterfaceFooter(w);
/*     */         
/*  64 */         String dir = this.helper_.getOutPath() + '/' + dtx.getInterfacePackage().replaceAll("\\.", "/") + '/';
/*  65 */         String fileName = dir + "I" + dtx.getName() + ".java";
/*  66 */         File f = new File(fileName);
/*  67 */         this.helper_.getWriter().write(f, w.toString());
/*     */       } 
/*     */     } 
/*  70 */     return null;
/*     */   }
/*     */   
/*     */   private void getEventEnum(StringBuilder out, String signame, String sigdesc) {
/*  74 */     out.append("  public static final ");
/*  75 */     out.append(this.ee);
/*  76 */     out.append(" ");
/*  77 */     out.append(signame);
/*  78 */     out.append(" = new ");
/*  79 */     out.append(this.ee);
/*  80 */     out.append("(\"");
/*  81 */     out.append(sigdesc);
/*  82 */     out.append("\");\n");
/*     */   }
/*     */   
/*     */   private void getInterfaceDaoMethods(StringBuilder out, DtxDefinition argDtx) {
/*  86 */     out.append("\n  // Methods related to DAO methods.  public void initDAO();\n  public void setDAO(");
/*     */ 
/*     */     
/*  89 */     out.append(IDataAccessObject.class.getName());
/*  90 */     out.append(" argDAO);\n");
/*     */     
/*  92 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/*  93 */       if (field.getExported()) {
/*     */ 
/*     */ 
/*     */         
/*  97 */         out.append("  /**\n   * Getter for ").append(field.getName()).append(".\n");
/*  98 */         String comment = field.getComment();
/*  99 */         if (comment != null && (comment = comment.trim()).length() > 0) {
/* 100 */           out.append("   * ").append(comment.replaceAll("\\n[\\t ]*", "\n   * ")).append('\n');
/*     */         }
/* 102 */         out.append("   * @return DAO alias for column ").append(field.getColumn());
/* 103 */         out.append("\n   */\n");
/* 104 */         out.append("  public ");
/* 105 */         out.append(DaoGenUtils.getVariableType(field.getType()));
/* 106 */         out.append(" ");
/* 107 */         out.append(DaoGenUtils.getGetterNameForField(field));
/* 108 */         out.append("();\n");
/* 109 */         out.append("  public void ");
/* 110 */         out.append(DaoGenUtils.getSetterNameForField(field));
/* 111 */         out.append("(");
/* 112 */         out.append(DaoGenUtils.getVariableType(field.getType()));
/* 113 */         out.append(" ");
/* 114 */         out.append(DaoGenUtils.getArgNameForField(field));
/* 115 */         out.append(");\n");
/*     */         
/* 117 */         if (!StringUtils.isEmpty(field.getEncrypt())) {
/* 118 */           if ("String".equalsIgnoreCase(field.getType())) {
/* 119 */             out.append("  public ");
/* 120 */             out.append(DaoGenUtils.getVariableType(field.getType()));
/* 121 */             out.append(" ");
/* 122 */             out.append(DaoGenUtils.getGetterNameForField(field)).append("Encrypted");
/* 123 */             out.append("();\n");
/*     */           } else {
/*     */             
/* 126 */             logger_.error("Configuration error: Non-string field [" + field.getName() + "] of [" + argDtx
/* 127 */                 .getName() + ".dtx] is marked with 'encrypt' attribute. Only 'String' type fields will support encryption");
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void getInterfaceEventEnums(StringBuilder out, DtxDefinition argDtx) {
/* 135 */     out.append("  // Events which may be posted by implementors of this model.\n");
/* 136 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/* 137 */       getEventEnum(out, "SET_" + field.getName().toUpperCase(), "set " + field.getName());
/*     */     }
/*     */     
/* 140 */     for (DtxRelationship rel : argDtx.getRelationships()) {
/* 141 */       String uc = rel.getName().toUpperCase();
/* 142 */       if (DtxRelationship.ONE_ONE.equalsIgnoreCase(rel.getType())) {
/* 143 */         getEventEnum(out, "SET_" + uc, "set " + rel.getName()); continue;
/*     */       } 
/* 145 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(rel.getType()) || DtxRelationship.MANY_MANY
/* 146 */         .equalsIgnoreCase(rel.getType())) {
/* 147 */         getEventEnum(out, "ADD_" + uc, "add " + rel.getName());
/* 148 */         getEventEnum(out, "REMOVE_" + uc, "remove " + rel.getName());
/* 149 */         getEventEnum(out, "SET_" + uc, "set " + rel.getName());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 154 */     getEventEnum(out, "START_TRANSACTION", "start transaction");
/* 155 */     getEventEnum(out, "ROLLBACK_TRANSACTION", "rollback transaction");
/* 156 */     getEventEnum(out, "COMMIT_TRANSACTION", "commit transaction");
/*     */ 
/*     */     
/* 159 */     out.append("\n");
/*     */   }
/*     */   
/*     */   private void getInterfaceExtensionMethods(StringBuilder out, DtxDefinition argDtx) {
/* 163 */     out.append("  /**\n");
/* 164 */     out.append("   * This method is used to get a customer extention object, if one is present.\n");
/* 165 */     out.append("   * @return IDataModel - this will either be null or a cust extention model.\n");
/* 166 */     out.append("   */\n");
/* 167 */     out.append("  public IDataModel get" + argDtx.getName() + "Ext();\n\n");
/*     */     
/* 169 */     out.append("  public void set" + argDtx.getName() + "Ext(IDataModel argExt);\n\n");
/*     */   }
/*     */   
/*     */   private void getInterfaceFooter(StringBuilder w) {
/* 173 */     w.append("}\n");
/*     */   }
/*     */   
/*     */   private void getInterfaceHeader(StringBuilder out, DtxDefinition argDtx) {
/* 177 */     out.append("package ");
/* 178 */     out.append(argDtx.getInterfacePackage());
/* 179 */     out.append(";\n\n");
/*     */     
/* 181 */     boolean hasConfigElementField = false;
/*     */ 
/*     */     
/* 184 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/* 185 */       if (field.getType() != null && field.getType().equals("Date")) {
/* 186 */         out.append("import java.util.Date;\n");
/*     */         
/*     */         break;
/*     */       } 
/* 190 */       if (DaoGenConfigElementHelper.isConfigElementField(field)) {
/* 191 */         hasConfigElementField = true;
/*     */       }
/*     */     } 
/*     */     
/* 195 */     out.append("import dtv.data2.access.IDataModel;\n");
/*     */     
/* 197 */     out.append("\n@SuppressWarnings(\"all\")");
/* 198 */     out.append("\npublic interface I");
/* 199 */     out.append(argDtx.getName());
/* 200 */     out.append(" extends IDataModel");
/*     */     
/* 202 */     if (hasConfigElementField) {
/* 203 */       out.append(", dtv.data2.access.IHasConfigElement");
/*     */     }
/*     */     
/* 206 */     if (argDtx.getImplements() != null) {
/* 207 */       out.append(", ");
/* 208 */       out.append(argDtx.getImplements());
/*     */     } 
/*     */     
/* 211 */     if (DaoGenHelper.isPropertyChildNeeded(argDtx)) {
/* 212 */       String propertyInterfaceName = DaoGenHelper.getPropertyInterfaceName(argDtx);
/*     */       
/* 214 */       out.append(", ");
/* 215 */       out.append("dtv.data2.access.IHasDataProperty<").append(propertyInterfaceName).append(">");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     if (argDtx.isProperties()) {
/* 236 */       out.append(", ");
/* 237 */       out.append("dtv.data2.access.IDataProperty");
/*     */     } 
/* 239 */     if (argDtx.isExtended()) {
/*     */       
/* 241 */       out.append(", ");
/* 242 */       out.append(argDtx.getExtends().getInterface());
/*     */     } 
/* 244 */     out.append(" {\n");
/*     */   }
/*     */   
/*     */   private void getInterfaceRelationshipMethods(StringBuilder out, DtxDefinition argDtx) {
/* 248 */     out.append("  // Methods related to data relationships\n");
/*     */     
/* 250 */     for (DtxRelationship rel : argDtx.getRelationships()) {
/*     */ 
/*     */       
/* 253 */       if (!rel.isExported()) {
/*     */         continue;
/*     */       }
/*     */       
/* 257 */       String argName = DaoGenUtils.getArgNameForRelationship(rel);
/* 258 */       String typeName = DaoGenUtils.getTypeForRelationship(rel, false);
/* 259 */       String getterName = DaoGenUtils.getGetterNameForRelationship(rel);
/* 260 */       String setterName = DaoGenUtils.getSetterNameForRelationship(rel);
/*     */ 
/*     */       
/* 263 */       out.append("  public ");
/* 264 */       out.append(typeName);
/* 265 */       out.append(" ");
/* 266 */       out.append(getterName);
/* 267 */       out.append("();\n");
/* 268 */       out.append("  public void ");
/* 269 */       out.append(setterName);
/* 270 */       out.append("(");
/* 271 */       out.append(typeName);
/* 272 */       out.append(" ");
/* 273 */       out.append(argName);
/* 274 */       out.append(");\n");
/*     */ 
/*     */       
/* 277 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(rel.getType()) || DtxRelationship.MANY_MANY
/* 278 */         .equalsIgnoreCase(rel.getType())) {
/* 279 */         String addRemoveArgName = DaoGenUtils.getArgNameForRelationshipAddRemove(rel);
/*     */         
/* 281 */         out.append("  public void ");
/* 282 */         out.append(DaoGenUtils.getAdderNameForRelationship(rel));
/* 283 */         out.append("(");
/* 284 */         out.append(rel.getChild().getInterface());
/* 285 */         out.append(" ");
/* 286 */         out.append(addRemoveArgName);
/* 287 */         out.append(");\n");
/* 288 */         out.append("  public void ");
/* 289 */         out.append(DaoGenUtils.getRemoverNameForRelationship(rel));
/* 290 */         out.append("(");
/* 291 */         out.append(rel.getChild().getInterface());
/* 292 */         out.append(" ");
/* 293 */         out.append(addRemoveArgName);
/* 294 */         out.append(");\n");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 302 */     for (DtxInverseRelationship inverseRelationship : argDtx.getInverseRelationships()) {
/*     */       
/* 304 */       out.append("  public void ");
/* 305 */       out.append(inverseRelationship.getSetMethodName());
/* 306 */       out.append("(");
/* 307 */       out.append(inverseRelationship.getParent().getInterface());
/* 308 */       out.append(" arg");
/* 309 */       out.append(StringUtils.ensureFirstUpperCase(inverseRelationship.getName()));
/* 310 */       out.append(");\n");
/*     */       
/* 312 */       out.append("  public ");
/* 313 */       out.append(inverseRelationship.getParent().getInterface());
/* 314 */       out.append(" ");
/* 315 */       out.append(inverseRelationship.getGetMethodName());
/* 316 */       out.append("();\n");
/*     */     } 
/*     */     
/* 319 */     out.append("\n");
/*     */   }
/*     */   
/*     */   private void getInterfaceTransactionMethods(StringBuilder out, DtxDefinition argDtx) {
/* 323 */     out.append("  // Methods required for transactions\n  public void startTransaction();\n  public void rollbackChanges();\n  public void commitTransaction();\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateInterfaces.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */