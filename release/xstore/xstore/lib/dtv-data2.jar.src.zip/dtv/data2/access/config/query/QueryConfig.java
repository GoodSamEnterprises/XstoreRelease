/*     */ package dtv.data2.access.config.query;
/*     */ 
/*     */ import dtv.data2.access.config.common.PropertyConfig;
/*     */ import dtv.data2.access.query.SqlQueryBuilder;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryConfig
/*     */   extends AbstractParentConfig
/*     */ {
/*  27 */   private static final Logger logger_ = Logger.getLogger(QueryConfig.class);
/*     */   
/*  29 */   private static final String SPACE_AS_HEX = Integer.toString(32, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private final Properties propertyConfigs_ = new Properties();
/*  47 */   private final List<ResultFieldConfig> resultFieldConfigs_ = new ArrayList<>();
/*  48 */   private final List<QueryStatementConfig> statementConfigs_ = new ArrayList<>();
/*  49 */   private final List<QuerySortConfig> sortConfigs_ = new ArrayList<>();
/*  50 */   private final List<QueryHavingConfig> havingConfigs_ = new ArrayList<>();
/*     */   private static final String COMMA_DELIMITER = ", ";
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String name_;
/*     */   private Class<Object> queryHandler_;
/*     */   private String resultClass_;
/*     */   private String _resultFilterName;
/*     */   
/*     */   public QueryDescriptor getQueryDescriptor() {
/*  59 */     String[] results = null;
/*  60 */     String[] resultTypes = null;
/*  61 */     ArrayList<String> resultDataTypes = null;
/*     */     
/*  63 */     adaptStatementConfig(this.statementConfigs_);
/*  64 */     adaptSortProperties(this.sortConfigs_);
/*  65 */     adaptHavingClauses(this.havingConfigs_);
/*     */     
/*  67 */     if (this.resultFieldConfigs_ != null && !this.resultFieldConfigs_.isEmpty()) {
/*  68 */       results = new String[this.resultFieldConfigs_.size()];
/*  69 */       resultDataTypes = new ArrayList<>();
/*  70 */       Collections.sort(this.resultFieldConfigs_);
/*     */       
/*  72 */       for (int i = 0; i < this.resultFieldConfigs_.size(); i++) {
/*  73 */         results[i] = ((ResultFieldConfig)this.resultFieldConfigs_.get(i)).getName();
/*  74 */         String dataType = ((ResultFieldConfig)this.resultFieldConfigs_.get(i)).getType();
/*     */         
/*  76 */         if (!StringUtils.isEmpty(dataType)) {
/*  77 */           resultDataTypes.add(((ResultFieldConfig)this.resultFieldConfigs_.get(i)).getType());
/*     */         }
/*     */       } 
/*     */       
/*  81 */       if (resultDataTypes.size() == results.length) {
/*     */         
/*  83 */         resultTypes = (String[])resultDataTypes.stream().map(String::trim).toArray(x$0 -> new String[x$0]);
/*     */       }
/*  85 */       else if (this.propertyConfigs_.getProperty("DataTypes") != null) {
/*     */         
/*  87 */         String dataTypesProp = this.propertyConfigs_.getProperty("DataTypes");
/*  88 */         String[] dataTypesSplit = dataTypesProp.split(",");
/*  89 */         if (dataTypesSplit.length == results.length) {
/*  90 */           resultTypes = (String[])Arrays.<String>stream(dataTypesSplit).map(String::trim).toArray(x$0 -> new String[x$0]);
/*     */         } else {
/*     */           
/*  93 */           logger_.warn("Configured QueryConfig property DataTypes has an invalid number of types.");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (this.propertyConfigs_ != null) {
/* 103 */       Set<Object> propertyKeys = this.propertyConfigs_.keySet();
/*     */       
/* 105 */       for (Object key : propertyKeys) {
/* 106 */         if (key.toString().startsWith("SQL") || key.toString().startsWith("WhereClause") || key
/* 107 */           .toString().startsWith("Parameters")) {
/* 108 */           String value = this.propertyConfigs_.getProperty(key.toString());
/* 109 */           value = SqlQueryBuilder.cleanSqlString(value) + " ";
/*     */           
/* 111 */           for (int ii = 0; ii < value.length(); ii++) {
/* 112 */             char c = value.charAt(ii);
/*     */             
/* 114 */             if (c >= '\000' && c < ' ') {
/* 115 */               value = value.replace(c, ' ');
/* 116 */               logger_.warn("Replacing non-printable char 0x" + Integer.toString(c, 16) + " with 0x" + SPACE_AS_HEX + " at string index: [" + ii + "] - Please cleanup property with key: [" + key + "] from the query definition at: " + 
/*     */                   
/* 118 */                   getSourceDescription());
/*     */             } 
/*     */           } 
/*     */           
/* 122 */           this.propertyConfigs_.setProperty(key.toString(), value);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 128 */     QueryDescriptor queryDescriptor = new QueryDescriptor(this.name_, this.queryHandler_, this.resultClass_, results, resultTypes, this.propertyConfigs_, getSourceDescription());
/* 129 */     queryDescriptor.setResultFilter(this._resultFilterName);
/* 130 */     return queryDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 136 */     if ("Name".equalsIgnoreCase(argKey)) {
/* 137 */       this.name_ = argValue.toString();
/*     */     }
/* 139 */     else if ("QueryHandler".equalsIgnoreCase(argKey)) {
/* 140 */       this.queryHandler_ = ConfigUtils.toClass(argValue);
/*     */     }
/* 142 */     else if ("ResultFilter".equalsIgnoreCase(argKey)) {
/* 143 */       this._resultFilterName = argValue.toString();
/*     */     }
/* 145 */     else if ("ResultClass".equalsIgnoreCase(argKey)) {
/* 146 */       this.resultClass_ = argValue.toString();
/* 147 */       addProperty("ResultClass", this.resultClass_);
/*     */     }
/* 149 */     else if ("ResultField".equalsIgnoreCase(argKey) && argValue instanceof ResultFieldConfig) {
/* 150 */       ResultFieldConfig value = (ResultFieldConfig)argValue;
/*     */       
/* 152 */       if (value.getOrder() < 0) {
/* 153 */         value.setOrder(this.resultFieldConfigs_.size());
/*     */       }
/* 155 */       this.resultFieldConfigs_.add(value);
/*     */     }
/* 157 */     else if ("Property".equalsIgnoreCase(argKey) && argValue instanceof PropertyConfig) {
/* 158 */       addProperty(((PropertyConfig)argValue).getKey(), ((PropertyConfig)argValue).getValue());
/*     */     }
/* 160 */     else if ("pmType".equalsIgnoreCase(argKey)) {
/* 161 */       addProperty("PMType", argValue.toString());
/*     */     }
/* 163 */     else if ("Suffix".equalsIgnoreCase(argKey)) {
/* 164 */       addProperty("Suffix", argValue.toString());
/*     */     }
/* 166 */     else if ("SQL".equalsIgnoreCase(argKey)) {
/* 167 */       QueryStatementConfig config = (QueryStatementConfig)argValue;
/* 168 */       if (config.getOrder() < 0)
/*     */       {
/* 170 */         config.setOrder(this.statementConfigs_.size());
/*     */       }
/* 172 */       this.statementConfigs_.add(config);
/*     */     }
/* 174 */     else if ("Sort".equalsIgnoreCase(argKey)) {
/* 175 */       this.sortConfigs_.add((QuerySortConfig)argValue);
/*     */     }
/* 177 */     else if ("Having".equalsIgnoreCase(argKey)) {
/* 178 */       this.havingConfigs_.add((QueryHavingConfig)argValue);
/*     */     }
/* 180 */     else if ("ClassName".equals(argKey)) {
/* 181 */       addProperty("ClassName", argValue.toString());
/*     */     } else {
/*     */       
/* 184 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptHavingClauses(List<QueryHavingConfig> argHavingConfigs) {
/* 194 */     int suffix = 1;
/*     */     
/* 196 */     for (QueryHavingConfig havingConfig : argHavingConfigs) {
/* 197 */       addProperty("Having" + suffix, havingConfig.getCondition());
/* 198 */       addProperty("Having" + suffix + ".Field", havingConfig.getTestExpression());
/* 199 */       addProperty("Having" + suffix + ".Parameters", 
/* 200 */           getParamsAsString(havingConfig.getParameters(), ", "));
/* 201 */       suffix++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptSortProperties(List<QuerySortConfig> argSortConfigs) {
/* 211 */     int suffix = 1;
/*     */     
/* 213 */     for (QuerySortConfig sortConfig : argSortConfigs) {
/* 214 */       addProperty("Sort" + suffix, sortConfig.getSortField());
/*     */       
/* 216 */       if (sortConfig.getSortOrder() != null) {
/* 217 */         addProperty("Sort" + suffix + "." + "Order", sortConfig.getSortOrder());
/*     */       }
/*     */       
/* 220 */       if (sortConfig.isRequiredSort() != null) {
/* 221 */         addProperty("Sort" + suffix + "." + "RequiredSort", sortConfig.isRequiredSort());
/*     */       }
/*     */       
/* 224 */       suffix++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptStatementConfig(List<QueryStatementConfig> argStatementConfigs) {
/* 234 */     int queryCount = argStatementConfigs.size();
/*     */     
/* 236 */     if (queryCount > 1) {
/* 237 */       addProperty("QueryCount", String.valueOf(queryCount));
/*     */     }
/*     */     
/* 240 */     Collections.sort(argStatementConfigs);
/* 241 */     int currentQueryIdx = 1;
/*     */     
/* 243 */     for (QueryStatementConfig statementConfig : argStatementConfigs) {
/* 244 */       String requiredParamList = "";
/* 245 */       String suffix = (queryCount > 1) ? String.valueOf(currentQueryIdx) : "";
/* 246 */       addProperty("SQL" + suffix, statementConfig.getStatement());
/* 247 */       requiredParamList = getParamsAsString(statementConfig.getParameters(), ", ");
/*     */       
/* 249 */       if (!StringUtils.isEmpty(requiredParamList)) {
/* 250 */         addProperty("Parameters" + suffix, requiredParamList.toString());
/*     */       }
/*     */       
/* 253 */       for (QueryExpressionConfig expression : statementConfig.getExpressions()) {
/* 254 */         addProperty("Parameters" + suffix + "." + expression.getTrigger(), expression.getParameters());
/* 255 */         addProperty("SQL" + suffix + "." + expression.getTrigger(), expression.getExpression());
/*     */       } 
/*     */       
/* 258 */       if (statementConfig.getDtxWhereClause() != null) {
/* 259 */         addProperty("WhereClause", statementConfig.getDtxWhereClause());
/*     */       }
/*     */       
/* 262 */       if (!statementConfig.isRequired()) {
/* 263 */         addProperty("SQL" + suffix + "." + "Required", String.valueOf(statementConfig.isRequired()));
/*     */       }
/*     */ 
/*     */       
/* 267 */       currentQueryIdx++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addProperty(String argKey, String argValue) {
/* 278 */     if (argKey != null && argValue != null) {
/* 279 */       this.propertyConfigs_.setProperty(argKey, argValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getParamsAsString(List<QueryParameterConfig> argParamConfigs, String argDelimiter) {
/* 291 */     StringBuffer paramString = new StringBuffer();
/*     */     
/* 293 */     for (QueryParameterConfig paramConfig : argParamConfigs) {
/* 294 */       if (paramString.length() > 0) {
/* 295 */         paramString.append(argDelimiter);
/*     */       }
/*     */       
/* 298 */       paramString.append(paramConfig.getName());
/*     */     } 
/*     */     
/* 301 */     return paramString.toString();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\query\QueryConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */