/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.FileUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.tools.JavaCompiler;
/*     */ import javax.tools.JavaFileObject;
/*     */ import javax.tools.StandardJavaFileManager;
/*     */ import javax.tools.ToolProvider;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.tools.ant.AntClassLoader;
/*     */ 
/*     */ public class DaoGenHelper
/*     */   implements AutoCloseable
/*     */ {
/*  30 */   private static final Logger logger_ = Logger.getLogger(DaoGenHelper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DaoGenHelper create() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
/*  42 */     String className = System.getProperty(DaoGenHelper.class.getName(), DaoGenHelper.class.getName());
/*  43 */     return (DaoGenHelper)Class.forName(className).newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPropertyInterfaceName(DtxDefinition argParentDtx) {
/*  53 */     return argParentDtx.getInterface() + "Property";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPropertyName(DtxDefinition argParentDtx) {
/*  63 */     return argParentDtx.getName() + "Property";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPropertyChildNeeded(DtxDefinition argParentDtx) {
/*  73 */     boolean propertyTableNeeded = false;
/*     */     
/*  75 */     if (!argParentDtx.isExtended() && !argParentDtx.isCustomerExtension() && !argParentDtx.isProperties() && (argParentDtx
/*  76 */       .getPrimaryKeyFields()).length > 0) {
/*  77 */       DtxDefinition.DtxDaoField orgId = argParentDtx.findField("organizationId");
/*  78 */       if (orgId != null && orgId.isPrimaryKey()) {
/*  79 */         propertyTableNeeded = true;
/*     */       }
/*     */     } 
/*  82 */     return propertyTableNeeded;
/*     */   }
/*     */ 
/*     */   
/*  86 */   protected List<DtxDefinition> dtxDefinitions_ = new ArrayList<>();
/*     */ 
/*     */   
/*  89 */   protected Map<String, DtxDefinition> typeNameToDefinition_ = new HashMap<>(300);
/*  90 */   private final Collection<File> baseInDirs_ = new ArrayList<>();
/*  91 */   private final Collection<String> baseInPaths_ = new ArrayList<>();
/*     */   
/*  93 */   private final DAOFileWriter writer_ = new DAOFileWriter();
/*  94 */   private File inDir_ = null;
/*  95 */   private File outDir_ = null;
/*  96 */   private File tempDir_ = null;
/*  97 */   private File sourcesDir_ = null;
/*  98 */   private String inPath_ = null;
/*  99 */   private String outPath_ = null;
/* 100 */   private String cleanbeanOutPath_ = null;
/*     */   private boolean overrideMode_ = false;
/* 102 */   private String overrideType_ = "";
/* 103 */   private String overrideExtends_ = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URLClassLoader precompileClassloader_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyDefinitions() {
/* 117 */     List<DtxDefinition> dtxPropertyDefs = new ArrayList<>();
/*     */     
/* 119 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/* 120 */       if (isPropertyChildNeeded(dtx)) {
/*     */         
/* 122 */         DtxDefinition dtxProp = getPropertyDtxDefinition(dtx);
/* 123 */         dtxPropertyDefs.add(dtxProp);
/* 124 */         this.typeNameToDefinition_.put(dtxProp.getName(), dtxProp);
/*     */         
/* 126 */         DtxRelationship propertyRelationship = new DtxRelationship();
/* 127 */         propertyRelationship.setName("Properties");
/* 128 */         propertyRelationship.setChildName(getPropertyName(dtx));
/* 129 */         propertyRelationship.setChild(dtxProp);
/* 130 */         propertyRelationship.setType(DtxRelationship.ONE_MANY);
/* 131 */         propertyRelationship.setPropertyRelationship(true);
/*     */         
/* 133 */         for (DtxDefinition.DtxDaoField key : dtx.getPrimaryKeyFields()) {
/* 134 */           propertyRelationship.getClass(); DtxRelationship.DtxRelationshipField relationField = new DtxRelationship.DtxRelationshipField(propertyRelationship);
/* 135 */           relationField.setParent(key.getName());
/* 136 */           relationField.setChild(key.getName());
/*     */           
/* 138 */           propertyRelationship.addField(relationField);
/*     */         } 
/*     */         
/* 141 */         dtx.addRelationship(propertyRelationship);
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     this.dtxDefinitions_.addAll(dtxPropertyDefs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws Exception {
/* 152 */     this.writer_.close();
/* 153 */     if (this.precompileClassloader_ != null) {
/* 154 */       this.precompileClassloader_.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doesExtendsEqualType() {
/* 164 */     return getOverrideType().equalsIgnoreCase(getOverrideExtends());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<File> getBaseInDirs() {
/* 173 */     return this.baseInDirs_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getBaseInPaths() {
/* 182 */     return this.baseInPaths_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassComment(String argClassComment) {
/* 192 */     return "\n/**\n * " + argClassComment + "<br>\n *\n * @author DAOGen\n */\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassCommentWithSuppressWarnings(String argClassComment) {
/* 202 */     return getClassComment(argClassComment) + "@SuppressWarnings(\"all\")\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCleanbeanOutPath() {
/* 211 */     return this.cleanbeanOutPath_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DtxDefinition> getDtxDefinitions() {
/* 220 */     return this.dtxDefinitions_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilePath(DtxDefinition argDtx) throws IOException {
/* 233 */     String canPath = argDtx.getSourceDtxFile().getParentFile().getCanonicalPath();
/* 234 */     if (canPath.startsWith(this.inPath_)) {
/* 235 */       return argDtx.getSourceDtxFile().getParentFile().getCanonicalPath().substring(this.inPath_.length()) + File.separator;
/*     */     }
/*     */ 
/*     */     
/* 239 */     for (String path : getBaseInPaths()) {
/* 240 */       if (canPath.startsWith(path)) {
/* 241 */         return argDtx.getSourceDtxFile().getParentFile().getCanonicalPath().substring(path.length()) + File.separator;
/*     */       }
/*     */     } 
/*     */     
/* 245 */     throw new RuntimeException("Cannot translate path: " + canPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilePathCleanbean(DtxDefinition argDtx) {
/* 257 */     String s = argDtx.getCleanbeanPackageRaw();
/* 258 */     String path = s.replace('.', File.separatorChar);
/* 259 */     return File.separator + path + File.separator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getInDir() {
/* 268 */     return this.inDir_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInPath() {
/* 277 */     return this.inPath_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getOutDir() {
/* 286 */     return this.outDir_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutPath() {
/* 295 */     return this.outPath_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOverrideExtends() {
/* 304 */     return this.overrideExtends_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOverrideType() {
/* 313 */     return this.overrideType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getPrecompileClassloader() {
/* 322 */     return this.precompileClassloader_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getSourcesDir() {
/* 331 */     return this.sourcesDir_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getTempDir() {
/* 340 */     return this.tempDir_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxDefinition getTypeNameDefinition(String argTypeName) {
/* 350 */     return this.typeNameToDefinition_.get(argTypeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DAOFileWriter getWriter() {
/* 359 */     return this.writer_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOverrideMode() {
/* 368 */     return this.overrideMode_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load() {
/* 375 */     addPropertyDefinitions();
/* 376 */     setupRelationships();
/* 377 */     optionalValidate();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 382 */     for (DtxDefinition dd : this.dtxDefinitions_) {
/* 383 */       dd.validate();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 390 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/* 391 */       DtxInverseRelationship[] inverseRelationships = dtx.getInverseRelationships();
/*     */       
/* 393 */       for (DtxInverseRelationship ir : inverseRelationships) {
/* 394 */         DtxDefinition dtxParent = ir.getParent();
/* 395 */         boolean ok = false;
/*     */         
/* 397 */         for (DtxRelationship relationship : dtxParent.getRelationships()) {
/* 398 */           if (relationship.getChild().getName().equals(dtx.getName())) {
/* 399 */             ok = true;
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 408 */         if (!ok && !dtx.getName().equals("TaxRateRuleOverride")) {
/* 409 */           throw new RuntimeException("dtx: " + dtx.getName() + " has an inverse relationship: " + ir.getName() + " which points to a parent: " + ir
/* 410 */               .getParentType() + " BUT THAT PARENT DOES NOT HAVE " + dtx
/* 411 */               .getName() + " as a child in any relationship.");
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 419 */     ensureUniqueNames(this.dtxDefinitions_);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 425 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/* 426 */       if (dtx.isExtended() && dtx.getTable().equals(dtx.getExtends().getTable()) && (
/* 427 */         dtx.getFields()).length > 0) {
/* 428 */         throw new RuntimeException("DTX: " + dtx
/* 429 */             .getName() + " is in error. When a derived DTX points to the same table as his parent, he is not allowed to declare new fields.");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 439 */     Comparator<DtxDefinition> comparator = new Comparator<DtxDefinition>()
/*     */       {
/*     */         public int compare(DtxDefinition argO1, DtxDefinition argO2) {
/* 442 */           String domain1 = argO1.getPackageDomain();
/*     */           
/* 444 */           boolean priority1 = (domain1.equals("trl") || domain1.equals("trn") || domain1.equals("tsn") || domain1.equals("itm") || domain1.equals("ttr"));
/*     */           
/* 446 */           String domain2 = argO2.getPackageDomain();
/*     */           
/* 448 */           boolean priority2 = (domain2.equals("trl") || domain2.equals("trn") || domain2.equals("tsn") || domain2.equals("itm") || domain2.equals("ttr"));
/*     */           
/* 450 */           if (priority1) {
/* 451 */             return priority2 ? 0 : -1;
/*     */           }
/*     */           
/* 454 */           return priority2 ? 1 : 0;
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 459 */     Collections.sort(this.dtxDefinitions_, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void optionalValidate() {
/* 466 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/* 467 */       if (!StringUtils.isEmpty(dtx.getExtendsStringType()) && 
/* 468 */         dtx.getExtendsStringType().startsWith("dtv.xst")) {
/* 469 */         throw new RuntimeException("DTX: " + dtx.getSourceDtxFile().getAbsolutePath() + " extends declaration should NOT have the fully-qualified name (" + dtx
/* 470 */             .getExtendsStringType() + ") just the type name.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 475 */       for (DtxRelationship relationship : dtx.getRelationships()) {
/*     */         
/* 477 */         DtxDefinition parent = relationship.getParent();
/*     */         
/* 479 */         for (DtxRelationship.DtxRelationshipField relationshipField : relationship.getFields()) {
/* 480 */           if (!StringUtils.isEmpty(relationshipField.getParent()) && 
/* 481 */             parent.findField(relationshipField.getParent()) == null) {
/* 482 */             throw new RuntimeException("The relationship: " + relationship.getName() + " has a field which references non-existent parent field: " + relationshipField
/*     */                 
/* 484 */                 .getParent());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void precompile() throws IOException {
/* 500 */     JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
/* 501 */     try (StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, null, null)) {
/*     */       
/* 503 */       List<File> compileFiles = new ArrayList<>();
/* 504 */       compileFiles.addAll(FileUtils.getFiles(this.outDir_, ".java"));
/* 505 */       if (this.sourcesDir_ != null) {
/* 506 */         compileFiles.addAll(FileUtils.getFiles(this.sourcesDir_, ".java"));
/*     */       }
/*     */ 
/*     */       
/* 510 */       List<String> compilerOptions = new ArrayList<>();
/* 511 */       compilerOptions.add("-d");
/* 512 */       compilerOptions.add(this.tempDir_.getCanonicalPath());
/* 513 */       if (getClass().getClassLoader() instanceof AntClassLoader) {
/* 514 */         compilerOptions.add("-classpath");
/* 515 */         compilerOptions.add(((AntClassLoader)getClass().getClassLoader()).getClasspath());
/*     */       } 
/*     */ 
/*     */       
/* 519 */       if (compileFiles.size() > 0) {
/* 520 */         logger_.info("Pre-compiling " + compileFiles.size() + " files.");
/*     */         
/* 522 */         Iterable<? extends JavaFileObject> javaObjects = fileManager.getJavaFileObjectsFromFiles(compileFiles);
/* 523 */         Writer outWriter = new StringWriter();
/*     */         
/* 525 */         JavaCompiler.CompilationTask compileTask = compiler.getTask(outWriter, fileManager, null, compilerOptions, null, javaObjects);
/* 526 */         if (!compileTask.call().booleanValue()) {
/* 527 */           throw new Error("Generated code did not compile cleanly.\n\nCompiler Output:\n" + outWriter
/* 528 */               .toString());
/*     */         }
/*     */       } else {
/*     */         
/* 532 */         logger_.info("No files to pre-compile.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 537 */     this
/* 538 */       .precompileClassloader_ = new URLClassLoader(new URL[] { this.tempDir_.toURI().toURL() }, getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preLoad(List<File> fileList, boolean argGenerate) {
/* 549 */     logger_.info("Preloading all dtx files");
/*     */     
/* 551 */     DAOParser parser = new DAOParser();
/*     */     
/* 553 */     for (File file : fileList) {
/* 554 */       DtxDefinition dtx = parser.parse(file);
/* 555 */       dtx.setNeedsGeneration(argGenerate);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 560 */       DtxDefinition existing = this.typeNameToDefinition_.get(dtx.getName());
/* 561 */       if (existing == null) {
/* 562 */         this.typeNameToDefinition_.put(dtx.getName(), dtx);
/* 563 */         this.dtxDefinitions_.add(dtx); continue;
/*     */       } 
/* 565 */       if (!existing.needsGeneration(null) && dtx.needsGeneration(null)) {
/* 566 */         logger_.warn("Overriding reference definition [" + existing.getSourceDtxFile().getAbsolutePath() + "] with definition [" + existing
/* 567 */             .getSourceDtxFile().getAbsolutePath() + "]");
/* 568 */         this.dtxDefinitions_.remove(existing);
/* 569 */         this.typeNameToDefinition_.put(dtx.getName(), dtx);
/* 570 */         this.dtxDefinitions_.add(dtx); continue;
/*     */       } 
/* 572 */       if (!dtx.needsGeneration(null)) {
/*     */ 
/*     */         
/* 575 */         logger_.warn("Ignoring reference definition [" + dtx.getSourceDtxFile().getAbsolutePath() + "] in favor of definition [" + existing
/* 576 */             .getSourceDtxFile().getAbsolutePath() + "]");
/*     */         continue;
/*     */       } 
/* 579 */       throw new RuntimeException("Duplicate dtx type detected: " + dtx.getName() + " defined in [" + dtx
/* 580 */           .getSourceDtxFile().getAbsolutePath() + "] and [" + existing
/* 581 */           .getSourceDtxFile().getAbsolutePath() + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseInDirs(Collection<? extends File> argBaseInDirs) throws IOException {
/* 595 */     if (argBaseInDirs != null) {
/* 596 */       for (File file : argBaseInDirs) {
/* 597 */         this.baseInDirs_.add(file);
/* 598 */         this.baseInPaths_.add(file.getCanonicalPath());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCleanbeanOutDir(File argCleanbeanOutDir) throws IOException {
/* 611 */     this.cleanbeanOutPath_ = (argCleanbeanOutDir != null) ? argCleanbeanOutDir.getCanonicalPath() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInDir(File argInDir) throws IOException {
/* 622 */     this.inDir_ = (argInDir != null) ? argInDir : new File(".");
/* 623 */     this.inPath_ = this.inDir_.getCanonicalPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutDir(File argOutDir) throws IOException {
/* 634 */     this.outDir_ = (argOutDir != null) ? argOutDir : new File(".");
/* 635 */     this.outPath_ = this.outDir_.getCanonicalPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideExtends(String argOverrideExtends) {
/* 644 */     this.overrideExtends_ = argOverrideExtends;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideMode(boolean argOverrideMode) {
/* 653 */     this.overrideMode_ = argOverrideMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideType(String argOverrideType) {
/* 662 */     this.overrideType_ = argOverrideType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourcesDir(File argSourcesDir) {
/* 671 */     this.sourcesDir_ = argSourcesDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTempDir(File argTempDir) {
/* 680 */     this.tempDir_ = argTempDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupRelationships() {
/* 690 */     for (DtxDefinition dtxDefinition : this.dtxDefinitions_) {
/*     */ 
/*     */ 
/*     */       
/* 694 */       String extendsStringType = dtxDefinition.getExtendsStringType();
/* 695 */       if (!StringUtils.isEmpty(extendsStringType)) {
/* 696 */         DtxDefinition parent = this.typeNameToDefinition_.get(extendsStringType);
/*     */         
/* 698 */         if (parent == null) {
/* 699 */           throw new RuntimeException("Could not find parent: " + extendsStringType + " for dtx: " + dtxDefinition
/* 700 */               .getName());
/*     */         }
/*     */         
/* 703 */         dtxDefinition.setExtends(parent);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 709 */       DtxInverseRelationship[] inverseRelationships = dtxDefinition.getInverseRelationships();
/* 710 */       for (DtxInverseRelationship ir : inverseRelationships) {
/*     */         
/* 712 */         DtxDefinition dtxParent = this.typeNameToDefinition_.get(ir.getParentType());
/*     */         
/* 714 */         if (dtxParent == null) {
/* 715 */           throw new RuntimeException("Could not find parent: " + ir.getParentType() + " for inverse relationship: " + ir
/* 716 */               .getName() + "\nfor dtx: " + dtxDefinition.getName());
/*     */         }
/*     */         
/* 719 */         ir.setParent(dtxParent);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 725 */       for (DtxRelationship relationship : dtxDefinition.getRelationships()) {
/* 726 */         DtxDefinition child = this.typeNameToDefinition_.get(relationship.getChildName());
/*     */         
/* 728 */         if (child == null) {
/* 729 */           throw new RuntimeException("Unknown child type: " + relationship.getChildName() + " on relationship: " + relationship
/* 730 */               .getName() + " in dtx: " + dtxDefinition
/* 731 */               .getSourceDtxFile().getAbsolutePath());
/*     */         }
/*     */         
/* 734 */         relationship.setChild(child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DtxDefinition.DtxDaoField getFieldDefinition(String argName, String argColumn, String argType, boolean argPrimaryKey) {
/* 750 */     DtxDefinition.DtxDaoField field = new DtxDefinition.DtxDaoField();
/*     */     
/* 752 */     field.setName(argName);
/* 753 */     field.setColumn(argColumn);
/* 754 */     field.setType(argType);
/* 755 */     field.setPrimaryKey(argPrimaryKey);
/*     */     
/* 757 */     return field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DtxDefinition getPropertyDtxDefinition(DtxDefinition argParentDtx) {
/* 767 */     DtxDefinition dtxProp = new DtxDefinition();
/*     */     
/* 769 */     String propName = getPropertyName(argParentDtx);
/* 770 */     String tableName = argParentDtx.getTable() + "_p";
/*     */     
/* 772 */     File propFile = new File(argParentDtx.getSourceDtxFile().getParentFile().getPath() + File.separatorChar + propName + ".dtx");
/*     */     
/* 774 */     dtxProp.setIsProperties(true);
/* 775 */     dtxProp.setName(propName);
/* 776 */     dtxProp.setTable(tableName);
/* 777 */     dtxProp.setPackage(argParentDtx.getPackageRaw());
/* 778 */     dtxProp.setSourceDtxFile(propFile);
/*     */     
/* 780 */     for (DtxDefinition.DtxDaoField key : argParentDtx.getPrimaryKeyFields()) {
/* 781 */       dtxProp.addField(key);
/*     */     }
/*     */     
/* 784 */     dtxProp.addField(getFieldDefinition("propertyCode", "property_code", "String", true));
/* 785 */     dtxProp.addField(getFieldDefinition("type", "type", "String", false));
/* 786 */     dtxProp.addField(getFieldDefinition("stringValue", "string_value", "String", false));
/* 787 */     dtxProp.addField(getFieldDefinition("dateValue", "date_value", "Date", false));
/* 788 */     dtxProp.addField(getFieldDefinition("decimalValue", "decimal_value", "BigDecimal", false));
/* 789 */     dtxProp.addField(getFieldDefinition("createDate", "create_date", "Date", false));
/* 790 */     dtxProp.addField(getFieldDefinition("createUserId", "create_user_id", "String", false));
/* 791 */     dtxProp.addField(getFieldDefinition("updateDate", "update_date", "Date", false));
/* 792 */     dtxProp.addField(getFieldDefinition("updateUserId", "update_user_id", "String", false));
/*     */     
/* 794 */     return dtxProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureUniqueNames(List<DtxDefinition> dtxDefinitions) {
/* 802 */     for (DtxDefinition dtx : dtxDefinitions) {
/* 803 */       Set<String> names = new HashSet<>();
/* 804 */       Set<String> columns = new HashSet<>();
/*     */       
/* 806 */       for (DtxDefinition.DtxDaoField field : dtx.getFields()) {
/* 807 */         if (names.contains(field.getName())) {
/* 808 */           throw new RuntimeException("The name " + field.getName() + " is used by more than one field in the " + dtx
/* 809 */               .getPackage() + "." + dtx.getName() + ".dtx.  One of these fields should be renamed.");
/*     */         }
/*     */         
/* 812 */         names.add(field.getName());
/*     */ 
/*     */         
/* 815 */         if (columns.contains(field.getColumn())) {
/* 816 */           throw new RuntimeException("The column " + field
/* 817 */               .getColumn() + " is used by more than one field in the " + dtx.getPackage() + "." + dtx
/* 818 */               .getName() + ".dtx.  One of these fields should be renamed.");
/*     */         }
/*     */         
/* 821 */         columns.add(field.getColumn());
/*     */       } 
/*     */ 
/*     */       
/* 825 */       for (DtxRelationship rel : dtx.getRelationships()) {
/* 826 */         if (names.contains(rel.getName())) {
/* 827 */           throw new RuntimeException("The name " + rel.getName() + " is used by more than one field/relationship in the " + dtx
/* 828 */               .getPackage() + "." + dtx
/* 829 */               .getName() + ".dtx.  One of these fields/relationships should be renamed.");
/*     */         }
/*     */         
/* 832 */         names.add(rel.getName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DaoGenHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */