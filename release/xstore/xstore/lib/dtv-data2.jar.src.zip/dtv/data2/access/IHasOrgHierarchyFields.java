package dtv.data2.access;

public interface IHasOrgHierarchyFields {
  String getOrgCode();
  
  String getOrgValue();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\IHasOrgHierarchyFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */