/*      */ package dtv.data2.access.pm;
/*      */ import dtv.data2.access.DaoUtils;
/*      */ import dtv.data2.access.IDataAccessObject;
/*      */ import dtv.data2.access.IDataModel;
/*      */ import dtv.data2.access.IDataModelRelationship;
/*      */ import dtv.data2.access.IObjectId;
/*      */ import dtv.data2.access.IPersistable;
/*      */ import dtv.data2.access.IPersistenceMgrType;
/*      */ import dtv.data2.access.IPersistenceRule;
/*      */ import dtv.data2.access.config.pmtype.PersistenceMgrTypeDescriptor;
/*      */ import dtv.data2.access.exception.DtxException;
/*      */ import dtv.data2.access.exception.FailoverException;
/*      */ import dtv.data2.access.exception.PersistenceCancelledException;
/*      */ import dtv.data2.access.exception.PersistenceException;
/*      */ import dtv.data2.access.exception.PrimaryKeyViolationException;
/*      */ import dtv.data2.access.exception.RetryException;
/*      */ import dtv.data2.access.impl.DaoState;
/*      */ import dtv.data2.access.impl.IDataModelImpl;
/*      */ import dtv.data2.access.impl.IPersistenceStrategy;
/*      */ import dtv.data2.access.impl.PersistableMetaData;
/*      */ import dtv.data2.access.query.IQueryHandler;
/*      */ import dtv.data2.access.query.QueryRequest;
/*      */ import dtv.data2.access.query.QueryToken;
/*      */ import dtv.data2.access.status.StatusMgr;
/*      */ import dtv.data2.access.transaction.DataSourceTransactionManager;
/*      */ import dtv.data2.access.transaction.TransactionToken;
/*      */ import dtv.data2.replication.IReplicationStrategy;
/*      */ import dtv.data2.replication.ReplicationStrategyHelper;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public class PersistenceManager implements IPersistenceMgr {
/*   36 */   private static final Logger logger_ = Logger.getLogger(PersistenceManager.class);
/*   37 */   private static final boolean LOGGER_DEBUG_ENABLED = logger_.isDebugEnabled();
/*      */ 
/*      */   
/*      */   private static final int ABSOLUTE_MAX_RETRIES = 10;
/*      */ 
/*      */   
/*   43 */   private static final int MAX_RETRIES = Integer.getInteger("dtv.data2.datasource.maxretries", 3).intValue();
/*   44 */   private static final int RETRY_WAIT = Integer.getInteger("dtv.data2.datasource.retrywait", 500).intValue();
/*      */ 
/*      */   
/*      */   @Inject
/*      */   private IPersistenceDefaults _persistenceDefaults;
/*      */ 
/*      */   
/*      */   @Inject
/*      */   PmTypeHelper _pmTypeHelper;
/*      */ 
/*      */   
/*      */   @Inject
/*      */   private PersistenceMgrTypeFactory _persistenceMgrTypeFactory;
/*      */ 
/*      */   
/*      */   protected Map<String, Integer> retryCountMap_;
/*      */   
/*      */   protected Map<IPersistenceMgrType, IPersistenceStrategy> pmTypeToStrategyMap_;
/*      */   
/*      */   protected Map<String, List<String>> pmTypeToSuccessfulDSMap_;
/*      */   
/*   65 */   private final Map<IObjectId, IDataModel> alreadyLoadedModels_ = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean replicationEnabled_ = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkExistence(IObjectId argId) {
/*   82 */     boolean objectLocated = false;
/*   83 */     List<PmStrategyInfo> strategies = this._pmTypeHelper.getLookupStrategies(argId);
/*      */     
/*   85 */     if (LOGGER_DEBUG_ENABLED) {
/*   86 */       logger_.debug("Begin checkExistence for id type: " + argId.getClass().getName() + " value: " + argId);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*   91 */     if (strategies.isEmpty()) {
/*   92 */       logNoDatasourceWarning(this._pmTypeHelper.getPMTypeByObjectId((Class)argId.getClass()), "checkExistence for id: " + argId + " will fail without trying to pull the data");
/*      */       
/*   94 */       return objectLocated;
/*      */     } 
/*      */     
/*   97 */     boolean scanOfflineSources = true;
/*      */     
/*   99 */     for (PmStrategyInfo strategyInfo : strategies) {
/*      */ 
/*      */       
/*  102 */       if (!strategyInfo.isCurrentlyAvailable()) {
/*      */         continue;
/*      */       }
/*      */       
/*  106 */       IPersistenceStrategy strategy = strategyInfo.getStrategy();
/*      */       
/*      */       try {
/*  109 */         if (!strategy.isOnlineStrategyType() && !scanOfflineSources) {
/*  110 */           if (LOGGER_DEBUG_ENABLED) {
/*  111 */             logger_.debug("Halting checkExistence because object (" + argId + ") was not found on online datasources.");
/*      */           }
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  118 */         objectLocated = strategy.checkExistence(argId, null);
/*  119 */         scanOfflineSources = false;
/*      */ 
/*      */         
/*  122 */         if (objectLocated) {
/*  123 */           if (LOGGER_DEBUG_ENABLED) {
/*  124 */             logger_.debug("checkExistence located the object (" + argId + ") returning success.");
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  130 */         if (LOGGER_DEBUG_ENABLED) {
/*  131 */           logger_.debug("checkExistence on datasource: " + strategy.getDataSourceName() + " did not locate the object (" + argId + ") ");
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  136 */       catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */     
/*  140 */     return objectLocated;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanup() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IDataModel getObjectById(IObjectId argId, IPersistenceMgrType argType) {
/*  161 */     return getObjectById(argId, argType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IDataModel getObjectById(IObjectId argId, IPersistenceMgrType argType, PmOperationInfo argOperationInfo) {
/*      */     IPersistenceMgrType type;
/*  176 */     if (argType == null) {
/*  177 */       type = this._pmTypeHelper.getPMTypeByObjectId(argId);
/*      */     } else {
/*      */       
/*  180 */       type = argType;
/*      */     } 
/*  182 */     QueryToken token = new QueryToken(argId, type);
/*      */     try {
/*  184 */       return getObjectById(argId, type, token, argOperationInfo);
/*      */     } finally {
/*      */       
/*  187 */       QueryResourceManager.getInstance().closeQueryResources(token);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IDataModel getObjectById(IObjectId argId, IPersistenceMgrType argType, QueryToken argQueryToken, PmOperationInfo argOperationInfo) {
/*  204 */     if (LOGGER_DEBUG_ENABLED) {
/*  205 */       logger_.debug("Begin getObjectById for id type: " + argId.getClass().getName() + " value: " + argId + " using Persistence manager type: " + argType
/*  206 */           .getName());
/*      */     }
/*      */     
/*  209 */     IDataModel result = null;
/*  210 */     List<PmStrategyInfo> strategies = this._pmTypeHelper.getLookupStrategies(argType);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  215 */     if (strategies.isEmpty()) {
/*  216 */       logNoDatasourceWarning(argType, "getObjectById for id: " + argId + " will fail without trying to pull the data");
/*      */       
/*  218 */       throw new DataSourceUnavailableException("Lookup failed for id type " + argId.getClass().getName() + " value: " + argId + " No datasources were available.");
/*      */     } 
/*      */ 
/*      */     
/*  222 */     boolean scanOfflineSources = true;
/*      */ 
/*      */ 
/*      */     
/*  226 */     IPersistenceStrategy preferredDataSource = null;
/*  227 */     PersistableMetaData metaData = new PersistableMetaData("OBJECT_RETRIEVED");
/*      */     
/*  229 */     for (PmStrategyInfo strategyInfo : strategies) {
/*      */ 
/*      */       
/*  232 */       if (!strategyInfo.isCurrentlyAvailable()) {
/*  233 */         if (argOperationInfo != null) {
/*  234 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  240 */       IPersistenceStrategy strategy = strategyInfo.getStrategy();
/*  241 */       String dsName = strategy.getDataSourceName();
/*      */ 
/*      */       
/*      */       try {
/*  245 */         if (!strategy.isOnlineStrategyType() && !scanOfflineSources) {
/*  246 */           if (LOGGER_DEBUG_ENABLED) {
/*  247 */             logger_.debug("Halting getObjectById because object (" + argId + ") was not found on online datasources.");
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/*  256 */         if (LOGGER_DEBUG_ENABLED) {
/*  257 */           logger_.debug("Performing getObjectById (" + argId + ") on datasource: " + dsName);
/*      */         }
/*      */         
/*      */         try {
/*  261 */           metaData.addDataSourceVisited(dsName);
/*  262 */           result = strategy.getObjectById(argId, argQueryToken);
/*  263 */           metaData.setPersistable((IPersistable)result);
/*      */         }
/*  265 */         catch (UnsupportedOperationException ee) {
/*  266 */           if (LOGGER_DEBUG_ENABLED) {
/*  267 */             logger_.debug("Datasource: " + dsName + " does not support getObjectById for id: " + argId);
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*  272 */         if (LOGGER_DEBUG_ENABLED) {
/*  273 */           logger_.debug("getObjectById (" + argId + ") on datasource: " + dsName + " resulted in object: " + result);
/*      */         }
/*      */ 
/*      */         
/*  277 */         scanOfflineSources = false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  282 */         if (result != null) {
/*  283 */           metaData.setSuccessfulDataSource(dsName);
/*      */           
/*  285 */           if (strategy.isFullGraphProvided()) {
/*      */             
/*  287 */             applyPersistenceRules(metaData, false, argType);
/*      */             
/*  289 */             if (LOGGER_DEBUG_ENABLED) {
/*  290 */               logger_.debug("getObjectById (" + argId + ") returning because strategy reports full graph is provided: " + result);
/*      */             }
/*      */ 
/*      */             
/*  294 */             return result;
/*      */           } 
/*      */           
/*  297 */           if (LOGGER_DEBUG_ENABLED) {
/*  298 */             logger_.debug("getObjectById (" + argId + ") preferredDataSource is now: " + dsName);
/*      */           }
/*      */           
/*  301 */           preferredDataSource = strategy;
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*  306 */       } catch (FailoverException ee) {
/*  307 */         StatusMgr.getInstance().notifyOffline(dsName, ee);
/*  308 */         if (argOperationInfo != null) {
/*  309 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */       }
/*  312 */       catch (RetryException ee) {
/*  313 */         StatusMgr.getInstance().notifyOffline(dsName, FailoverException.getNewException((Throwable)ee, dsName));
/*  314 */         if (argOperationInfo != null) {
/*  315 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  324 */     if (result != null) {
/*  325 */       result = loadRelationships(result, preferredDataSource, argQueryToken, false);
/*      */     } else {
/*      */       
/*  328 */       if (LOGGER_DEBUG_ENABLED) {
/*  329 */         logger_.debug("getObjectById (" + argId + ") failed, throwing ObjectNotFoundException.");
/*      */       }
/*  331 */       throw new ObjectNotPresentException("Lookup failed for id type " + argId
/*  332 */           .getClass().getName() + " value: " + argId);
/*      */     } 
/*      */     
/*  335 */     if (LOGGER_DEBUG_ENABLED) {
/*  336 */       logger_.debug("getObjectById (" + argId + ") succeeded, returning result: " + result);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  341 */     applyPersistenceRules(metaData, false, argType);
/*      */     
/*  343 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObjectByQuery(String argQueryKey, Map<String, Object> argParams, IPersistenceMgrType argPmType) {
/*  362 */     return getObjectByQuery(new QueryRequest(argQueryKey, argParams, argPmType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReplicationEnabled() {
/*  371 */     return (!this._persistenceDefaults.isTraining() && ReplicationStrategyHelper.isReplicationEnabled() && this.replicationEnabled_);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T makePersistent(T argObject, long argTimeout) {
/*  387 */     if (LOGGER_DEBUG_ENABLED) {
/*  388 */       logger_.debug("Begin makePersistent on object " + argObject);
/*      */     }
/*  390 */     this.retryCountMap_ = new HashMap<>(4);
/*      */ 
/*      */ 
/*      */     
/*  394 */     T objToPersist = applyManagerPersistenceRules(argObject);
/*      */     
/*  396 */     if (objToPersist != null) {
/*      */ 
/*      */       
/*  399 */       List<? extends IPersistable> persistableList = getPersistables(objToPersist);
/*      */       
/*  401 */       if (persistableList.isEmpty()) {
/*  402 */         logger_.debug("There are no objects to persist contained within " + argObject + ".  Returning.");
/*  403 */         return argObject;
/*      */       } 
/*      */       
/*  406 */       boolean complete = false;
/*  407 */       long START_TIME = System.currentTimeMillis();
/*      */ 
/*      */       
/*  410 */       int maxRetries = 10;
/*      */ 
/*      */ 
/*      */       
/*  414 */       while (!complete) {
/*      */         
/*  416 */         TransactionToken token = startTransaction(persistableList);
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  421 */           if (maxRetries-- <= 0) {
/*  422 */             rollbackTransaction(token);
/*  423 */             throw new PersistenceCancelledException("makePersistent call being cancelled because absolute maxRetries (10) has been exceeded");
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  428 */           for (IPersistable persistable : persistableList) {
/*  429 */             IPersistenceStrategy strategy = getPersistenceStrategy(persistable);
/*      */ 
/*      */             
/*  432 */             PersistableMetaData metaData = new PersistableMetaData("OBJECT_PERSISTED");
/*      */             
/*  434 */             metaData.setPersistable(persistable);
/*      */             
/*  436 */             if (strategy == null) {
/*  437 */               throw handleNoStrategiesForPersistence(token, objToPersist, persistable);
/*      */             }
/*  439 */             String dsName = strategy.getDataSourceName();
/*      */             
/*  441 */             if (LOGGER_DEBUG_ENABLED) {
/*  442 */               logger_.debug("Calling makePersistent on strategy: " + dsName + " with persistable: " + persistable);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*  447 */             metaData.addDataSourceVisited(dsName);
/*  448 */             persistable = applyPersistenceRules(metaData, true, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  455 */             strategy.makePersistent(token, persistable);
/*      */ 
/*      */             
/*  458 */             List<String> successfulDSNames = getSuccessfulDSNames(persistable, dsName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/*  465 */               replicateData(token, dsName, persistable, successfulDSNames);
/*      */             }
/*  467 */             catch (ReplicationException ex) {
/*  468 */               logger_.error("Replication of [" + persistable + "] after writing to [" + dsName + "]failed!", (Throwable)ex);
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  473 */             long ELAPSED_TIME = System.currentTimeMillis() - START_TIME;
/*      */             
/*  475 */             if (argTimeout > 0L && ELAPSED_TIME >= argTimeout) {
/*  476 */               throw new PersistenceCancelledException("makePersistent call sucessfully cancelled due to timeout, transaction rolled back. (timeoutValue: " + argTimeout + " elapsed time: " + ELAPSED_TIME);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  482 */           commitTransaction(token, persistableList);
/*  483 */           complete = true;
/*      */         }
/*  485 */         catch (PersistenceCancelledException ex) {
/*  486 */           complete = false;
/*  487 */           handlePersistenceCancelled(token, ex);
/*      */         }
/*  489 */         catch (RetryException ex) {
/*  490 */           complete = false;
/*  491 */           handlePersistenceRetry(token, ex);
/*      */         }
/*  493 */         catch (FailoverException ex) {
/*  494 */           complete = false;
/*  495 */           handlePersistenceFailover(token, ex);
/*      */         }
/*  497 */         catch (PrimaryKeyViolationException ex) {
/*  498 */           complete = false;
/*  499 */           handlePrimaryKeyViolation(token, ex, objToPersist);
/*      */         }
/*  501 */         catch (Exception ex) {
/*  502 */           complete = false;
/*  503 */           handleGeneralPersistenceException(token, ex, objToPersist);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  508 */       commitDataModelTransaction(objToPersist);
/*      */       
/*  510 */       if (!complete) {
/*  511 */         throw new DtxException("Invalid state in DefaultPersistenceManager - this code should not be executed unless complete = true. Persistable objects will not be saved.");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  517 */     if (LOGGER_DEBUG_ENABLED) {
/*  518 */       logger_.debug("makePersistent completed successfully for object " + argObject);
/*      */     }
/*  520 */     return objToPersist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replicateData(TransactionToken argTransToken, String argCurrentDataSourceName, IPersistable argPersisable, List<String> argExcludedDataSources) {
/*  528 */     if (isReplicationEnabled()) {
/*  529 */       IReplicationStrategy strategy = ReplicationStrategyHelper.getReplicationStategy();
/*      */       
/*  531 */       if (strategy.isReplicationCandidate(argCurrentDataSourceName, argPersisable, argExcludedDataSources)) {
/*  532 */         if (!(argPersisable instanceof IDataAccessObject) && !(argPersisable instanceof QueryRequest)) {
/*  533 */           throw new DtxException("Replication is not yet supported for IPersistable implementation: " + argPersisable
/*  534 */               .getClass().getName() + ". Please implement.");
/*      */         }
/*      */         
/*  537 */         strategy.replicateData(argCurrentDataSourceName, argTransToken, argPersisable, argExcludedDataSources);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReplicationEnabled(boolean argEnabled) {
/*  553 */     this.replicationEnabled_ = argEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IPersistable applyPersistenceRules(PersistableMetaData argMetaData, boolean argApplyRulesAtStrategyLevel, Object argObject) {
/*      */     List<IPersistenceRule> persistenceRules;
/*  572 */     IPersistable persistable = argMetaData.getPersistable();
/*  573 */     IPersistenceMgrType pmType = null;
/*  574 */     if (argObject instanceof IPersistenceMgrType) {
/*  575 */       pmType = (IPersistenceMgrType)argObject;
/*      */     } else {
/*      */       
/*  578 */       pmType = this._pmTypeHelper.getPMTypeForPersistable(argMetaData.getPersistable());
/*      */     } 
/*      */     
/*  581 */     PersistenceMgrTypeDescriptor pmTypeDescriptor = this._persistenceMgrTypeFactory.getPersistenceMgrTypeDescriptor(pmType);
/*      */ 
/*      */     
/*  584 */     if (argApplyRulesAtStrategyLevel) {
/*  585 */       persistenceRules = pmTypeDescriptor.getPersistenceStrategyRules();
/*      */     } else {
/*      */       
/*  588 */       persistenceRules = pmTypeDescriptor.getPersistenceManagerRules();
/*      */     } 
/*      */     
/*  591 */     for (IPersistenceRule persistenceRule : persistenceRules) {
/*  592 */       if (persistenceRule.isApplicable(argMetaData, argObject)) {
/*  593 */         persistable = persistenceRule.applyRule(argMetaData, argObject);
/*  594 */         argMetaData.setPersistable(persistable);
/*      */       } 
/*      */     } 
/*  597 */     return persistable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void commitTransaction(TransactionToken argToken, List<? extends IPersistable> argPersistables) throws PersistenceException {
/*  610 */     if (LOGGER_DEBUG_ENABLED) {
/*  611 */       logger_.debug("Committing transaction " + argToken);
/*      */     }
/*      */     
/*  614 */     DataSourceTransactionManager.getInstance().commit(argToken);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  619 */     for (IPersistable persistable : argPersistables) {
/*  620 */       if (persistable instanceof IDataAccessObject) {
/*  621 */         IDataAccessObject dao = (IDataAccessObject)persistable;
/*      */         
/*  623 */         if (DaoState.isNew(dao) || DaoState.isUpdated(dao)) {
/*  624 */           dao.setObjectState(DaoState.CLEAN.intVal());
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getObjectByQuery(QueryRequest argQueryRequest, PmOperationInfo argOperationInfo) {
/*  643 */     QueryToken token = new QueryToken(argQueryRequest);
/*      */     try {
/*  645 */       return getObjectByQuery(argQueryRequest, token, argOperationInfo);
/*      */     } finally {
/*      */       
/*  648 */       QueryResourceManager.getInstance().closeQueryResources(token);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getObjectByQuery(QueryRequest argQueryRequest, QueryToken argQueryToken, PmOperationInfo argOperationInfo) {
/*  668 */     String queryKey = argQueryRequest.getQueryKey();
/*  669 */     Map<String, Object> params = argQueryRequest.getParams();
/*      */     
/*  671 */     if (LOGGER_DEBUG_ENABLED) {
/*  672 */       logger_.debug("Begin getObjectByQuery. Query key: " + queryKey + " params: " + params);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  678 */     IQueryHandler handler = DataFactory.getInstance().getQueryHandler(queryKey);
/*      */     
/*  680 */     if (LOGGER_DEBUG_ENABLED) {
/*  681 */       logger_.debug("getObjectByQuery using query handler: " + handler + " for query: " + queryKey);
/*      */     }
/*      */     
/*  684 */     Object<IDataModel> result = null;
/*      */ 
/*      */     
/*  687 */     IPersistenceMgrType pmType = (argQueryRequest.getPmType() != null) ? argQueryRequest.getPmType() : this._pmTypeHelper.getPMTypeByQueryKey(queryKey, params);
/*      */     
/*  689 */     List<PmStrategyInfo> strategies = this._pmTypeHelper.getLookupStrategies(pmType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  695 */     if (strategies.isEmpty()) {
/*  696 */       logNoDatasourceWarning(pmType, "getObjectByQuery for key: " + queryKey + " will fail without trying to pull the data.");
/*      */       
/*  698 */       throw new DataSourceUnavailableException("Lookup failed for Query Key: " + queryKey + " There were no available datasources.");
/*      */     } 
/*      */ 
/*      */     
/*  702 */     boolean scanOfflineSources = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  707 */     IPersistenceStrategy preferredDataSource = null;
/*  708 */     PersistableMetaData metaData = new PersistableMetaData("OBJECT_QUERIED");
/*  709 */     metaData.setPersistable((IPersistable)argQueryRequest);
/*      */     
/*  711 */     for (PmStrategyInfo strategyInfo : strategies) {
/*      */       
/*  713 */       if (!strategyInfo.isCurrentlyAvailable()) {
/*  714 */         if (argOperationInfo != null) {
/*  715 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  721 */       IPersistenceStrategy strategy = strategyInfo.getStrategy();
/*  722 */       String dsName = strategy.getDataSourceName();
/*      */       
/*      */       try {
/*  725 */         if (!strategy.isOnlineStrategyType() && !scanOfflineSources) {
/*  726 */           if (LOGGER_DEBUG_ENABLED) {
/*  727 */             logger_
/*  728 */               .debug("getObjectByQuery is aborting because no result was found on online strategies");
/*      */           }
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  737 */           metaData.addDataSourceVisited(dsName);
/*  738 */           result = (Object<IDataModel>)strategy.getObjectByQuery(queryKey, params, argQueryToken);
/*      */           
/*  740 */           applyPersistenceRules(metaData, true, result);
/*      */         }
/*  742 */         catch (UnsupportedOperationException ee) {
/*  743 */           if (LOGGER_DEBUG_ENABLED) {
/*  744 */             logger_.debug("Datasource: " + dsName + " does not support getObjectByQuery for qyery key: " + queryKey);
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  750 */         if (LOGGER_DEBUG_ENABLED) {
/*  751 */           logger_.debug("getObjectByQuery got result " + result + " on datasource: " + dsName + " for query key: " + queryKey);
/*      */         }
/*      */ 
/*      */         
/*  755 */         scanOfflineSources = false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  760 */         if (result != null) {
/*  761 */           metaData.setSuccessfulDataSource(dsName);
/*      */ 
/*      */ 
/*      */           
/*  765 */           replicateActionQuery(strategy, queryKey, params);
/*      */           
/*  767 */           if (strategy.isFullGraphProvided()) {
/*  768 */             if (LOGGER_DEBUG_ENABLED) {
/*  769 */               logger_.debug("getObjectByQuery is returning " + result + " because  datasource: " + dsName + " is a full graph provider.");
/*      */             }
/*      */             
/*  772 */             applyPersistenceRules(metaData, false, result);
/*      */             
/*  774 */             return result;
/*      */           } 
/*      */           
/*  777 */           preferredDataSource = strategy;
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*  782 */       } catch (FailoverException ee) {
/*  783 */         StatusMgr.getInstance().notifyOffline(dsName, ee);
/*  784 */         if (argOperationInfo != null) {
/*  785 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */       }
/*  788 */       catch (RetryException ee) {
/*  789 */         StatusMgr.getInstance().notifyOffline(dsName, FailoverException.getNewException((Throwable)ee, dsName));
/*  790 */         if (argOperationInfo != null) {
/*  791 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  797 */     applyPersistenceRules(metaData, false, result);
/*      */     
/*  799 */     if (result != null) {
/*      */ 
/*      */ 
/*      */       
/*  803 */       if (handler instanceof dtv.data2.access.query.DtxQueryHandler) {
/*  804 */         if (result instanceof Collection) {
/*  805 */           List<IDataModel> list = asList(result);
/*  806 */           result = (Object<IDataModel>)list;
/*  807 */           for (int ii = 0; ii < list.size(); ii++) {
/*  808 */             if (LOGGER_DEBUG_ENABLED) {
/*  809 */               logger_.debug("getObjectByQuery is loading relationships for model: " + list.get(ii));
/*      */             }
/*  811 */             IDataModel m = loadRelationships(list.get(ii), preferredDataSource, argQueryToken, false);
/*  812 */             list.set(ii, m);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  818 */           throw new DtxException("An unxpected type was returned from DtxQueryHandler. Should be a Collection, but found: " + 
/*  819 */               ObjectUtils.getClassNameFromObject(result));
/*      */         } 
/*      */       }
/*  822 */       if (LOGGER_DEBUG_ENABLED) {
/*  823 */         logger_.debug("getObjectByQuery returning result  " + result + " for query key: " + queryKey);
/*      */       }
/*      */       
/*  826 */       return result;
/*      */     } 
/*      */ 
/*      */     
/*  830 */     String msg = "Lookup failed for Query Key: " + queryKey + " with params: " + StringUtils.truncate(params.toString(), 200);
/*  831 */     throw new ObjectNotPresentException(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<? extends IPersistable> getPersistables(Object argObject) {
/*  846 */     if (argObject == null) {
/*  847 */       throw new DtxException("makePersistent() cannot accept null object");
/*      */     }
/*      */     
/*  850 */     List<? extends IPersistable> persistableList = DaoUtils.getPersistables(argObject);
/*  851 */     return persistableList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IPersistenceStrategy getPersistenceStrategy(IPersistable argPersistable) {
/*  863 */     IPersistenceMgrType pmType = this._pmTypeHelper.getPMTypeForPersistable(argPersistable);
/*      */     
/*  865 */     if (this.pmTypeToStrategyMap_.containsKey(pmType)) {
/*  866 */       return this.pmTypeToStrategyMap_.get(pmType);
/*      */     }
/*      */     
/*  869 */     List<PmStrategyInfo> strategies = this._pmTypeHelper.getPersistenceStrategies(pmType);
/*      */     
/*  871 */     if (strategies == null || strategies.isEmpty()) {
/*  872 */       return null;
/*      */     }
/*      */     
/*  875 */     for (PmStrategyInfo strategyInfo : strategies) {
/*  876 */       if (strategyInfo.isCurrentlyAvailable()) {
/*  877 */         this.pmTypeToStrategyMap_.put(pmType, strategyInfo.getStrategy());
/*  878 */         return strategyInfo.getStrategy();
/*      */       } 
/*      */     } 
/*      */     
/*  882 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<String> getSuccessfulDSNames(IPersistable argPersistable, String argCurDataSource) {
/*      */     List<String> successfulDSNames;
/*  897 */     IPersistenceMgrType pmType = this._pmTypeHelper.getPMTypeForPersistable(argPersistable);
/*      */ 
/*      */     
/*  900 */     if (pmType == null) {
/*  901 */       logger_.error("Persistence Manager not found for type: " + argPersistable.getClass().getName());
/*  902 */       successfulDSNames = new ArrayList<>();
/*      */     
/*      */     }
/*  905 */     else if (this.pmTypeToSuccessfulDSMap_.containsKey(pmType.getName())) {
/*  906 */       successfulDSNames = this.pmTypeToSuccessfulDSMap_.get(pmType.getName());
/*      */     } else {
/*      */       
/*  909 */       successfulDSNames = new ArrayList<>();
/*  910 */       this.pmTypeToSuccessfulDSMap_.put(pmType.getName(), successfulDSNames);
/*      */     } 
/*      */ 
/*      */     
/*  914 */     if (!successfulDSNames.contains(argCurDataSource)) {
/*  915 */       successfulDSNames.add(argCurDataSource);
/*      */     }
/*      */     
/*  918 */     return successfulDSNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadRelationship(IDataModelRelationship argRel, IDataModelImpl argModel, IPersistenceStrategy argPreferredDataSource, QueryToken argQueryToken, boolean isTransientRelationship, PmOperationInfo argOperationInfo) {
/*  938 */     if (argRel.isPropertyRelationship() && 
/*  939 */       !this._pmTypeHelper.isLoadPropertiesEnabled((Class)argModel.getObjectId().getClass()).booleanValue()) {
/*      */       return;
/*      */     }
/*      */     
/*  943 */     if (LOGGER_DEBUG_ENABLED) {
/*  944 */       logger_.debug("Begin loadRelationship. Relationship: " + argRel.getIdentifier() + " Type: " + argRel
/*  945 */           .getType() + " for model: " + argModel + (isTransientRelationship ? " <Transient>" : ""));
/*      */     }
/*      */     
/*  948 */     IDataModelRelationship relationship = argRel;
/*  949 */     IDataModelImpl parentModel = argModel;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  954 */     relationship.setParent((IDataModel)parentModel);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  959 */     IObjectId childObjectId = null;
/*      */     
/*  961 */     if (IDataModelRelationship.RelationshipType.ONE_TO_ONE.equals(relationship.getType())) {
/*  962 */       childObjectId = argPreferredDataSource.getChildObjectIdForRelationship(relationship);
/*      */       
/*  964 */       if (LOGGER_DEBUG_ENABLED) {
/*  965 */         String childClassName = (childObjectId != null) ? childObjectId.getClass().getName() : null;
/*  966 */         logger_.debug("Determined child object for relationship: " + argRel.getIdentifier() + " Type: " + argRel
/*  967 */             .getType() + " to have id: " + childClassName + " value: " + childObjectId);
/*      */       } 
/*      */       
/*  970 */       if (childObjectId == null) {
/*  971 */         if (LOGGER_DEBUG_ENABLED) {
/*  972 */           logger_.debug("loadRelationship is returning without having loaded the relationship: " + argRel
/*  973 */               .getIdentifier() + " Type: " + argRel.getType() + " because childObjectId is null.");
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*  978 */       if (!childObjectId.validate()) {
/*  979 */         if (LOGGER_DEBUG_ENABLED) {
/*  980 */           logger_.debug("loadRelationship is returning without having loaded the relationship: " + argRel
/*  981 */               .getIdentifier() + " Type: " + argRel.getType() + " because childObjectId (" + childObjectId
/*  982 */               .getClass().getName() + " value: " + childObjectId + ") was not valid. This usually means the parent did not have the proper keys to load the relationship.");
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  988 */       if (this.alreadyLoadedModels_.containsKey(childObjectId)) {
/*  989 */         IDataModel peerModel = this.alreadyLoadedModels_.get(childObjectId);
/*      */         
/*  991 */         if (LOGGER_DEBUG_ENABLED) {
/*  992 */           logger_.debug("loadRelationship found an entry for (" + childObjectId + ") in alreadyLoadedModels_." + relationship
/*  993 */               .getIdentifier() + " will be set to: " + peerModel + " if it's not null on model " + parentModel);
/*      */         }
/*      */ 
/*      */         
/*  997 */         if (peerModel != null) {
/*  998 */           parentModel.setValue(relationship.getIdentifier(), peerModel);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1010 */     IPersistenceMgrType pmType = this._pmTypeHelper.getPMTypeByObjectId(relationship.getChild());
/*      */     
/* 1012 */     if (LOGGER_DEBUG_ENABLED) {
/* 1013 */       logger_.debug("loadRelationship using PM type: " + pmType + " to lookup relationship " + relationship
/* 1014 */           .getIdentifier() + " for model " + parentModel);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1020 */     List<PmStrategyInfo> strategies = null;
/*      */ 
/*      */ 
/*      */     
/* 1024 */     if (argPreferredDataSource != null && (IDataModelRelationship.RelationshipType.ONE_TO_MANY
/* 1025 */       .equals(relationship.getType()) || (relationship
/* 1026 */       .isUseParentPm() && IDataModelRelationship.RelationshipType.ONE_TO_ONE
/* 1027 */       .equals(relationship.getType())))) {
/*      */       
/* 1029 */       strategies = new ArrayList<>(1);
/* 1030 */       strategies.add(new PmStrategyInfo(argPreferredDataSource, true));
/*      */       
/* 1032 */       if (LOGGER_DEBUG_ENABLED) {
/* 1033 */         logger_.debug("loadRelationship using *Preferred Datasource*: " + argPreferredDataSource
/* 1034 */             .getDataSourceName() + " to lookup relationship " + relationship
/* 1035 */             .getIdentifier() + " for model " + parentModel);
/*      */       }
/*      */     } else {
/*      */       
/* 1039 */       strategies = this._pmTypeHelper.getLookupStrategies(pmType);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1045 */     if (strategies.isEmpty()) {
/* 1046 */       logNoDatasourceWarning(pmType, "loadRelationships() for relationship: '" + relationship.getIdentifier() + "' on model: " + parentModel + " will fail without trying to pull the data.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1051 */     boolean scanOfflineSources = true;
/*      */     
/* 1053 */     for (PmStrategyInfo strategyInfo : strategies) {
/*      */       
/* 1055 */       if (!strategyInfo.isCurrentlyAvailable()) {
/* 1056 */         if (argOperationInfo != null) {
/* 1057 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1063 */       IPersistenceStrategy strategy = strategyInfo.getStrategy();
/* 1064 */       String dsName = strategy.getDataSourceName();
/*      */       
/* 1066 */       if (!strategy.isOnlineStrategyType() && !scanOfflineSources) {
/* 1067 */         if (LOGGER_DEBUG_ENABLED) {
/* 1068 */           logger_.debug("loadRelationship returning without having loaded relationship " + relationship
/* 1069 */               .getIdentifier() + " for model " + parentModel + " because a value was not found on the online datasources.");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1080 */       if (strategy.isFullGraphProvided() && 
/* 1081 */         !IDataModelRelationship.RelationshipType.ONE_TO_ONE.equals(relationship.getType())) {
/* 1082 */         if (LOGGER_DEBUG_ENABLED) {
/* 1083 */           logger_.debug("loadRelationship skipped datasource " + dsName + " for relationship " + relationship
/* 1084 */               .getIdentifier() + " on model " + parentModel + " because it is a fullGraphProvider, and therefore does not support relationship lookups.");
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       try {
/* 1091 */         Object relatedObject = null;
/*      */         
/*      */         try {
/* 1094 */           relatedObject = strategy.getObjectByRelationship(relationship, argQueryToken);
/*      */         }
/* 1096 */         catch (UnsupportedOperationException ee) {
/* 1097 */           if (LOGGER_DEBUG_ENABLED) {
/* 1098 */             logger_.debug("Datasource: " + dsName + " does not support getObjectByRelationship for relationship: " + relationship
/*      */                 
/* 1100 */                 .getIdentifier());
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/* 1105 */         if (LOGGER_DEBUG_ENABLED) {
/* 1106 */           logger_.debug("loadRelationship got result " + relatedObject + " for getObjectByRelationship on datasource: " + dsName + " for  relationship " + relationship
/* 1107 */               .getIdentifier() + " on model " + parentModel);
/*      */         }
/*      */ 
/*      */         
/* 1111 */         scanOfflineSources = false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1116 */         if (relatedObject != null) {
/* 1117 */           if (strategy.isFullGraphProvided()) {
/* 1118 */             if (LOGGER_DEBUG_ENABLED) {
/* 1119 */               logger_.debug("loadRelationship is setting " + relationship.getIdentifier() + " to " + relatedObject + " on model " + parentModel + " without recursively calling loadRelationships because datasource: " + dsName + " is a full graph provider");
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 1124 */             parentModel.setValue(relationship.getIdentifier(), relatedObject);
/*      */ 
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */ 
/*      */           
/* 1132 */           if (relatedObject instanceof IDataModel) {
/* 1133 */             if (LOGGER_DEBUG_ENABLED) {
/* 1134 */               logger_
/* 1135 */                 .debug("loadRelationship loading relationships for relatedObject  " + relatedObject);
/*      */             }
/*      */             
/* 1138 */             if (isTransientRelationship && relatedObject instanceof IDataModelImpl) {
/* 1139 */               ((IDataModelImpl)relatedObject).getDAO().setTransientObject(true);
/*      */             }
/*      */             
/* 1142 */             relatedObject = loadRelationships((IDataModel)relatedObject, strategy, argQueryToken, isTransientRelationship);
/*      */           
/*      */           }
/* 1145 */           else if (relatedObject instanceof List) {
/* 1146 */             List<IDataModel> list = asList(relatedObject);
/*      */ 
/*      */             
/* 1149 */             for (int ii = 0; ii < list.size(); ii++) {
/* 1150 */               IDataModel m = list.get(ii);
/* 1151 */               if (LOGGER_DEBUG_ENABLED) {
/* 1152 */                 logger_.debug("loadRelationship loading relationships for relatedObject list element  " + ii + ": " + m);
/*      */               }
/*      */               
/* 1155 */               m = loadRelationships(m, strategy, argQueryToken, isTransientRelationship);
/*      */               
/* 1157 */               if (isTransientRelationship && m instanceof IDataModelImpl) {
/* 1158 */                 ((IDataModelImpl)m).getDAO().setTransientObject(true);
/*      */               }
/*      */               
/* 1161 */               list.set(ii, m);
/*      */             } 
/*      */           } 
/*      */           
/* 1165 */           if (LOGGER_DEBUG_ENABLED) {
/* 1166 */             logger_.debug("loadRelationship setting  " + relationship.getIdentifier() + " to " + relatedObject + " on: " + parentModel);
/*      */           }
/*      */           
/* 1169 */           parentModel.setValue(relationship.getIdentifier(), relatedObject);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1179 */         if (childObjectId != null);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1184 */       catch (FailoverException ee) {
/* 1185 */         StatusMgr.getInstance().notifyOffline(dsName, ee);
/* 1186 */         if (argOperationInfo != null) {
/* 1187 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */       }
/* 1190 */       catch (RetryException ee) {
/* 1191 */         StatusMgr.getInstance().notifyOffline(dsName, FailoverException.getNewException((Throwable)ee, dsName));
/* 1192 */         if (argOperationInfo != null) {
/* 1193 */           argOperationInfo.setOfflineDatasourceFound();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IDataModel loadRelationships(IDataModel argDataModel, IPersistenceStrategy argPreferredDataSource, QueryToken argQueryToken, boolean ancestorHasTransientRelationship) {
/* 1212 */     if (LOGGER_DEBUG_ENABLED) {
/* 1213 */       logger_.debug("Begin loadRelationships for model: " + argDataModel + " with preferredDataSource: " + ((argPreferredDataSource != null) ? argPreferredDataSource
/* 1214 */           .getDataSourceName() : null));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1221 */     if (this.alreadyLoadedModels_.containsKey(argDataModel.getObjectId())) {
/* 1222 */       if (LOGGER_DEBUG_ENABLED) {
/* 1223 */         logger_.debug("loadRelationships found model: " + argDataModel + " in the alreadyLoadedModels_ map.  Returning.");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1231 */       IDataModel alreadyLoaded = this.alreadyLoadedModels_.get(argDataModel.getObjectId());
/*      */       
/* 1233 */       if (alreadyLoaded != null) {
/* 1234 */         return alreadyLoaded;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1241 */     IDataModelImpl model = (IDataModelImpl)argDataModel;
/* 1242 */     IDataAccessObject dao = model.getDAO();
/* 1243 */     IDataModelRelationship[] relationships = DataModelFactory.getModelRelationships(dao);
/* 1244 */     if (relationships != null) {
/* 1245 */       for (IDataModelRelationship relationship : relationships) {
/* 1246 */         loadRelationship(relationship, model, argPreferredDataSource, argQueryToken, relationship
/* 1247 */             .isTransientRelationship() | ancestorHasTransientRelationship, null);
/*      */       }
/*      */     }
/* 1250 */     dao.setObjectState(DaoState.CLEAN.intVal());
/* 1251 */     return argDataModel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rollbackTransaction(TransactionToken argToken) throws PersistenceException {
/* 1263 */     if (LOGGER_DEBUG_ENABLED) {
/* 1264 */       logger_.debug("Rolling back transaction " + argToken);
/*      */     }
/* 1266 */     DataSourceTransactionManager.getInstance().rollback(argToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TransactionToken startTransaction(Object argObject) throws PersistenceException {
/* 1279 */     if (this.pmTypeToStrategyMap_ == null) {
/* 1280 */       this.pmTypeToStrategyMap_ = new HashMap<>();
/*      */     }
/* 1282 */     this.pmTypeToStrategyMap_.clear();
/*      */     
/* 1284 */     if (this.pmTypeToSuccessfulDSMap_ == null) {
/* 1285 */       this.pmTypeToSuccessfulDSMap_ = new HashMap<>();
/*      */     }
/* 1287 */     this.pmTypeToSuccessfulDSMap_.clear();
/*      */     
/* 1289 */     IDataAccessObject sampleDao = DaoUtils.getSampleDao(argObject);
/* 1290 */     IObjectId objectIdTransTokenRandomSeed = null;
/*      */     
/* 1292 */     if (sampleDao != null) {
/* 1293 */       objectIdTransTokenRandomSeed = sampleDao.getObjectId();
/*      */     }
/*      */ 
/*      */     
/* 1297 */     TransactionToken token = DataSourceTransactionManager.getInstance().startTransaction(objectIdTransTokenRandomSeed);
/*      */     
/* 1299 */     if (LOGGER_DEBUG_ENABLED) {
/* 1300 */       logger_.debug("Starting transaction " + token);
/*      */     }
/*      */     
/* 1303 */     return token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> T applyManagerPersistenceRules(T argObjectToPersist) {
/* 1311 */     List<IPersistable> persistables = new ArrayList<>();
/*      */ 
/*      */ 
/*      */     
/* 1315 */     for (DaoUtils.PersistableLink rootLink : DaoUtils.getRootPersistables(argObjectToPersist)) {
/* 1316 */       IPersistable rootPersistable = rootLink.getPersistable();
/* 1317 */       IPersistenceMgrType pmType = this._pmTypeHelper.getPMTypeForPersistable(rootPersistable);
/* 1318 */       PersistableMetaData metaData = new PersistableMetaData("OBJECT_PERSISTED");
/* 1319 */       metaData.setPersistable(rootPersistable);
/*      */       
/* 1321 */       persistables.add(applyPersistenceRules(metaData, false, pmType));
/*      */     } 
/*      */ 
/*      */     
/* 1325 */     T objToPersist = argObjectToPersist;
/*      */     
/* 1327 */     if (!persistables.isEmpty()) {
/* 1328 */       if (objToPersist instanceof Collection) {
/*      */ 
/*      */ 
/*      */         
/* 1332 */         ((Collection)objToPersist).clear();
/* 1333 */         ((Collection<IPersistable>)objToPersist).addAll(persistables);
/*      */       }
/*      */       else {
/*      */         
/* 1337 */         objToPersist = (T)persistables.get(0);
/*      */       } 
/*      */     }
/* 1340 */     return objToPersist;
/*      */   }
/*      */ 
/*      */   
/*      */   private List<IDataModel> asList(Object relatedObject) {
/* 1345 */     if (relatedObject == null) {
/* 1346 */       return null;
/*      */     }
/* 1348 */     if (relatedObject instanceof Collection) {
/* 1349 */       return new ArrayList<>((Collection<? extends IDataModel>)relatedObject);
/*      */     }
/*      */     
/* 1352 */     throw new DtxException("asList argument must be a collection at the very least, but was: " + relatedObject);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void commitDataModelTransaction(Object argObject) {
/* 1358 */     if (argObject instanceof Collection) {
/* 1359 */       for (Object dataObject : argObject) {
/* 1360 */         if (dataObject instanceof IDataModel) {
/* 1361 */           ((IDataModel)dataObject).commitTransaction();
/*      */         }
/*      */       }
/*      */     
/* 1365 */     } else if (argObject instanceof IDataModel) {
/* 1366 */       ((IDataModel)argObject).commitTransaction();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleGeneralPersistenceException(TransactionToken argToken, Exception argEx, Object argObjectToSave) {
/* 1373 */     logger_.error("Exception caught persisting object: " + argObjectToSave, argEx);
/* 1374 */     DaoUtils.logFailedPersistence(argEx, argObjectToSave);
/* 1375 */     rollbackTransaction(argToken);
/*      */     
/* 1377 */     throw new PersistenceException(argEx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PersistenceException handleNoStrategiesForPersistence(TransactionToken argToken, Object argObjectToPersist, IPersistable argCurrentPersistable) {
/* 1392 */     String msg = "!!! makePersistent() failure !!! Cannot persist object: " + argCurrentPersistable + " No Available Datasources.";
/*      */ 
/*      */     
/* 1395 */     if (!(argCurrentPersistable instanceof QueryRequest)) {
/* 1396 */       logNoDatasourceWarning(this._pmTypeHelper.getPMTypeForPersistable(argCurrentPersistable), msg);
/*      */     }
/*      */     
/* 1399 */     Throwable throwable = new Throwable("STACK TRACE - Could not save data due to no available datasources");
/*      */ 
/*      */     
/* 1402 */     logger_.error(msg, throwable);
/* 1403 */     rollbackTransaction(argToken);
/* 1404 */     DaoUtils.logFailedPersistence(throwable, argObjectToPersist);
/*      */     
/* 1406 */     return new PersistenceException(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handlePersistenceCancelled(TransactionToken argToken, PersistenceCancelledException argException) {
/* 1418 */     logger_.warn("Persistence was intentionally cancelled. " + argException.toString());
/* 1419 */     rollbackTransaction(argToken);
/* 1420 */     throw argException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handlePersistenceFailover(TransactionToken argToken, FailoverException argFailover) {
/* 1430 */     if (LOGGER_DEBUG_ENABLED) {
/* 1431 */       logger_.debug("Failover occurred.  Rollback the transaction and start over.");
/*      */     }
/* 1433 */     StatusMgr.getInstance().notifyOffline(argFailover.getDataSourceName(), argFailover);
/* 1434 */     rollbackTransaction(argToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handlePersistenceRetry(TransactionToken argToken, RetryException argRetry) {
/* 1444 */     rollbackTransaction(argToken);
/*      */     
/* 1446 */     if (LOGGER_DEBUG_ENABLED) {
/* 1447 */       logger_.debug("Retry exception occurred.  Rollback the transaction and start over.");
/*      */     }
/*      */     
/* 1450 */     Integer retryCountObj = this.retryCountMap_.get(argRetry.getDataSourceName());
/*      */     
/* 1452 */     int retryCount = (retryCountObj != null) ? retryCountObj.intValue() : 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1457 */     if (retryCount >= MAX_RETRIES) {
/*      */       
/* 1459 */       FailoverException ee = FailoverException.getNewException("Failing over datasource: " + argRetry.getDataSourceName() + " because the retry count (" + MAX_RETRIES + ") was exceeded.", (Throwable)argRetry, argRetry
/* 1460 */           .getDataSourceName());
/* 1461 */       StatusMgr.getInstance().notifyOffline(argRetry.getDataSourceName(), ee);
/*      */     } else {
/*      */       
/*      */       try {
/* 1465 */         retryCount++;
/* 1466 */         this.retryCountMap_.put(argRetry.getDataSourceName(), Integer.valueOf(retryCount));
/* 1467 */         Thread.sleep(RETRY_WAIT);
/*      */       }
/* 1469 */       catch (InterruptedException interruptedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handlePrimaryKeyViolation(TransactionToken argToken, PrimaryKeyViolationException argEx, Object argObjectToSave) {
/* 1478 */     rollbackTransaction(argToken);
/* 1479 */     logger_.error("Primary Key Violation while persisting object: " + argObjectToSave, (Throwable)argEx);
/* 1480 */     DaoUtils.logFailedPersistence((Throwable)argEx, argObjectToSave);
/* 1481 */     throw new PersistenceException(argEx);
/*      */   }
/*      */   
/*      */   private void logNoDatasourceWarning(IPersistenceMgrType argPmType, String argMsg) {
/* 1485 */     logger_.warn("** No Available Datasources were found for PM Type: " + argPmType + "** They are all offline or disabled. Check the PersistenceManagerConfig.xml and related. " + argMsg);
/*      */ 
/*      */ 
/*      */     
/* 1489 */     this._pmTypeHelper.logPmTypeStatus(argPmType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void replicateActionQuery(IPersistenceStrategy argStrategy, String argQueryKey, Map<String, Object> argParams) {
/* 1498 */     if (isReplicationEnabled()) {
/* 1499 */       IReplicationStrategy strategy = ReplicationStrategyHelper.getReplicationStategy();
/*      */       
/* 1501 */       if (strategy.isReplicationCandidate(argStrategy.getDataSourceName(), argQueryKey, null)) {
/*      */ 
/*      */ 
/*      */         
/* 1505 */         QueryRequest queryBundle = new QueryRequest();
/* 1506 */         queryBundle.setQueryKey(argQueryKey);
/* 1507 */         queryBundle.setParams(argParams);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1512 */         TransactionToken tempToken = new TransactionToken(argParams.hashCode());
/* 1513 */         strategy.replicateData(argStrategy.getDataSourceName(), tempToken, (IPersistable)queryBundle, null);
/* 1514 */         DataSourceTransactionManager.getInstance().commit(tempToken);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PersistenceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */