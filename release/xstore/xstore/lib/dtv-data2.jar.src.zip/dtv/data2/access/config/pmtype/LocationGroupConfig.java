/*    */ package dtv.data2.access.config.pmtype;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocationGroupConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 22 */   private final List<DataSourceLocationConfig> lookupConfigs_ = new ArrayList<>();
/* 23 */   private final List<DataSourceLocationConfig> persistenceConfigs_ = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean sorted_ = false;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<DataSourceLocationConfig> getLookupLocations() {
/* 33 */     sort();
/* 34 */     return this.lookupConfigs_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<DataSourceLocationConfig> getPersistenceLocations() {
/* 42 */     sort();
/* 43 */     return this.persistenceConfigs_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 49 */     if (argValue instanceof DataSourceLocationConfig) {
/* 50 */       DataSourceLocationConfig value = (DataSourceLocationConfig)argValue;
/* 51 */       if ("LookupLocation".equalsIgnoreCase(argKey)) {
/*    */         
/* 53 */         if (value.getOrder() < 0) {
/* 54 */           value.setOrder(this.lookupConfigs_.size());
/*    */         }
/* 56 */         this.lookupConfigs_.add(value);
/*    */         return;
/*    */       } 
/* 59 */       if ("PersistenceLocation".equalsIgnoreCase(argKey)) {
/*    */         
/* 61 */         if (value.getOrder() < 0) {
/* 62 */           value.setOrder(this.persistenceConfigs_.size());
/*    */         }
/* 64 */         this.persistenceConfigs_.add(value);
/*    */         return;
/*    */       } 
/*    */     } 
/* 68 */     warnUnsupported(argKey, argValue);
/*    */   }
/*    */   
/*    */   private void sort() {
/* 72 */     if (!this.sorted_) {
/* 73 */       Collections.sort(this.lookupConfigs_);
/* 74 */       Collections.sort(this.persistenceConfigs_);
/* 75 */       this.sorted_ = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\pmtype\LocationGroupConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */