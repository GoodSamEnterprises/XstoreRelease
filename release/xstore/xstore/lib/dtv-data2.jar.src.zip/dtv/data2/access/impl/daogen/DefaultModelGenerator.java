/*      */ package dtv.data2.access.impl.daogen;
/*      */ 
/*      */ import dtv.util.FileUtils;
/*      */ import dtv.util.StringUtils;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DefaultModelGenerator
/*      */   implements IModelGenerator
/*      */ {
/*      */   private final DaoGenHelper _helper;
/*      */   
/*      */   public DefaultModelGenerator(DaoGenHelper argHelper) {
/*   34 */     this._helper = argHelper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String generateModel(DtxDefinition argDtxDefinition) throws IOException {
/*   41 */     StringBuilder sb = new StringBuilder(20480);
/*   42 */     generateHeader(sb, argDtxDefinition);
/*   43 */     generateFields(sb, argDtxDefinition);
/*   44 */     generateDaoMethods(sb, argDtxDefinition);
/*      */     
/*   46 */     List<DtxRelationship> relationships = argDtxDefinition.getRelationships();
/*      */     
/*   48 */     if (DaoGenHelper.isPropertyChildNeeded(argDtxDefinition)) {
/*   49 */       generatePropertyMethods(sb, argDtxDefinition);
/*      */     }
/*      */     
/*   52 */     generateRelationshipFields(sb, relationships);
/*   53 */     generateRelationshipMethods(sb, argDtxDefinition, relationships);
/*      */     
/*   55 */     if (!argDtxDefinition.isProperties()) {
/*   56 */       generateExtensionMethods(sb, argDtxDefinition);
/*      */     }
/*      */     
/*   59 */     generateTransactionMethods(sb, argDtxDefinition);
/*      */     
/*   61 */     String dtjContents = getDtjContents(argDtxDefinition.getDtj());
/*      */     
/*   63 */     if (dtjContents.indexOf("private void readObject") == -1) {
/*   64 */       generateCustomSerialization(sb, argDtxDefinition);
/*      */     }
/*      */     
/*   67 */     sb = overrideMethods(argDtxDefinition, sb, dtjContents);
/*      */     
/*   69 */     sb.append(dtjContents);
/*   70 */     generateFooter(sb, argDtxDefinition);
/*      */     
/*   72 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addListInitializer(StringBuilder out, DtxRelationship relationship, String argInitializeWith, String argElseSetList) {
/*   85 */     String initializeFieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*   86 */     out.append("    if (").append(initializeFieldName).append(" == null) {\n");
/*   87 */     out.append("      ").append(initializeFieldName).append(" = new HistoricalList<")
/*   88 */       .append(relationship.getChild().getInterface()).append(">(").append(argInitializeWith).append(");\n");
/*   89 */     out.append("    }");
/*   90 */     if (argElseSetList != null) {
/*   91 */       out.append(" else { \n");
/*   92 */       out.append("      ").append(initializeFieldName).append(".setCurrentList(").append(argInitializeWith)
/*   93 */         .append(");\n");
/*   94 */       out.append("    }");
/*      */     } 
/*   96 */     out.append("\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateCustomSerialization(StringBuilder out, DtxDefinition argDtx) {
/*  106 */     out.append("  private void readObject(java.io.ObjectInputStream argStream)\n                         throws java.io.IOException, ClassNotFoundException {\n    argStream.defaultReadObject();\n  }\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateDaoMethods(StringBuilder out, DtxDefinition argDtx) {
/*  119 */     if (!argDtx.isExtended()) {
/*  120 */       out.append("  @Override\n  public String toString() {\n    return super.toString() + \" Id: \" + this.getObjectId();\n  }\n\n");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  126 */     out.append("  @Override\n  public void initDAO() {\n    setDAO(new ");
/*      */ 
/*      */     
/*  129 */     out.append(argDtx.getName());
/*  130 */     out.append("DAO());\n  }\n\n  /**\n   * Return the data access object associated with this data model\n   * @return our DAO, properly casted\n   */\n  private ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  138 */     out.append(argDtx.getName());
/*  139 */     out.append("DAO getDAO_() {\n     return (");
/*      */     
/*  141 */     out.append(argDtx.getName());
/*  142 */     out.append("DAO) _daoImpl;\n  }\n\n");
/*      */ 
/*      */ 
/*      */     
/*  146 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*      */ 
/*      */       
/*  149 */       if (!argDtx.isExtended() || !field.isPrimaryKey() || 
/*  150 */         !argDtx.getRelationships(DtxRelationship.ONE_MANY).isEmpty()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  155 */         generateFieldGetter(out, argDtx, field);
/*  156 */         generateFieldSetter(out, argDtx, field);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateEncryptedFieldGetter(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField argField) {
/*  171 */     String getterName = DaoGenUtils.getGetterNameForField(argField);
/*  172 */     String encryptedGetterName = DaoGenUtils.getGetterNameForField(argField) + "Encrypted";
/*      */     
/*  174 */     out.append("  /**\n   * Gets the value of the ");
/*      */     
/*  176 */     out.append(argField.getColumn());
/*  177 */     out.append(" field.\n   * @return The encrypted value of the field.\n   */\n  public ");
/*      */ 
/*      */ 
/*      */     
/*  181 */     out.append(DaoGenUtils.getVariableType(argField.getType()));
/*  182 */     out.append(" ");
/*  183 */     out.append(encryptedGetterName);
/*  184 */     out.append("() {\n");
/*      */     
/*  186 */     out.append("    return getDAO_().");
/*  187 */     out.append(getterName);
/*  188 */     out.append("()");
/*  189 */     out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  190 */     out.append(";\n");
/*      */     
/*  192 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateExtensionMethods(StringBuilder out, DtxDefinition argDtx) {
/*  202 */     out.append("  public IDataModel get" + argDtx.getName() + "Ext() {\n");
/*  203 */     out.append("    return _myExtension;\n");
/*  204 */     out.append("  }\n\n");
/*      */     
/*  206 */     out.append("  public void set" + argDtx.getName() + "Ext(IDataModel argExt) {\n");
/*  207 */     out.append("    _myExtension = argExt;\n");
/*  208 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFieldGetter(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField argField) {
/*  222 */     String getterName = DaoGenUtils.getGetterNameForField(argField);
/*      */     
/*  224 */     out.append("  /**\n   * Gets the value of the ");
/*      */     
/*  226 */     out.append(argField.getColumn());
/*  227 */     out.append(" field.\n   * @return The value of the field.\n   */\n  public ");
/*      */ 
/*      */ 
/*      */     
/*  231 */     out.append(DaoGenUtils.getVariableType(argField.getType()));
/*  232 */     out.append(" ");
/*  233 */     out.append(getterName);
/*  234 */     out.append("() {\n");
/*      */     
/*  236 */     if ("Boolean".equalsIgnoreCase(argField.getType())) {
/*  237 */       out.append("    if (getDAO_().");
/*  238 */       out.append(getterName);
/*  239 */       out.append("() != null) {\n      return getDAO_().");
/*      */       
/*  241 */       out.append(getterName);
/*  242 */       out.append("()");
/*  243 */       out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  244 */       out.append(";\n    }\n    else {\n      return false;\n    }\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  250 */     else if ("Integer".equalsIgnoreCase(argField.getType()) || "Long"
/*  251 */       .equalsIgnoreCase(argField.getType())) {
/*      */       
/*  253 */       out.append("    if (getDAO_().");
/*  254 */       out.append(getterName);
/*  255 */       out.append("() != null) {\n      return getDAO_().");
/*      */       
/*  257 */       out.append(getterName);
/*  258 */       out.append("()");
/*  259 */       out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  260 */       out.append(";\n    }\n    else {\n");
/*      */ 
/*      */       
/*  263 */       if (argField.getDefaultValueIfNull() == null) {
/*  264 */         out.append("      return 0; // no default specified in the dtx; we default to 0\n");
/*      */       }
/*  266 */       else if (argField.getDefaultValueIfNull() instanceof Long) {
/*  267 */         out.append("      return ");
/*  268 */         out.append(argField.getDefaultValueIfNull());
/*  269 */         out.append("l; // <<< default specified in .dtx\n");
/*      */       } else {
/*      */         
/*  272 */         out.append("      return ");
/*  273 */         out.append(argField.getDefaultValueIfNull());
/*  274 */         out.append("; // <<< default specified in .dtx\n");
/*      */       } 
/*  276 */       out.append("    }\n");
/*      */     
/*      */     }
/*  279 */     else if (!StringUtils.isEmpty(argField.getEncrypt()) && "String".equalsIgnoreCase(argField.getType())) {
/*  280 */       out.append("    return decryptField(\"");
/*  281 */       out.append(argField.getEncrypt());
/*  282 */       out.append("\", ");
/*  283 */       out.append("getDAO_().");
/*  284 */       out.append(getterName);
/*  285 */       out.append("())");
/*  286 */       out.append(";\n");
/*      */     } else {
/*      */       
/*  289 */       out.append("    return getDAO_().");
/*  290 */       out.append(getterName);
/*  291 */       out.append("()");
/*  292 */       out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  293 */       out.append(";\n");
/*      */     } 
/*      */ 
/*      */     
/*  297 */     out.append("  }\n\n");
/*      */     
/*  299 */     if (!StringUtils.isEmpty(argField.getEncrypt()) && "String".equalsIgnoreCase(argField.getType())) {
/*  300 */       generateEncryptedFieldGetter(out, argDtx, argField);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFields(StringBuilder out, DtxDefinition argDtx) {
/*  314 */     for (DtxInverseRelationship rel : argDtx.getInverseRelationships()) {
/*  315 */       out.append("  private ");
/*  316 */       out.append(rel.getParent().getInterface());
/*  317 */       out.append(" _");
/*  318 */       out.append(StringUtils.ensureFirstLowerCase(rel.getName()));
/*  319 */       out.append(";\n");
/*      */     } 
/*      */     
/*  322 */     if ((argDtx.getInverseRelationships()).length > 0) {
/*  323 */       out.append("\n");
/*      */     }
/*      */     
/*  326 */     out.append("\n  private transient boolean _alreadyInStart = false;\n  private transient boolean _alreadyInCommit = false;\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  334 */     out.append("  private IDataModel _myExtension;\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFieldSetter(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField argField) {
/*  349 */     boolean childPrimaryKey = false;
/*      */     
/*  351 */     if (argDtx.isExtended() && argField.isPrimaryKey() && 
/*  352 */       !argDtx.getRelationships(DtxRelationship.ONE_MANY).isEmpty())
/*      */     {
/*      */ 
/*      */       
/*  356 */       childPrimaryKey = true;
/*      */     }
/*      */ 
/*      */     
/*  360 */     String getterName = DaoGenUtils.getGetterNameForField(argField);
/*  361 */     String setterName = DaoGenUtils.getSetterNameForField(argField);
/*  362 */     String argName = DaoGenUtils.getArgNameForField(argField);
/*      */     
/*  364 */     String obj = DaoGenUtils.wrapStatementWithObject(argName, argField.getType());
/*  365 */     out.append("  /**\n");
/*  366 */     out.append("   * Sets the value of the ").append(argField.getColumn()).append(" field.\n");
/*  367 */     out.append("   * @param ").append(argName).append(" The new value for the field.\n");
/*  368 */     out.append("   */\n");
/*  369 */     out.append("  public void ").append(setterName).append("(").append(DaoGenUtils.getVariableType(argField.getType()))
/*  370 */       .append(" ").append(argName).append(") {\n");
/*  371 */     out.append("    if (").append(setterName).append("_noev(").append(argName).append(")) {\n");
/*      */     
/*  373 */     if (!argField.isSuppressed()) {
/*  374 */       out.append("      if (_events != null) {\n");
/*  375 */       out.append("        if (postEventsForChanges()) {\n");
/*  376 */       out.append("          _events.post(").append(argDtx.getInterface()).append(".SET_")
/*  377 */         .append(argField.getName().toUpperCase()).append(", ").append(obj).append(");\n");
/*  378 */       out.append("        }\n");
/*  379 */       out.append("      }\n");
/*      */     } else {
/*      */       
/*  382 */       out.append("      // suppress-event is specified for this field.\n");
/*      */     } 
/*  384 */     out.append("    }\n");
/*  385 */     out.append("  }\n");
/*  386 */     out.append("\n");
/*      */ 
/*      */ 
/*      */     
/*  390 */     out.append("  public boolean ").append(setterName).append("_noev(")
/*  391 */       .append(DaoGenUtils.getVariableType(argField.getType())).append(" ").append(argName).append(") {\n");
/*  392 */     out.append("    boolean ev_postable = false;\n");
/*  393 */     out.append("\n");
/*      */     
/*  395 */     if (!childPrimaryKey) {
/*  396 */       out.append("    if ((getDAO_().").append(getterName).append("() == null && ").append(obj)
/*  397 */         .append(" != null) ||\n");
/*  398 */       out.append("        (getDAO_().").append(getterName).append("() != null && !getDAO_().")
/*  399 */         .append(getterName).append("().equals(").append(obj).append("))) {\n");
/*  400 */       if (!StringUtils.isEmpty(argField.getEncrypt()) && "String".equalsIgnoreCase(argField.getType())) {
/*  401 */         out.append("      getDAO_().").append(setterName).append("(").append("encryptField(\"")
/*  402 */           .append(argField.getEncrypt()).append("\" ,").append(obj).append("));\n");
/*      */       } else {
/*      */         
/*  405 */         out.append("      getDAO_().").append(setterName).append("(").append(obj).append(");\n");
/*      */       } 
/*      */       
/*  408 */       out.append("      ev_postable = true;\n");
/*      */     } else {
/*      */       
/*  411 */       out.append("\n").append("    if (super.").append(setterName).append("_noev(").append(argName)
/*  412 */         .append(")) {\n");
/*      */     } 
/*      */ 
/*      */     
/*  416 */     for (DtxRelationship rel : argDtx.getRelationships(DtxRelationship.ONE_MANY)) {
/*  417 */       for (DtxRelationship.DtxRelationshipField fld : rel.getFields()) {
/*  418 */         if (fld.getParent().equals(argField.getName())) {
/*  419 */           String properChild = StringUtils.ensureFirstUpperCase(fld.getChild());
/*  420 */           out.append("      if (" + rel.getParentAttributeName()).append(" != null) {\n");
/*  421 */           out.append("        // Propagate changes to related objects in relation " + rel.getName())
/*  422 */             .append(".\n");
/*  423 */           out.append("        java.util.Iterator it = " + rel.getParentAttributeName() + ".iterator();\n");
/*  424 */           out.append("        while(it.hasNext()) {\n");
/*  425 */           out.append("          // Use the non-eventing setter directly.\n");
/*  426 */           out.append("          ((" + rel.getChild().getModel() + ") it.next()).set" + properChild + "_noev(" + argName + ");\n");
/*      */           
/*  428 */           out.append("        }\n");
/*  429 */           out.append("      }\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  435 */     for (DtxRelationship rel : argDtx.getRelationships(DtxRelationship.ONE_ONE)) {
/*  436 */       if (!rel.getDependent()) {
/*      */         continue;
/*      */       }
/*  439 */       for (DtxRelationship.DtxRelationshipField fld : rel.getFields()) {
/*  440 */         if (fld.getParent().equals(argField.getName())) {
/*  441 */           String properChild = StringUtils.ensureFirstUpperCase(fld.getChild());
/*  442 */           out.append("      if (" + rel.getParentAttributeName()).append(" != null) {\n");
/*  443 */           out.append("        // Propagate changes to related objects in relation " + rel.getName())
/*  444 */             .append(".\n");
/*  445 */           out.append("          // Use the non-eventing setter directly.\n");
/*  446 */           out.append("          ((" + rel.getChild().getModel() + ")" + rel.getParentAttributeName() + ").set" + properChild + "_noev(" + argName + ");\n");
/*      */           
/*  448 */           out.append("      }\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  453 */     out.append("    }\n");
/*  454 */     out.append("\n");
/*  455 */     out.append("    return ev_postable;\n");
/*  456 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFooter(StringBuilder out, DtxDefinition dtx) {
/*  467 */     out.append("\n");
/*  468 */     out.append("}\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateHeader(StringBuilder out, DtxDefinition argDtx) {
/*  478 */     out.append("package " + argDtx.getPackage() + ";\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  483 */     out.append("import java.math.BigDecimal;\n");
/*  484 */     out.append("import java.util.*;\n");
/*  485 */     out.append("import dtv.data2.access.impl.*;\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  490 */     out.append("import dtv.data2.access.IDataModel;\n");
/*  491 */     out.append("import dtv.data2.access.ModelEventor;\n");
/*      */     
/*  493 */     boolean historicalListImported = false;
/*      */     
/*  495 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*  496 */       if (DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType())) {
/*  497 */         out.append("import " + relationship.getChild().getInterface() + ";\n");
/*      */         continue;
/*      */       } 
/*  500 */       if (!historicalListImported) {
/*  501 */         out.append("import dtv.util.HistoricalList;\n");
/*  502 */         out.append("import dtv.data2.access.*;\n");
/*      */         
/*  504 */         historicalListImported = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  512 */     if (!argDtx.isExtended()) {
/*  513 */       out.append("import ");
/*  514 */       out.append(argDtx.getId());
/*  515 */       out.append(";\n");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  521 */     out.append(this._helper.getClassCommentWithSuppressWarnings("Auto Generated Model"));
/*      */     
/*  523 */     out.append("public class ");
/*  524 */     out.append(argDtx.getName());
/*  525 */     out.append("Model \n");
/*  526 */     if (argDtx.isExtended()) {
/*      */ 
/*      */       
/*  529 */       out.append("  extends ");
/*  530 */       out.append(argDtx.getExtends().getModel());
/*  531 */       out.append("\n");
/*      */     }
/*  533 */     else if (DaoGenHelper.isPropertyChildNeeded(argDtx)) {
/*  534 */       out.append("  extends dtv.data2.access.impl.AbstractDataModelWithPropertyImpl<");
/*  535 */       out.append(DaoGenHelper.getPropertyInterfaceName(argDtx));
/*  536 */       out.append(">\n");
/*      */     }
/*  538 */     else if (argDtx.isProperties()) {
/*  539 */       out.append("  extends dtv.data2.access.impl.AbstractDataModelPropertiesImpl\n");
/*      */     } else {
/*      */       
/*  542 */       out.append("  extends dtv.data2.access.impl.AbstractDataModelImpl\n");
/*      */     } 
/*      */     
/*  545 */     out.append("  implements ");
/*  546 */     out.append(argDtx.getInterface());
/*  547 */     out.append(" {\n\n  // Fix serialization compatability based on the name of the DAO\n  private static final long serialVersionUID = ");
/*      */ 
/*      */     
/*  550 */     out.append(argDtx.getName().hashCode());
/*  551 */     out.append("L;\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generatePropertyMethods(StringBuilder out, DtxDefinition argDtx) {
/*  562 */     String propertyName = DaoGenHelper.getPropertyName(argDtx);
/*  563 */     DtxDefinition child = this._helper.getTypeNameDefinition(propertyName);
/*      */ 
/*      */     
/*  566 */     out.append("  protected ");
/*  567 */     out.append(child.getInterface());
/*  568 */     out.append(" newProperty(String argPropertyName)  {\n");
/*      */     
/*  570 */     out.append("    ");
/*  571 */     out.append(child.getId());
/*  572 */     out.append(" id = new ");
/*  573 */     out.append(child.getId());
/*  574 */     out.append("();\n\n");
/*      */     
/*  576 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/*  577 */       if (!field.getName().equals("organizationId")) {
/*  578 */         out.append("    id.");
/*  579 */         out.append(DaoGenUtils.getSetterNameForField(field));
/*  580 */         out.append("(");
/*  581 */         out.append(DaoGenUtils.wrapStatementWithObject(DaoGenUtils.getGetterNameForField(field) + "()", field.getType()));
/*  582 */         out.append(");\n");
/*      */       } 
/*      */     } 
/*      */     
/*  586 */     out.append("    id.setPropertyCode(argPropertyName);\n\n");
/*  587 */     out.append("    ");
/*  588 */     out.append(child.getInterface());
/*  589 */     out.append(" prop = dtv.data2.access.DataFactory.getInstance().createNewObject(id, ");
/*  590 */     out.append(child.getInterface());
/*  591 */     out.append(".class);\n");
/*  592 */     out.append("    return prop;\n");
/*  593 */     out.append("  }\n");
/*  594 */     out.append("\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateRelationshipFields(StringBuilder out, List<DtxRelationship> argRelationships) {
/*  606 */     for (DtxRelationship relationship : argRelationships) {
/*      */ 
/*      */       
/*  609 */       String typeName = DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType()) ? relationship.getChild().getInterfaceTypeOnly() : ("HistoricalList<" + relationship.getChild().getInterface() + ">");
/*  610 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*  611 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*  612 */       out.append("  private " + typeName + " " + fieldName + ";\n");
/*  613 */       out.append("  // So that rollback() reverts to proper value\n");
/*  614 */       out.append("  private transient " + typeName + " " + savepointFieldName + ";\n");
/*      */     } 
/*  616 */     out.append("\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateRelationshipMethods(StringBuilder out, DtxDefinition argDtx, List<DtxRelationship> argRelationships) {
/*  628 */     StringBuilder persistenceDefaultsBuilder = new StringBuilder();
/*      */     
/*  630 */     persistenceDefaultsBuilder.append("  @Override\n");
/*  631 */     persistenceDefaultsBuilder.append("  public void setDependencies(dtv.data2.IPersistenceDefaults argPD, dtv.event.EventManager argEM) {\n");
/*      */ 
/*      */     
/*  634 */     if (argDtx.getExtends() == null) {
/*  635 */       persistenceDefaultsBuilder.append("    _persistenceDefaults = argPD;\n");
/*  636 */       persistenceDefaultsBuilder.append("    _daoImpl.setPersistenceDefaults(argPD);\n");
/*  637 */       persistenceDefaultsBuilder.append("    _eventManager = argEM;\n");
/*  638 */       persistenceDefaultsBuilder.append("    _events = new ModelEventor(this, argEM);\n");
/*  639 */       persistenceDefaultsBuilder
/*  640 */         .append("    _eventCascade = new dtv.event.handler.CascadingHandler(this);\n");
/*      */     } else {
/*      */       
/*  643 */       persistenceDefaultsBuilder.append("    super.setDependencies(argPD, argEM);\n");
/*      */     } 
/*      */     
/*  646 */     for (DtxRelationship relationship : argRelationships) {
/*  647 */       DtxDefinition child = relationship.getChild();
/*  648 */       String argName = DaoGenUtils.getArgNameForRelationship(relationship);
/*  649 */       String typeName = DaoGenUtils.getTypeForRelationship(relationship, false);
/*  650 */       String getterName = DaoGenUtils.getGetterNameForRelationship(relationship);
/*  651 */       String setterName = DaoGenUtils.getSetterNameForRelationship(relationship);
/*  652 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*  653 */       String relationshipName = StringUtils.ensureFirstUpperCase(relationship.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  658 */       persistenceDefaultsBuilder.append("    if (" + fieldName + " != null) {\n");
/*  659 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType()) || DtxRelationship.MANY_MANY
/*  660 */         .equalsIgnoreCase(relationship.getType())) {
/*  661 */         persistenceDefaultsBuilder.append("      for (")
/*  662 */           .append(relationship.getChild().getInterface() + " relationship : ").append(fieldName)
/*  663 */           .append(") {\n");
/*  664 */         persistenceDefaultsBuilder.append("        ((dtv.data2.access.impl.IDataModelImpl)relationship).setDependencies(argPD, argEM);\n");
/*      */         
/*  666 */         persistenceDefaultsBuilder.append("      }\n");
/*      */       } else {
/*      */         
/*  669 */         persistenceDefaultsBuilder.append("      ((dtv.data2.access.impl.IDataModelImpl)" + fieldName + ").setDependencies(argPD, argEM);\n");
/*      */       } 
/*      */       
/*  672 */       persistenceDefaultsBuilder.append("    }\n");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  677 */       out.append("  @Relationship(name=\"").append(relationshipName).append("\")\n");
/*  678 */       out.append("  public ").append(typeName).append(" ").append(getterName).append("() {\n");
/*  679 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType()) || DtxRelationship.MANY_MANY
/*  680 */         .equalsIgnoreCase(relationship.getType())) {
/*  681 */         addListInitializer(out, relationship, "null", null);
/*      */       }
/*  683 */       out.append("    return ").append(fieldName).append(";\n");
/*  684 */       out.append("  }\n\n");
/*      */       
/*  686 */       if (DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType())) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  691 */         out.append("  public void ").append(setterName).append("( ").append(typeName);
/*  692 */         out.append(" ").append(argName).append(") {\n");
/*      */         
/*  694 */         out.append("    // null out keys that define this relationship\n");
/*  695 */         out.append("    if( ").append(argName).append(" == null) {\n");
/*      */         
/*  697 */         if (relationship.getFieldsNotShared().isEmpty()) {
/*  698 */           out.append("      // all the fields that define this relationship are shared.  It cannot be broken.\n");
/*      */           
/*  700 */           out.append("      if (");
/*  701 */           out.append(fieldName);
/*  702 */           out.append(" != null) {\n");
/*  703 */           out.append("        throw new dtv.data2.access.exception.DtxException(\"An Attempt was made to break a ONE-ONE");
/*      */           
/*  705 */           out.append(" relationship that cannot be broken because all fields that define the relationship are");
/*      */           
/*  707 */           out.append(" primary keys on the parent data object.\");\n");
/*  708 */           out.append("      }\n");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  713 */         if (!relationship.getDependent()) {
/*  714 */           out.append("      // null out the keys that define this relationship of two independent objects.\n");
/*      */           
/*  716 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFieldsNotShared()) {
/*  717 */             out.append("      getDAO_().set");
/*  718 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  719 */             out.append("(null);\n");
/*      */           } 
/*      */         } 
/*      */         
/*  723 */         out.append("      if ( ");
/*  724 */         out.append(fieldName);
/*  725 */         out.append(" != null) {\n");
/*      */         
/*  727 */         out.append("        // De-register from the previous child.\n");
/*  728 */         out.append("        if (postEventsForChanges()) {\n");
/*  729 */         out.append("          _eventManager.deregisterEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */         
/*  731 */         out.append(fieldName);
/*  732 */         out.append("));\n");
/*  733 */         out.append("        }\n");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  738 */         if (relationship.getDependent()) {
/*  739 */           out.append("        super.addDeletedObject(");
/*  740 */           out.append(fieldName);
/*  741 */           out.append(");\n");
/*      */         } 
/*  743 */         out.append("      }\n");
/*  744 */         out.append("    }\n");
/*  745 */         out.append("    else {\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  751 */         if (relationship.getDependent()) {
/*  752 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFields()) {
/*  753 */             out.append("      ");
/*  754 */             out.append(argName);
/*  755 */             out.append(".set");
/*  756 */             out.append(StringUtils.ensureFirstUpperCase(field.getChild()));
/*  757 */             out.append("(this.get");
/*  758 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  759 */             out.append("());\n");
/*      */           } 
/*  761 */           out.append("\n");
/*      */         } else {
/*      */           
/*  764 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFieldsNotShared()) {
/*  765 */             DtxDefinition.DtxDaoField theRealField = relationship.getChild().findField(field.getChild());
/*      */             
/*  767 */             out.append("      getDAO_().set");
/*  768 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  769 */             out.append("(");
/*  770 */             out.append(DaoGenUtils.wrapStatementWithObject(argName + ".get" + 
/*  771 */                   StringUtils.ensureFirstUpperCase(field.getChild()) + "()", theRealField
/*  772 */                   .getType()));
/*  773 */             out.append(");\n");
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  779 */         DtxInverseRelationship inverseRelationship = child.getInverseRelationship(argDtx);
/*  780 */         if (inverseRelationship != null) {
/*  781 */           out.append("      // notify children with inverse relationships that they have a parent.\n");
/*  782 */           out.append("      " + argName + "." + inverseRelationship.getSetMethodName() + "(this);\n\n");
/*      */         } 
/*      */         
/*  785 */         out.append("      // Register the cascading event handler to receive events from the new child.\n");
/*  786 */         out.append("      if (postEventsForChanges()) {\n");
/*  787 */         out.append("        _eventManager.registerEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */         
/*  789 */         out.append(argName + "));\n");
/*  790 */         out.append("      }\n");
/*  791 */         out.append("    }\n\n");
/*  792 */         out.append("    ");
/*  793 */         out.append(fieldName);
/*  794 */         out.append(" = ");
/*  795 */         out.append(argName);
/*  796 */         out.append(";\n");
/*  797 */         out.append("    if (postEventsForChanges()) {\n");
/*  798 */         out.append("      _events.post(");
/*  799 */         out.append(argDtx.getInterface());
/*  800 */         out.append(".SET_");
/*  801 */         out.append(relationship.getName().toUpperCase());
/*  802 */         out.append(", ");
/*  803 */         out.append(argName);
/*  804 */         out.append(");\n");
/*  805 */         out.append("    }\n");
/*  806 */         out.append("  }\n\n");
/*      */         continue;
/*      */       } 
/*  809 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType()) || DtxRelationship.MANY_MANY
/*  810 */         .equalsIgnoreCase(relationship.getType())) {
/*      */         
/*  812 */         String addRemoveArgName = DaoGenUtils.getArgNameForRelationshipAddRemove(relationship);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  818 */         out.append("  public void ").append(setterName).append("( ").append(typeName);
/*  819 */         out.append(" ").append(argName).append(") {\n");
/*  820 */         addListInitializer(out, relationship, argName, argName);
/*      */ 
/*      */         
/*  823 */         DtxInverseRelationship inverseRelationship = child.getInverseRelationship(argDtx);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  828 */         if (inverseRelationship != null) {
/*  829 */           out.append("    // notify children with inverse relationships that they have a parent.\n");
/*  830 */           out.append("    for( ").append(relationship.getChild().getInterface()).append(" child : ")
/*  831 */             .append(fieldName).append(") {\n");
/*  832 */           out.append("      child.").append(inverseRelationship.getSetMethodName()).append("(this);\n");
/*  833 */           out.append("    }\n");
/*      */         } 
/*      */ 
/*      */         
/*  837 */         String childType = child.getInterface();
/*  838 */         String childModel = child.getModel();
/*  839 */         if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType())) {
/*  840 */           out.append("    // Propagate identification information through the graph.\n");
/*  841 */           out.append("    for( ").append(childType).append(" child : ").append(fieldName).append(") {\n");
/*  842 */           out.append("      ").append(childModel).append(" model = (").append(childModel)
/*  843 */             .append(") child;\n");
/*      */           
/*  845 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFields()) {
/*  846 */             String parentName = StringUtils.ensureFirstUpperCase(field.getParent());
/*  847 */             String childName = StringUtils.ensureFirstUpperCase(field.getChild());
/*  848 */             out.append("      model.set" + childName + "_noev(this.get" + parentName + "());\n");
/*      */           } 
/*      */           
/*  851 */           out.append("      if (child instanceof IDataModelImpl) {\n");
/*  852 */           out.append("        IDataAccessObject childDao = ((IDataModelImpl) child).getDAO();\n");
/*  853 */           out.append("        if (dtv.util.StringUtils.isEmpty(childDao.getOriginDataSource()) && \n");
/*  854 */           out.append("            !dtv.util.StringUtils.isEmpty(this.getDAO().getOriginDataSource())) {\n");
/*  855 */           out.append("          childDao.setOriginDataSource(this.getDAO().getOriginDataSource());\n");
/*  856 */           out.append("        }\n");
/*  857 */           out.append("      }\n");
/*      */ 
/*      */           
/*  860 */           out.append("      if (postEventsForChanges()) {\n");
/*  861 */           out.append("        _eventManager.registerEventHandler(_eventCascade, child);\n");
/*  862 */           out.append("      }\n");
/*  863 */           out.append("    }\n");
/*      */         } 
/*      */ 
/*      */         
/*  867 */         out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  873 */         out.append("  public void ");
/*  874 */         out.append(DaoGenUtils.getAdderNameForRelationship(relationship));
/*  875 */         out.append("(");
/*  876 */         out.append(relationship.getChild().getInterface());
/*  877 */         out.append(" ");
/*  878 */         out.append(addRemoveArgName);
/*  879 */         out.append(") {\n");
/*      */         
/*  881 */         if (inverseRelationship != null) {
/*  882 */           out.append("    // notify children with inverse relationships that they have a parent.\n    ");
/*      */           
/*  884 */           out.append(addRemoveArgName);
/*  885 */           out.append(".");
/*  886 */           out.append(inverseRelationship.getSetMethodName());
/*  887 */           out.append("(this);\n");
/*      */         } 
/*      */ 
/*      */         
/*  891 */         addListInitializer(out, relationship, "null", null);
/*      */ 
/*      */         
/*  894 */         if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType())) {
/*  895 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFields()) {
/*  896 */             out.append("    ");
/*  897 */             out.append(addRemoveArgName);
/*  898 */             out.append(".set");
/*  899 */             out.append(StringUtils.ensureFirstUpperCase(field.getChild()));
/*  900 */             out.append("(this.get");
/*  901 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  902 */             out.append("());\n");
/*      */           } 
/*      */ 
/*      */           
/*  906 */           out.append("    if (");
/*  907 */           out.append(addRemoveArgName);
/*  908 */           out.append(" instanceof IDataModelImpl) {\n");
/*  909 */           out.append("      IDataAccessObject childDao = ((IDataModelImpl) ");
/*  910 */           out.append(addRemoveArgName);
/*  911 */           out.append(").getDAO();\n");
/*  912 */           out.append("      if (dtv.util.StringUtils.isEmpty(childDao.getOriginDataSource()) && \n");
/*  913 */           out.append("          !dtv.util.StringUtils.isEmpty(this.getDAO().getOriginDataSource())) {\n");
/*  914 */           out.append("        childDao.setOriginDataSource(this.getDAO().getOriginDataSource());\n");
/*  915 */           out.append("      }\n");
/*  916 */           out.append("    }\n\n");
/*      */           
/*  918 */           out.append("    // Register the _handleChildEvent method to receive events from the new child.\n");
/*  919 */           out.append("    if (postEventsForChanges()) {\n");
/*  920 */           out.append("      _eventManager.registerEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */           
/*  922 */           out.append(addRemoveArgName);
/*  923 */           out.append("));\n");
/*  924 */           out.append("    }\n\n");
/*      */         } 
/*      */         
/*  927 */         out.append("    ");
/*  928 */         out.append(fieldName);
/*  929 */         out.append(".add(");
/*  930 */         out.append(addRemoveArgName);
/*  931 */         out.append(");\n");
/*  932 */         out.append("    if (postEventsForChanges()) {\n");
/*  933 */         out.append("      _events.post(");
/*  934 */         out.append(argDtx.getInterface());
/*  935 */         out.append(".ADD_");
/*  936 */         out.append(relationship.getName().toUpperCase());
/*  937 */         out.append(", ");
/*  938 */         out.append(addRemoveArgName);
/*  939 */         out.append(");\n");
/*  940 */         out.append("    }\n");
/*  941 */         out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  947 */         out.append("  public void ");
/*  948 */         out.append(DaoGenUtils.getRemoverNameForRelationship(relationship));
/*  949 */         out.append("(");
/*  950 */         out.append(relationship.getChild().getInterface());
/*  951 */         out.append(" ");
/*  952 */         out.append(addRemoveArgName);
/*  953 */         out.append(") {\n");
/*      */         
/*  955 */         out.append("    if (");
/*  956 */         out.append(fieldName);
/*  957 */         out.append(" != null) {\n");
/*  958 */         out.append("    // De-Register the _handleChildEvent method from receiving the child events.\n");
/*  959 */         out.append("    if (postEventsForChanges()) {\n");
/*  960 */         out.append("      _eventManager.deregisterEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */         
/*  962 */         out.append(addRemoveArgName + "));\n");
/*  963 */         out.append("    }\n");
/*  964 */         out.append("      ");
/*  965 */         out.append(fieldName);
/*  966 */         out.append(".remove(");
/*  967 */         out.append(addRemoveArgName);
/*  968 */         out.append(");\n");
/*      */         
/*  970 */         if (inverseRelationship != null) {
/*  971 */           out.append("    // notify children with inverse relationships that they have a parent.\n");
/*  972 */           out.append("    ").append(addRemoveArgName).append(".")
/*  973 */             .append(inverseRelationship.getSetMethodName()).append("(null);\n");
/*      */         } 
/*      */         
/*  976 */         out.append("      if (postEventsForChanges()) {\n");
/*  977 */         out.append("        _events.post(");
/*  978 */         out.append(argDtx.getInterface());
/*  979 */         out.append(".REMOVE_");
/*  980 */         out.append(relationship.getName().toUpperCase());
/*  981 */         out.append(", ");
/*  982 */         out.append(addRemoveArgName);
/*  983 */         out.append(");\n");
/*  984 */         out.append("      }\n");
/*  985 */         out.append("    }\n  }\n\n");
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  990 */       throw new Error("*** UNKNOWN RELATIONSHIP TYPE: " + relationship.getType() + " in file: " + argDtx
/*  991 */           .getSourceDtxFile().getAbsolutePath());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  999 */     for (DtxInverseRelationship inverseRelationship : argDtx.getInverseRelationships()) {
/*      */       
/* 1001 */       String argName = "arg" + StringUtils.ensureFirstUpperCase(inverseRelationship.getName());
/* 1002 */       String fieldName = "_" + StringUtils.ensureFirstLowerCase(inverseRelationship.getName());
/*      */       
/* 1004 */       out.append("  public void ");
/* 1005 */       out.append(inverseRelationship.getSetMethodName());
/* 1006 */       out.append("(");
/* 1007 */       out.append(inverseRelationship.getParent().getInterface());
/* 1008 */       out.append(" ");
/* 1009 */       out.append(argName);
/* 1010 */       out.append(") {\n    ");
/*      */       
/* 1012 */       out.append(fieldName);
/* 1013 */       out.append(" = ");
/* 1014 */       out.append(argName);
/* 1015 */       out.append(";\n  }\n\n  public ");
/*      */ 
/*      */ 
/*      */       
/* 1019 */       out.append(inverseRelationship.getParent().getInterface());
/* 1020 */       out.append(" ");
/* 1021 */       out.append(inverseRelationship.getGetMethodName());
/* 1022 */       out.append("() {\n    return " + fieldName + ";\n  }\n\n");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1033 */     out.append("  @Override\n  public Object getValue(String argFieldId) {\n");
/*      */ 
/*      */     
/* 1036 */     boolean ifPrinted = false;
/* 1037 */     for (DtxRelationship relationship : argRelationships) {
/*      */       
/* 1039 */       if (!ifPrinted) {
/* 1040 */         out.append("    if (");
/* 1041 */         ifPrinted = true;
/*      */       } else {
/*      */         
/* 1044 */         out.append("    else if (");
/*      */       } 
/*      */       
/* 1047 */       out.append("\"");
/* 1048 */       out.append(StringUtils.ensureFirstUpperCase(relationship.getName()));
/* 1049 */       out.append("\".equals(argFieldId)) {\n      return ");
/*      */       
/* 1051 */       out.append(DaoGenUtils.getGetterNameForRelationship(relationship));
/* 1052 */       out.append("();\n    }\n");
/*      */     } 
/*      */ 
/*      */     
/* 1056 */     if (argRelationships.size() == 0) {
/* 1057 */       out.append("    if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } else {
/*      */       
/* 1060 */       out.append("    else if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } 
/*      */     
/* 1063 */     out.append("      return _myExtension;\n");
/* 1064 */     out.append("    }\n");
/*      */     
/* 1066 */     out.append("    else {\n      return super.getValue(argFieldId);\n    }\n  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1076 */     out.append("  @Override\n  public void setValue(String argFieldId, Object argValue) {\n");
/*      */ 
/*      */     
/* 1079 */     ifPrinted = false;
/* 1080 */     for (DtxRelationship relationship : argRelationships) {
/*      */       
/* 1082 */       if (!ifPrinted) {
/* 1083 */         out.append("    if (");
/* 1084 */         ifPrinted = true;
/*      */       } else {
/*      */         
/* 1087 */         out.append("    else if (");
/*      */       } 
/*      */       
/* 1090 */       out.append("\"");
/* 1091 */       out.append(StringUtils.ensureFirstUpperCase(relationship.getName()));
/* 1092 */       out.append("\".equals(argFieldId)) {\n");
/*      */       
/* 1094 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1095 */         out.append("      ");
/* 1096 */         out.append(DaoGenUtils.getSetterNameForRelationship(relationship));
/* 1097 */         out.append("((");
/* 1098 */         out.append(relationship.getChild().getInterface());
/* 1099 */         out.append(")argValue);\n");
/*      */       } else {
/*      */         
/* 1102 */         out.append("      ");
/* 1103 */         out.append(DaoGenUtils.getSetterNameForRelationship(relationship));
/* 1104 */         out.append("(changeToList(argValue,");
/* 1105 */         out.append(relationship.getChild().getInterface());
/* 1106 */         out.append(".class));\n");
/*      */       } 
/*      */       
/* 1109 */       out.append("    }\n");
/*      */     } 
/*      */     
/* 1112 */     if (argRelationships.size() == 0) {
/* 1113 */       out.append("    if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } else {
/*      */       
/* 1116 */       out.append("    else if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } 
/*      */     
/* 1119 */     out.append("      _myExtension = (IDataModel)argValue;\n");
/* 1120 */     out.append("    }\n");
/*      */     
/* 1122 */     out.append("    else {\n      super.setValue(argFieldId, argValue);\n    }\n  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1129 */     persistenceDefaultsBuilder.append("  }\n\n");
/* 1130 */     out.append(persistenceDefaultsBuilder.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateTransactionMethods(StringBuilder out, DtxDefinition argDtx) {
/* 1147 */     out.append("  @Override\n  public void startTransaction() {\n    if (_alreadyInStart) {\n      return;\n    }\n    else {\n      _alreadyInStart = true;\n    }\n\n    super.startTransaction();\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1159 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*      */       
/* 1161 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/* 1162 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*      */ 
/*      */       
/* 1165 */       out.append("    ");
/* 1166 */       out.append(savepointFieldName);
/* 1167 */       out.append(" = ");
/* 1168 */       out.append(fieldName);
/* 1169 */       out.append(";\n    if (");
/*      */       
/* 1171 */       out.append(fieldName);
/* 1172 */       out.append(" != null) {\n");
/*      */       
/* 1174 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1175 */         out.append("      ");
/* 1176 */         out.append(fieldName);
/* 1177 */         out.append(".startTransaction();\n");
/*      */       }
/* 1179 */       else if ("One-Many".equalsIgnoreCase(relationship.getType()) || "Many-Many"
/* 1180 */         .equalsIgnoreCase(relationship.getType())) {
/*      */ 
/*      */         
/* 1183 */         out.append("      ");
/* 1184 */         out.append(savepointFieldName);
/* 1185 */         out.append(" = new HistoricalList<");
/* 1186 */         out.append(relationship.getChild().getInterface());
/* 1187 */         out.append(">(");
/* 1188 */         out.append(fieldName);
/* 1189 */         out.append(");\n      java.util.Iterator it = ");
/*      */         
/* 1191 */         out.append(fieldName);
/* 1192 */         out.append(".iterator();\n      while (it.hasNext()) {\n        ((dtv.data2.access.IDataModel)it.next()).startTransaction();\n      }\n");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1197 */       out.append("    }\n\n");
/*      */     } 
/*      */     
/* 1200 */     out.append("    \n    _alreadyInStart = false;\n  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1208 */     out.append("  @Override\n  public void rollbackChanges() {\n    if (isAlreadyRolledBack())\n      return;\n\n    super.rollbackChanges();\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1216 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*      */       
/* 1218 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/* 1219 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*      */ 
/*      */       
/* 1222 */       out.append("    ");
/* 1223 */       out.append(fieldName);
/* 1224 */       out.append(" = ");
/* 1225 */       out.append(savepointFieldName);
/* 1226 */       out.append(";\n    ");
/*      */       
/* 1228 */       out.append(savepointFieldName);
/* 1229 */       out.append(" = null;\n    if (");
/*      */       
/* 1231 */       out.append(fieldName);
/* 1232 */       out.append(" != null) {\n");
/*      */       
/* 1234 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1235 */         out.append("      ");
/* 1236 */         out.append(fieldName);
/* 1237 */         out.append(".rollbackChanges();\n");
/*      */       }
/* 1239 */       else if ("One-Many".equalsIgnoreCase(relationship.getType()) || "Many-Many"
/* 1240 */         .equalsIgnoreCase(relationship.getType())) {
/*      */         
/* 1242 */         out.append("      java.util.Iterator it = ");
/* 1243 */         out.append(fieldName);
/* 1244 */         out.append(".iterator();\n      while (it.hasNext()) {\n        ((dtv.data2.access.IDataModel)it.next()).rollbackChanges();\n      }\n");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1250 */       out.append("    }\n\n");
/*      */     } 
/*      */     
/* 1253 */     out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1258 */     out.append("  @Override\n  public void commitTransaction() {\n    if (_alreadyInCommit) {\n      return;\n    } else {\n      _alreadyInCommit = true;\n    }\n\n    super.commitTransaction();\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1269 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*      */       
/* 1271 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/* 1272 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*      */ 
/*      */       
/* 1275 */       out.append("    ");
/* 1276 */       out.append(savepointFieldName);
/* 1277 */       out.append(" = ");
/* 1278 */       out.append(fieldName);
/* 1279 */       out.append(";\n    if (");
/*      */       
/* 1281 */       out.append(fieldName);
/* 1282 */       out.append(" != null) {\n");
/*      */       
/* 1284 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1285 */         out.append("      ");
/* 1286 */         out.append(fieldName);
/* 1287 */         out.append(".commitTransaction();\n");
/*      */       }
/* 1289 */       else if ("One-Many".equalsIgnoreCase(relationship.getType()) || "Many-Many"
/* 1290 */         .equalsIgnoreCase(relationship.getType())) {
/*      */ 
/*      */         
/* 1293 */         out.append("      java.util.Iterator it = ");
/* 1294 */         out.append(fieldName);
/* 1295 */         out.append(".iterator();\n      while (it.hasNext()) {\n        ((dtv.data2.access.IDataModel)it.next()).commitTransaction();\n      }\n");
/*      */ 
/*      */ 
/*      */         
/* 1299 */         out.append("      ");
/* 1300 */         out.append(fieldName);
/* 1301 */         out.append(" = new HistoricalList<");
/* 1302 */         out.append(relationship.getChild().getInterface());
/* 1303 */         out.append(">(");
/* 1304 */         out.append(fieldName);
/* 1305 */         out.append(");\n");
/*      */       } 
/* 1307 */       out.append("    }\n\n");
/*      */     } 
/*      */     
/* 1310 */     for (int i = 0; i < (argDtx.getFields()).length; i++) {
/* 1311 */       DtxDefinition.DtxDaoField field = argDtx.getFields()[i];
/*      */       
/* 1313 */       if (field.getIncrementField()) {
/* 1314 */         out.append("    getDAO_().setInit");
/* 1315 */         out.append(StringUtils.ensureFirstUpperCase(field.getName()));
/* 1316 */         out.append("(");
/* 1317 */         out.append(DaoGenUtils.wrapStatementWithObject(DaoGenUtils.getGetterNameForField(field) + "()", field.getType()));
/* 1318 */         out.append(");\n");
/*      */         
/* 1320 */         if (i == (argDtx.getFields()).length - 1) {
/* 1321 */           out.append("\n");
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1326 */     out.append("    \n    _alreadyInCommit = false;\n  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getDtjContents(File argDtj) throws IOException {
/* 1335 */     if (!argDtj.exists()) {
/* 1336 */       return "";
/*      */     }
/* 1338 */     StringBuilder sb = new StringBuilder(1024);
/* 1339 */     sb.append("\n\n")
/* 1340 */       .append("  // ------------------------------------------------------------- \n")
/* 1341 */       .append("  // ------------------------------------------------------------- \n")
/* 1342 */       .append("  // - CUSTOM CODE BELOW THIS POINT. EDIT IN THE APPROPRIATE DTJ - \n")
/* 1343 */       .append("  // ------------------------------------------------------------- \n")
/* 1344 */       .append("  // ------------------------------------------------------------- \n\n");
/*      */     
/* 1346 */     try (Reader in = FileUtils.getFileReader(argDtj)) {
/* 1347 */       int inChar = -1;
/* 1348 */       while ((inChar = in.read()) > 0) {
/* 1349 */         sb.append((char)inChar);
/*      */       }
/* 1351 */       return sb.toString();
/*      */     } 
/*      */   }
/*      */   
/*      */   private StringBuilder overrideMethods(DtxDefinition argDtx, StringBuilder sb, String dtjContents) {
/* 1356 */     if (StringUtils.isEmpty(dtjContents)) {
/* 1357 */       return sb;
/*      */     }
/*      */     
/* 1360 */     String METHOD_OVERRIDE = "{OVERRIDE GENERATED METHOD}";
/*      */     
/* 1362 */     String[] dtj = dtjContents.split("\n");
/*      */     
/* 1364 */     for (int ii = 0; ii < dtj.length; ii++) {
/* 1365 */       if (dtj[ii].indexOf("{OVERRIDE GENERATED METHOD}") != -1) {
/*      */ 
/*      */ 
/*      */         
/* 1369 */         String methodDecl = (dtj[ii].indexOf("*/") >= 0) ? dtj[ii + 1] : dtj[ii + 2];
/*      */         
/* 1371 */         methodDecl = methodDecl.substring(0, methodDecl.indexOf("(")).trim();
/*      */         
/* 1373 */         if (sb.indexOf(methodDecl) == -1) {
/* 1374 */           throw new RuntimeException("Could not find method declaration: " + methodDecl + " in model generated for " + argDtx
/* 1375 */               .getName() + " methods overriden in the dtj must match the generated declaration character by character (case sensitive).");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1381 */         String overrideMethodDecl = methodDecl.replaceAll("public", "protected").trim();
/* 1382 */         overrideMethodDecl = overrideMethodDecl + "Impl(";
/* 1383 */         methodDecl = methodDecl + "(";
/* 1384 */         StringUtils.replaceAll(sb, methodDecl, overrideMethodDecl);
/*      */       } 
/*      */     } 
/*      */     
/* 1388 */     return sb;
/*      */   }
/*      */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DefaultModelGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */