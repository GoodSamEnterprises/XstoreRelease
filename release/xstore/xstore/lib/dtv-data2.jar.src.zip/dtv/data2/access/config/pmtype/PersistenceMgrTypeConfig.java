/*     */ package dtv.data2.access.config.pmtype;
/*     */ 
/*     */ import dtv.data2.access.IPersistenceRuleFactory;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.ICascadableConfig;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import dtv.util.config.StringConfig;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceMgrTypeConfig
/*     */   extends AbstractParentConfig
/*     */   implements ICascadableConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  24 */   private static final Logger _logger = Logger.getLogger(PersistenceMgrTypeConfig.class);
/*     */   
/*     */   private static final String NAME_TAG = "Name";
/*     */   
/*     */   private static final String REF_TAG = "Ref";
/*     */   
/*     */   private static final String PERSISTENCE_MANAGER_RULES_TAG = "PersistenceManagerRules";
/*     */   
/*     */   private static final String PERSISTENCE_STRATEGY_RULES_TAG = "PersistenceStrategyRules";
/*     */   
/*     */   private static final String ONLINE_TAG = "Online";
/*     */   private static final String OFFLINE_TAG = "Offline";
/*     */   private static final String TRAINING_TAG = "Training";
/*     */   private static final String WRITE_JOURNAL_OFFLINE_TAG = "WriteJournalOnline";
/*     */   private static final String SYNC_TAG = "Sync";
/*     */   private static final String CONVERT_TAG = "Convert";
/*     */   private String _name;
/*     */   private String _referenceName;
/*     */   private LocationGroupConfig _onlineLocations;
/*     */   private LocationGroupConfig _offlineLocations;
/*     */   private LocationGroupConfig _trainingLocations;
/*     */   private PersistenceRuleGroupConfig _persistenceManagerRules;
/*     */   private PersistenceRuleGroupConfig _persistenceStrategyRules;
/*     */   private boolean _writeJournalOnline = false;
/*     */   private boolean _isReference = false;
/*     */   @Inject
/*     */   IPersistenceRuleFactory _persistenceRuleFactory;
/*     */   
/*     */   public void cascadeValues(IConfigObject argReference) {
/*  53 */     if (argReference == null || !(argReference instanceof PersistenceMgrTypeConfig)) {
/*  54 */       _logger.error("Attempted to cascade from invalid configuration object!");
/*     */       
/*     */       return;
/*     */     } 
/*  58 */     if (getSourceDescription() == null) {
/*  59 */       setSourceInfo(argReference.getSourceUrl(), argReference.getSourceLineNumber());
/*     */     }
/*     */     
/*  62 */     PersistenceMgrTypeConfig reference = (PersistenceMgrTypeConfig)argReference;
/*     */     
/*  64 */     if (getName() == null) {
/*  65 */       setName(reference.getName());
/*     */     }
/*     */     
/*  68 */     if (getPersistenceManagerRules() == null) {
/*  69 */       setPersistenceManagerRules(reference.getPersistenceManagerRules());
/*     */     }
/*     */     
/*  72 */     if (getPersistenceStrategyRules() == null) {
/*  73 */       setPersistenceStrategyRules(reference.getPersistenceStrategyRules());
/*     */     }
/*     */     
/*  76 */     if (getOfflineLocations() == null) {
/*  77 */       setOfflineLocations(reference.getOfflineLocations());
/*     */     }
/*     */     
/*  80 */     if (getOnlineLocations() == null) {
/*  81 */       setOnlineLocations(reference.getOnlineLocations());
/*     */     }
/*     */     
/*  84 */     if (getTrainingLocations() == null) {
/*  85 */       setTrainingLocations(reference.getTrainingLocations());
/*     */     }
/*     */     
/*  88 */     if (!isWriteJournalOnline()) {
/*  89 */       setWriteJournalOnline(reference.isWriteJournalOnline());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  98 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationGroupConfig getOfflineLocations() {
/* 107 */     return this._offlineLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationGroupConfig getOnlineLocations() {
/* 116 */     return this._onlineLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceRuleGroupConfig getPersistenceManagerRules() {
/* 125 */     return this._persistenceManagerRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceRuleGroupConfig getPersistenceStrategyRules() {
/* 134 */     return this._persistenceStrategyRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReferenceName() {
/* 145 */     return this._referenceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationGroupConfig getTrainingLocations() {
/* 154 */     return this._trainingLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReference() {
/* 162 */     return this._isReference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWriteJournalOnline() {
/* 171 */     return this._writeJournalOnline;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 177 */     if ("Name".equalsIgnoreCase(argKey)) {
/* 178 */       this._name = argValue.toString();
/*     */     }
/* 180 */     else if ("Ref".equalsIgnoreCase(argKey)) {
/* 181 */       this._isReference = true;
/* 182 */       this._referenceName = argValue.toString();
/*     */     }
/* 184 */     else if ("PersistenceManagerRules".equalsIgnoreCase(argKey) && argValue instanceof PersistenceRuleGroupConfig) {
/*     */       
/* 186 */       this._persistenceManagerRules = (PersistenceRuleGroupConfig)argValue;
/*     */     }
/* 188 */     else if ("PersistenceStrategyRules".equalsIgnoreCase(argKey) && argValue instanceof PersistenceRuleGroupConfig) {
/*     */       
/* 190 */       this._persistenceStrategyRules = (PersistenceRuleGroupConfig)argValue;
/*     */     }
/* 192 */     else if ("Online".equalsIgnoreCase(argKey) && argValue instanceof LocationGroupConfig) {
/* 193 */       this._onlineLocations = (LocationGroupConfig)argValue;
/*     */     }
/* 195 */     else if ("Offline".equalsIgnoreCase(argKey) && argValue instanceof LocationGroupConfig) {
/* 196 */       this._offlineLocations = (LocationGroupConfig)argValue;
/*     */     }
/* 198 */     else if ("Training".equalsIgnoreCase(argKey) && argValue instanceof LocationGroupConfig) {
/* 199 */       this._trainingLocations = (LocationGroupConfig)argValue;
/*     */     }
/* 201 */     else if ("WriteJournalOnline".equalsIgnoreCase(argKey)) {
/* 202 */       this._writeJournalOnline = ConfigUtils.toBoolean(argValue);
/*     */     }
/* 204 */     else if ("Sync".equalsIgnoreCase(argKey) && ConfigUtils.toBoolean(argValue)) {
/*     */       
/* 206 */       PersistenceRuleConfig cfg = new PersistenceRuleConfig();
/* 207 */       cfg.setConfigObject("beanName", (IConfigObject)new StringConfig("manageDataInTwoPlacesRule"));
/*     */       
/* 209 */       if (this._persistenceStrategyRules == null) {
/* 210 */         this._persistenceStrategyRules = new PersistenceRuleGroupConfig();
/*     */       }
/* 212 */       this._persistenceStrategyRules.setConfigObject("PersistenceRule", (IConfigObject)cfg);
/*     */     }
/* 214 */     else if ("Convert".equalsIgnoreCase(argKey) && ConfigUtils.toBoolean(argValue)) {
/*     */       
/* 216 */       PersistenceRuleConfig cfg = new PersistenceRuleConfig();
/* 217 */       cfg.setConfigObject("beanName", (IConfigObject)new StringConfig("daoConversionRule"));
/*     */       
/* 219 */       if (this._persistenceStrategyRules == null) {
/* 220 */         this._persistenceStrategyRules = new PersistenceRuleGroupConfig();
/*     */       }
/* 222 */       this._persistenceStrategyRules.setConfigObject("PersistenceRule", (IConfigObject)cfg);
/*     */     } else {
/*     */       
/* 225 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String argName) {
/* 235 */     this._name = argName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOfflineLocations(LocationGroupConfig argOfflineLocations) {
/* 244 */     this._offlineLocations = argOfflineLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnlineLocations(LocationGroupConfig argOnlineLocations) {
/* 253 */     this._onlineLocations = argOnlineLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceManagerRules(PersistenceRuleGroupConfig argPersistenceManagerRules) {
/* 262 */     this._persistenceManagerRules = argPersistenceManagerRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceStrategyRules(PersistenceRuleGroupConfig argPersistenceStrategyRules) {
/* 271 */     this._persistenceStrategyRules = argPersistenceStrategyRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrainingLocations(LocationGroupConfig argTrainingLocations) {
/* 280 */     this._trainingLocations = argTrainingLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteJournalOnline(boolean argWriteJournalOnline) {
/* 289 */     this._writeJournalOnline = argWriteJournalOnline;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\pmtype\PersistenceMgrTypeConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */