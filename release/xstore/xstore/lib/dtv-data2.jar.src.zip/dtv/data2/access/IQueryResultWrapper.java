package dtv.data2.access;

public interface IQueryResultWrapper<T> {
  T getData();
  
  long getQueryLimit();
  
  boolean isQueryLimitReached();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\IQueryResultWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */