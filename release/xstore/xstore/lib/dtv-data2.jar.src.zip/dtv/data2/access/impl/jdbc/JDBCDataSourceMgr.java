/*     */ package dtv.data2.access.impl.jdbc;
/*     */ 
/*     */ import dtv.data2.SQLExceptionScrubber;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.query.QueryToken;
/*     */ import dtv.data2.access.status.IDataSourceStatusListener;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import oracle.ucp.jdbc.ValidConnection;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCDataSourceMgr
/*     */   implements IDataSourceStatusListener
/*     */ {
/*  37 */   private static final Logger _logger = Logger.getLogger(JDBCDataSourceMgr.class);
/*     */ 
/*     */   
/*     */   static final String JNDI_URL_PREFIX = "jndi:";
/*     */ 
/*     */   
/*  43 */   private static final JDBCDataSourceMgr instance_ = new JDBCDataSourceMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JDBCDataSourceMgr getInstance() {
/*  55 */     return instance_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJDBCDataSource(DataSourceDescriptor argDataSourceDescriptor) {
/*  65 */     return argDataSourceDescriptor.getPersistenceStrategyName().toLowerCase().contains("jdbc");
/*     */   }
/*     */   
/*     */   private static void throwAwayConnection(Connection argConnection) {
/*  69 */     if (argConnection instanceof ValidConnection) {
/*     */       try {
/*  71 */         ((ValidConnection)argConnection).setInvalid();
/*     */       }
/*  73 */       catch (Throwable almostIgnored) {
/*  74 */         _logger.debug("CAUGHT EXCEPTION", almostIgnored);
/*     */       } 
/*     */     }
/*     */     try {
/*  78 */       argConnection.close();
/*     */     }
/*  80 */     catch (Throwable almostIgnored) {
/*  81 */       _logger.debug("CAUGHT EXCEPTION", almostIgnored);
/*     */     } 
/*     */   }
/*     */   
/*  85 */   private final ConcurrentMap<String, JDBCConnectionProvider> connectionPools_ = new ConcurrentHashMap<>(5, 1.0F, 1);
/*     */   
/*  87 */   private final ConcurrentMap<String, JDBCConnectionTemplate> dataSources_ = new ConcurrentHashMap<>(5, 1.0F, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JDBCDataSourceMgr() {
/*     */     try {
/*  95 */       Collection<DataSourceDescriptor> datasources = DataSourceFactory.getInstance().getDataSourceDescriptors();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       for (DataSourceDescriptor datasource : datasources) {
/* 101 */         if (datasource.isEnabled() && 
/* 102 */           isJDBCDataSource(datasource)) {
/* 103 */           registerDatasource(datasource);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       StatusMgr.getInstance().registerStatusListener(this);
/*     */     }
/* 113 */     catch (Exception ee) {
/* 114 */       _logger.fatal("An exception occurred while creating " + JDBCDataSourceMgr.class.getName() + ". There may be a fundamental configuration error with system.properties or DataSourceConfig.xml or a related config", ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DBConnection getConnection(String argDatasourceName) {
/* 127 */     return getConnection(argDatasourceName, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DBConnection getConnection(String argDatasourceName, boolean argAutoCommit) {
/*     */     Connection connection;
/* 138 */     JDBCConnectionTemplate template = getTemplate(argDatasourceName);
/*     */ 
/*     */     
/*     */     try {
/* 142 */       JDBCConnectionProvider connectionPool = getConnectionPool(argDatasourceName);
/*     */ 
/*     */       
/* 145 */       connection = connectionPool.getConnection();
/*     */     }
/* 147 */     catch (SQLException ex) {
/* 148 */       SQLException scrubbedException = SQLExceptionScrubber.scrub(ex);
/* 149 */       if (FailoverException.isFailover(ex)) {
/* 150 */         throw FailoverException.getNewException(scrubbedException, argDatasourceName);
/*     */       }
/*     */       
/* 153 */       String message = "Could not obtain new datasource conenction for " + argDatasourceName;
/* 154 */       throw new DBConnectionException(message, scrubbedException);
/*     */     } 
/*     */     
/*     */     try {
/* 158 */       return DBConnection.adapt(connection, template, argAutoCommit);
/*     */     }
/* 160 */     catch (RuntimeException|Error ex) {
/* 161 */       throwAwayConnection(connection);
/* 162 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DBConnection getConnection(TransactionToken argTransactionToken, String argDataSourceName) {
/* 175 */     DBConnection datasource = (DBConnection)argTransactionToken.getDataSource(argDataSourceName, DBConnection.class);
/*     */ 
/*     */     
/* 178 */     if (datasource == null) {
/* 179 */       datasource = getConnection(argDataSourceName, false);
/* 180 */       datasource.setAssociatedTransaction(argTransactionToken);
/* 181 */       datasource.setMyManager(this);
/* 182 */       argTransactionToken.registerDataSource(datasource);
/*     */     } 
/*     */     
/* 185 */     return datasource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCurrentPoolSize() {
/* 194 */     int poolSize = 0;
/* 195 */     for (JDBCConnectionProvider connectionPool : this.connectionPools_.values()) {
/* 196 */       poolSize += connectionPool.getPoolSize();
/*     */     }
/* 198 */     return poolSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DBConnection getQueryConnection(String argDataSourceName, QueryToken argQueryToken) {
/* 209 */     if (argQueryToken == null) {
/* 210 */       throw new DtxException("getQueryConnection was called without a QueryToken.  This is not supported.");
/*     */     }
/*     */     
/* 213 */     DBConnection queryConnection = (DBConnection)argQueryToken.getQueryResource(argDataSourceName, DBConnection.class);
/* 214 */     if (queryConnection == null) {
/* 215 */       queryConnection = getConnection(argDataSourceName);
/* 216 */       argQueryToken.registerQueryResource(queryConnection);
/*     */     } 
/* 218 */     return queryConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notfiyOffline(String argDatasourceName) {
/* 229 */     closeConnectionPool(argDatasourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyOnline(String argDatasourceName) {
/* 240 */     if (this.dataSources_.containsKey(argDatasourceName) && !this.connectionPools_.containsKey(argDatasourceName)) {
/* 241 */       loadConnectionPool(argDatasourceName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerDatasource(DataSourceDescriptor dsd) {
/* 252 */     JDBCConnectionTemplate template = new JDBCConnectionTemplate(dsd);
/* 253 */     String dataSourceName = template.getDataSourceName();
/* 254 */     if (this.dataSources_.putIfAbsent(dataSourceName, template) != null) {
/* 255 */       throw new DBConnectionException("An attempt was made to re-register datasource: " + dataSourceName + " Registration should only occur once for a datasource.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 264 */     List<String> poolKeys = new ArrayList<>(this.connectionPools_.keySet());
/* 265 */     for (String poolKey : poolKeys) {
/* 266 */       closeConnectionPool(poolKey);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 276 */     StringBuilder poolStats = new StringBuilder();
/* 277 */     for (Map.Entry<String, JDBCConnectionProvider> poolEntry : this.connectionPools_.entrySet()) {
/* 278 */       poolStats.append(poolEntry.getKey());
/* 279 */       poolStats.append(" [").append(((JDBCConnectionProvider)poolEntry.getValue()).getStats()).append("]");
/* 280 */       poolStats.append("\n\n");
/*     */     } 
/* 282 */     return poolStats.toString();
/*     */   }
/*     */   
/*     */   private void closeConnectionPool(String argDatasourceName) {
/* 286 */     JDBCConnectionProvider connectionPool = this.connectionPools_.remove(argDatasourceName);
/* 287 */     if (connectionPool != null) {
/*     */       try {
/* 289 */         _logger.debug("Shutting down connection pool for datasource " + argDatasourceName);
/* 290 */         connectionPool.close();
/*     */       }
/* 292 */       catch (Throwable t) {
/* 293 */         _logger.warn("Connection pool for datasource " + argDatasourceName + " could not be closed.", t);
/*     */       } 
/*     */     } else {
/*     */       
/* 297 */       _logger.debug("An attempt was made to close a connection pool for a datasource named " + argDatasourceName + " but no pool appears to exist for that datasource.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JDBCConnectionProvider getConnectionPool(String argDatasourceName) {
/* 304 */     JDBCConnectionProvider connectionPool = this.connectionPools_.get(argDatasourceName);
/*     */ 
/*     */     
/* 307 */     if (connectionPool == null) {
/* 308 */       connectionPool = loadConnectionPool(argDatasourceName);
/*     */     }
/*     */     
/* 311 */     return connectionPool;
/*     */   }
/*     */   
/*     */   private JDBCConnectionTemplate getTemplate(String argDatasourceName) {
/* 315 */     JDBCConnectionTemplate template = this.dataSources_.get(argDatasourceName);
/* 316 */     if (template == null) {
/* 317 */       throw new DBConnectionException("No datasource named '" + argDatasourceName + "' is registered with this manager. Available datasources are: " + this.dataSources_
/* 318 */           .keySet());
/*     */     }
/* 320 */     return template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized JDBCConnectionProvider loadConnectionPool(String argDatasourceName) {
/* 331 */     JDBCConnectionProvider returnPool = this.connectionPools_.get(argDatasourceName);
/*     */ 
/*     */     
/* 334 */     if (returnPool == null) {
/*     */       
/* 336 */       if (_logger.isDebugEnabled()) {
/* 337 */         _logger.debug("Creating new JDBC connection for datasource name: [" + argDatasourceName + "]");
/*     */       }
/*     */ 
/*     */       
/* 341 */       JDBCConnectionTemplate template = getTemplate(argDatasourceName);
/*     */ 
/*     */       
/*     */       try {
/* 345 */         returnPool = JDBCConnectionProvider.make(template);
/* 346 */         this.connectionPools_.put(argDatasourceName, returnPool);
/*     */       }
/* 348 */       catch (Exception ee) {
/*     */ 
/*     */         
/* 351 */         Exception scrubbedException = (ee instanceof SQLException) ? SQLExceptionScrubber.scrub((SQLException)ee) : ee;
/* 352 */         if (FailoverException.isFailover(ee)) {
/* 353 */           throw FailoverException.getNewException(scrubbedException, argDatasourceName);
/*     */         }
/*     */         
/* 356 */         throw new DBConnectionException("An unexpected exception occurred while creating a jdbc connection for datasource: " + argDatasourceName + ".", scrubbedException);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 363 */     return returnPool;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JDBCDataSourceMgr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */