/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateConfigElementTableList
/*     */   implements Callable<Void>
/*     */ {
/*  22 */   private static final Logger logger_ = Logger.getLogger(GenerateConfigElementTableList.class);
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_CLASS_NAME = "ConfigElementTableList";
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_FILE_NAME = "ConfigElementTableList.java";
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_DIRECTORY = "/dtv/xst/dao/";
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_PACKAGE = "dtv.xst.dao";
/*     */ 
/*     */   
/*     */   protected DaoGenHelper helper_;
/*     */ 
/*     */   
/*     */   public static GenerateConfigElementTableList createInstance(DaoGenHelper argHelper) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
/*  41 */     String className = System.getProperty(GenerateConfigElementTableList.class.getName(), GenerateConfigElementTableList.class
/*  42 */         .getName());
/*     */     
/*  44 */     GenerateConfigElementTableList instance = (GenerateConfigElementTableList)Class.forName(className).newInstance();
/*  45 */     instance.setHelper(argHelper);
/*  46 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  66 */     logger_.info("Generating Config Element Table List");
/*     */     
/*  68 */     Writer stringWriter = new StringWriter(10240);
/*     */     
/*  70 */     writePackageDeclaration(stringWriter);
/*  71 */     writeImportDeclaration(stringWriter);
/*     */     
/*  73 */     writeClassDeclaration(stringWriter);
/*  74 */     stringWriter.append("\n");
/*     */     
/*  76 */     writeVariableDeclaration(stringWriter);
/*  77 */     writeStaticDeclaration(stringWriter);
/*     */     
/*  79 */     writeAdditionalMethods(stringWriter);
/*     */     
/*  81 */     stringWriter.append("}\n\n");
/*     */     
/*  83 */     File f = new File(this.helper_.getOutPath() + "/dtv/xst/dao/" + getFileName());
/*     */     
/*  85 */     this.helper_.getWriter().write(f, stringWriter.toString());
/*     */     
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFileName() {
/*  96 */     return "ConfigElementTableList.java";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setHelper(DaoGenHelper argHelper) {
/* 105 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeAdditionalMethods(Writer argW) throws IOException {
/* 116 */     writeAddTableMethod(argW);
/* 117 */     writeGetConfigElementTablesMethod(argW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeClassDeclaration(Writer argW) throws IOException {
/* 128 */     argW.append(this.helper_.getClassCommentWithSuppressWarnings("An auto-generated list of tables whose rows are qualified by an entry in the system's config path."));
/*     */     
/* 130 */     argW.append("public class ");
/* 131 */     argW.append("ConfigElementTableList");
/* 132 */     argW.append(" implements IHasConfigElementTables {\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeImportDeclaration(Writer argW) throws IOException {
/* 143 */     argW.append("import java.util.ArrayList;\nimport java.util.List;\nimport dtv.data2.access.impl.daogen.IHasConfigElementTables;\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writePackageDeclaration(Writer argW) throws IOException {
/* 156 */     if (argW == null) {
/*     */       return;
/*     */     }
/* 159 */     argW.append("package ");
/* 160 */     argW.append("dtv.xst.dao");
/* 161 */     argW.append(";\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeStaticDeclaration(Writer argW) throws IOException {
/* 172 */     if (this.helper_.getDtxDefinitions() == null || this.helper_.getDtxDefinitions().isEmpty()) {
/*     */       return;
/*     */     }
/* 175 */     argW.append("  {\n");
/*     */     
/* 177 */     argW.append("    // populate config element table list\n");
/* 178 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/* 179 */       for (DtxDefinition.DtxDaoField field : dtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 180 */         if (DaoGenConfigElementHelper.isConfigElementField(field)) {
/* 181 */           argW.append("    addTable(\"" + dtx.getTable() + "\");\n");
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 186 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeVariableDeclaration(Writer argW) throws IOException {
/* 198 */     argW.append("  private final List<String> _entries = new ArrayList<>();\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendOverrides(Writer argW) throws IOException {
/* 204 */     argW.append("  @Override\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddTableMethod(Writer argW) throws IOException {
/* 209 */     argW.append("  protected void addTable(String argTable) {\n");
/* 210 */     argW.append("    _entries.add(argTable);\n");
/* 211 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetConfigElementTablesMethod(Writer argW) throws IOException {
/* 216 */     appendOverrides(argW);
/* 217 */     argW.append("  public List<String> getConfigElementTables() {\n");
/* 218 */     argW.append("    return _entries;\n");
/* 219 */     argW.append("  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateConfigElementTableList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */