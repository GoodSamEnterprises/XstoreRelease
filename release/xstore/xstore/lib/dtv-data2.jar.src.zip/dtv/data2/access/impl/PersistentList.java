/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentList<E>
/*     */   implements List<E>
/*     */ {
/*  19 */   List<E> persistentList_ = null;
/*     */ 
/*     */   
/*  22 */   List<E> unmodifiableList_ = null;
/*     */ 
/*     */   
/*  25 */   List<E> deletedList_ = null;
/*     */ 
/*     */   
/*  28 */   List<E> newList_ = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentList() {
/*  34 */     this.persistentList_ = new ArrayList<>();
/*  35 */     this.unmodifiableList_ = Collections.unmodifiableList(this.persistentList_);
/*  36 */     this.deletedList_ = new ArrayList<>();
/*  37 */     this.newList_ = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentList(List<E> argInitialList) {
/*  46 */     this.persistentList_ = argInitialList;
/*  47 */     this.unmodifiableList_ = Collections.unmodifiableList(this.persistentList_);
/*  48 */     this.deletedList_ = new ArrayList<>();
/*  49 */     this.newList_ = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(E o) {
/*  55 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int index, E element) {
/*  61 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> c) {
/*  67 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection<? extends E> c) {
/*  73 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  79 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/*  85 */     return this.persistentList_.contains(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/*  91 */     return this.persistentList_.containsAll(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E get(int index) {
/*  97 */     return this.persistentList_.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 103 */     return this.persistentList_.indexOf(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 109 */     return this.persistentList_.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 115 */     return this.unmodifiableList_.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 121 */     return this.persistentList_.lastIndexOf(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 127 */     return this.unmodifiableList_.listIterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(int index) {
/* 133 */     return this.unmodifiableList_.listIterator(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E remove(int index) {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 145 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 151 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 157 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E set(int index, E element) {
/* 163 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 169 */     return this.persistentList_.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<E> subList(int fromIndex, int toIndex) {
/* 175 */     return this.unmodifiableList_.subList(fromIndex, toIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 181 */     return this.persistentList_.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] a) {
/* 187 */     return this.persistentList_.toArray(a);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\PersistentList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */