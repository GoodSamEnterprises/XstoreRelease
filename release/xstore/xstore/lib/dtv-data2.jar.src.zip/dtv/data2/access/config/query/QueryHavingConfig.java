/*    */ package dtv.data2.access.config.query;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryHavingConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String condition_;
/*    */   private String testExpression_;
/* 24 */   private final List<QueryParameterConfig> parameters_ = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCondition() {
/* 32 */     return this.condition_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<QueryParameterConfig> getParameters() {
/* 41 */     return this.parameters_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTestExpression() {
/* 50 */     return this.testExpression_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 56 */     if ("Condition".equalsIgnoreCase(argKey)) {
/* 57 */       this.condition_ = argValue.toString();
/*    */     }
/* 59 */     else if ("TestExpression".equalsIgnoreCase(argKey)) {
/* 60 */       this.testExpression_ = argValue.toString();
/*    */     }
/* 62 */     else if ("Parameter".equalsIgnoreCase(argKey)) {
/* 63 */       this.parameters_.add((QueryParameterConfig)argValue);
/*    */     } else {
/*    */       
/* 66 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\query\QueryHavingConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */