/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.datasource.config.IPing;
/*     */ import dtv.util.DtvThreadFactory;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingSocketPing
/*     */   implements IPing
/*     */ {
/*  28 */   private static final Logger logger_ = Logger.getLogger(CachingSocketPing.class);
/*     */   
/*  30 */   private static Map<String, InetSocketAddress> addressCache_ = new HashMap<>(8);
/*     */   private String host_;
/*     */   private int port_;
/*  33 */   private int timeout_ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExecutorService executor_;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InetSocketAddress getAddress(String argHost, int argPort) {
/*  45 */     StringBuilder buff = new StringBuilder(24);
/*  46 */     buff.append(argHost).append(':').append(argPort);
/*  47 */     String key = buff.toString();
/*     */     
/*  49 */     if (addressCache_.containsKey(key)) {
/*  50 */       return addressCache_.get(key);
/*     */     }
/*     */     
/*  53 */     long startTime = logger_.isInfoEnabled() ? System.currentTimeMillis() : 0L;
/*     */     try {
/*  55 */       InetSocketAddress address = new InetSocketAddress(this.host_, this.port_);
/*     */       
/*  57 */       long endTime = logger_.isInfoEnabled() ? System.currentTimeMillis() : 0L;
/*     */       
/*  59 */       if (logger_.isInfoEnabled()) {
/*  60 */         logger_.info("Time to create address [" + address + "]: " + (endTime - startTime) + " ms.");
/*     */       }
/*  62 */       addressCache_.put(key, address);
/*  63 */       return address;
/*     */     }
/*  65 */     catch (Exception ee) {
/*  66 */       logger_.warn("Failed to create InetSocketAddress for host: " + this.host_ + " port: " + this.port_, ee);
/*     */       
/*  68 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/*  75 */     return this.host_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/*  81 */     return this.port_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ping() {
/*  87 */     long startTime = System.currentTimeMillis();
/*     */     
/*  89 */     InetSocketAddress address = getAddress(this.host_, this.port_);
/*  90 */     if (address == null) {
/*  91 */       if (logger_.isInfoEnabled()) {
/*  92 */         logger_
/*  93 */           .info("Ping failed because we could not get an address for host: " + this.host_ + " port: " + this.port_);
/*     */       }
/*  95 */       return false;
/*     */     } 
/*     */     
/*  98 */     Future<Boolean> ping = this.executor_.submit(new PingWorker(address));
/*     */     try {
/* 100 */       return ((Boolean)ping.get(this.timeout_, TimeUnit.MILLISECONDS)).booleanValue();
/*     */     }
/* 102 */     catch (TimeoutException ex) {
/* 103 */       ping.cancel(true);
/* 104 */       if (logger_.isInfoEnabled()) {
/* 105 */         logger_.info("We forcefully aborted our ping of host: " + this.host_ + " port: " + this.port_);
/*     */       }
/*     */     }
/* 108 */     catch (Exception ex) {
/* 109 */       logger_.error("CAUGHT EXCEPTION", ex);
/*     */     } finally {
/*     */       
/* 112 */       if (logger_.isInfoEnabled()) {
/* 113 */         logger_.info("TIME TO PING: " + (System.currentTimeMillis() - startTime) + " host: " + this.host_ + " port: " + this.port_);
/*     */       }
/*     */     } 
/*     */     
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProperties) {
/* 123 */     this.host_ = argProperties.getProperty("Host");
/* 124 */     if (this.host_ == null) {
/* 125 */       logger_.error("No host string specified");
/*     */     }
/*     */     
/* 128 */     String portString = argProperties.getProperty("Port");
/* 129 */     if (StringUtils.isPositiveNumber(portString)) {
/* 130 */       this.port_ = Integer.valueOf(portString).intValue();
/*     */     } else {
/*     */       
/* 133 */       logger_.error("No port configured or invalid: " + portString);
/* 134 */       this.port_ = -1;
/*     */     } 
/*     */     
/* 137 */     String timeoutString = argProperties.getProperty("Timeout");
/* 138 */     if (timeoutString != null) {
/* 139 */       if (StringUtils.isPositiveNumber(timeoutString)) {
/* 140 */         this.timeout_ = Integer.valueOf(timeoutString).intValue();
/*     */       } else {
/*     */         
/* 143 */         logger_.error("Invalid timeout specified: " + timeoutString);
/*     */       } 
/*     */     }
/* 146 */     this
/* 147 */       .executor_ = Executors.newSingleThreadExecutor((ThreadFactory)DtvThreadFactory.make("SocketPing[" + this.host_ + ":" + this.port_ + "]"));
/*     */   }
/*     */   
/*     */   private class PingWorker
/*     */     implements Callable<Boolean> {
/*     */     private final InetSocketAddress addr_;
/*     */     
/*     */     PingWorker(InetSocketAddress argAddress) {
/* 155 */       this.addr_ = argAddress;
/*     */     }
/*     */ 
/*     */     
/*     */     public Boolean call() {
/* 160 */       if (CachingSocketPing.logger_.isInfoEnabled()) {
/* 161 */         CachingSocketPing.logger_.info("ping thread for host: " + CachingSocketPing.this.host_ + " port: " + CachingSocketPing.this.port_ + " running...");
/*     */       }
/* 163 */       Socket socket = new Socket();
/*     */       try {
/* 165 */         socket.setPerformancePreferences(1, 0, 0);
/*     */         
/* 167 */         if (CachingSocketPing.logger_.isInfoEnabled()) {
/* 168 */           CachingSocketPing.logger_.info("ping of [" + this.addr_ + "] with timeout " + CachingSocketPing.this.timeout_ + "ms begun...");
/*     */         }
/*     */         
/* 171 */         socket.connect(this.addr_, CachingSocketPing.this.timeout_);
/* 172 */         if (CachingSocketPing.logger_.isInfoEnabled()) {
/* 173 */           CachingSocketPing.logger_.info("ping succeeded for [" + this.addr_ + "], host: " + CachingSocketPing.this.host_ + " port: " + CachingSocketPing.this.port_);
/*     */         }
/*     */         
/* 176 */         return Boolean.TRUE;
/*     */       }
/* 178 */       catch (Throwable ex) {
/* 179 */         if (CachingSocketPing.logger_.isInfoEnabled()) {
/* 180 */           CachingSocketPing.logger_.info("ping failed for [" + this.addr_ + "], host: " + CachingSocketPing.this.host_ + " port: " + CachingSocketPing.this.port_, ex);
/*     */         }
/* 182 */         return Boolean.FALSE;
/*     */       } finally {
/*     */         
/*     */         try {
/* 186 */           socket.close();
/*     */         }
/* 188 */         catch (IOException ex) {
/* 189 */           CachingSocketPing.logger_.warn("Error closing the socket in the ping worker.");
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\CachingSocketPing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */