/*    */ package dtv.data2.access;
/*    */ 
/*    */ import dtv.util.NumberUtils;
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanDataPropertyAccessor<T extends IHasDataProperty<? extends IDataProperty>>
/*    */   extends AbstractDataPropertyAccessor<T, Boolean>
/*    */ {
/*    */   public BooleanDataPropertyAccessor(Class<T> argParentType, String argKey) {
/* 26 */     super(argParentType, argKey);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Boolean getValue(T argParent) {
/* 35 */     return getValue(argParent, Boolean.valueOf(false));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Boolean getValue(T argParent, Boolean argDefault) {
/* 44 */     Boolean def = Boolean.valueOf(argDefault.booleanValue());
/* 45 */     Boolean value = getValueObject(argParent, def);
/* 46 */     return Boolean.valueOf(value.booleanValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Boolean getValueObject(T argParent) {
/* 56 */     return getValueObject(argParent, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Boolean getValueObject(T argParent, Boolean argDefault) {
/* 67 */     BigDecimal value = argParent.getDecimalProperty(getKey());
/* 68 */     if (value == null) {
/* 69 */       return argDefault;
/*    */     }
/* 71 */     return Boolean.valueOf(!NumberUtils.isZero(value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<Boolean> getValueType() {
/* 80 */     return Boolean.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(T argParent, Boolean argValue) {
/* 86 */     argParent.setDecimalProperty(getKey(), argValue.booleanValue() ? BigDecimal.ONE : BigDecimal.ZERO);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\BooleanDataPropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */