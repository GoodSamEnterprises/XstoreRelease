/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.impl.SelectingImplFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DataModelFactory
/*     */ {
/*  29 */   private static final Logger logger_ = Logger.getLogger(DataModelFactory.class);
/*  30 */   private static DataModelFactory factory_ = null;
/*     */ 
/*     */   
/*     */   static {
/*  34 */     factory_ = (DataModelFactory)SelectingImplFactory.getImplClass(DataModelFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDataAccessObject getDaoForDaoName(String argDaoName) {
/*     */     try {
/*  45 */       IDataAccessObject imp = factory_.getDaoForDaoNameImpl(argDaoName);
/*  46 */       if (imp != null) {
/*  47 */         return imp;
/*     */       }
/*     */     }
/*  50 */     catch (DtxException ex) {
/*  51 */       logger_.debug(ex);
/*     */     } 
/*  53 */     throw new DtxException("Could not find MODEL for DAO name: " + argDaoName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IObjectId getIdForDaoName(String argDaoName) {
/*     */     try {
/*  64 */       IObjectId oid = factory_.getIdForDaoNameImpl(argDaoName);
/*  65 */       if (oid != null) {
/*  66 */         return oid;
/*     */       }
/*     */     }
/*  69 */     catch (DtxException ex) {
/*  70 */       logger_.debug(ex);
/*     */     } 
/*  72 */     throw new DtxException("Could not find ID class for DTX type name: " + argDaoName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDataModelImpl getModelForDAO(IDataAccessObject argDao) {
/*     */     try {
/*  83 */       IDataModelImpl imp = factory_.getModelForDAOImpl(argDao.getClass().getName());
/*  84 */       if (imp != null) {
/*  85 */         return imp;
/*     */       }
/*     */     }
/*  88 */     catch (DtxException ex) {
/*  89 */       logger_.debug(ex);
/*     */     } 
/*  91 */     throw new DtxException("Could not locate model for DAO: " + argDao.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IDataModel> T getModelForInterface(Class<T> argInterfaceClass) {
/*     */     try {
/* 103 */       T imp = factory_.getModelForInterfaceImpl(argInterfaceClass);
/* 104 */       if (imp != null) {
/* 105 */         return imp;
/*     */       }
/*     */     }
/* 108 */     catch (DtxException ex) {
/* 109 */       logger_.debug(ex);
/*     */     } 
/* 111 */     throw new DtxException("Could not locate model for Interface: " + argInterfaceClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDataModelRelationship[] getModelRelationships(IDataAccessObject argDao) {
/*     */     try {
/* 122 */       IDataModelRelationship[] rels = factory_.getRelationshipsImpl(argDao.getClass().getName());
/* 123 */       if (rels != null) {
/* 124 */         return rels;
/*     */       }
/*     */     }
/* 127 */     catch (DtxException ex) {
/* 128 */       logger_.debug(ex);
/*     */     } 
/* 130 */     logger_.debug("No model relationships found for " + argDao.getClass().getName());
/* 131 */     return null;
/*     */   }
/*     */   
/*     */   protected abstract IDataAccessObject getDaoForDaoNameImpl(String paramString);
/*     */   
/*     */   protected abstract IObjectId getIdForDaoNameImpl(String paramString);
/*     */   
/*     */   protected abstract IDataModelImpl getModelForDAOImpl(String paramString);
/*     */   
/*     */   protected abstract <T extends IDataModel> T getModelForInterfaceImpl(Class<T> paramClass);
/*     */   
/*     */   protected abstract IDataModelRelationship[] getRelationshipsImpl(String paramString);
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\DataModelFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */