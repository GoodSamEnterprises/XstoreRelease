/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.datasource.config.IPing;
/*     */ import dtv.util.DtvThreadFactory;
/*     */ import dtv.util.StringUtils;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketPing
/*     */   implements IPing
/*     */ {
/*  29 */   private static final Logger _logger = Logger.getLogger(SocketPing.class);
/*     */   
/*  31 */   private ExecutorService _executor = null;
/*  32 */   private String _host = null;
/*  33 */   private int _port = 0;
/*  34 */   private int _timeout = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SocketPing() {
/*  41 */     this._port = getDefaultPort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/*  50 */     return this._host;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/*  59 */     return (this._port < 0) ? getDefaultPort() : this._port;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ping() {
/*  65 */     Future<Boolean> ping = this._executor.submit(new PingWorker());
/*     */     
/*     */     try {
/*  68 */       return ((Boolean)ping.get(this._timeout, TimeUnit.MILLISECONDS)).booleanValue();
/*     */     }
/*  70 */     catch (TimeoutException ex) {
/*  71 */       ping.cancel(true);
/*  72 */       _logger.info("We forcefully aborted our ping of [" + this._host + ":" + this._port + "]");
/*     */     }
/*  74 */     catch (Exception ex) {
/*  75 */       _logger.error("CAUGHT EXCEPTION", ex);
/*     */     } 
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProperties) {
/*  83 */     this._host = argProperties.getProperty("Host");
/*  84 */     if (this._host == null) {
/*  85 */       _logger.error("No host string specified");
/*     */     }
/*     */     
/*  88 */     String portString = argProperties.getProperty("Port");
/*  89 */     if (StringUtils.isPositiveNumber(portString)) {
/*  90 */       this._port = Integer.valueOf(portString).intValue();
/*     */     } else {
/*     */       
/*  93 */       _logger.error("No port configured or invalid: " + portString);
/*     */     } 
/*     */     
/*  96 */     String timeoutString = argProperties.getProperty("Timeout");
/*  97 */     if (timeoutString != null) {
/*  98 */       if (StringUtils.isPositiveNumber(timeoutString)) {
/*  99 */         this._timeout = Integer.valueOf(timeoutString).intValue();
/*     */       } else {
/*     */         
/* 102 */         _logger.error("Invalid timeout specified: " + timeoutString);
/*     */       } 
/*     */     }
/* 105 */     this._executor = Executors.newSingleThreadExecutor((ThreadFactory)DtvThreadFactory.make("SocketPing[" + this._host + ":" + this._port + "]"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InetSocketAddress createSocketAddress() throws UnknownHostException {
/* 117 */     return new InetSocketAddress(InetAddress.getByName(getHost()), getPort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultPort() {
/* 125 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getTimeout() {
/* 133 */     return this._timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean pingImpl() throws Exception {
/* 145 */     Socket s = new Socket(Proxy.NO_PROXY);
/* 146 */     s.connect(createSocketAddress(), getTimeout());
/* 147 */     s.shutdownOutput();
/* 148 */     s.close();
/*     */     
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private class PingWorker
/*     */     implements Callable<Boolean>
/*     */   {
/*     */     private PingWorker() {}
/*     */     
/*     */     public Boolean call() {
/* 160 */       boolean success = false;
/* 161 */       Exception failureEx = null;
/*     */       
/* 163 */       long startTime = SocketPing._logger.isInfoEnabled() ? System.currentTimeMillis() : 0L;
/*     */       try {
/* 165 */         SocketPing._logger.info("Starting ping @ " + startTime);
/* 166 */         success = SocketPing.this.pingImpl();
/*     */       }
/* 168 */       catch (Exception ex) {
/* 169 */         success = false;
/* 170 */         failureEx = ex;
/*     */       } 
/* 172 */       SocketPing._logger.info(success ? ("Ping suceeded! Time: " + (
/* 173 */           System.currentTimeMillis() - startTime)) : ("Ping failed! Time :" + (
/* 174 */           System.currentTimeMillis() - startTime) + " -- " + failureEx));
/*     */       
/* 176 */       return Boolean.valueOf(success);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\SocketPing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */