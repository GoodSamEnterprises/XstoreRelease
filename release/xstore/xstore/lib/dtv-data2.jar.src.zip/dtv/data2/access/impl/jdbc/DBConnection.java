/*     */ package dtv.data2.access.impl.jdbc;
/*     */ import dtv.data2.SQLExceptionScrubber;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.pm.PersistenceManagerStatus;
/*     */ import dtv.data2.access.query.IQueryResource;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.access.transaction.ITransactionalDataSource;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.NClob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Struct;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import oracle.ucp.jdbc.ValidConnection;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DBConnection implements ITransactionalDataSource, Connection, IQueryResource, IManagedConnection, ValidConnection {
/*  33 */   private static final Logger _logger = Logger.getLogger(DBConnection.class);
/*  34 */   private static final String RESOURCE_CLOSURE_DEBUG = DBConnection.class
/*  35 */     .getName() + ".ResourceClosureDebugEnabled";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private static final boolean statementClosureDebugEnabled = Boolean.getBoolean(RESOURCE_CLOSURE_DEBUG);
/*     */   
/*     */   private final Connection _activeConnection;
/*     */   
/*     */   private final JDBCConnectionTemplate _template;
/*     */   
/*     */   private TransactionToken _associatedTransaction;
/*     */   
/*     */   private JDBCDataSourceMgr _myManager;
/*     */   private final int _queryTimeout;
/*     */   
/*     */   public static DBConnection adapt(Connection argConnection, JDBCConnectionTemplate argTemplate, boolean argAutoCommit) {
/*  52 */     return new DBConnection(argConnection, argTemplate, argAutoCommit);
/*     */   }
/*     */   
/*     */   private static void logUnclosedMessage(String argObjectType, StackTraceElement[] argStack) {
/*  56 */     StringBuilder stringBuilder = new StringBuilder();
/*  57 */     stringBuilder.append("Unclosed ").append(argObjectType).append(" detected.  This ").append(argObjectType)
/*  58 */       .append(" will be closed automatically.");
/*  59 */     if (argStack != null) {
/*  60 */       stringBuilder.append("\nCreator Stacktrace:\n");
/*  61 */       for (StackTraceElement stackElement : argStack) {
/*  62 */         stringBuilder.append("\t").append(stackElement).append("\n");
/*     */       }
/*     */     } else {
/*     */       
/*  66 */       stringBuilder.append(" Set system property " + RESOURCE_CLOSURE_DEBUG + "=true for more information.");
/*     */     } 
/*  68 */     _logger.error(stringBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _isClosed = false;
/*     */ 
/*     */ 
/*     */   
/*  78 */   private Map<Statement, StackTraceElement[]> _openStatements = null;
/*     */   private final StackTraceElement[] _creationStackTrace;
/*     */   
/*     */   private DBConnection(Connection argConn, JDBCConnectionTemplate argTemplate, boolean argAutoCommit) {
/*  82 */     this._activeConnection = argConn;
/*  83 */     this._template = argTemplate;
/*  84 */     this._queryTimeout = argTemplate.getQueryTimeout();
/*  85 */     this._creationStackTrace = statementClosureDebugEnabled ? (new Throwable()).getStackTrace() : null;
/*     */     try {
/*  87 */       if (this._activeConnection.getAutoCommit() != argAutoCommit) {
/*  88 */         this._activeConnection.setAutoCommit(argAutoCommit);
/*     */       }
/*     */     }
/*  91 */     catch (SQLException ee) {
/*  92 */       throw new DBConnectionException("An exception occurred while setting JDBC connection auto commit to true for datasource: " + 
/*     */           
/*  94 */           getDataSourceName(), 
/*  95 */           SQLExceptionScrubber.scrub(ee));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort(Executor argExecutor) throws SQLException {
/* 103 */     this._activeConnection.abort(argExecutor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearWarnings() throws SQLException {
/* 110 */     this._activeConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 117 */     processUnclosedStatements();
/* 118 */     completeTransaction();
/* 119 */     this._isClosed = true;
/* 120 */     this._activeConnection.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commit() throws SQLException {
/* 127 */     this._activeConnection.commit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase1(TransactionToken argTransToken) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase2(TransactionToken argTransToken) {
/*     */     try {
/* 147 */       commit();
/*     */     }
/* 149 */     catch (SQLException ee) {
/* 150 */       throw new DBConnectionException("Attempt to commit database transaction failed: " + ee
/* 151 */           .getMessage() + " on: " + this, ee);
/*     */     } 
/* 153 */     completeTransaction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Array createArrayOf(String argTypeName, Object[] argElements) throws SQLException {
/* 160 */     return this._activeConnection.createArrayOf(argTypeName, argElements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blob createBlob() throws SQLException {
/* 167 */     return this._activeConnection.createBlob();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Clob createClob() throws SQLException {
/* 174 */     return this._activeConnection.createClob();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NClob createNClob() throws SQLException {
/* 181 */     return this._activeConnection.createNClob();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLXML createSQLXML() throws SQLException {
/* 188 */     return this._activeConnection.createSQLXML();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement() throws SQLException {
/* 196 */     Statement statement = this._activeConnection.createStatement();
/* 197 */     configureStatement(statement);
/* 198 */     return DtvPreparedStatement.adaptStatement(statement, "null", this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int argResultSetType, int argResultSetConcurrency) throws SQLException {
/* 206 */     Statement statement = this._activeConnection.createStatement(argResultSetType, argResultSetConcurrency);
/* 207 */     configureStatement(statement);
/* 208 */     return DtvPreparedStatement.adaptStatement(statement, "null", this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int argResultSetType, int argResultSetConcurrency, int argResultSetHoldability) throws SQLException {
/* 218 */     Statement statement = this._activeConnection.createStatement(argResultSetType, argResultSetConcurrency, argResultSetHoldability);
/* 219 */     configureStatement(statement);
/* 220 */     return DtvPreparedStatement.adaptStatement(statement, "null", this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Struct createStruct(String argTypeName, Object[] argAttributes) throws SQLException {
/* 227 */     return this._activeConnection.createStruct(argTypeName, argAttributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public TransactionToken getAssociatedTransaction() {
/* 232 */     return this._associatedTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAutoCommit() throws SQLException {
/* 239 */     return this._activeConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalog() throws SQLException {
/* 246 */     return this._activeConnection.getCatalog();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getClientInfo() throws SQLException {
/* 253 */     return this._activeConnection.getClientInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClientInfo(String argName) throws SQLException {
/* 260 */     return this._activeConnection.getClientInfo(argName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 266 */     return this._template.getDataSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHoldability() throws SQLException {
/* 273 */     return this._activeConnection.getHoldability();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseMetaData getMetaData() throws SQLException {
/* 280 */     return this._activeConnection.getMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNetworkTimeout() throws SQLException {
/* 287 */     return this._activeConnection.getNetworkTimeout();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchema() throws SQLException {
/* 294 */     return this._activeConnection.getSchema();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTransactionIsolation() throws SQLException {
/* 301 */     return this._activeConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Class<?>> getTypeMap() throws SQLException {
/* 308 */     return this._activeConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException {
/* 315 */     return this._activeConnection.getWarnings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() throws SQLException {
/* 322 */     return this._isClosed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() throws SQLException {
/* 329 */     return this._activeConnection.isReadOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() throws SQLException {
/* 336 */     if (this._activeConnection instanceof ValidConnection) {
/* 337 */       ValidConnection conn = (ValidConnection)this._activeConnection;
/* 338 */       return conn.isValid();
/*     */     } 
/* 340 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid(int argTimeout) throws SQLException {
/* 347 */     return this._activeConnection.isValid(argTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> argIface) throws SQLException {
/* 354 */     return this._activeConnection.isWrapperFor(argIface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nativeSQL(String argSql) throws SQLException {
/* 361 */     return this._activeConnection.nativeSQL(argSql);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String argSql) throws SQLException {
/* 369 */     CallableStatement statement = this._activeConnection.prepareCall(argSql);
/* 370 */     configureStatement(statement);
/* 371 */     return DtvPreparedStatement.adaptCallableStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String argSql, int argResultSetType, int argResultSetConcurrency) throws SQLException {
/* 380 */     CallableStatement statement = this._activeConnection.prepareCall(argSql, argResultSetType, argResultSetConcurrency);
/* 381 */     configureStatement(statement);
/* 382 */     return DtvPreparedStatement.adaptCallableStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String argSql, int argResultSetType, int argResultSetConcurrency, int argResultSetHoldability) throws SQLException {
/* 391 */     CallableStatement statement = this._activeConnection.prepareCall(argSql, argResultSetType, argResultSetConcurrency, argResultSetHoldability);
/*     */     
/* 393 */     configureStatement(statement);
/* 394 */     return DtvPreparedStatement.adaptCallableStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String argSql) throws SQLException {
/* 402 */     PreparedStatement statement = this._activeConnection.prepareStatement(argSql);
/* 403 */     configureStatement(statement);
/* 404 */     return DtvPreparedStatement.adaptPreparedStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String argSql, int argAutoGeneratedKeys) throws SQLException {
/* 412 */     PreparedStatement statement = this._activeConnection.prepareStatement(argSql, argAutoGeneratedKeys);
/* 413 */     configureStatement(statement);
/* 414 */     return DtvPreparedStatement.adaptPreparedStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String argSql, int argResultSetType, int argResultSetConcurrency) throws SQLException {
/* 423 */     PreparedStatement statement = this._activeConnection.prepareStatement(argSql, argResultSetType, argResultSetConcurrency);
/* 424 */     configureStatement(statement);
/* 425 */     return DtvPreparedStatement.adaptPreparedStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String argSql, int argResultSetType, int argResultSetConcurrency, int argResultSetHoldability) throws SQLException {
/* 434 */     PreparedStatement statement = this._activeConnection.prepareStatement(argSql, argResultSetType, argResultSetConcurrency, argResultSetHoldability);
/*     */     
/* 436 */     configureStatement(statement);
/* 437 */     return DtvPreparedStatement.adaptPreparedStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String argSql, int[] argColumnIndexes) throws SQLException {
/* 445 */     PreparedStatement statement = this._activeConnection.prepareStatement(argSql, argColumnIndexes);
/* 446 */     configureStatement(statement);
/* 447 */     return DtvPreparedStatement.adaptPreparedStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String argSql, String[] argColumnNames) throws SQLException {
/* 455 */     PreparedStatement statement = this._activeConnection.prepareStatement(argSql, argColumnNames);
/* 456 */     configureStatement(statement);
/* 457 */     return DtvPreparedStatement.adaptPreparedStatement(statement, argSql, this._template.getDataSourceName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseSavepoint(Savepoint argSavepoint) throws SQLException {
/* 464 */     this._activeConnection.releaseSavepoint(argSavepoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback() throws SQLException {
/* 471 */     this._activeConnection.rollback();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(Savepoint argSavepoint) throws SQLException {
/* 478 */     this._activeConnection.rollback(argSavepoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void rollback(TransactionToken argToken) {
/*     */     try {
/* 488 */       this._activeConnection.rollback();
/*     */     }
/* 490 */     catch (SQLException ee) {
/*     */       
/* 492 */       if (!StatusMgr.getInstance().getDataSourceStatus(this._template.getDataSourceName()).equals(PersistenceManagerStatus.OFFLINE))
/*     */       {
/* 494 */         if (FailoverException.isFailover(ee)) {
/* 495 */           StatusMgr.getInstance().notifyOffline(this._template.getDataSourceName(), 
/* 496 */               FailoverException.getNewException(ee, this._template.getDataSourceName()));
/*     */         } else {
/*     */           
/* 499 */           throw new DBConnectionException("Attempt to rollback database transaction failed: " + ee
/* 500 */               .getMessage() + " on: " + this, ee);
/*     */         } 
/*     */       }
/*     */     } finally {
/*     */       
/* 505 */       completeTransaction();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAssociatedTransaction(TransactionToken argAssociatedTransaction) {
/* 511 */     if (this._associatedTransaction != null && argAssociatedTransaction != null && this._associatedTransaction != argAssociatedTransaction)
/*     */     {
/*     */       
/* 514 */       throw new DtxException("Class constraint of DBConnection violated. A connection cannot be associated with multiple transactions at the same time. on: " + this);
/*     */     }
/*     */ 
/*     */     
/* 518 */     this._associatedTransaction = argAssociatedTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoCommit(boolean argAutoCommit) throws SQLException {
/* 525 */     this._activeConnection.setAutoCommit(argAutoCommit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(String argCatalog) throws SQLException {
/* 532 */     this._activeConnection.setCatalog(argCatalog);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClientInfo(Properties argProperties) throws SQLClientInfoException {
/* 539 */     this._activeConnection.setClientInfo(argProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClientInfo(String argName, String argValue) throws SQLClientInfoException {
/* 546 */     this._activeConnection.setClientInfo(argName, argValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHoldability(int argHoldability) throws SQLException {
/* 553 */     this._activeConnection.setHoldability(argHoldability);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInvalid() throws SQLException {
/* 560 */     if (this._activeConnection instanceof ValidConnection) {
/* 561 */       ValidConnection conn = (ValidConnection)this._activeConnection;
/* 562 */       conn.setInvalid();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMyManager(JDBCDataSourceMgr argMyManager) {
/* 568 */     this._myManager = argMyManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNetworkTimeout(Executor argExecutor, int argMilliseconds) throws SQLException {
/* 575 */     this._activeConnection.setNetworkTimeout(argExecutor, argMilliseconds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean argReadOnly) throws SQLException {
/* 582 */     this._activeConnection.setReadOnly(argReadOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Savepoint setSavepoint() throws SQLException {
/* 589 */     return this._activeConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Savepoint setSavepoint(String argName) throws SQLException {
/* 596 */     return this._activeConnection.setSavepoint(argName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(String argSchema) throws SQLException {
/* 603 */     this._activeConnection.setSchema(argSchema);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionIsolation(int argLevel) throws SQLException {
/* 610 */     this._activeConnection.setTransactionIsolation(argLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeMap(Map<String, Class<?>> argMap) throws SQLException {
/* 617 */     this._activeConnection.setTypeMap(argMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 622 */     return getClass().getName() + " " + getDescription() + " @" + hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> argIface) throws SQLException {
/* 629 */     return this._activeConnection.unwrap(argIface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 636 */     if (!isClosed()) {
/* 637 */       logUnclosedMessage("connection", this._creationStackTrace);
/*     */       try {
/* 639 */         close();
/*     */       }
/* 641 */       catch (Throwable ex) {
/* 642 */         _logger.error("CAUGHT EXCEPTION", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void completeTransaction() {
/*     */     try {
/* 649 */       if (this._myManager != null && this._associatedTransaction != null) {
/* 650 */         setAssociatedTransaction(null);
/* 651 */         setMyManager(null);
/* 652 */         this._isClosed = true;
/* 653 */         this._activeConnection.close();
/*     */       }
/*     */     
/* 656 */     } catch (SQLException e) {
/* 657 */       _logger.error("Attept to close connection failed: " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureStatement(Statement argStatement) throws SQLException {
/* 663 */     argStatement.setQueryTimeout(this._queryTimeout);
/* 664 */     if (statementClosureDebugEnabled) {
/* 665 */       storeStatementDebugInfo(argStatement);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getDescription() {
/* 670 */     return "Datasource: [" + this._template.getDataSourceName() + "] Driver: " + this._template
/* 671 */       .getConnectionFactoryClassName() + " Url: " + this._template.getUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processUnclosedStatements() {
/* 680 */     if (statementClosureDebugEnabled && this._openStatements != null) {
/* 681 */       for (Map.Entry<Statement, StackTraceElement[]> entry : this._openStatements.entrySet()) {
/*     */         
/*     */         try {
/* 684 */           Statement statement = entry.getKey();
/* 685 */           if (!statement.isClosed()) {
/* 686 */             logUnclosedMessage("statement", entry.getValue());
/* 687 */             statement.close();
/*     */           }
/*     */         
/* 690 */         } catch (SQLException ex) {
/* 691 */           _logger.error("An exception occurred when asserting the state of a connection or closing it.", ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void storeStatementDebugInfo(Statement argStatement) {
/* 706 */     if (statementClosureDebugEnabled) {
/* 707 */       if (this._openStatements == null) {
/* 708 */         this._openStatements = (Map)new HashMap<>();
/*     */       }
/* 710 */       this._openStatements.put(argStatement, (new Throwable()).getStackTrace());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\DBConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */