/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.IQueryResult;
/*     */ import dtv.data2.access.IQueryResultList;
/*     */ import dtv.data2.access.QueryResultList;
/*     */ import dtv.data2.access.config.query.QueryDescriptor;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.jdbc.JDBCCall;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlQueryHandler
/*     */   implements IQueryHandler
/*     */ {
/*     */   public static final String PARAM_DB_TABLE = "DB_TABLE";
/*     */   private static final String PARAM_SUPPRESS_ALIAS = "SuppressTableAlias";
/*     */   private static final String WILDCARD_DB_TABLE = "\\{\\%TABLE\\%\\}";
/*     */   private static final String WILDCARD_DB_TABLE_ALIAS = "\\{\\%ALIAS\\%\\}";
/*     */   private static final Pattern DB_TABLE_ALIAS_PATTERN;
/*  66 */   private static final Logger logger_ = Logger.getLogger(SqlQueryHandler.class);
/*  67 */   private static final Logger queryDebugLogger_ = Logger.getLogger("DtxQueryDebugger");
/*     */   
/*     */   static {
/*  70 */     String ws = "[\\s\\r\\n]+";
/*  71 */     DB_TABLE_ALIAS_PATTERN = Pattern.compile("DELETE[\\s\\r\\n]+\\{\\%ALIAS\\%\\}[\\s\\r\\n]+FROM[\\s\\r\\n]+\\w+[\\s\\r\\n]+(\\w)", 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties props_;
/*     */ 
/*     */   
/*     */   private String sourceDescription_;
/*     */ 
/*     */   
/*     */   private String queryKey_;
/*     */ 
/*     */   
/*     */   private ISqlQueryDecorator _queryDecorator;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IResultFilterFactory _resultFilterFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execute(IPersistenceStrategy argStrategy, Map<String, Object> argParameters, QueryToken argQueryToken) throws Exception {
/*  95 */     if (!(argStrategy instanceof dtv.data2.access.impl.jdbc.JDBCPersistenceStrategy)) {
/*  96 */       throw new DtxException(getClass().getName() + " can only work with JDBCPersistenceStrategy currently. The strategy passed instead was: " + argStrategy);
/*     */     }
/*     */ 
/*     */     
/* 100 */     String sqlStatementBase = "";
/* 101 */     int queryCount = Integer.parseInt(this.props_.getProperty("QueryCount", "0"));
/*     */     
/* 103 */     if (queryCount > 0) {
/* 104 */       sqlStatementBase = SqlQueryBuilder.buildBaseQuery(this.props_, argParameters, queryCount);
/*     */     } else {
/*     */       
/* 107 */       sqlStatementBase = this.props_.getProperty("SQL");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 112 */     sqlStatementBase = replaceTableWildcard(sqlStatementBase, argParameters);
/* 113 */     sqlStatementBase = replaceAliasWildcard(sqlStatementBase, argParameters);
/*     */     
/* 115 */     QueryDescriptor queryDescriptor = DataFactory.getInstance().getQueryDescriptor(this.queryKey_);
/*     */     
/* 117 */     JDBCCall call = SqlQueryBuilder.getJDBCCall(argStrategy, sqlStatementBase, this.props_, argParameters);
/*     */     
/* 119 */     String callString = this._queryDecorator.decorateSql(call.getSqlString(), argStrategy, argParameters);
/* 120 */     StringBuilder sql = new StringBuilder(callString);
/*     */     
/* 122 */     if (queryDebugLogger_.isDebugEnabled()) {
/* 123 */       queryDebugLogger_.debug("SQL Query: [" + this.queryKey_ + "] preparing to execute on data source: " + argStrategy
/* 124 */           .getDataSourceName() + " (SqlQueryHandler)");
/* 125 */       queryDebugLogger_.debug("  [" + this.queryKey_ + "] sql to execute: " + call.getSqlString());
/* 126 */       queryDebugLogger_.debug("  [" + this.queryKey_ + "] parameter values: " + call.getParams());
/*     */     } 
/*     */     
/* 129 */     IQueryResultList<?> result = null;
/*     */     try {
/* 131 */       result = SqlQueryExecutor.execute(sql.toString(), call.getParams(), call.getParamNames(), this.props_, queryDescriptor, argStrategy, argQueryToken);
/*     */ 
/*     */       
/* 134 */       if (result == null) {
/* 135 */         return null;
/*     */       }
/*     */       
/* 138 */       if (queryDescriptor.getResultClass() != null) {
/* 139 */         if (IQueryResult.class.isAssignableFrom(result.getResultClass())) {
/* 140 */           IQueryResultList<? extends IQueryResult> resultList = (IQueryResultList)result;
/*     */           
/* 142 */           if (queryDescriptor.getResultFilter() != null) {
/* 143 */             IResultFilter filter = this._resultFilterFactory.getResultFilter(queryDescriptor.getResultFilter());
/* 144 */             Collection<?> filteredResults = filter.filter((List<? extends IQueryResult>)resultList, argParameters);
/* 145 */             result = QueryResultList.makeList(filteredResults, result.getResultClass());
/*     */           } 
/*     */         } else {
/*     */           
/* 149 */           logger_
/* 150 */             .warn("Query: [" + this.queryKey_ + "] returned unexpected results: [" + result + "] Unable to load this data into the result class.  The raw data will be returned.");
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 155 */       return result;
/*     */     }
/* 157 */     catch (Exception ee) {
/* 158 */       if (FailoverException.isFailover(ee)) {
/* 159 */         throw FailoverException.getNewException(ee, argStrategy.getDataSourceName());
/*     */       }
/*     */       
/* 162 */       throw ee;
/*     */     }
/*     */     finally {
/*     */       
/* 166 */       if (queryDebugLogger_.isDebugEnabled()) {
/* 167 */         queryDebugLogger_.debug("  [" + this.queryKey_ + "] result: " + result);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getProperties() {
/* 175 */     return this.props_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceDescription() {
/* 181 */     return this.sourceDescription_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProperties) {
/* 187 */     this.props_ = argProperties;
/*     */     
/* 189 */     if (this.props_ == null) {
/* 190 */       throw new DtxException("Null props were passed to SqlQueryHandler");
/*     */     }
/* 192 */     this.queryKey_ = this.props_.getProperty("Name");
/*     */     
/* 194 */     if (StringUtils.isEmpty(this.queryKey_)) {
/* 195 */       throw new DtxException("Properties passed to SqlQueryHandler do not contain a valid query key. " + this.props_);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueryDecorator(ISqlQueryDecorator argQueryDecorator) {
/* 203 */     this._queryDecorator = argQueryDecorator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceDescription(String argSourceDescription) {
/* 209 */     this.sourceDescription_ = argSourceDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String replaceAliasWildcard(String argSqlStatement, Map<String, Object> argParameters) {
/* 222 */     String sqlStatement = argSqlStatement;
/* 223 */     boolean suppressAlias = ConfigUtils.toBoolean(argParameters.get("SuppressTableAlias"), false).booleanValue();
/*     */     
/* 225 */     Matcher matcher = DB_TABLE_ALIAS_PATTERN.matcher(argSqlStatement);
/*     */     
/* 227 */     if (matcher.find()) {
/* 228 */       String alias = suppressAlias ? "" : matcher.group(1);
/* 229 */       sqlStatement = sqlStatement.replaceAll("\\{\\%ALIAS\\%\\}", alias);
/*     */     } 
/* 231 */     return sqlStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String replaceTableWildcard(String argSqlStatement, Map<String, Object> argParameters) {
/* 244 */     return argSqlStatement.replaceAll("\\{\\%TABLE\\%\\}", StringUtils.nonNull(argParameters.get("DB_TABLE")));
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\SqlQueryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */