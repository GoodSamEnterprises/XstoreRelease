/*    */ package dtv.data2.access.query;
/*    */ 
/*    */ import dtv.data2.access.IQueryResultWrapper;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryResultWrapper<T>
/*    */   implements IQueryResultWrapper<T>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private T data_;
/*    */   private boolean isLimitReached_;
/*    */   private long limit_;
/*    */   
/*    */   public QueryResultWrapper(T argData) {
/* 32 */     this(argData, false, 0L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QueryResultWrapper(T argData, boolean argLimitReached, long argLimit) {
/* 43 */     this.data_ = argData;
/* 44 */     this.isLimitReached_ = argLimitReached;
/* 45 */     this.limit_ = argLimit;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T getData() {
/* 55 */     return this.data_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getQueryLimit() {
/* 65 */     return this.limit_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isQueryLimitReached() {
/* 75 */     return this.isLimitReached_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setData(T argData) {
/* 84 */     this.data_ = argData;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 90 */     return "QueryResultWrapper with data: " + this.data_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryResultWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */