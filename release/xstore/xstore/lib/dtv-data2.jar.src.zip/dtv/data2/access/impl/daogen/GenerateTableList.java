/*    */ package dtv.data2.access.impl.daogen;
/*    */ 
/*    */ import dtv.util.StringUtils;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerateTableList
/*    */   implements Callable<Object>
/*    */ {
/* 23 */   private static final Logger logger_ = Logger.getLogger(GenerateTableList.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private final DaoGenHelper helper_;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   GenerateTableList(DaoGenHelper argHelper) {
/* 33 */     this.helper_ = argHelper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object call() throws Exception {
/* 41 */     logger_.info("Generating Table List");
/*    */     
/* 43 */     StringBuilder w = new StringBuilder(5120);
/*    */     
/* 45 */     List<DtxDefinition> dtxDefs = new ArrayList<>(this.helper_.getDtxDefinitions());
/* 46 */     Collections.sort(dtxDefs, new DtxComparator());
/*    */     
/* 48 */     for (DtxDefinition dtx : dtxDefs) {
/* 49 */       if (!StringUtils.isEmpty(dtx.getTable())) {
/* 50 */         w.append(dtx.getTable() + "\n");
/*    */       }
/*    */     } 
/*    */     
/* 54 */     File file = new File(this.helper_.getOutPath() + File.separator + "table_list.txt");
/* 55 */     this.helper_.getWriter().write(file, w.toString());
/*    */     
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   class DtxComparator
/*    */     implements Comparator<DtxDefinition>
/*    */   {
/*    */     public int compare(DtxDefinition o1, DtxDefinition o2) {
/* 69 */       String table1 = o1.getTable();
/* 70 */       String table2 = o2.getTable();
/*    */       
/* 72 */       if (table1 == null) {
/* 73 */         table1 = "";
/*    */       }
/* 75 */       if (table2 == null) {
/* 76 */         table2 = "";
/*    */       }
/*    */       
/* 79 */       return table1.compareTo(table2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateTableList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */