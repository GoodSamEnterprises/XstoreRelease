/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.transaction.DataSourceTransactionManager;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTransactionalPersister
/*     */   implements ITransactionalPersister
/*     */ {
/*  23 */   private static final Logger _logger = Logger.getLogger(AbstractTransactionalPersister.class);
/*     */   
/*     */   private final Map<TransactionToken, List<IPersistable>> _transactionsToPersist;
/*     */   
/*  27 */   private String _dataSourceName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractTransactionalPersister() {
/*  34 */     this._transactionsToPersist = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase1(TransactionToken argTransToken) {
/*  40 */     for (IPersistable persistable : this._transactionsToPersist.get(argTransToken)) {
/*  41 */       commit(persistable);
/*     */     }
/*  43 */     this._transactionsToPersist.remove(argTransToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase2(TransactionToken argTransToken) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/*  55 */     return this._dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void prepareForPersistence(TransactionToken argTransToken, IPersistable argPersistable) {
/*  61 */     if (!isApplicableForPersistence(argPersistable)) {
/*  62 */       _logger.warn("[" + argPersistable + "] is not a valid persistable for this strategy helper!");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  68 */     synchronized (this._transactionsToPersist) {
/*  69 */       List<IPersistable> persistablesForThisTrans = this._transactionsToPersist.get(argTransToken);
/*     */       
/*  71 */       if (persistablesForThisTrans == null) {
/*  72 */         persistablesForThisTrans = new ArrayList<>();
/*  73 */         this._transactionsToPersist.put(argTransToken, persistablesForThisTrans);
/*     */ 
/*     */ 
/*     */         
/*  77 */         DataSourceTransactionManager.getInstance().registerDataSource(argTransToken, this);
/*     */       } 
/*     */       
/*  80 */       persistablesForThisTrans.add(argPersistable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(TransactionToken argTransToken) {
/*  87 */     this._transactionsToPersist.remove(argTransToken);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String argDataSourceName) {
/*  93 */     this._dataSourceName = argDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void commit(IPersistable paramIPersistable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isApplicableForPersistence(IPersistable argPersistable) {
/* 111 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractTransactionalPersister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */