/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxInverseRelationship
/*     */ {
/*     */   private String name_;
/*     */   private DtxDefinition parent_;
/*     */   private String parentType_;
/*     */   
/*     */   public String getGetMethodName() {
/*  30 */     return "get" + StringUtils.ensureFirstUpperCase(getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  39 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxDefinition getParent() {
/*  48 */     return this.parent_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParentType() {
/*  57 */     return this.parentType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSetMethodName() {
/*  66 */     return "set" + StringUtils.ensureFirstUpperCase(getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String argName) {
/*  75 */     this.name_ = argName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(DtxDefinition argParent) {
/*  84 */     this.parent_ = argParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentType(String argParentType) {
/*  93 */     this.parentType_ = argParentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() {
/* 102 */     if (StringUtils.isEmpty(getName())) {
/* 103 */       throw new RuntimeException("InverseRelationship does not define a name.");
/*     */     }
/* 105 */     if (StringUtils.isEmpty(getParentType()))
/* 106 */       throw new RuntimeException("InverseRelationship: " + getName() + " does not define a parent."); 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DtxInverseRelationship.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */