/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.util.DtvDate;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GmtDateFactory
/*    */   extends DaoDateFactory
/*    */ {
/* 19 */   private static ThreadLocal<Calendar> CAL = new ThreadLocal<Calendar>()
/*    */     {
/*    */       protected Calendar initialValue()
/*    */       {
/* 23 */         return Calendar.getInstance();
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */   
/*    */   public DtvDate newDate() {
/* 30 */     DtvDate date = new DtvDate();
/* 31 */     Calendar cal = CAL.get();
/*    */     
/* 33 */     long now = date.getTime();
/* 34 */     cal.setTimeInMillis(now);
/* 35 */     now -= cal.get(15);
/* 36 */     now -= cal.get(16);
/* 37 */     date.setTime(now);
/*    */     
/* 39 */     return date;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\GmtDateFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */