/*    */ package dtv.data2.access.pm;
/*    */ 
/*    */ import dtv.data2.access.IPersistenceMgrType;
/*    */ import dtv.data2.access.config.pmtype.PersistenceMgrTypeConfigHelper;
/*    */ import dtv.data2.access.config.pmtype.PersistenceMgrTypeDescriptor;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistenceMgrTypeFactory
/*    */ {
/*    */   private final PersistenceMgrTypeConfigHelper _configHelper;
/*    */   
/*    */   protected PersistenceMgrTypeFactory(PersistenceMgrTypeConfigHelper cfg) {
/* 28 */     this._configHelper = cfg;
/* 29 */     this._configHelper.initialize();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<PersistenceMgrTypeDescriptor> getPersistenceMgrtTypeDescriptors() {
/* 38 */     return this._configHelper.getDescriptors();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PersistenceMgrTypeDescriptor getPersistenceMgrTypeDescriptor(IPersistenceMgrType argType) throws NoSuchDescriptorException {
/* 51 */     String typeName = argType.getName();
/*    */ 
/*    */     
/* 54 */     PersistenceMgrTypeDescriptor descriptor = this._configHelper.getDescriptor(typeName);
/*    */ 
/*    */     
/* 57 */     if (descriptor == null) {
/* 58 */       throw new NoSuchDescriptorException(typeName);
/*    */     }
/*    */ 
/*    */     
/* 62 */     return descriptor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class NoSuchDescriptorException
/*    */     extends RuntimeException
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public NoSuchDescriptorException(String descriptorTypeName) {
/* 82 */       super("No such Persistence Manager Type Descriptor: '" + descriptorTypeName + "'");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PersistenceMgrTypeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */