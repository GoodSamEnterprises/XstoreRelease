/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.data2.access.exception.DtxException;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AdapterMap
/*    */ {
/* 19 */   protected static final Logger logger_ = Logger.getLogger(AdapterMap.class);
/*    */ 
/*    */   
/* 22 */   protected static AdapterMap adapterMap_ = null;
/*    */   
/*    */   static {
/* 25 */     adapterMap_ = SelectingImplFactory.<AdapterMap>getImplClass(AdapterMap.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract IRelationshipAdapter getRelationshipAdapterImpl(Class paramClass, String paramString);
/*    */ 
/*    */ 
/*    */   
/*    */   public static final IRelationshipAdapter getRelationshipAdapter(Class<?> argClass, String argIdentifier) {
/*    */     try {
/* 37 */       IRelationshipAdapter rel = adapterMap_.getRelationshipAdapterImpl(argClass, argIdentifier);
/* 38 */       if (rel != null) {
/* 39 */         return rel;
/*    */       }
/*    */     }
/* 42 */     catch (DtxException ex) {
/* 43 */       logger_.debug(ex);
/*    */     } 
/* 45 */     throw new DtxException("No relationship adapter found for " + argClass + " and " + argIdentifier);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AdapterMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */