/*    */ package dtv.data2.access;
/*    */ 
/*    */ import dtv.util.ClassPathUtils;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigKeyedDataFilter
/*    */ {
/*    */   public <R extends IHasConfigElement> Collection<R> filterResults(Collection<R> argElementsToFilter) {
/* 34 */     Map<String, Integer> prioritizedConfigElements = ClassPathUtils.getPrioritizedConfigPathElements();
/*    */     
/* 36 */     prioritizedConfigElements.put("*", Integer.valueOf(-2147483648));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     final Map<String, Integer> prioritizedConfigElementsToUpperCase = (Map<String, Integer>)prioritizedConfigElements.entrySet().stream().collect(Collectors.toMap(e -> ((String)e.getKey()).toUpperCase(), e -> (Integer)e.getValue()));
/*    */ 
/*    */ 
/*    */     
/* 45 */     List<R> sortedResults = (List<R>)argElementsToFilter.stream().filter(r -> prioritizedConfigElementsToUpperCase.containsKey(r.getConfigElement().toUpperCase())).collect(Collectors.toList());
/*    */     
/* 47 */     Collections.sort(sortedResults, new Comparator<R>()
/*    */         {
/*    */           public int compare(R argO1, R argO2)
/*    */           {
/* 51 */             Integer priority1 = (Integer)prioritizedConfigElementsToUpperCase.get(argO1.getConfigElement().toUpperCase());
/* 52 */             Integer priority2 = (Integer)prioritizedConfigElementsToUpperCase.get(argO2.getConfigElement().toUpperCase());
/* 53 */             return priority1.compareTo(priority2);
/*    */           }
/*    */         });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 64 */     Map<IObjectId, R> filteredResults = new HashMap<>();
/*    */     
/* 66 */     for (IHasConfigElement iHasConfigElement : sortedResults) {
/* 67 */       IObjectId id = iHasConfigElement.getObjectId();
/*    */       
/* 69 */       if (id instanceof IHasConfigElement) {
/* 70 */         IHasConfigElement configId = (IHasConfigElement)id;
/* 71 */         configId.setConfigElement((String)null);
/*    */       } 
/*    */       
/* 74 */       filteredResults.put(id, (R)iHasConfigElement);
/*    */     } 
/*    */     
/* 77 */     return filteredResults.values();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\ConfigKeyedDataFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */