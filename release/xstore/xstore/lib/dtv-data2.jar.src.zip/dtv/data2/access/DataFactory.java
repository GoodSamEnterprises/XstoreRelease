/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.config.query.QueryDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.query.IQueryHandler;
/*     */ import dtv.data2.access.query.QueryFactory;
/*     */ import dtv.data2.access.query.QueryResultWrapper;
/*     */ import dtv.data2.access.status.IStatusMgr;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import dtv.event.EventManager;
/*     */ import dtv.util.ObjectUtils;
/*     */ import dtv.util.ReflectionException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFactory
/*     */   extends AbstractDataFactory
/*     */ {
/*  36 */   private static final Logger _logger = Logger.getLogger(DataFactory.class);
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceManagerFactory _persistenceFactory;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private QueryFactory _queryFactory;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private EventManager _eventManager;
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IDataModel> T createObject(Class<T> objectInterface) {
/*  58 */     return createObject(null, objectInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IDataModel> T createObject(IObjectId argId, Class<T> objectInterface) {
/*  87 */     return getInstance().createNewObject(argId, objectInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IDataModel> T createTransientObject(Class<T> objectInterface) {
/*  99 */     T model = createObject(null, objectInterface);
/* 100 */     makeTransient(model);
/* 101 */     return model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int executeQuery(IQueryKey<Object[]> argQueryKey, Map<String, Object> argQueryParams) {
/* 113 */     Object[] results = executeQueryImpl(argQueryKey.getName(), argQueryParams);
/*     */     
/* 115 */     if (results == null || results.length == 0) {
/* 116 */       _logger.warn("No side effects reported by query: " + argQueryKey, new Throwable("STACK TRACE"));
/* 117 */       return -1;
/*     */     } 
/* 119 */     return getResults(results);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDataFactory getInstance() {
/* 132 */     return DataFactoryAssistant.getDataFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M extends IDataModel> M getObjectById(IObjectId argId) {
/* 165 */     return getObjectById(argId, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M extends IDataModel> M getObjectById(IObjectId argId, IPersistenceMgrType argType) {
/*     */     IDataModel iDataModel;
/* 178 */     M result = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (argId == null) {
/* 184 */       throw new DtxException("Invalid argument passed to getObjectById.  getObjectById cannot accept a null object id");
/*     */     }
/*     */ 
/*     */     
/* 188 */     if (!argId.validate()) {
/*     */       
/* 190 */       String msg = "Invalid object id passed to getObjectById.  Object id type: [" + argId.getClass().getName() + "] value: [" + argId + "]";
/*     */       
/* 192 */       _logger.warn(msg, new Throwable("STACK TRACE"));
/* 193 */       throw new ObjectNotFoundException(msg);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     long start = _logger.isDebugEnabled() ? System.currentTimeMillis() : 0L;
/*     */     
/* 201 */     IPersistenceMgr persistenceMgr = null;
/*     */     try {
/* 203 */       persistenceMgr = getInstance().getPersistenceMgr();
/* 204 */       iDataModel = persistenceMgr.getObjectById(argId, argType);
/*     */     } finally {
/*     */       
/* 207 */       cleanupPersistenceManager(persistenceMgr);
/*     */       
/* 209 */       if (_logger.isDebugEnabled()) {
/* 210 */         long end = System.currentTimeMillis();
/* 211 */         _logger.debug("== getObjectById time: " + (end - start) + " For id: " + 
/* 212 */             ObjectUtils.getClassNameFromObject(argId) + "--" + argId + " result: " + iDataModel);
/*     */       } 
/*     */     } 
/* 215 */     return (M)iDataModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M extends IDataModel> M getObjectByIdFromList(IObjectId argId, List<M> argList) {
/* 227 */     M result = null;
/*     */     
/* 229 */     return (M)argList.stream().filter(obj -> obj.getObjectId().equals(argId)).findFirst().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M extends IDataModel> M getObjectByIdNoThrow(IObjectId argId) {
/*     */     try {
/* 246 */       return getObjectById(argId);
/*     */     }
/* 248 */     catch (ObjectNotFoundException ex) {
/* 249 */       _logger.debug("CAUGHT EXCEPTION", (Throwable)ex);
/* 250 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M extends IDataModel> M getObjectByIdNoThrow(IObjectId argId, IPersistenceMgrType argType) {
/*     */     try {
/* 268 */       return getObjectById(argId, argType);
/*     */     }
/* 270 */     catch (ObjectNotFoundException ex) {
/* 271 */       _logger.debug("CAUGHT EXCEPTION", (Throwable)ex);
/* 272 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> IQueryResultList<T> getObjectByQuery(IQueryKey<T> argQueryKey, Map<String, Object> argParams) {
/* 306 */     return getObjectByQuery(argQueryKey, argParams, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> IQueryResultList<T> getObjectByQuery(IQueryKey<T> argQueryKey, Map<String, Object> argParams, IPersistenceMgrType argPmType) {
/* 323 */     return getObjectByQueryImpl(argQueryKey.getName(), argParams, argQueryKey.getResultClass(), argQueryKey
/* 324 */         .getInitializerClass(), argPmType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> IQueryResultList<T> getObjectByQueryNoThrow(IQueryKey<T> argQueryKey, Map<String, Object> argParams) {
/*     */     try {
/* 342 */       return getObjectByQuery(argQueryKey, argParams);
/*     */     }
/* 344 */     catch (ObjectNotFoundException ex) {
/* 345 */       _logger.debug("CAUGHT EXCEPTION", (Throwable)ex);
/* 346 */       return new QueryResultList<>(argQueryKey.getResultClass());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> IQueryResultList<T> getObjectByQueryNoThrow(IQueryKey<T> argQueryKey, Map<String, Object> argParams, IPersistenceMgrType argPmType) {
/*     */     try {
/* 367 */       return getObjectByQuery(argQueryKey, argParams, argPmType);
/*     */     }
/* 369 */     catch (ObjectNotFoundException ex) {
/* 370 */       _logger.debug("CAUGHT EXCEPTION", (Throwable)ex);
/* 371 */       return new QueryResultList<>(argQueryKey.getResultClass());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T makePersistent(T argObject) {
/* 415 */     return makePersistent(argObject, getInstance().getPersistenceMgr(), 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T makePersistent(T argObject, IPersistenceMgr argPersistenceMgr) {
/* 429 */     return makePersistent(argObject, argPersistenceMgr, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T makePersistent(T argObject, IPersistenceMgr argPersistenceMgr, long argTimeout) {
/* 447 */     T result = null;
/* 448 */     long start = _logger.isDebugEnabled() ? System.currentTimeMillis() : 0L;
/*     */     
/*     */     try {
/* 451 */       result = argPersistenceMgr.makePersistent(argObject, argTimeout);
/*     */     } finally {
/*     */       
/* 454 */       if (argPersistenceMgr != null) {
/*     */         try {
/* 456 */           argPersistenceMgr.cleanup();
/*     */         }
/* 458 */         catch (Exception ee) {
/* 459 */           _logger.debug("Exception occurred while cleaning up persistence mananger " + argPersistenceMgr, ee);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 464 */       if (_logger.isDebugEnabled()) {
/* 465 */         long end = System.currentTimeMillis();
/* 466 */         _logger.debug("== makePersistent time: " + (end - start) + " result: " + result);
/*     */       } 
/*     */     } 
/* 469 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T makePersistent(T argObject, long argTimeout) {
/* 485 */     return makePersistent(argObject, getInstance().getPersistenceMgr(), argTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void makeTransient(Object argObject) {
/* 496 */     List<? extends IPersistable> persistables = DaoUtils.getPersistables(argObject);
/*     */     
/* 498 */     for (Iterator<? extends IPersistable> iter = persistables.iterator(); iter.hasNext(); ) {
/* 499 */       IPersistable persistable = iter.next();
/* 500 */       if (persistable instanceof IDataAccessObject) {
/* 501 */         ((IDataAccessObject)persistable).setTransientObject(true);
/*     */       }
/*     */       
/* 504 */       iter.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void replicateData(TransactionToken argTransToken, String argCurrentDataSourceName, IPersistable argPersistable, List<String> argExcludedDataSources) {
/* 521 */     getInstance().getPersistenceMgr().replicateData(argTransToken, argCurrentDataSourceName, argPersistable, argExcludedDataSources);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void cleanupPersistenceManager(IPersistenceMgr argPersistenceMgr) {
/* 526 */     if (argPersistenceMgr != null) {
/*     */       try {
/* 528 */         argPersistenceMgr.cleanup();
/*     */       }
/* 530 */       catch (Exception ee) {
/* 531 */         _logger.debug("Exception occurred while cleaning up persistence mananger " + argPersistenceMgr, ee);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object[] executeQueryImpl(String argQueryKey, Map<String, Object> argParams) {
/* 539 */     long start = _logger.isDebugEnabled() ? System.currentTimeMillis() : 0L;
/*     */     
/* 541 */     IPersistenceMgr persistenceMgr = null;
/* 542 */     Object[] results = null;
/*     */     try {
/* 544 */       persistenceMgr = getInstance().getPersistenceMgr();
/* 545 */       Object tempResults = persistenceMgr.getObjectByQuery(argQueryKey, argParams, null);
/*     */       
/* 547 */       if (tempResults instanceof QueryResultWrapper) {
/* 548 */         results = (Object[])((QueryResultWrapper)tempResults).getData();
/*     */       }
/* 550 */       else if (tempResults instanceof Collection) {
/* 551 */         results = ((Collection)tempResults).toArray();
/*     */       } else {
/*     */         
/* 554 */         results = (Object[])tempResults;
/*     */       } 
/*     */     } finally {
/*     */       
/* 558 */       if (persistenceMgr != null) {
/*     */         try {
/* 560 */           persistenceMgr.cleanup();
/*     */         }
/* 562 */         catch (Exception ex) {
/* 563 */           _logger.debug("Exception occurred while cleaning up persistence manager " + persistenceMgr, ex);
/*     */         } 
/*     */       }
/*     */       
/* 567 */       if (_logger.isDebugEnabled()) {
/* 568 */         long end = System.currentTimeMillis();
/* 569 */         _logger.debug("== getObjectByQuery time: " + (end - start) + " For key: " + argQueryKey);
/*     */       } 
/*     */     } 
/* 572 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> IQueryResultList<T> getObjectByQueryImpl(String argQueryKey, Map<String, Object> argParams, Class<T> argTemplate, Class<? extends IQueryResultInitializer<? extends IQueryResult>> argInitializer, IPersistenceMgrType argPmType) {
/* 592 */     IQueryResultList<T> list = null;
/* 593 */     Map<String, Object> params = (argParams == null) ? new HashMap<>() : argParams;
/*     */     
/* 595 */     long start = _logger.isDebugEnabled() ? System.currentTimeMillis() : 0L;
/*     */     
/* 597 */     IPersistenceMgr persistenceMgr = null;
/*     */     try {
/* 599 */       persistenceMgr = getInstance().getPersistenceMgr();
/* 600 */       Object result = persistenceMgr.getObjectByQuery(argQueryKey, params, argPmType);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       list = QueryResultList.makeList(result, argTemplate);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 611 */       initializeResults(list, argInitializer);
/*     */     } finally {
/*     */       
/* 614 */       if (persistenceMgr != null) {
/*     */         try {
/* 616 */           persistenceMgr.cleanup();
/*     */         }
/* 618 */         catch (Exception ee) {
/* 619 */           _logger.debug("Exception occurred while cleaning up persistence mananger " + persistenceMgr, ee);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 624 */       if (_logger.isDebugEnabled()) {
/* 625 */         long end = System.currentTimeMillis();
/* 626 */         String resultString = (list != null) ? (list.get(0).toString() + ". . .") : null;
/*     */         
/* 628 */         _logger.debug("== getObjectByQuery time: " + (end - start) + " For key: " + argQueryKey + " Result: " + resultString);
/*     */       } 
/*     */     } 
/*     */     
/* 632 */     return list;
/*     */   }
/*     */   
/*     */   private static int getResults(Object[] argResults) {
/* 636 */     if (argResults == null || argResults.length < 1) {
/* 637 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 646 */     if (argResults[0] instanceof Object[]) {
/* 647 */       Object[] affectedRowsArray = (Object[])argResults[0];
/* 648 */       int affectedRows = ((Number)affectedRowsArray[0]).intValue();
/* 649 */       return affectedRows;
/*     */     } 
/*     */     
/* 652 */     if (!(argResults[0] instanceof Number)) {
/* 653 */       _logger.warn("unexpected result '" + argResults[0] + "' of type " + 
/* 654 */           ObjectUtils.getClassNameFromObject(argResults[0]));
/* 655 */       return -1;
/*     */     } 
/* 657 */     return ((Number)argResults[0]).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initializeResults(IQueryResultList result, Class<? extends IQueryResultInitializer<? extends IQueryResult>> argInitializerClass) {
/*     */     IQueryResultInitializer<IQueryResult> initializer;
/* 670 */     if (argInitializerClass == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 677 */       initializer = (IQueryResultInitializer<IQueryResult>)argInitializerClass.newInstance();
/*     */     }
/* 679 */     catch (Throwable ex) {
/* 680 */       throw new ReflectionException("Could not instantiate initializer " + argInitializerClass, ex);
/*     */     } 
/* 682 */     for (Object row : result) {
/* 683 */       initializer.initialize((IQueryResult)row);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataFactory() {
/* 704 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IDataModel> T createNewObject(IObjectId argObjectId, Class<T> argInterface) {
/* 718 */     if (argInterface == null) {
/* 719 */       throw new CreateObjectException("Cannot create model object from null argInterface");
/*     */     }
/* 721 */     T model = DataModelFactory.getModelForInterface(argInterface);
/*     */     
/* 723 */     ((IDataModelImpl)model).setDependencies(this._persistenceDefaults, this._eventManager);
/* 724 */     ((IDataModelImpl)model).getDAO().setObjectState(DaoState.NEW.intVal());
/* 725 */     if (argObjectId != null) {
/* 726 */       model.setObjectId(argObjectId);
/*     */     }
/*     */     
/* 729 */     return model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgr getPersistenceMgr() {
/* 743 */     return this._persistenceFactory.getManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryDescriptor getQueryDescriptor(String argKey) {
/* 754 */     return this._queryFactory.getQueryDescriptor(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IQueryHandler getQueryHandler(String argKey) {
/* 767 */     return this._queryFactory.getQueryHandler(argKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatusMgr getStatusMgr() {
/* 777 */     return (IStatusMgr)StatusMgr.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reinitialize() {
/* 784 */     initialize();
/* 785 */     DataSourceFactory.getInstance().reinitialize();
/* 786 */     this._queryFactory.reinitialize();
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 791 */     DataSourceFactory.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CreateObjectException
/*     */     extends RuntimeException
/*     */   {
/*     */     static final long serialVersionUID = -1517193094408594040L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CreateObjectException(String msg) {
/* 811 */       super(msg);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CreateObjectException(String msg, Throwable cause) {
/* 821 */       super(msg, cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\DataFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */