/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.data2.IPersistenceDefaults;
/*    */ import dtv.data2.access.AbstractPersistenceRule;
/*    */ import dtv.data2.access.DaoUtils;
/*    */ import dtv.data2.access.IDataAccessObject;
/*    */ import dtv.data2.access.IDataModel;
/*    */ import dtv.data2.access.IPersistable;
/*    */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*    */ import dtv.data2.access.datasource.DataSourceFactory;
/*    */ import dtv.data2.access.query.QueryResourceManager;
/*    */ import dtv.data2.access.query.QueryToken;
/*    */ import javax.inject.Inject;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DaoConversionRule
/*    */   extends AbstractPersistenceRule
/*    */ {
/* 29 */   private static final Logger _logger = Logger.getLogger(DaoConversionRule.class);
/*    */ 
/*    */   
/*    */   @Inject
/*    */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*    */ 
/*    */   
/*    */   @Inject
/*    */   private IPersistenceDefaults _persistenceDefaults;
/*    */ 
/*    */   
/*    */   public DaoConversionRule() {
/* 41 */     super(false, false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IPersistable applyRule(PersistableMetaData argPersistableMetaData, Object argObject) {
/* 47 */     IPersistable persistable = argPersistableMetaData.getPersistable();
/* 48 */     IDataAccessObject dao = (IDataAccessObject)persistable;
/*    */     
/* 50 */     int currentSourceIndex = argPersistableMetaData.getDataSourcesVisited().size() - 1;
/* 51 */     String currentDataSource = argPersistableMetaData.getDataSourcesVisited().get(currentSourceIndex);
/*    */     
/* 53 */     if (DaoState.NEW.matches(dao)) {
/*    */       
/* 55 */       DataSourceDescriptor dataSource = DataSourceFactory.getInstance().getDataSourceDescriptor(currentDataSource);
/* 56 */       IPersistenceStrategy strategy = this._persistenceStrategyFactory.createStrategy(dataSource, true);
/*    */       
/* 58 */       IDataModel result = null;
/*    */       
/* 60 */       QueryToken token = new QueryToken(dao.getObjectId(), getPMTypeByObjectId(dao.getObjectId().getClass()));
/*    */       try {
/* 62 */         result = strategy.getObjectById(dao.getObjectId(), token);
/*    */       }
/* 64 */       catch (Exception ex) {
/* 65 */         _logger.error("CAUGHT EXCEPTION", ex);
/*    */       } finally {
/*    */         
/* 68 */         QueryResourceManager.getInstance().closeQueryResources(token);
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 73 */       if (result != null) {
/* 74 */         IDataAccessObject daoClone = DaoUtils.cloneDao(dao);
/* 75 */         daoClone.setPersistenceDefaults(this._persistenceDefaults);
/* 76 */         daoClone.setObjectState(DaoState.UPDATED.intVal());
/* 77 */         daoClone.setObjectStateRulesApplied(true);
/* 78 */         return (IPersistable)daoClone;
/*    */       } 
/*    */     } 
/*    */     
/* 82 */     return (IPersistable)dao;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\DaoConversionRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */