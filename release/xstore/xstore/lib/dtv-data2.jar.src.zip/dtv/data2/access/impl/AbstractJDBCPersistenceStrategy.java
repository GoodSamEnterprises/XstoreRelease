/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import com.google.common.primitives.Ints;
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.config.query.QueryDescriptor;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.jdbc.IJDBCTableAdapter;
/*     */ import dtv.data2.access.impl.jdbc.JDBCAdapterMap;
/*     */ import dtv.data2.access.impl.jdbc.JDBCCall;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.access.query.SqlQueryBuilder;
/*     */ import dtv.data2.access.query.SqlQueryRequest;
/*     */ import dtv.util.ArrayUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.net.InetUtils;
/*     */ import java.net.InetAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJDBCPersistenceStrategy
/*     */   extends AbstractPersistenceStrategy
/*     */   implements IJDBCPersistenceStrategy
/*     */ {
/*  39 */   private static final Logger _logger = Logger.getLogger(AbstractJDBCPersistenceStrategy.class);
/*  40 */   private static final IDataSourceComparator _defaultDataSourceComparator = new DefaultDataSourceComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equivalentDataSources(IPersistenceStrategy argOther) {
/*  66 */     boolean sameDataSources = false;
/*     */     
/*  68 */     if (argOther instanceof IJDBCPersistenceStrategy)
/*     */     {
/*  70 */       sameDataSources = getDataSourceComparator().equivalentDataSources(this, (IJDBCPersistenceStrategy)argOther);
/*     */     }
/*  72 */     return sameDataSources;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionUrl() {
/*  78 */     return getProperties().getProperty("ConnectionURL");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JDBCCall> getJDBCCallData(IPersistable argPersistable) {
/*  84 */     if (argPersistable == null) {
/*  85 */       throw new DtxException("getJDBCCallData cannot be called with a null argPersistable - Illegal call");
/*     */     }
/*     */ 
/*     */     
/*  89 */     if (argPersistable instanceof IDataAccessObject) {
/*  90 */       return getJDBCCallDataForDao((IDataAccessObject)argPersistable);
/*     */     }
/*  92 */     if (argPersistable instanceof QueryRequest) {
/*  93 */       return getJDBCCallDataForQueryRequest((QueryRequest)argPersistable);
/*     */     }
/*  95 */     if (argPersistable instanceof SqlQueryRequest) {
/*  96 */       return getJDBCCallDataForSqlQueryRequest((SqlQueryRequest)argPersistable);
/*     */     }
/*     */     
/*  99 */     throw new DtxException("Persistable type: " + argPersistable.getClass().getName() + " is not yet supported by JDBCHelper.  Please add support if needed.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJDBCTableAdapter getTableAdapter(Class<?> argClass) {
/* 107 */     return getTableAdapter(argClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IJDBCTableAdapter getTableAdapter(IObjectId argId) {
/* 113 */     return getTableAdapter(argId.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IJDBCTableAdapter getTableAdapter(String argIdentifier) {
/* 119 */     return JDBCAdapterMap.getTableAdapter(argIdentifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDataSourceComparator getDataSourceComparator() {
/* 129 */     return _defaultDataSourceComparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<JDBCCall> getJDBCCallDataForDao(IDataAccessObject argDAO) {
/*     */     JDBCCall[] calls;
/* 140 */     if (DaoState.isClean(argDAO)) {
/* 141 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 145 */     IJDBCTableAdapter adapter = getTableAdapter(argDAO.getClass());
/*     */     
/* 147 */     adapter.fill(argDAO);
/*     */ 
/*     */ 
/*     */     
/* 151 */     int objectState = argDAO.getObjectState();
/*     */ 
/*     */     
/* 154 */     if (DaoState.INSERT_OR_UPDATE.matches(argDAO)) {
/* 155 */       if (argDAO.isObjectStateRulesApplied()) {
/* 156 */         objectState = DaoState.UPDATED.intVal();
/*     */       } else {
/*     */         
/* 159 */         objectState = DaoState.NEW.intVal();
/*     */       } 
/*     */     }
/*     */     
/* 163 */     if (objectState == DaoState.NEW.intVal() || objectState == DaoState.INSERT_ONLY.intVal()) {
/* 164 */       String[] sqlStrings = adapter.getInsert();
/* 165 */       Object[][] params = adapter.getInsertParameters();
/* 166 */       int[][] paramTypes = adapter.getInsertParameterTypes();
/* 167 */       calls = new JDBCCall[sqlStrings.length];
/* 168 */       for (int ii = 0; ii < sqlStrings.length; ii++) {
/* 169 */         calls[ii] = new JDBCCall();
/* 170 */         calls[ii].setSqlString(sqlStrings[ii]);
/* 171 */         calls[ii].setParams(Arrays.asList(params[ii]));
/* 172 */         calls[ii].setTypes(Ints.asList(paramTypes[ii]));
/*     */       }
/*     */     
/* 175 */     } else if (objectState == DaoState.DELETED.intVal()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       String[] adapterDeleteStatements = adapter.getDelete();
/* 181 */       String[] deleteStatements = new String[adapterDeleteStatements.length];
/* 182 */       Object[] whereParams = adapter.getWhereParameters();
/* 183 */       int[] whereParamTypes = adapter.getWhereParameterTypes();
/*     */       
/* 185 */       calls = new JDBCCall[deleteStatements.length];
/* 186 */       for (int ii = 0; ii < deleteStatements.length; ii++) {
/* 187 */         calls[ii] = new JDBCCall();
/* 188 */         calls[ii].setSqlString(adapterDeleteStatements[ii] + adapter.getWhere());
/* 189 */         calls[ii].setParams(Arrays.asList(whereParams));
/* 190 */         calls[ii].setTypes(Ints.asList(whereParamTypes));
/*     */       }
/*     */     
/* 193 */     } else if (objectState == DaoState.UPDATED.intVal()) {
/*     */ 
/*     */       
/* 196 */       if (argDAO instanceof IHasIncrementalValues && 
/* 197 */         !((IHasIncrementalValues)argDAO).getIncrementalActive())
/*     */       {
/* 199 */         ((IHasIncrementalValues)adapter).setIncrementalActive(false);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       String[] adapterUpdateStatements = adapter.getUpdate();
/* 206 */       String[] updateStatements = new String[adapterUpdateStatements.length];
/* 207 */       Object[][] adapterParams = adapter.getUpdateParameters();
/* 208 */       int[][] adapterParamTypes = adapter.getUpdateParameterTypes();
/* 209 */       Object[] whereParams = adapter.getWhereParameters();
/* 210 */       int[] whereParamTypes = adapter.getWhereParameterTypes();
/*     */       
/* 212 */       calls = new JDBCCall[updateStatements.length];
/* 213 */       for (int ii = 0; ii < updateStatements.length; ii++) {
/* 214 */         calls[ii] = new JDBCCall();
/* 215 */         calls[ii].setSqlString(adapterUpdateStatements[ii] + adapter.getWhere());
/* 216 */         Object[] params = ArrayUtils.combine(adapterParams[ii], whereParams);
/* 217 */         calls[ii].setParams(Arrays.asList(params));
/* 218 */         int[] paramTypes = ArrayUtils.combine(adapterParamTypes[ii], whereParamTypes);
/* 219 */         calls[ii].setTypes(Ints.asList(paramTypes));
/*     */       } 
/*     */     } else {
/*     */       
/* 223 */       throw new DtxException("dao " + argDAO.getClass().getName() + " was passed in with state UNDEFINED.  This is invalid for makePersistent(). This condition usually results from a model that was explicitely instantiated rather than created with DataFactory.createObject() (as it should be)");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 228 */     return Arrays.asList(calls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<JDBCCall> getJDBCCallDataForQueryRequest(QueryRequest argQueryRequest) {
/* 238 */     QueryRequest query = argQueryRequest;
/* 239 */     JDBCCall jdbcCall = new JDBCCall();
/*     */     
/* 241 */     if (query.getQueryKey() != null) {
/* 242 */       QueryDescriptor queryDescriptor = DataFactory.getInstance().getQueryDescriptor(query.getQueryKey());
/* 243 */       String baseSqlStatement = queryDescriptor.getProperties().getProperty("SQL");
/*     */       
/* 245 */       jdbcCall = SqlQueryBuilder.getJDBCCall(this, baseSqlStatement, queryDescriptor.getProperties(), query
/* 246 */           .getParams());
/*     */     } else {
/*     */       
/* 249 */       throw new DtxException("A QueryRequest was passed that doesn't define a query key. [" + query + "]");
/*     */     } 
/*     */ 
/*     */     
/* 253 */     List<JDBCCall> list = new ArrayList<>(1);
/* 254 */     list.add(jdbcCall);
/* 255 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<JDBCCall> getJDBCCallDataForSqlQueryRequest(SqlQueryRequest argQueryRequest) {
/* 265 */     SqlQueryRequest query = argQueryRequest;
/* 266 */     JDBCCall jdbcCall = new JDBCCall();
/*     */     
/* 268 */     jdbcCall.setSqlString(query.getSqlStatement());
/*     */     
/* 270 */     if (query.getParams() != null) {
/* 271 */       List<Object> params = query.getParams();
/*     */       
/* 273 */       jdbcCall.setParams(params);
/* 274 */       jdbcCall.setTypes(JDBCHelper.getJDBCTypesForList(params));
/*     */     } 
/* 276 */     List<JDBCCall> list = new ArrayList<>(1);
/* 277 */     list.add(jdbcCall);
/* 278 */     return list;
/*     */   }
/*     */   
/*     */   protected static interface IDataSourceComparator
/*     */   {
/*     */     boolean equivalentDataSources(IJDBCPersistenceStrategy param1IJDBCPersistenceStrategy1, IJDBCPersistenceStrategy param1IJDBCPersistenceStrategy2);
/*     */   }
/*     */   
/*     */   protected static class DefaultDataSourceComparator
/*     */     implements IDataSourceComparator {
/*     */     private static final String LOCAL_HOST = "localhost";
/* 289 */     private static Pattern _localHostIpPattern = null;
/* 290 */     private static Pattern _localHostNamePattern = null;
/*     */     
/*     */     static {
/*     */       try {
/* 294 */         InetAddress localHost = InetAddress.getLocalHost();
/* 295 */         _localHostIpPattern = Pattern.compile(localHost.getHostAddress(), 2);
/* 296 */         _localHostNamePattern = Pattern.compile(InetUtils.getLocalHostName(), 2);
/*     */       }
/* 298 */       catch (Exception ex) {
/* 299 */         AbstractJDBCPersistenceStrategy._logger.warn("Could not determine IP address/name of local host!: " + ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equivalentDataSources(IJDBCPersistenceStrategy argPS1, IJDBCPersistenceStrategy argPS2) {
/* 307 */       String dbUrl = StringUtils.pack(StringUtils.nonNull(argPS1.getConnectionUrl()));
/* 308 */       String otherDbUrl = StringUtils.pack(StringUtils.nonNull(argPS2.getConnectionUrl()));
/*     */ 
/*     */       
/* 311 */       dbUrl = normalizeLocalHost(dbUrl);
/* 312 */       otherDbUrl = normalizeLocalHost(otherDbUrl);
/*     */ 
/*     */       
/* 315 */       boolean sameDataSources = dbUrl.equalsIgnoreCase(otherDbUrl);
/* 316 */       if (sameDataSources)
/*     */       {
/*     */ 
/*     */         
/* 320 */         if (argPS1 instanceof AbstractJDBCPersistenceStrategy && argPS2 instanceof AbstractJDBCPersistenceStrategy) {
/*     */ 
/*     */           
/* 323 */           String ps1User = ((AbstractJDBCPersistenceStrategy)argPS1).getProperties().getProperty("ConnectionUserName");
/* 324 */           String ps2User = ((AbstractJDBCPersistenceStrategy)argPS2).getProperties().getProperty("ConnectionUserName");
/*     */           
/* 326 */           sameDataSources = StringUtils.equalsIgnoreCase(ps1User, ps2User);
/*     */         } 
/*     */       }
/* 329 */       return sameDataSources;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String normalizeLocalHost(String argDbUrl) {
/* 341 */       String dbUrl = argDbUrl;
/*     */       
/* 343 */       if (_localHostIpPattern != null) {
/* 344 */         dbUrl = _localHostIpPattern.matcher(dbUrl).replaceAll("localhost");
/*     */       }
/* 346 */       if (_localHostNamePattern != null) {
/* 347 */         dbUrl = _localHostNamePattern.matcher(dbUrl).replaceAll("localhost");
/*     */       }
/* 349 */       return dbUrl;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractJDBCPersistenceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */