/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DaoGenOrgHierarchyHelper
/*     */ {
/*     */   public static final String FIELD_ORG_CODE = "orgCode";
/*     */   public static final String FIELD_ORG_VALUE = "orgValue";
/*  27 */   private static final List<String> _orgHierarchyTables = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void addOrgHierarchyTable(String argTableName) {
/*  36 */     _orgHierarchyTables.add(argTableName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Collection<String> getOrgHierarchyTables() {
/*  47 */     return _orgHierarchyTables;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isOrgHierarchical(DtxDefinition argDtxDef) {
/*  59 */     boolean hasOrgCode = false;
/*  60 */     boolean hasOrgValue = false;
/*     */     
/*  62 */     for (DtxDefinition.DtxDaoField field : argDtxDef.getFieldsPlusInheritedPrimaryKeys()) {
/*  63 */       if ("orgCode".equalsIgnoreCase(field.getName())) {
/*  64 */         hasOrgCode = true;
/*     */       }
/*  66 */       else if ("orgValue".equalsIgnoreCase(field.getName())) {
/*  67 */         hasOrgValue = true;
/*     */       } 
/*     */       
/*  70 */       if (hasOrgCode && hasOrgValue) {
/*     */         break;
/*     */       }
/*     */     } 
/*  74 */     return (hasOrgCode && hasOrgValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isOrgHierarchyField(DtxDefinition.DtxDaoField argDtxField) {
/*  91 */     return ("orgCode".equalsIgnoreCase(argDtxField.getName()) || "orgValue"
/*  92 */       .equalsIgnoreCase(argDtxField.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isOrgHierarchyRelationshipJoin(DtxRelationship.DtxRelationshipField argDtxRelField) {
/* 104 */     boolean isOrgHierarchyJoin = false;
/*     */     
/* 106 */     if ("orgCode".equalsIgnoreCase(argDtxRelField.getParent())) {
/* 107 */       isOrgHierarchyJoin = "orgCode".equalsIgnoreCase(argDtxRelField.getChild());
/*     */     }
/* 109 */     else if ("orgValue".equalsIgnoreCase(argDtxRelField.getParent())) {
/* 110 */       isOrgHierarchyJoin = "orgValue".equalsIgnoreCase(argDtxRelField.getChild());
/*     */     } 
/* 112 */     return isOrgHierarchyJoin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeOrgHierarchyCUDParam(DtxDefinition argDtx, DtxDefinition.DtxDaoField argDtxField, StringBuilder out) {
/* 132 */     String fieldName = argDtxField.getName();
/*     */     
/* 134 */     if ("orgCode".equalsIgnoreCase(fieldName)) {
/* 135 */       String codeField = DaoGenUtils.getFieldNameForField(argDtxField);
/* 136 */       out.append("dtv.util.ObjectUtils.coalesce(" + codeField + ", \"*\")");
/*     */     }
/* 138 */     else if ("orgValue".equalsIgnoreCase(fieldName)) {
/* 139 */       String valueField = DaoGenUtils.getFieldNameForField(argDtxField);
/* 140 */       out.append("dtv.util.ObjectUtils.coalesce(" + valueField + ", \"*\")");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DaoGenOrgHierarchyHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */