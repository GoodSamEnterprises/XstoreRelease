/*    */ package dtv.data2.access.pm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PmTypeDeterminationException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public PmTypeDeterminationException() {}
/*    */   
/*    */   public PmTypeDeterminationException(String argMessage) {
/* 30 */     super(argMessage);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PmTypeDeterminationException(String argMessage, Throwable argCause) {
/* 40 */     super(argMessage, argCause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PmTypeDeterminationException(Throwable argCause) {
/* 49 */     super(argCause);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PmTypeDeterminationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */