/*    */ package dtv.data2.access;
/*    */ 
/*    */ import dtv.event.Event;
/*    */ import dtv.event.EventDescriptor;
/*    */ import dtv.event.EventEnum;
/*    */ import dtv.event.EventHandler;
/*    */ import dtv.event.EventManager;
/*    */ import dtv.event.Eventor;
/*    */ import dtv.event.IEventAware;
/*    */ import dtv.event.IEventConstraint;
/*    */ import dtv.event.IEventSource;
/*    */ import dtv.event.constraint.NameConstraint;
/*    */ import dtv.event.eventor.DefaultEventor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelEventor
/*    */   extends Eventor
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 23 */   public static final EventDescriptor EVENT_DESCRIPTOR = new EventDescriptor(ModelEventor.class);
/*    */ 
/*    */   
/*    */   public static final String PRIVILEGED_EVENT_DESCRIPTOR_NAME = "PrivilegedEventDescriptor";
/*    */ 
/*    */   
/* 29 */   public static final EventEnum CLOSE_EVENT = new EventEnum("EVENT_CLOSE_MODEL_EVENTORS");
/*    */ 
/*    */   
/* 32 */   public static final EventEnum OPEN_EVENT = new EventEnum("EVENT_OPEN_MODEL_EVENTORS");
/*    */ 
/*    */   
/*    */   protected boolean passing_ = true;
/*    */ 
/*    */   
/*    */   protected Eventor _privilegedEventor;
/*    */   
/*    */   private IDataModel _eventSource;
/*    */ 
/*    */   
/* 43 */   protected IEventAware _closeHandler = (IEventAware)new EventHandler()
/*    */     {
/*    */       protected void handle(Event argEvent) {
/* 46 */         ModelEventor.this.passing_ = false;
/*    */       }
/*    */     };
/*    */   
/* 50 */   private IEventAware _openHandler = (IEventAware)new EventHandler()
/*    */     {
/*    */       protected void handle(Event argEvent) {
/* 53 */         ModelEventor.this.passing_ = true;
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ModelEventor(IDataModel argSource, EventManager argEventManager) {
/* 64 */     super(argSource);
/*    */     
/* 66 */     this._eventSource = argSource;
/* 67 */     EventDescriptor self = new EventDescriptor(ModelEventor.class);
/* 68 */     this._eventManager = argEventManager;
/* 69 */     EventManager em = (this._eventManager != null) ? this._eventManager : _staticEventManager;
/* 70 */     em.registerEventHandler(this._closeHandler, (IEventSource)self, (IEventConstraint)new NameConstraint(CLOSE_EVENT));
/* 71 */     em.registerEventHandler(this._openHandler, (IEventSource)self, (IEventConstraint)new NameConstraint(OPEN_EVENT));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void post(Object argEventName) {
/* 77 */     postEvent(argEventName, null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void post(Object argEventName, Object argPayload) {
/* 83 */     if (this._privilegedEventor == null) {
/* 84 */       EventDescriptor privilegedDescriptor = new EventDescriptor("PrivilegedEventDescriptor", this._eventSource);
/*    */       
/* 86 */       this._privilegedEventor = (Eventor)new DefaultEventor((IEventSource)privilegedDescriptor);
/*    */     } 
/*    */     
/* 89 */     this._privilegedEventor.post(argEventName, argPayload);
/*    */     
/* 91 */     if (this.passing_)
/* 92 */       postEvent(argEventName, argPayload); 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\ModelEventor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */