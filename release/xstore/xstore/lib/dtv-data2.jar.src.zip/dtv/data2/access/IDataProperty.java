/*     */ package dtv.data2.access;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IDataProperty
/*     */ {
/*     */   @Deprecated
/*     */   public static final String TYPE_STRING = "STRING";
/*     */   @Deprecated
/*     */   public static final String TYPE_DATE = "DATE";
/*     */   @Deprecated
/*     */   public static final String TYPE_DECIMAL = "BIGDECIMAL";
/*     */   @Deprecated
/*     */   public static final String TYPE_BOOLEAN = "BOOLEAN";
/*     */   
/*     */   boolean getBooleanValue(boolean paramBoolean);
/*     */   
/*     */   Date getDateValue();
/*     */   
/*     */   BigDecimal getDecimalValue();
/*     */   
/*     */   String getPropertyCode();
/*     */   
/*     */   Object getPropertyValue();
/*     */   
/*     */   String getStringValue();
/*     */   
/*     */   String getType();
/*     */   
/*     */   void setBooleanValue(boolean paramBoolean);
/*     */   
/*     */   void setDateValue(Date paramDate);
/*     */   
/*     */   void setDecimalValue(BigDecimal paramBigDecimal);
/*     */   
/*     */   void setPropertyValue(Object paramObject);
/*     */   
/*     */   void setStringValue(String paramString);
/*     */   
/*     */   void setType(String paramString);
/*     */   
/*     */   public enum PropertyType
/*     */   {
/* 119 */     STRING, DATE, BIGDECIMAL, BOOLEAN;
/*     */     
/*     */     public boolean matches(String argName) {
/* 122 */       return name().equals(argName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\IDataProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */