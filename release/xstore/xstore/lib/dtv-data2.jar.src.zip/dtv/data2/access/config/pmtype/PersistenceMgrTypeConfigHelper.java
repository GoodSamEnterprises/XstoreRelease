/*     */ package dtv.data2.access.config.pmtype;
/*     */ 
/*     */ import dtv.data2.access.IPersistenceRuleFactory;
/*     */ import dtv.data2.access.config.common.AbstractDataConfigHelper;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import dtv.util.config.PositiveIntegerConfig;
/*     */ import dtv.util.config.StringConfig;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceMgrTypeConfigHelper
/*     */   extends AbstractDataConfigHelper<PersistenceMgrTypeSetConfig>
/*     */ {
/*  24 */   private final Map<String, PersistenceMgrTypeDescriptor> _descriptors = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceRuleFactory _persistenceRuleFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildDescriptors() {
/*  34 */     this._descriptors.clear();
/*  35 */     PersistenceMgrTypeSetConfig root = (PersistenceMgrTypeSetConfig)getRootConfig();
/*     */     
/*  37 */     for (PersistenceMgrTypeConfig pmTypeConfig : root.getChildren()) {
/*  38 */       PersistenceMgrTypeConfig actual = new PersistenceMgrTypeConfig();
/*  39 */       actual = resolveReferences(actual, pmTypeConfig);
/*  40 */       this._descriptors.put(pmTypeConfig.getName(), createPersistenceMgrTypeDescriptor(actual));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceMgrTypeDescriptor getDescriptor(String argPmTypeName) {
/*  52 */     PersistenceMgrTypeDescriptor descriptor = this._descriptors.get(argPmTypeName);
/*     */     
/*  54 */     if (descriptor == null) {
/*  55 */       descriptor = buildDescriptor(argPmTypeName);
/*  56 */       this._descriptors.put(argPmTypeName, descriptor);
/*     */     } 
/*     */     
/*  59 */     return descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<PersistenceMgrTypeDescriptor> getDescriptors() {
/*  67 */     return this._descriptors.values();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeImpl() {
/*  73 */     super.initializeImpl();
/*     */     
/*  75 */     buildDescriptors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PersistenceMgrTypeDescriptor buildDescriptor(String argPmTypeName) {
/*  86 */     PersistenceMgrTypeSetConfig root = (PersistenceMgrTypeSetConfig)getRootConfig();
/*  87 */     PersistenceMgrTypeConfig requested = root.getPmTypeConfig(argPmTypeName);
/*     */ 
/*     */     
/*  90 */     PersistenceMgrTypeConfig actual = new PersistenceMgrTypeConfig();
/*  91 */     actual.cascadeValues((IConfigObject)requested);
/*     */     
/*  93 */     if (requested.isReference()) {
/*  94 */       PersistenceMgrTypeConfig referenced = root.getPmTypeConfig(requested.getReferenceName());
/*  95 */       actual.cascadeValues((IConfigObject)referenced);
/*     */     } 
/*     */     
/*  98 */     return createPersistenceMgrTypeDescriptor(actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PersistenceMgrTypeDescriptor createPersistenceMgrTypeDescriptor(PersistenceMgrTypeConfig argConfig) {
/* 109 */     if (argConfig.getTrainingLocations() != null) {
/* 110 */       return new PersistenceMgrTypeDescriptor(argConfig.getName(), argConfig
/* 111 */           .getOnlineLocations().getLookupLocations(), argConfig
/* 112 */           .getOnlineLocations().getPersistenceLocations(), argConfig
/* 113 */           .getOfflineLocations().getLookupLocations(), argConfig
/* 114 */           .getOfflineLocations().getPersistenceLocations(), argConfig
/* 115 */           .getTrainingLocations().getLookupLocations(), argConfig
/* 116 */           .getTrainingLocations().getPersistenceLocations(), argConfig.isWriteJournalOnline(), argConfig
/* 117 */           .getPersistenceManagerRules(), argConfig.getPersistenceStrategyRules(), this._persistenceRuleFactory);
/*     */     }
/*     */ 
/*     */     
/* 121 */     return new PersistenceMgrTypeDescriptor(argConfig.getName(), argConfig
/* 122 */         .getOnlineLocations().getLookupLocations(), argConfig
/* 123 */         .getOnlineLocations().getPersistenceLocations(), argConfig
/* 124 */         .getOfflineLocations().getLookupLocations(), argConfig
/* 125 */         .getOfflineLocations().getPersistenceLocations(), argConfig
/* 126 */         .getTrainingLocations().getLookupLocations(), argConfig
/* 127 */         .getTrainingLocations().getPersistenceLocations(), argConfig.isWriteJournalOnline(), null, null, this._persistenceRuleFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getConfigFileName() {
/* 135 */     return "PersistenceManagerConfig";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IConfigObject getConfigObject(String argTagName, String argDtype, String argSourceDescription) {
/* 141 */     if ("PersistenceManagerTypeSet".equalsIgnoreCase(argDtype)) {
/* 142 */       return (IConfigObject)new PersistenceMgrTypeSetConfig();
/*     */     }
/* 144 */     if ("PersistenceManagerTypeNew".equalsIgnoreCase(argDtype) || "PersistenceManagerType"
/* 145 */       .equalsIgnoreCase(argDtype)) {
/* 146 */       return (IConfigObject)new PersistenceMgrTypeConfig();
/*     */     }
/* 148 */     if ("PersistenceLocation".equalsIgnoreCase(argDtype) || "LookupLocation"
/* 149 */       .equals(argTagName) || "PersistenceLocation".equals(argTagName)) {
/* 150 */       return (IConfigObject)new DataSourceLocationConfig();
/*     */     }
/* 152 */     if ("LocationGroup".equalsIgnoreCase(argDtype)) {
/* 153 */       return (IConfigObject)new LocationGroupConfig();
/*     */     }
/* 155 */     if ("DataSourceName".equals(argTagName)) {
/* 156 */       return (IConfigObject)new StringConfig();
/*     */     }
/* 158 */     if ("Order".equals(argTagName)) {
/* 159 */       return (IConfigObject)new PositiveIntegerConfig();
/*     */     }
/* 161 */     if ("PersistenceRules".equalsIgnoreCase(argDtype)) {
/* 162 */       return (IConfigObject)new PersistenceRuleGroupConfig();
/*     */     }
/* 164 */     if ("PersistenceRule".equals(argTagName)) {
/* 165 */       return (IConfigObject)new PersistenceRuleConfig();
/*     */     }
/*     */     
/* 168 */     return super.getConfigObject(argTagName, argDtype, argSourceDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PersistenceMgrTypeConfig resolveReferences(PersistenceMgrTypeConfig argActual, PersistenceMgrTypeConfig argReference) {
/* 181 */     argActual.cascadeValues((IConfigObject)argReference);
/*     */     
/* 183 */     if (argReference.isReference()) {
/* 184 */       PersistenceMgrTypeSetConfig root = (PersistenceMgrTypeSetConfig)getRootConfig();
/* 185 */       PersistenceMgrTypeConfig secondReference = root.getPmTypeConfig(argReference.getReferenceName());
/* 186 */       if (secondReference == null) {
/* 187 */         throw new DtxException("Failed to resolve PM type reference: [" + argReference
/* 188 */             .getReferenceName() + "]");
/*     */       }
/* 190 */       resolveReferences(argActual, secondReference);
/*     */     } 
/*     */     
/* 193 */     return argActual;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\pmtype\PersistenceMgrTypeConfigHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */