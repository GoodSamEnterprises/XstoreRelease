package dtv.data2.access.query;

public interface IQueryResource extends AutoCloseable {
  String getDataSourceName();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\IQueryResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */