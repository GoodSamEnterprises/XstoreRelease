/*      */ package dtv.data2.access.impl.daogen;
/*      */ 
/*      */ import com.google.common.base.CaseFormat;
/*      */ import dtv.util.StringUtils;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Callable;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GenerateDaoAndDba
/*      */   implements Callable<Void>
/*      */ {
/*   30 */   private static final Logger _logger = Logger.getLogger(GenerateDaoAndDba.class);
/*   31 */   private static final String[] FIELDS_EXCLUDED_FROM_UPDATE = new String[] { "createDate", "createUserId" };
/*      */ 
/*      */   
/*      */   private final DaoGenHelper helper_;
/*      */ 
/*      */   
/*      */   private final List<DtxDefinition> dtxDefinitions_;
/*      */ 
/*      */ 
/*      */   
/*      */   GenerateDaoAndDba(DaoGenHelper argHelper) {
/*   42 */     this.helper_ = argHelper;
/*   43 */     this.dtxDefinitions_ = this.helper_.getDtxDefinitions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Void call() throws IOException {
/*   51 */     _logger.info("Generating dtx mappings");
/*      */     
/*   53 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/*   54 */       if (DaoGenOrgHierarchyHelper.isOrgHierarchical(dtx)) {
/*   55 */         DaoGenOrgHierarchyHelper.addOrgHierarchyTable(dtx.getTable());
/*      */       }
/*      */       
/*   58 */       File dbaFile = new File(this.helper_.getOutPath() + this.helper_.getFilePath(dtx) + dtx.getName() + "DBA.java");
/*   59 */       if (dtx.needsGeneration(dbaFile)) {
/*   60 */         StringBuilder out = new StringBuilder(20480);
/*   61 */         getDBAHeader(out, dtx);
/*   62 */         getDBAMembers(out, dtx);
/*   63 */         getDBAMethods(out, dtx);
/*   64 */         getDBAFooter(out, dtx);
/*      */         
/*   66 */         this.helper_.getWriter().write(dbaFile, out.toString());
/*      */       } 
/*      */       
/*   69 */       File daoFile = new File(this.helper_.getOutPath() + this.helper_.getFilePath(dtx) + dtx.getName() + "DAO.java");
/*   70 */       if (dtx.needsGeneration(daoFile)) {
/*   71 */         StringBuilder out = new StringBuilder(20480);
/*   72 */         out.setLength(0);
/*   73 */         getDAOHeader(out, dtx);
/*   74 */         getDAOMembers(out, dtx);
/*   75 */         getDAOMethods(out, dtx);
/*   76 */         getDaoDbaUpdateDiffMethods(out, dtx);
/*   77 */         getDAOToString(out, dtx);
/*   78 */         getDAOFooter(out, dtx);
/*      */         
/*   80 */         this.helper_.getWriter().write(daoFile, out.toString());
/*      */       } 
/*      */     } 
/*   83 */     return null;
/*      */   }
/*      */   
/*      */   private void getDaoDbaUpdateDiffMethods(StringBuilder out, DtxDefinition argDtx) {
/*   87 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFieldsPlusInheritedPrimaryKeys();
/*      */     
/*   89 */     for (DtxDefinition.DtxDaoField field : fields) {
/*   90 */       if (field.getIncrementField()) {
/*   91 */         String fieldName = DaoGenUtils.getFieldNameForField(field);
/*   92 */         String initFieldName = "_init" + StringUtils.ensureFirstUpperCase(field.getName());
/*   93 */         String rawDataType = DaoGenUtils.getRawDataType(field.getType());
/*      */         
/*   95 */         out.append("  private " + rawDataType + " " + DaoGenUtils.getGetterNameForField(field) + "Diff() {\n    " + rawDataType + " val1;\n    " + rawDataType + " val2;\n\n    if (" + fieldName + " == null) {\n      val1 = new " + rawDataType + "(0);\n    }\n    else {\n      val1 = " + fieldName + ";\n    }\n\n    if (" + initFieldName + " == null) {\n      val2 = new " + rawDataType + "(0);\n    }\n    else {\n      val2 = " + initFieldName + ";\n    }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  113 */         if ("BigDecimal".equalsIgnoreCase(field.getType())) {
/*  114 */           out.append("    java.math.BigDecimal res = val1.subtract(val2);\n\n");
/*  115 */           out.append("    if (res.scale()<8) {\n");
/*  116 */           out.append("      res = res.setScale(8);\n");
/*  117 */           out.append("    }\n\n");
/*  118 */           out.append("    return res;\n");
/*      */         }
/*  120 */         else if ("Integer".equalsIgnoreCase(field.getType())) {
/*  121 */           out.append("    return Integer.valueOf(val1.intValue() - val2.intValue());\n");
/*      */         }
/*  123 */         else if ("Long".equalsIgnoreCase(field.getType())) {
/*  124 */           out.append("    return Long.valueOf(val1.longValue() - val2.longValue());\n");
/*      */         } 
/*      */         
/*  127 */         out.append("  }\n\n");
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void getDAOFooter(StringBuilder out, DtxDefinition argDtx) {
/*  133 */     if (!argDtx.isExtended()) {
/*  134 */       out.append("  public IObjectId getObjectId() {\n");
/*  135 */       out.append("    " + argDtx.getId() + " id = new " + argDtx.getId() + "();\n");
/*      */       
/*  137 */       for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/*  138 */         String getterName = DaoGenUtils.getGetterNameForField(field);
/*  139 */         String setterName = DaoGenUtils.getSetterNameForField(field);
/*  140 */         out.append("    id." + setterName + "(this." + getterName + "());\n");
/*      */       } 
/*      */       
/*  143 */       out.append("    return id;\n");
/*  144 */       out.append("  }\n\n");
/*      */       
/*  146 */       out.append("  public void setObjectId(IObjectId argObjectId) {\n");
/*      */       
/*  148 */       if ((argDtx.getPrimaryKeyFields()).length > 0) {
/*  149 */         for (DtxDefinition.DtxDaoField f : argDtx.getPrimaryKeyFields()) {
/*  150 */           String getterName = DaoGenUtils.getGetterNameForField(f);
/*  151 */           String setterName = DaoGenUtils.getSetterNameForField(f);
/*  152 */           out.append("    " + setterName + "(((" + argDtx
/*  153 */               .getId() + ")argObjectId)." + getterName + "());\n");
/*      */         } 
/*      */       } else {
/*      */         
/*  157 */         out.append("    // " + argDtx.getName() + " does not define a primary key.\n");
/*      */       } 
/*      */       
/*  160 */       out.append("  }\n\n");
/*      */       
/*  162 */       out.append("  public String getImplementingClass() {\n");
/*  163 */       if (argDtx.isExtensible()) {
/*  164 */         out.append("    return _" + argDtx.getImplementingClassField() + ";\n");
/*      */       } else {
/*      */         
/*  167 */         out.append("    return null; // This DAO is not extensible\n");
/*      */       } 
/*      */       
/*  170 */       out.append("  }\n\n");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  176 */     if (argDtx.isExtended()) {
/*  177 */       out.append("  @Override\n");
/*      */     }
/*      */     
/*  180 */     out.append("  public String toXmlString() {\n");
/*  181 */     int buffSize = 50 * (argDtx.getFields()).length;
/*  182 */     DtxDefinition parent = argDtx.getExtends();
/*      */     
/*  184 */     while (parent != null) {
/*  185 */       buffSize += 50 * (parent.getFields()).length;
/*  186 */       parent = parent.getExtends();
/*      */     } 
/*      */     
/*  189 */     out.append("    StringBuilder buf = new StringBuilder(" + buffSize + ");\n");
/*  190 */     out.append("    buf.append(\"<\").append(DAO_ELEMENT_NAME).append(\" name=\\\"" + argDtx.getName() + "\\\" cmd=\\\"\" + getObjectStateString() + \"\\\">\");\n");
/*      */     
/*  192 */     out.append("    getFieldsAsXml(buf);\n");
/*  193 */     out.append("    buf.append(\"</\").append(DAO_ELEMENT_NAME).append(\">\");\n\n");
/*  194 */     out.append("    return buf.toString();\n");
/*  195 */     out.append("  }\n");
/*      */ 
/*      */     
/*  198 */     out.append("  @Override\n");
/*  199 */     out.append("  public java.util.Map<String, String> getValues() {\n");
/*  200 */     out.append("    java.util.Map<String, String> values = super.getValues();\n");
/*      */     
/*  202 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/*  203 */       String name = DaoGenUtils.getFieldNameForField(field);
/*  204 */       String publicName = "\"" + StringUtils.ensureFirstUpperCase(field.getName()) + "\"";
/*      */       
/*  206 */       out.append("    if (" + name + " != null) values.put(" + publicName + ", dtv.data2.access.DaoUtils.getXmlSafeFieldValue(" + 
/*  207 */           DaoGenUtils.getTypeForField(field) + ", ");
/*  208 */       if (field.getIncrementField()) {
/*  209 */         out.append("get" + StringUtils.ensureFirstUpperCase(field.getName()) + "Diff()");
/*      */       } else {
/*      */         
/*  212 */         out.append(name);
/*      */       } 
/*  214 */       out.append("));\n");
/*      */     } 
/*  216 */     out.append("    return values;\n");
/*  217 */     out.append("  }\n\n");
/*      */     
/*  219 */     out.append("  @Override\n");
/*      */     
/*  221 */     out.append("  public void setValues(java.util.Map<String, String> argValues) {\n");
/*  222 */     out.append("    super.setValues(argValues);\n");
/*  223 */     out.append("    for (java.util.Map.Entry<String, String> field : argValues.entrySet()) {\n\n");
/*  224 */     out.append("      String fieldName = field.getKey();\n");
/*  225 */     out.append("      String fieldValue = field.getValue();\n");
/*  226 */     out.append("      switch (fieldName) {\n\n");
/*      */     
/*  228 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/*  229 */       String publicName = StringUtils.ensureFirstUpperCase(field.getName());
/*  230 */       String setterName = DaoGenUtils.getSetterNameForField(field);
/*  231 */       out.append("        case \"" + publicName + "\": {\n");
/*  232 */       out.append("          try {\n");
/*  233 */       out.append("            Object value = dtv.data2.access.DaoUtils.getFieldValueForXmlString(" + 
/*  234 */           DaoGenUtils.getTypeForField(field) + ", fieldValue);\n");
/*  235 */       out.append("            ").append(setterName).append("(" + makeCast(field)).append("value);\n");
/*  236 */       out.append("          } catch (Exception ee) {\n");
/*  237 */       out.append("            throw new dtv.data2.access.exception.DtxException(\"An exception occurred while calling " + setterName + "() with \" + fieldValue + \" on: \" + this + \" \" + ee.toString(), ee);\n");
/*      */ 
/*      */       
/*  240 */       out.append("          }\n");
/*  241 */       out.append("          break;\n");
/*  242 */       out.append("        }\n");
/*      */     } 
/*      */     
/*  245 */     out.append("        default: break;\n");
/*  246 */     out.append("      }\n");
/*  247 */     out.append("    }\n");
/*  248 */     out.append("  }\n");
/*  249 */     out.append("} ");
/*      */   }
/*      */   
/*      */   private String getDAOHeader(StringBuilder out, DtxDefinition argDtx) {
/*  253 */     out.append("package ");
/*  254 */     out.append(argDtx.getPackage());
/*  255 */     out.append(";\n\n");
/*  256 */     out.append("import java.util.Date;\n\n");
/*  257 */     out.append("import org.apache.log4j.Logger;\n\n");
/*  258 */     out.append("import dtv.data2.access.IObjectId;\n");
/*      */     
/*  260 */     out.append(this.helper_
/*  261 */         .getClassCommentWithSuppressWarnings("Auto-generated DAO\n *\n * DO NOT MANUALLY MODIFY THIS FILE."));
/*      */     
/*  263 */     out.append("public class " + argDtx.getName() + "DAO\n");
/*      */     
/*  265 */     if (argDtx.isExtended()) {
/*  266 */       out.append("    extends ");
/*  267 */       out.append(argDtx.getExtends().getDao());
/*  268 */       out.append("\n");
/*      */     }
/*  270 */     else if (argDtx.isExtensible()) {
/*  271 */       out.append("    extends dtv.data2.access.impl.AbstractExtensibleDAOImpl\n");
/*      */     } else {
/*      */       
/*  274 */       out.append("    extends dtv.data2.access.impl.AbstractDAOImpl\n");
/*      */     } 
/*      */     
/*  277 */     boolean hasConfigElementField = false;
/*      */     
/*  279 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  280 */       if (DaoGenConfigElementHelper.isConfigElementField(field)) {
/*  281 */         hasConfigElementField = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  286 */     if (argDtx.hasIncrementalField()) {
/*  287 */       out.append("    implements dtv.data2.access.impl.IHasIncrementalValues");
/*      */       
/*  289 */       if (hasConfigElementField) {
/*  290 */         out.append(", dtv.data2.access.IHasConfigElement");
/*      */       }
/*      */     }
/*  293 */     else if (hasConfigElementField) {
/*  294 */       out.append(" implements dtv.data2.access.IHasConfigElement");
/*      */     } 
/*      */     
/*  297 */     out.append(" {\n\n");
/*  298 */     out.append("  // Fix serialization compatability based on the name of the DAO\n");
/*  299 */     out.append("  private static final long serialVersionUID = " + argDtx.getName().hashCode() + "L;\n");
/*      */     
/*  301 */     out.append("  private static final Logger _logger = Logger.getLogger(" + argDtx
/*  302 */         .getDao() + ".class);\n\n");
/*      */     
/*  304 */     return out.toString();
/*      */   }
/*      */   
/*      */   private void getDAOMembers(StringBuilder out, DtxDefinition argDtx) {
/*  308 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFields();
/*      */     
/*  310 */     for (DtxDefinition.DtxDaoField field : fields) {
/*  311 */       String fieldType = DaoGenUtils.getConcreteDataType(field.getType());
/*  312 */       String fieldName = DaoGenUtils.getFieldNameForField(field);
/*  313 */       out.append("  private " + fieldType + " " + fieldName);
/*      */       
/*  315 */       if ("Boolean".equals(field.getType()))
/*      */       {
/*      */         
/*  318 */         out.append(" = Boolean.FALSE");
/*      */       }
/*  320 */       out.append(";\n");
/*      */       
/*  322 */       if (field.getIncrementField()) {
/*  323 */         out.append("  private " + fieldType + " _init" + StringUtils.ensureFirstUpperCase(field.getName()) + ";\n");
/*      */       }
/*      */     } 
/*      */     
/*  327 */     if (argDtx.hasIncrementalField()) {
/*  328 */       out.append("  protected boolean _incrementalActive = true;\n");
/*      */     }
/*  330 */     out.append("\n");
/*      */   }
/*      */   
/*      */   private void getDAOMethods(StringBuilder out, DtxDefinition argDtx) {
/*  334 */     getIncrementalActive(out, argDtx);
/*      */     
/*  336 */     for (DtxDefinition.DtxDaoField f : argDtx.getFields()) {
/*  337 */       String proper = StringUtils.ensureFirstUpperCase(f.getName());
/*  338 */       String arg = "arg" + proper;
/*  339 */       String argType = DaoGenUtils.getRawDataType(f.getType());
/*      */ 
/*      */       
/*  342 */       DaoGenUtils.appendGetterForField(out, f);
/*      */       
/*  344 */       if (f.getIncrementField()) {
/*  345 */         out.append("  public " + argType + " getInit" + proper + "() {\n");
/*  346 */         out.append("    return _init" + StringUtils.ensureFirstUpperCase(f.getName()) + ";\n");
/*  347 */         out.append("  }\n\n");
/*      */       } 
/*      */ 
/*      */       
/*  351 */       DaoGenUtils.appendSetterForField(out, f, true, true);
/*      */       
/*  353 */       if (f.getIncrementField()) {
/*  354 */         out.append("  public void setInit" + proper + "(" + argType + " " + arg + ") {\n");
/*  355 */         out.append("    _init" + StringUtils.ensureFirstUpperCase(f.getName()) + " = " + arg + ";\n");
/*  356 */         out.append("  }\n\n");
/*      */       } 
/*      */     } 
/*  359 */     out.append("\n");
/*      */   }
/*      */   
/*      */   private void getDAOToString(StringBuilder out, DtxDefinition argDtx) {
/*  363 */     out.append("  @Override\n");
/*  364 */     out.append("  public String toString() {\n");
/*  365 */     out.append("    StringBuilder buf = new StringBuilder(512);\n");
/*      */     
/*  367 */     if (!argDtx.isExtended()) {
/*  368 */       out.append("    buf.append(super.toString()).append(\" Id: \").append(getObjectId()).append(\" Values: \");\n");
/*      */     }
/*      */     else {
/*      */       
/*  372 */       out.append("    buf.append(super.toString());\n");
/*      */     } 
/*      */     
/*  375 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/*  376 */       if ("Boolean".equalsIgnoreCase(field.getType())) {
/*  377 */         out.append("    if (" + DaoGenUtils.getGetterNameForField(field) + "() != null && " + DaoGenUtils.getGetterNameForField(field) + "()) {\n");
/*      */       }
/*      */       else {
/*      */         
/*  381 */         out.append("    if (" + DaoGenUtils.getGetterNameForField(field) + "() != null) {\n");
/*      */       } 
/*      */ 
/*      */       
/*  385 */       String fieldValue = field.isSensitive() ? "REDACTED" : (DaoGenUtils.getGetterNameForField(field) + "()");
/*  386 */       out.append("      buf.append(\"" + field.getName() + "\").append(\"=\").append(" + fieldValue + ").append(\" \");\n");
/*      */       
/*  388 */       out.append("    }\n");
/*      */     } 
/*  390 */     out.append("\n    return buf.toString();\n");
/*  391 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDBADelete(StringBuilder out, DtxDefinition argDtx) {
/*  400 */     if (argDtx.isExtended() && argDtx.getTable().equals(argDtx.getExtends().getTable())) {
/*      */       return;
/*      */     }
/*      */     
/*  404 */     out.append("  private static final String[] DELETE_OBJECT = new String[] {\"DELETE FROM " + argDtx
/*  405 */         .getTable() + "\"};\n\n");
/*      */     
/*  407 */     if (argDtx.isExtended()) {
/*  408 */       out.append("  @Override\n");
/*      */     }
/*  410 */     out.append("  public String[] getDelete() {\n");
/*  411 */     if (!argDtx.isExtended()) {
/*  412 */       out.append("    return DELETE_OBJECT;\n");
/*      */     } else {
/*      */       
/*  415 */       out.append("    return dtv.util.ArrayUtils.combine(super.getDelete(), DELETE_OBJECT);\n");
/*      */     } 
/*  417 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAExtensions(StringBuilder out, DtxDefinition argDtx) {
/*  421 */     if (argDtx.isExtended()) {
/*  422 */       if (argDtx.getExtends().isExtended()) {
/*  423 */         out.append("  public String[] getAllSelects() {\n");
/*  424 */         out.append("    String[] sels = super.getAllSelects();\n");
/*  425 */         out.append("    String[] result = new String[sels.length+1];\n");
/*  426 */         out.append("    result[0] = getSelectImpl();\n");
/*  427 */         out.append("    System.arraycopy(sels, 0, result, 1, sels.length);\n");
/*  428 */         out.append("    return result;\n");
/*  429 */         out.append("  }\n\n");
/*      */         
/*  431 */         out.append("  public IFiller[] getAllFillers() {\n");
/*  432 */         out.append("    IFiller[] fills = super.getAllFillers();\n");
/*  433 */         out.append("    IFiller[] result = new IFiller[fills.length+1];\n");
/*  434 */         out.append("    result[0] = getFillerImpl();\n");
/*  435 */         out.append("    System.arraycopy(fills, 0, result, 1, fills.length);\n");
/*  436 */         out.append("    return result;\n");
/*  437 */         out.append("  }\n\n");
/*      */       } else {
/*      */         
/*  440 */         out.append("  public String[] getAllSelects() {\n");
/*  441 */         out.append("    return new String[] { getSelectImpl() };\n");
/*  442 */         out.append("  }\n\n");
/*      */         
/*  444 */         out.append("  public IFiller[] getAllFillers() {\n");
/*  445 */         out.append("    return new IFiller[] { getFillerImpl() };\n");
/*  446 */         out.append("  }\n\n");
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void getDBAFill(StringBuilder out, DtxDefinition argDtx) {
/*  452 */     if (argDtx.isExtensible()) {
/*  453 */       out.append("  public void fill(IJDBCTableAdapter argAdapter) {\n");
/*  454 */       out.append("    " + argDtx.getName() + "DBA adapter = (" + argDtx.getName() + "DBA) argAdapter;\n");
/*  455 */       for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  456 */         String fieldName = DaoGenUtils.getFieldNameForField(field);
/*  457 */         out.append("    " + fieldName + " = adapter." + fieldName + ";\n");
/*      */       } 
/*  459 */       out.append("  }\n\n");
/*      */     }
/*  461 */     else if (!argDtx.isExtended()) {
/*      */ 
/*      */ 
/*      */       
/*  465 */       out.append("  public void fill(IJDBCTableAdapter argAdapter) {\n");
/*  466 */       out.append("    // This DBA is not extensible, no need to implement!\n");
/*  467 */       out.append("  }\n\n");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void getDBAFiller(StringBuilder out, DtxDefinition argDtx) {
/*  472 */     if (argDtx.isExtended()) {
/*  473 */       out.append("  @Override\n");
/*      */     }
/*      */     
/*  476 */     out.append("  public IFiller getFiller() {\n");
/*  477 */     out.append("    return getFillerImpl();\n");
/*  478 */     out.append("  }\n\n");
/*      */     
/*  480 */     out.append("  private IFiller getFillerImpl() {\n");
/*  481 */     out.append("    return new " + argDtx.getName() + "Filler(this);\n");
/*  482 */     out.append("  }\n\n");
/*      */     
/*  484 */     out.append("  private static class " + argDtx.getName() + "Filler implements IFiller {\n\n");
/*  485 */     out.append("    private " + argDtx.getName() + "DBA _parent;\n\n");
/*  486 */     out.append("    public " + argDtx.getName() + "Filler(" + argDtx.getName() + "DBA argParent) {\n");
/*  487 */     out.append("      _parent = argParent;\n");
/*  488 */     out.append("    }\n\n");
/*      */     
/*  490 */     out.append("    public void fill(ResultSet argResultSet) throws java.sql.SQLException{");
/*      */     
/*  492 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFieldsPlusInheritedPrimaryKeys();
/*  493 */     int idx = 0;
/*  494 */     for (DtxDefinition.DtxDaoField field : fields) {
/*  495 */       idx++;
/*  496 */       String fieldName = DaoGenUtils.getFieldNameForField(field);
/*  497 */       String dbaField = "    _parent." + fieldName + " = ";
/*      */       
/*  499 */       if ("Date".equalsIgnoreCase(field.getType())) {
/*  500 */         String tempVariableName = "t" + idx;
/*      */         
/*  502 */         out.append("\n      java.sql.Timestamp " + tempVariableName + " = argResultSet.getTimestamp(" + idx + ");\n      if (" + tempVariableName + " != null) {\n    " + dbaField + " new dtv.util.DtvDate(" + tempVariableName + ".getTime());\n      }\n      else {\n        " + dbaField + " null;\n      }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  511 */       else if ("BigDecimal".equalsIgnoreCase(field.getType())) {
/*  512 */         out.append(dbaField + "argResultSet.g" + DaoGenUtils.getEtter(field.getType(), idx) + ";\n");
/*      */       }
/*  514 */       else if ("Long".equalsIgnoreCase(field.getType())) {
/*  515 */         out.append("\n      { // load Long value for field: " + field.getName() + " while preserving null values.\n");
/*      */         
/*  517 */         out.append("        long primitiveResult = argResultSet.getLong(" + idx + ");\n");
/*  518 */         out.append("        if (primitiveResult != 0 || argResultSet.getObject(" + idx + ") != null) {\n");
/*  519 */         out.append("        " + dbaField + "Long.valueOf(primitiveResult);\n");
/*  520 */         out.append("        }\n");
/*  521 */         out.append("      }\n\n");
/*      */       }
/*  523 */       else if ("Integer".equalsIgnoreCase(field.getType())) {
/*  524 */         out.append("\n      { // load Integer value for field: " + field.getName() + " while preserving null values.\n");
/*      */         
/*  526 */         out.append("        int primitiveResult = argResultSet.getInt(" + idx + ");\n");
/*  527 */         out.append("        if (primitiveResult != 0 || argResultSet.getObject(" + idx + ") != null) {\n");
/*  528 */         out.append("        " + dbaField + "Integer.valueOf(primitiveResult);\n");
/*  529 */         out.append("        }\n");
/*  530 */         out.append("      }\n\n");
/*      */       }
/*  532 */       else if ("Clob".equalsIgnoreCase(field.getType())) {
/*  533 */         out.append("\n    // load CLOB value for field: " + field.getName() + ".\n");
/*  534 */         out.append("    " + dbaField + "dtv.data2.access.impl.jdbc.JDBCHelper.clobToString(argResultSet, " + idx + ");\n\n");
/*      */       }
/*      */       else {
/*      */         
/*  538 */         out.append(dbaField + 
/*  539 */             DaoGenUtils.wrapStatementWithObject("argResultSet.g" + DaoGenUtils.getEtter(field.getType(), idx), field.getType()) + ";\n");
/*      */       } 
/*      */ 
/*      */       
/*  543 */       if (field.getIncrementField()) {
/*  544 */         String initField = "          _parent._init" + StringUtils.ensureFirstUpperCase(field.getName()) + " = ";
/*      */         
/*  546 */         if ("BigDecimal".equalsIgnoreCase(field.getType())) {
/*  547 */           out.append(initField + "argResultSet.g" + DaoGenUtils.getEtter(field.getType(), idx) + ";\n");
/*      */         } else {
/*      */           
/*  550 */           out.append(initField + 
/*  551 */               DaoGenUtils.wrapStatementWithObject("argResultSet.g" + DaoGenUtils.getEtter(field.getType(), idx), field.getType()) + ";\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  556 */     out.append("      }\n  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAFillFromDAO(StringBuilder out, DtxDefinition argDtx) {
/*  560 */     if (argDtx.isExtended()) {
/*  561 */       out.append("  @Override\n");
/*      */     }
/*      */     
/*  564 */     out.append("  public void fill(IDataAccessObject argDAO) {\n");
/*  565 */     out.append("    ");
/*  566 */     out.append(argDtx.getName());
/*  567 */     out.append("DAO dao = (");
/*  568 */     out.append(argDtx.getName());
/*  569 */     out.append("DAO)argDAO;\n");
/*      */     
/*  571 */     if (argDtx.isExtended()) {
/*  572 */       out.append("    super.fill(dao);\n");
/*      */     }
/*      */     
/*  575 */     int idx = 0;
/*  576 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  577 */       if ("Object".equalsIgnoreCase(field.getType())) {
/*  578 */         String fieldName = DaoGenUtils.getFieldNameForField(field);
/*  579 */         String varName = "oo" + idx++;
/*  580 */         out.append("    // BLOB field - Serialize the value for JDBC\n");
/*  581 */         out.append("    Object ");
/*  582 */         out.append(varName);
/*  583 */         out.append(" = dao.");
/*  584 */         out.append(DaoGenUtils.getGetterNameForField(field));
/*  585 */         out.append("();\n");
/*  586 */         out.append("    if (");
/*  587 */         out.append(varName);
/*  588 */         out.append(" != null) {\n");
/*  589 */         out.append("      try {\n");
/*  590 */         out.append("          java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();\n");
/*  591 */         out.append("          java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);\n");
/*  592 */         out.append("          oos.writeObject(");
/*  593 */         out.append(varName);
/*  594 */         out.append(");\n");
/*  595 */         out.append("          ");
/*  596 */         out.append(fieldName);
/*  597 */         out.append(" = baos.toByteArray();\n");
/*  598 */         out.append("      }\n");
/*  599 */         out.append("      catch (Exception ee) {\n");
/*  600 */         out.append("        throw new dtv.data2.access.exception.DtxException(\"An exception occurred while serializing to field: ");
/*      */         
/*  602 */         out.append(fieldName);
/*  603 */         out.append(". Value: \" + ");
/*  604 */         out.append(varName);
/*  605 */         out.append(", ee);\n");
/*  606 */         out.append("      }\n");
/*  607 */         out.append("    }\n");
/*  608 */         out.append("    else {\n");
/*  609 */         out.append("      ");
/*  610 */         out.append(fieldName);
/*  611 */         out.append(" = null;\n");
/*  612 */         out.append("    }\n\n");
/*      */       
/*      */       }
/*  615 */       else if ("Boolean".equalsIgnoreCase(field.getType())) {
/*  616 */         String method = DaoGenUtils.getGetterNameForField(field);
/*  617 */         out.append("    " + DaoGenUtils.getFieldNameForField(field) + " = dao." + method + "() != null ? dao." + method + "() : Boolean.valueOf(false);\n");
/*      */       }
/*      */       else {
/*      */         
/*  621 */         out.append("    ");
/*  622 */         out.append(DaoGenUtils.getFieldNameForField(field));
/*  623 */         out.append(" = dao.");
/*  624 */         out.append(DaoGenUtils.getGetterNameForField(field));
/*  625 */         out.append("();\n");
/*      */         
/*  627 */         if (field.getIncrementField()) {
/*  628 */           out.append("    _init");
/*  629 */           out.append(StringUtils.ensureFirstUpperCase(field.getName()));
/*  630 */           out.append(" = dao.getInit");
/*  631 */           out.append(StringUtils.ensureFirstUpperCase(field.getName()));
/*  632 */           out.append("();\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*  636 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAFooter(StringBuilder out, DtxDefinition argDtx) {
/*  640 */     out.append("}\n");
/*      */   }
/*      */   
/*      */   private void getDBAGetObjectId(StringBuilder out, DtxDefinition argDtx) {
/*  644 */     if (!argDtx.isExtended()) {
/*  645 */       out.append("  public IObjectId getObjectId() {\n");
/*  646 */       out.append("    " + argDtx.getId() + " id = new " + argDtx.getId() + "();\n");
/*  647 */       DtxDefinition.DtxDaoField[] primaryKeyfields = argDtx.getPrimaryKeyFields();
/*      */       
/*  649 */       for (DtxDefinition.DtxDaoField primaryKeyfield : primaryKeyfields) {
/*  650 */         out.append("    id." + DaoGenUtils.getSetterNameForField(primaryKeyfield) + "(" + 
/*  651 */             DaoGenUtils.getFieldNameForField(primaryKeyfield) + ");\n");
/*      */       }
/*  653 */       out.append("    return id;\n");
/*  654 */       out.append("  }\n\n");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void getDBAHeader(StringBuilder out, DtxDefinition argDtx) {
/*  659 */     out.append("package ");
/*  660 */     out.append(argDtx.getPackage());
/*  661 */     out.append(";\n\n");
/*      */     
/*  663 */     out.append("import java.sql.PreparedStatement;\nimport java.sql.ResultSet;\nimport java.util.Date;\nimport java.util.List;\n\nimport dtv.data2.access.IDataAccessObject;\nimport dtv.data2.access.IObjectId;\nimport dtv.data2.access.impl.jdbc.IFiller;\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  671 */     if (argDtx.isExtended()) {
/*  672 */       out.append("import dtv.data2.access.impl.jdbc.IExtendedJDBCAdapter;\n\n");
/*      */     } else {
/*      */       
/*  675 */       out.append("import dtv.data2.access.impl.jdbc.IJDBCTableAdapter;\n\n");
/*      */     } 
/*      */     
/*  678 */     out.append(this.helper_.getClassCommentWithSuppressWarnings("Auto-generated DBA"));
/*      */     
/*  680 */     out.append("public class ");
/*  681 */     out.append(argDtx.getName());
/*  682 */     out.append("DBA");
/*  683 */     if (argDtx.isExtended()) {
/*  684 */       out.append(" extends ");
/*  685 */       out.append(argDtx.getExtends().getDba());
/*  686 */       out.append(" implements IExtendedJDBCAdapter");
/*      */     } else {
/*      */       
/*  689 */       out.append(" implements IJDBCTableAdapter");
/*      */     } 
/*      */     
/*  692 */     if (argDtx.hasIncrementalField()) {
/*  693 */       out.append(", dtv.data2.access.impl.IHasIncrementalValues");
/*      */     }
/*      */     
/*  696 */     out.append(" {\n\n");
/*      */     
/*  698 */     out.append("  // Fix serialization compatability based on the name of the DAO\n  private static final long serialVersionUID = ");
/*      */     
/*  700 */     out.append(String.valueOf(argDtx.getName().hashCode()));
/*  701 */     out.append("L;\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDBAInsert(StringBuilder out, DtxDefinition argDtx) {
/*  710 */     if (argDtx.isExtended() && argDtx.getTable().equals(argDtx.getExtends().getTable())) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  717 */     out.append("  private static final String[] INSERT_OBJECT = new String[] {\"");
/*  718 */     getDBAInsertSql(out, argDtx);
/*  719 */     out.append("\"};\n\n");
/*  720 */     if (argDtx.isExtended()) {
/*  721 */       out.append("  @Override\n");
/*      */     }
/*  723 */     out.append("  public String[] getInsert() {\n");
/*      */     
/*  725 */     if (!argDtx.isExtended()) {
/*  726 */       out.append("    return INSERT_OBJECT;\n");
/*      */     } else {
/*      */       
/*  729 */       out.append("    return dtv.util.ArrayUtils.combine(super.getInsert(), INSERT_OBJECT);\n");
/*      */     } 
/*  731 */     out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  736 */     if (argDtx.isExtended()) {
/*  737 */       out.append("  @Override\n");
/*      */     }
/*  739 */     out.append("  public Object[][] getInsertParameters() {\n");
/*  740 */     out.append("    Object[][] insertParameterObject = new Object[][] {{");
/*  741 */     getDBAInsertParameters(out, argDtx);
/*  742 */     out.append("}};\n");
/*      */     
/*  744 */     if (!argDtx.isExtended()) {
/*  745 */       out.append("    return insertParameterObject;\n");
/*      */     } else {
/*      */       
/*  748 */       out.append("    return dtv.util.ArrayUtils.combine(super.getInsertParameters(), insertParameterObject);\n");
/*      */     } 
/*      */     
/*  751 */     out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  756 */     out.append("  private static final int[][] INSERT_PARAMETER_TYPES_OBJECT = new int[][] {{");
/*  757 */     getDBAInsertParameterTypes(out, argDtx);
/*  758 */     out.append("}};\n\n");
/*      */     
/*  760 */     if (argDtx.isExtended()) {
/*  761 */       out.append("  @Override\n");
/*      */     }
/*  763 */     out.append("  public int[][] getInsertParameterTypes() {\n");
/*      */     
/*  765 */     if (!argDtx.isExtended()) {
/*  766 */       out.append("    return INSERT_PARAMETER_TYPES_OBJECT;\n");
/*      */     } else {
/*      */       
/*  769 */       out.append("    return dtv.util.ArrayUtils.combine(super.getInsertParameterTypes(), INSERT_PARAMETER_TYPES_OBJECT);\n");
/*      */     } 
/*      */     
/*  772 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAInsertParameters(StringBuilder out, DtxDefinition argDtx) {
/*  776 */     boolean orgNoded = argDtx.isOrgHierarchical();
/*      */     
/*  778 */     String prevSeparator = "";
/*  779 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  780 */       out.append(prevSeparator);
/*      */       
/*  782 */       if (orgNoded && DaoGenOrgHierarchyHelper.isOrgHierarchyField(field)) {
/*  783 */         DaoGenOrgHierarchyHelper.writeOrgHierarchyCUDParam(argDtx, field, out);
/*      */       }
/*  785 */       else if (DaoGenConfigElementHelper.isConfigElementField(field)) {
/*  786 */         DaoGenConfigElementHelper.ensureNonNullConfigElement(field, out);
/*      */       } else {
/*      */         
/*  789 */         out.append(DaoGenUtils.getFieldNameForField(field));
/*      */       } 
/*  791 */       prevSeparator = ", ";
/*      */     } 
/*      */   }
/*      */   
/*      */   private void getDBAInsertParameterTypes(StringBuilder out, DtxDefinition argDtx) {
/*  796 */     String prevSeparator = "";
/*  797 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  798 */       out.append(prevSeparator);
/*  799 */       out.append(String.valueOf(DaoGenUtils.getTypeForField(field)));
/*  800 */       prevSeparator = ", ";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDBAInsertSql(StringBuilder out, DtxDefinition argDtx) {
/*  808 */     out.append("INSERT INTO " + argDtx.getTable() + "(");
/*      */     
/*  810 */     String prevSeparator = "";
/*  811 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFieldsPlusInheritedPrimaryKeys();
/*  812 */     for (DtxDefinition.DtxDaoField field : fields) {
/*  813 */       out.append(prevSeparator);
/*  814 */       out.append(field.getColumn());
/*  815 */       prevSeparator = ", ";
/*      */     } 
/*      */     
/*  818 */     out.append(") VALUES (");
/*      */     
/*  820 */     prevSeparator = "";
/*      */     
/*  822 */     for (DtxDefinition.DtxDaoField field : fields) {
/*  823 */       out.append(prevSeparator);
/*  824 */       out.append("?");
/*  825 */       prevSeparator = ", ";
/*      */     } 
/*      */     
/*  828 */     out.append(")");
/*      */   }
/*      */   
/*      */   private void getDBALoadDAO(StringBuilder out, DtxDefinition argDtx) {
/*  832 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFieldsPlusInheritedPrimaryKeys();
/*      */     
/*  834 */     if (argDtx.isExtended()) {
/*  835 */       out.append("  @Override\n");
/*      */     }
/*      */     
/*  838 */     out.append("  public IDataAccessObject loadDAO(IDataAccessObject argDAO) {\n");
/*  839 */     if (argDtx.isExtended()) {
/*  840 */       out.append("    super.loadDAO(argDAO);\n");
/*      */     }
/*  842 */     out.append("    argDAO.suppressStateChanges(true);\n");
/*  843 */     out.append("    " + argDtx.getName() + "DAO dao = (" + argDtx.getName() + "DAO)argDAO;\n");
/*  844 */     for (DtxDefinition.DtxDaoField field : fields) {
/*  845 */       String fieldName = DaoGenUtils.getFieldNameForField(field);
/*  846 */       String setterName = DaoGenUtils.getSetterNameForField(field);
/*  847 */       if (field.getType().equalsIgnoreCase("Object")) {
/*  848 */         out.append("    // BLOB field - Deserialize the raw bytes\n    if (");
/*      */         
/*  850 */         out.append(fieldName);
/*  851 */         out.append(" != null) {\n        try {\n            java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(");
/*      */ 
/*      */         
/*  854 */         out.append(fieldName);
/*  855 */         out.append(");\n            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(bais);\n            Object o = ois.readObject();\n            dao.");
/*      */ 
/*      */ 
/*      */         
/*  859 */         out.append(setterName);
/*  860 */         out.append("(o); // deserialize\n        }\n        catch (Exception ee) {\n          throw new dtv.data2.access.exception.DtxException(\"An exception occurred while deserializing field: ");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  865 */         out.append(fieldName);
/*  866 */         out.append(". Value: \" + ");
/*  867 */         out.append(fieldName);
/*  868 */         out.append(", ee);\n        }\n    }\n    else {\n      dao.");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  873 */         out.append(setterName);
/*  874 */         out.append("(null);\n    }\n");
/*      */       }
/*      */       else {
/*      */         
/*  878 */         out.append("    dao.");
/*  879 */         out.append(setterName);
/*  880 */         out.append("(");
/*  881 */         out.append(fieldName);
/*  882 */         out.append(");\n");
/*      */         
/*  884 */         if (field.getIncrementField()) {
/*  885 */           out.append("    dao.setInit");
/*  886 */           out.append(StringUtils.ensureFirstUpperCase(field.getName()));
/*  887 */           out.append("(");
/*  888 */           out.append(fieldName);
/*  889 */           out.append(");\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*  893 */     out.append("    argDAO.suppressStateChanges(false);\n");
/*  894 */     out.append("    return dao;\n");
/*  895 */     out.append("  }\n\n");
/*      */     
/*  897 */     if (argDtx.isExtended()) {
/*  898 */       out.append("  @Override\n");
/*      */     }
/*      */     
/*  901 */     out.append("  public IDataAccessObject loadDefaultDAO() {\n");
/*  902 */     out.append("    return loadDAO(new ");
/*  903 */     out.append(argDtx.getName());
/*  904 */     out.append("DAO());\n");
/*  905 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAMembers(StringBuilder out, DtxDefinition argDtx) {
/*  909 */     for (DtxDefinition.DtxDaoField f : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  910 */       if (f.getType().equalsIgnoreCase("Object")) {
/*  911 */         out.append("  private byte[] _");
/*  912 */         out.append(f.getName());
/*  913 */         out.append(";\n");
/*      */       } else {
/*      */         
/*  916 */         out.append("  private ");
/*  917 */         out.append(DaoGenUtils.getRawDataType(f.getType()));
/*  918 */         out.append(" ");
/*  919 */         out.append(DaoGenUtils.getFieldNameForField(f));
/*  920 */         out.append(";\n");
/*  921 */         if (f.getIncrementField()) {
/*  922 */           out.append("  private ");
/*  923 */           out.append(DaoGenUtils.getRawDataType(f.getType()));
/*  924 */           out.append(" _init");
/*  925 */           out.append(StringUtils.ensureFirstUpperCase(f.getName()));
/*  926 */           out.append(";\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  931 */     if (argDtx.hasIncrementalField()) {
/*  932 */       out.append("  protected boolean _incrementalActive = true;\n");
/*      */     }
/*  934 */     out.append("\n");
/*      */   }
/*      */   
/*      */   private void getDBAMethods(StringBuilder out, DtxDefinition argDtx) {
/*  938 */     getIncrementalActive(out, argDtx);
/*      */     
/*  940 */     getDBASelect(out, argDtx);
/*  941 */     getDBAInsert(out, argDtx);
/*  942 */     getDBAUpdate(out, argDtx);
/*  943 */     getDBADelete(out, argDtx);
/*  944 */     getDBAWhere(out, argDtx);
/*      */     
/*  946 */     getDaoDbaUpdateDiffMethods(out, argDtx);
/*  947 */     getDBATableName(out, argDtx);
/*  948 */     getDBAFiller(out, argDtx);
/*  949 */     getDBALoadDAO(out, argDtx);
/*  950 */     getDBAFillFromDAO(out, argDtx);
/*      */     
/*  952 */     getDBAWriteObjectId(out, argDtx);
/*  953 */     getDBAGetObjectId(out, argDtx);
/*  954 */     getDBAFill(out, argDtx);
/*  955 */     getDBARemaining(out, argDtx);
/*  956 */     getDBAExtensions(out, argDtx);
/*      */   }
/*      */   
/*      */   private void getDBARemaining(StringBuilder out, DtxDefinition argDtx) {
/*  960 */     if (!argDtx.isExtended()) {
/*  961 */       out.append("  public boolean isExtensible() {\n");
/*  962 */       out.append("    return " + argDtx.isExtensible() + ";\n");
/*  963 */       out.append("  }\n\n");
/*      */       
/*  965 */       out.append("  public String getImplementingClass() {\n");
/*  966 */       if (argDtx.isExtensible()) {
/*  967 */         out.append("    return _" + argDtx.getImplementingClassField() + ";\n");
/*      */       } else {
/*      */         
/*  970 */         out.append("    return null; // This DBA is not extensible\n");
/*      */       } 
/*  972 */       out.append("  }\n\n");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void getDBASelect(StringBuilder out, DtxDefinition argDtx) {
/*  978 */     out.append("  private static final String SELECT_OBJECT = ");
/*  979 */     out.append("\"SELECT ");
/*  980 */     String prevSeparator = "";
/*  981 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*  982 */       out.append(prevSeparator);
/*  983 */       out.append("t.");
/*  984 */       out.append(field.getColumn());
/*  985 */       prevSeparator = ", ";
/*      */     } 
/*  987 */     out.append(" FROM ");
/*  988 */     out.append(argDtx.getTable());
/*  989 */     out.append(" t\";\n\n");
/*      */     
/*  991 */     if (argDtx.isExtended()) {
/*  992 */       out.append("  @Override\n");
/*      */     }
/*  994 */     out.append("  public String getSelect() {\n    return getSelectImpl();\n  }\n\n  private String getSelectImpl() {\n    return SELECT_OBJECT;\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1000 */     out.append("  }\n\n");
/*      */     
/* 1002 */     getDBASelectWhere(out, argDtx);
/*      */   }
/*      */   
/*      */   private void getDBASelectWhere(StringBuilder out, DtxDefinition argDtx) {
/* 1006 */     boolean isOrgHierarchical = argDtx.isOrgHierarchical();
/*      */     
/* 1008 */     out.append("  private static final String SELECT_WHERE_OBJECT = \"");
/* 1009 */     boolean whereWritten = false;
/*      */     
/* 1011 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 1012 */       if (field.isPrimaryKey() && (
/* 1013 */         !isOrgHierarchical || !DaoGenOrgHierarchyHelper.isOrgHierarchyField(field))) {
/* 1014 */         if (whereWritten) {
/* 1015 */           out.append(" AND ");
/*      */         } else {
/*      */           
/* 1018 */           out.append(" WHERE ");
/* 1019 */           whereWritten = true;
/*      */         } 
/* 1021 */         out.append(field.getColumn());
/* 1022 */         out.append(" = ? ");
/*      */       } 
/*      */     } 
/*      */     
/* 1026 */     out.append(" \";\n\n");
/*      */     
/* 1028 */     if (argDtx.isExtended()) {
/* 1029 */       out.append("  @Override\n");
/*      */     }
/* 1031 */     out.append("  public String getSelectWhere() {\n");
/* 1032 */     out.append("    return SELECT_WHERE_OBJECT;\n");
/* 1033 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBATableName(StringBuilder out, DtxDefinition argDtx) {
/* 1037 */     if (argDtx.isExtended()) {
/* 1038 */       out.append("  @Override\n");
/*      */     }
/* 1040 */     out.append("  public String getTableName() {\n    return \"" + argDtx
/* 1041 */         .getTable() + "\";\n  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDBAUpdate(StringBuilder out, DtxDefinition argDtx) {
/* 1051 */     if ((argDtx.isExtended() && argDtx.getTable().equals(argDtx.getExtends().getTable())) || argDtx
/* 1052 */       .getNonPkFields().isEmpty()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1061 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFieldsPlusInheritedPrimaryKeys();
/*      */     
/* 1063 */     if (argDtx.hasIncrementalField()) {
/* 1064 */       out.append("  public String[] getUpdate () {\n");
/* 1065 */       out.append("    if (_incrementalActive) {\n");
/* 1066 */       out.append("      return getIncrementalUpdate();\n");
/* 1067 */       out.append("    }\n");
/* 1068 */       out.append("    else {\n");
/* 1069 */       out.append("      return getStandardUpdate();\n");
/* 1070 */       out.append("    }\n");
/* 1071 */       out.append("  }\n\n");
/*      */       
/* 1073 */       getDBAUpdateMethod(out, argDtx, "getIncrementalUpdate", true, false);
/* 1074 */       getDBAUpdateMethod(out, argDtx, "getStandardUpdate", false, false);
/*      */     } else {
/*      */       
/* 1077 */       getDBAUpdateMethod(out, argDtx, "getUpdate", true, argDtx.isExtended());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1084 */     if (argDtx.isExtended()) {
/* 1085 */       out.append("  @Override\n");
/*      */     }
/* 1087 */     out.append("  public Object[][] getUpdateParameters() {\n");
/* 1088 */     out.append("    Object[][] updateParameterObject = new Object[][] {{");
/* 1089 */     getDBAUpdateCurrentFieldList(out, fields);
/* 1090 */     out.append("}};\n");
/*      */     
/* 1092 */     if (!argDtx.isExtended()) {
/* 1093 */       out.append("    return updateParameterObject;\n");
/*      */     } else {
/*      */       
/* 1096 */       out.append("    return dtv.util.ArrayUtils.combine(super.getUpdateParameters(), updateParameterObject);\n");
/*      */     } 
/*      */ 
/*      */     
/* 1100 */     out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1105 */     out.append("  private static final int[][] UPDATE_PARAMETER_TYPE_OBJECT = new int[][] {{");
/* 1106 */     getDBAUpdateParameters(out, fields);
/* 1107 */     out.append("}};\n");
/*      */     
/* 1109 */     if (argDtx.isExtended()) {
/* 1110 */       out.append("  @Override\n");
/*      */     }
/* 1112 */     out.append("  public int[][] getUpdateParameterTypes() {\n");
/* 1113 */     if (!argDtx.isExtended()) {
/* 1114 */       out.append("    return UPDATE_PARAMETER_TYPE_OBJECT;\n");
/*      */     } else {
/*      */       
/* 1117 */       out.append("    return dtv.util.ArrayUtils.combine(super.getUpdateParameterTypes(), UPDATE_PARAMETER_TYPE_OBJECT);\n");
/*      */     } 
/*      */ 
/*      */     
/* 1121 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAUpdateCurrentFieldList(StringBuilder w, DtxDefinition.DtxDaoField[] fields) {
/* 1125 */     String prevSeparator = "";
/* 1126 */     for (DtxDefinition.DtxDaoField field : fields) {
/* 1127 */       if (!field.isPrimaryKey() && !Arrays.<String>asList(FIELDS_EXCLUDED_FROM_UPDATE).contains(field.getName())) {
/* 1128 */         w.append(prevSeparator);
/* 1129 */         if (field.getIncrementField()) {
/* 1130 */           w.append(DaoGenUtils.getGetterNameForField(field));
/* 1131 */           w.append("Diff()");
/*      */         }
/* 1133 */         else if (DaoGenConfigElementHelper.isConfigElementField(field)) {
/* 1134 */           DaoGenConfigElementHelper.ensureNonNullConfigElement(field, w);
/*      */         } else {
/*      */           
/* 1137 */           w.append(DaoGenUtils.getFieldNameForField(field));
/*      */         } 
/* 1139 */         prevSeparator = ", ";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void getDBAUpdateMethod(StringBuilder out, DtxDefinition argDtx, String argMethodName, boolean argHonorIncremental, boolean argIsExtended) {
/* 1146 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFieldsPlusInheritedPrimaryKeys();
/*      */     
/* 1148 */     String fieldName = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_UNDERSCORE, argMethodName.substring(3)) + "_OBJECT";
/*      */     
/* 1150 */     out.append("  private static final String[] " + fieldName + " = new String[] {\"");
/* 1151 */     getDBAUpdateSql(out, argDtx, fields, argHonorIncremental);
/* 1152 */     out.append("\"};\n\n");
/*      */     
/* 1154 */     if (argIsExtended) {
/* 1155 */       out.append("  @Override\n");
/*      */     }
/* 1157 */     out.append("  public String[] " + argMethodName + "() {\n");
/*      */     
/* 1159 */     if (!argDtx.isExtended()) {
/* 1160 */       out.append("    return " + fieldName + ";\n");
/*      */     } else {
/*      */       
/* 1163 */       out.append("    return dtv.util.ArrayUtils.combine(super.getUpdate(), " + fieldName + ");\n");
/*      */     } 
/*      */     
/* 1166 */     out.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getDBAUpdateParameters(StringBuilder out, DtxDefinition.DtxDaoField[] fields) {
/* 1170 */     String prevSeparator = "";
/* 1171 */     for (DtxDefinition.DtxDaoField field : fields) {
/* 1172 */       if (!field.isPrimaryKey() && !Arrays.<String>asList(FIELDS_EXCLUDED_FROM_UPDATE).contains(field.getName())) {
/* 1173 */         out.append(prevSeparator);
/* 1174 */         out.append(String.valueOf(DaoGenUtils.getTypeForField(field)));
/* 1175 */         prevSeparator = ", ";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDBAUpdateSql(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField[] fields, boolean argHonorIncrementalFields) {
/* 1187 */     out.append("UPDATE ");
/* 1188 */     out.append(argDtx.getTable());
/* 1189 */     out.append(" SET ");
/*      */     
/* 1191 */     String prevSeparator = "";
/* 1192 */     for (DtxDefinition.DtxDaoField field : fields) {
/* 1193 */       if (!field.isPrimaryKey() && !Arrays.<String>asList(FIELDS_EXCLUDED_FROM_UPDATE).contains(field.getName())) {
/* 1194 */         out.append(prevSeparator);
/* 1195 */         if (field.getIncrementField() && argHonorIncrementalFields) {
/* 1196 */           out.append(field.getColumn());
/* 1197 */           out.append(" = ");
/* 1198 */           out.append("COALESCE(");
/* 1199 */           out.append(field.getColumn());
/* 1200 */           out.append(",0) + ?");
/*      */         } else {
/*      */           
/* 1203 */           out.append(field.getColumn());
/* 1204 */           out.append(" = ?");
/*      */         } 
/* 1206 */         prevSeparator = ", ";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void getDBAWhere(StringBuilder out, DtxDefinition argDtx) {
/* 1213 */     out.append("  private static final String WHERE_OBJECT = \"");
/* 1214 */     boolean whereWritten = false;
/* 1215 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 1216 */       if (field.isPrimaryKey()) {
/* 1217 */         if (whereWritten) {
/* 1218 */           out.append(" AND ");
/*      */         } else {
/*      */           
/* 1221 */           out.append(" WHERE ");
/* 1222 */           whereWritten = true;
/*      */         } 
/* 1224 */         out.append(field.getColumn());
/* 1225 */         out.append(" = ? ");
/*      */       } 
/*      */     } 
/* 1228 */     out.append(" \";\n\n");
/*      */     
/* 1230 */     if (argDtx.isExtended()) {
/* 1231 */       out.append("  @Override\n");
/*      */     }
/* 1233 */     out.append("  public String getWhere() {\n");
/* 1234 */     out.append("    return WHERE_OBJECT;");
/* 1235 */     out.append("  }\n\n");
/*      */     
/* 1237 */     getWhereParameters(out, argDtx);
/* 1238 */     getWhereParameterTypes(out, argDtx);
/*      */   }
/*      */   
/*      */   private void getDBAWriteObjectId(StringBuilder sb, DtxDefinition argDtx) {
/* 1242 */     boolean orgNoded = argDtx.isOrgHierarchical();
/* 1243 */     DtxDefinition.DtxDaoField[] primaryKeyfields = argDtx.getPrimaryKeyFields();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1248 */     if (argDtx.isExtended() && argDtx.getExtends().isPlaceHolder()) {
/*      */       return;
/*      */     }
/* 1251 */     boolean hasKey = (primaryKeyfields.length > 0);
/*      */     
/* 1253 */     if (argDtx.isExtended()) {
/* 1254 */       sb.append("  @Override\n");
/*      */     }
/*      */     
/* 1257 */     sb.append("  public PreparedStatement writeObjectId(IObjectId argId, PreparedStatement argStatement) ");
/* 1258 */     if (hasKey) {
/* 1259 */       sb.append("throws java.sql.SQLException ");
/*      */     }
/* 1261 */     sb.append("{\n");
/*      */     
/* 1263 */     if (hasKey) {
/* 1264 */       sb.append("    ").append(argDtx.getId()).append(" id = (").append(argDtx.getId()).append(") argId;\n");
/*      */     }
/*      */     
/* 1267 */     for (int i = 0; i < primaryKeyfields.length; i++) {
/* 1268 */       if (!orgNoded || !DaoGenOrgHierarchyHelper.isOrgHierarchyField(primaryKeyfields[i])) {
/*      */ 
/*      */ 
/*      */         
/* 1272 */         sb.append("      argStatement.s");
/* 1273 */         sb.append(DaoGenUtils.getEtterInputObject(primaryKeyfields[i].getType(), i + 1, "id.get" + 
/* 1274 */               StringUtils.ensureFirstUpperCase(DaoGenUtils.toPrimitive(primaryKeyfields[i]))));
/* 1275 */         sb.append(";\n");
/*      */       } 
/* 1277 */     }  sb.append("    return argStatement;\n");
/* 1278 */     sb.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private void getIncrementalActive(StringBuilder out, DtxDefinition argDtx) {
/* 1282 */     if (argDtx.hasIncrementalField()) {
/* 1283 */       out.append("  public void setIncrementalActive(boolean argActive) {\n");
/* 1284 */       out.append("    _incrementalActive = argActive;\n");
/* 1285 */       out.append("  }\n\n");
/*      */       
/* 1287 */       out.append("  public boolean getIncrementalActive() {\n");
/* 1288 */       out.append("    return _incrementalActive;\n");
/* 1289 */       out.append("  }\n\n");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getWhereParameters(StringBuilder out, DtxDefinition argDtx) {
/* 1297 */     boolean orgNoded = argDtx.isOrgHierarchical();
/*      */     
/* 1299 */     if (argDtx.isExtended()) {
/* 1300 */       out.append("  @Override\n");
/*      */     }
/* 1302 */     out.append("  public Object[] getWhereParameters() {\n    return new Object[] { ");
/*      */ 
/*      */     
/* 1305 */     String prevSeparator = "";
/* 1306 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 1307 */       if (field.isPrimaryKey()) {
/* 1308 */         out.append(prevSeparator);
/*      */         
/* 1310 */         if (orgNoded && DaoGenOrgHierarchyHelper.isOrgHierarchyField(field)) {
/* 1311 */           DaoGenOrgHierarchyHelper.writeOrgHierarchyCUDParam(argDtx, field, out);
/*      */         }
/* 1313 */         else if (DaoGenConfigElementHelper.isConfigElementField(field)) {
/* 1314 */           DaoGenConfigElementHelper.ensureNonNullConfigElement(field, out);
/*      */         } else {
/*      */           
/* 1317 */           out.append(DaoGenUtils.getFieldNameForField(field));
/*      */         } 
/* 1319 */         prevSeparator = ", ";
/*      */       } 
/*      */     } 
/*      */     
/* 1323 */     out.append(" };\n  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getWhereParameterTypes(StringBuilder w, DtxDefinition argDtx) {
/* 1332 */     w.append("  private static final int[] WHERE_PARAMETER_OBJECT = new int[] { ");
/* 1333 */     String prevSeparator = "";
/* 1334 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 1335 */       if (field.isPrimaryKey()) {
/* 1336 */         w.append(prevSeparator);
/* 1337 */         w.append(String.valueOf(DaoGenUtils.getTypeForField(field)));
/* 1338 */         prevSeparator = ", ";
/*      */       } 
/*      */     } 
/* 1341 */     w.append(" };\n\n");
/*      */     
/* 1343 */     if (argDtx.isExtended()) {
/* 1344 */       w.append("  @Override\n");
/*      */     }
/* 1346 */     w.append("  public int[] getWhereParameterTypes() {\n");
/* 1347 */     w.append("    return WHERE_PARAMETER_OBJECT;");
/* 1348 */     w.append("  }\n\n");
/*      */   }
/*      */   
/*      */   private String makeCast(DtxDefinition.DtxDaoField field) {
/* 1352 */     String type = DaoGenUtils.getRawDataType(field.getType());
/* 1353 */     if ("Object".equals(type)) {
/* 1354 */       return "";
/*      */     }
/* 1356 */     return "(" + type + ")";
/*      */   }
/*      */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateDaoAndDba.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */