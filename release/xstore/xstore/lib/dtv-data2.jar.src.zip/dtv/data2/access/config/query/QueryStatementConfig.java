/*     */ package dtv.data2.access.config.query;
/*     */ 
/*     */ import com.google.common.base.CharMatcher;
/*     */ import dtv.util.config.AbstractParentConfig;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryStatementConfig
/*     */   extends AbstractParentConfig
/*     */   implements Comparable<QueryStatementConfig>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  24 */   private final List<QueryExpressionConfig> expressions_ = new ArrayList<>();
/*  25 */   private int order_ = -1;
/*  26 */   private final List<QueryParameterConfig> parameters_ = new ArrayList<>();
/*  27 */   private String statement_ = null;
/*  28 */   private String dtxWhereClause_ = null;
/*     */   
/*     */   private boolean requiredFlag_ = true;
/*     */ 
/*     */   
/*     */   public int compareTo(QueryStatementConfig argOther) {
/*  34 */     return this.order_ - argOther.order_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDtxWhereClause() {
/*  43 */     return this.dtxWhereClause_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<QueryExpressionConfig> getExpressions() {
/*  52 */     return this.expressions_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  61 */     return this.order_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<QueryParameterConfig> getParameters() {
/*  70 */     return this.parameters_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatement() {
/*  79 */     return this.statement_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/*  88 */     return this.requiredFlag_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/*  94 */     if ("Expression".equalsIgnoreCase(argKey)) {
/*  95 */       this.expressions_.add((QueryExpressionConfig)argValue);
/*     */     }
/*  97 */     else if ("Parameter".equalsIgnoreCase(argKey)) {
/*  98 */       this.parameters_.add((QueryParameterConfig)argValue);
/*     */     }
/* 100 */     else if ("Order".equalsIgnoreCase(argKey)) {
/* 101 */       this.order_ = ConfigUtils.asInt(argValue.toString());
/*     */     }
/* 103 */     else if ("Statement".equalsIgnoreCase(argKey)) {
/* 104 */       this.statement_ = CharMatcher.WHITESPACE.trimLeadingFrom(argValue.toString());
/*     */     }
/* 106 */     else if ("WhereClause".equalsIgnoreCase(argKey)) {
/* 107 */       this.dtxWhereClause_ = argValue.toString();
/*     */     }
/* 109 */     else if ("required".equalsIgnoreCase(argKey)) {
/* 110 */       this.requiredFlag_ = Boolean.valueOf(argValue.toString()).booleanValue();
/*     */     } else {
/*     */       
/* 113 */       warnUnsupported(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int argOrder) {
/* 123 */     this.order_ = argOrder;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\query\QueryStatementConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */