/*    */ package dtv.data2.access;
/*    */ 
/*    */ import dtv.data2.access.impl.PersistenceConstants;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractObjectId
/*    */   implements IObjectId
/*    */ {
/*    */   private static final long serialVersionUID = 5555577777L;
/* 22 */   protected static final boolean MANAGE_CASE = PersistenceConstants.MANAGE_CASE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final Map<Object, Object> _properties;
/*    */ 
/*    */ 
/*    */   
/*    */   protected Long _organizationId;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractObjectId() {
/* 37 */     if (this._organizationId == null) {
/* 38 */       setOrganizationId(Long.getLong("dtv.location.organizationId"));
/*    */     }
/* 40 */     this._properties = new HashMap<>();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean containsKey(Object argKey) {
/* 46 */     return this._properties.containsKey(argKey);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean equals(Object paramObject);
/*    */ 
/*    */ 
/*    */   
/*    */   public Object get(Object argKey) {
/* 56 */     return this._properties.get(argKey);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Long getOrganizationId() {
/* 62 */     if (this._organizationId == null) {
/* 63 */       setOrganizationId(Long.getLong("dtv.location.organizationId"));
/*    */     }
/* 65 */     return this._organizationId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract int hashCode();
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<Object> iterator() {
/* 75 */     return this._properties.keySet().iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void put(Object argKey, Object argValue) {
/* 81 */     this._properties.put(argKey, argValue);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOrganizationId(Long argOrganizationId) {
/* 87 */     this._organizationId = argOrganizationId;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\AbstractObjectId.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */