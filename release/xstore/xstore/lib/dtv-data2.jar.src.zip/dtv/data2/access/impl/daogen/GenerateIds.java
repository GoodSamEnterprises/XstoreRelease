/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateIds
/*     */   implements Callable<Void>
/*     */ {
/*  26 */   private static final Logger logger_ = Logger.getLogger(GenerateIds.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final DaoGenHelper helper_;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenerateIds(DaoGenHelper argHelper) {
/*  36 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  44 */     logger_.info("Generating id classes");
/*     */     
/*  46 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/*     */       
/*  48 */       if (dtx.isExtended() || !dtx.needsGeneration(null)) {
/*     */         continue;
/*     */       }
/*  51 */       StringBuilder w = new StringBuilder(5120);
/*     */       
/*  53 */       getIdHeader(w, dtx);
/*  54 */       getIdConstuctors(w, dtx);
/*  55 */       getIdFields(w, dtx);
/*  56 */       getIdMethods(w, dtx);
/*  57 */       getIdEquals(w, dtx);
/*  58 */       getIdHashCode(w, dtx);
/*  59 */       getIdDtxTypeName(w, dtx);
/*  60 */       getIdToString(w, dtx);
/*  61 */       getIdValidate(w, dtx);
/*  62 */       getIdFooter(w);
/*     */ 
/*     */       
/*  65 */       String daiPath = (this.helper_.getOutPath() + this.helper_.getFilePath(dtx)).replaceAll("impl\\" + File.separator, "");
/*  66 */       File f = new File(daiPath + dtx.getIdType() + ".java");
/*  67 */       this.helper_.getWriter().write(f, w.toString());
/*     */     } 
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   private void getIdConstuctors(StringBuilder w, DtxDefinition argDtx) {
/*  73 */     String constructorName = argDtx.getIdType();
/*     */     
/*  75 */     w.append("  public " + constructorName + "() {\n");
/*  76 */     w.append("    super();");
/*  77 */     w.append("    // default\n");
/*  78 */     w.append("  }\n\n");
/*  79 */     w.append("  public " + constructorName + "(String argObjectIdValue) {\n");
/*  80 */     w.append("    setValue(argObjectIdValue);\n");
/*  81 */     w.append("  }\n\n");
/*     */   }
/*     */   
/*     */   private void getIdDtxTypeName(StringBuilder w, DtxDefinition argDtx) {
/*  85 */     w.append("  public String getDtxTypeName() {\n");
/*  86 */     w.append("    return \"" + argDtx.getName() + "\";\n");
/*  87 */     w.append("  }\n\n");
/*     */   }
/*     */   
/*     */   private void getIdEquals(StringBuilder w, DtxDefinition argDtx) {
/*  91 */     String idName = argDtx.getIdType();
/*     */     
/*  93 */     w.append("  @Override\n  public boolean equals(Object ob) {\n");
/*     */     
/*  95 */     if ((argDtx.getPrimaryKeyFields()).length == 0) {
/*  96 */       w.append("    return false;");
/*  97 */       w.append("  }\n\n");
/*     */       
/*     */       return;
/*     */     } 
/* 101 */     w.append("    if (this == ob) {\n");
/* 102 */     w.append("      return true;\n");
/* 103 */     w.append("    }\n");
/* 104 */     w.append("    if (!(ob instanceof " + idName + ")) {\n");
/* 105 */     w.append("      return false;\n");
/* 106 */     w.append("    }\n");
/* 107 */     w.append("    " + idName + " other = (" + idName + ") ob;\n");
/*     */     
/* 109 */     boolean first = true;
/* 110 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 111 */       if (first) {
/* 112 */         w.append("    return\n          ");
/* 113 */         first = false;
/*     */       } else {
/*     */         
/* 116 */         w.append("        && ");
/*     */       } 
/* 118 */       String fieldName = DaoGenUtils.getFieldNameForField(field);
/* 119 */       w.append("((" + fieldName + " == null && other." + fieldName + " == null) ||\n");
/* 120 */       w.append("            (this." + fieldName + " != null &&\n");
/* 121 */       if (field.getType().equals("Date")) {
/* 122 */         w.append("             this." + fieldName + ".equals((Object)other." + fieldName + ")))\n");
/*     */       } else {
/*     */         
/* 125 */         w.append("             this." + fieldName + ".equals(other." + fieldName + ")))\n");
/*     */       } 
/*     */     } 
/* 128 */     w.append("          ;\n  }\n\n");
/*     */   }
/*     */   
/*     */   private void getIdFields(StringBuilder w, DtxDefinition argDtx) {
/* 132 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 133 */       if (!field.getName().equalsIgnoreCase("organizationId")) {
/* 134 */         w.append("  private " + 
/* 135 */             DaoGenUtils.getConcreteDataType(field.getType()) + " " + DaoGenUtils.getFieldNameForField(field) + ";\n");
/*     */       }
/*     */     } 
/* 138 */     w.append("\n");
/*     */   }
/*     */   
/*     */   private void getIdFooter(StringBuilder w) {
/* 142 */     w.append("} ");
/*     */   }
/*     */   
/*     */   private void getIdHashCode(StringBuilder w, DtxDefinition argDtx) {
/* 146 */     w.append("  @Override\n  public int hashCode() {\n");
/*     */ 
/*     */     
/* 149 */     if ((argDtx.getPrimaryKeyFields()).length == 0) {
/* 150 */       w.append("    return 0;\n");
/* 151 */       w.append("  }\n\n");
/*     */       return;
/*     */     } 
/* 154 */     w.append("    return (\n");
/*     */     
/* 156 */     boolean first = true;
/* 157 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 158 */       w.append("        ");
/* 159 */       if (first) {
/* 160 */         first = false;
/*     */       } else {
/*     */         
/* 163 */         w.append("+ ");
/*     */       } 
/* 165 */       w.append("((" + DaoGenUtils.getFieldNameForField(field) + " == null) ? 0 : " + DaoGenUtils.getFieldNameForField(field) + ".hashCode())\n");
/*     */     } 
/*     */     
/* 168 */     w.append("        );\n  }\n\n");
/*     */   }
/*     */   
/*     */   private void getIdHeader(StringBuilder w, DtxDefinition argDtx) {
/* 172 */     w.append("package " + argDtx.getInterfacePackage() + ";\n\n");
/*     */     
/* 174 */     DtxDefinition.DtxDaoField[] primaryKeyFields = argDtx.getPrimaryKeyFields();
/* 175 */     boolean keyHasConfigElement = false;
/*     */     
/* 177 */     for (DtxDefinition.DtxDaoField primaryKeyField : primaryKeyFields) {
/* 178 */       if (primaryKeyField.getType().equals("Date")) {
/* 179 */         w.append("import java.util.Date;\n\n");
/*     */       }
/* 181 */       else if (primaryKeyField.getType().equals("BigDecimal")) {
/* 182 */         w.append("import java.math.BigDecimal;\n\n");
/*     */       } 
/*     */       
/* 185 */       if (DaoGenConfigElementHelper.isConfigElementField(primaryKeyField)) {
/* 186 */         keyHasConfigElement = true;
/*     */       }
/*     */     } 
/*     */     
/* 190 */     w.append("import dtv.util.common.CommonConstants;\n\n");
/*     */     
/* 192 */     w.append(this.helper_.getClassCommentWithSuppressWarnings("Auto generated Id Object for " + argDtx.getName()));
/*     */     
/* 194 */     w.append("public class ");
/* 195 */     w.append(argDtx.getIdType());
/*     */     
/* 197 */     w.append("\n    extends dtv.data2.access.AbstractObjectId");
/*     */     
/* 199 */     if (keyHasConfigElement) {
/* 200 */       w.append("\n    implements dtv.data2.access.IHasConfigElement");
/*     */     }
/*     */     
/* 203 */     w.append(" {\n\n");
/*     */     
/* 205 */     w.append("  // Fix serialization compatability based on the name of the DAO\n");
/* 206 */     w.append("  private static final long serialVersionUID = ");
/* 207 */     w.append(String.valueOf(argDtx.getName().hashCode()));
/* 208 */     w.append("L;\n\n");
/*     */     
/* 210 */     if (keyHasConfigElement) {
/* 211 */       w.append("  @Override\n");
/* 212 */       w.append("  public dtv.data2.access.IObjectId getObjectId() {\n");
/* 213 */       w.append("    return this;\n");
/* 214 */       w.append("  }\n\n");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void getIdMethods(StringBuilder w, DtxDefinition argDtx) {
/* 219 */     DtxDefinition.DtxDaoField[] primaryKeyFields = argDtx.getPrimaryKeyFields();
/*     */     
/* 221 */     for (DtxDefinition.DtxDaoField field : primaryKeyFields) {
/* 222 */       if (!field.getName().equalsIgnoreCase("organizationId")) {
/*     */         
/* 224 */         DaoGenUtils.appendGetterForField(w, field);
/*     */ 
/*     */         
/* 227 */         DaoGenUtils.appendSetterForField(w, field, false, true);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     w.append("  public void setValue(String argObjectIdValue) {\n");
/* 236 */     w.append("    String str = argObjectIdValue;\n");
/* 237 */     w.append("    if (dtv.util.StringUtils.isEmpty(str)) {\n");
/* 238 */     w.append("      throw new dtv.data2.access.exception.DtxException(\"argument passed to setValue() is null or empty - a valid value must be passed\");\n");
/*     */     
/* 240 */     w.append("    }\n");
/*     */     
/* 242 */     w.append("    try {\n");
/*     */     
/* 244 */     w.append("      String[] tokens = str.split(\"::\");\n");
/*     */     
/* 246 */     int ii = 0;
/* 247 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 248 */       w.append("      str = tokens[" + ii++ + "];\n\n");
/*     */       
/* 250 */       String fieldNameForField = DaoGenUtils.getFieldNameForField(field);
/* 251 */       String setterNameForField = DaoGenUtils.getSetterNameForField(field);
/* 252 */       if (field.getType().equals("Date")) {
/* 253 */         w.append("      if (\"null\".equals(str)) {\n");
/* 254 */         w.append("        " + setterNameForField + "(null);\n");
/* 255 */         w.append("      }\n");
/* 256 */         w.append("      else {\n");
/* 257 */         w.append("        " + setterNameForField + "(new dtv.util.DtvDate());\n");
/* 258 */         w.append("        " + fieldNameForField + ".setTimeFromSerialization(Long.parseLong(str));\n");
/* 259 */         w.append("      }\n");
/*     */       }
/* 261 */       else if (field.getType().equals("Long")) {
/* 262 */         w.append("      " + setterNameForField + "(java.lang.Long.valueOf(str));\n");
/*     */       }
/* 264 */       else if (field.getType().equals("Integer")) {
/* 265 */         w.append("      " + setterNameForField + "(java.lang.Integer.valueOf(str));\n");
/*     */       }
/* 267 */       else if (field.getType().equals("BigDecimal")) {
/* 268 */         w.append("      " + setterNameForField + "(new java.math.BigDecimal(str));\n");
/*     */       } else {
/*     */         
/* 271 */         w.append("      if (\"null\".equals(str)) {\n");
/* 272 */         w.append("        " + setterNameForField + "(null);\n");
/* 273 */         w.append("      }\n");
/* 274 */         w.append("      else {\n");
/* 275 */         w.append("        " + setterNameForField + "(str);\n");
/* 276 */         w.append("      }\n");
/*     */       } 
/*     */     } 
/*     */     
/* 280 */     w.append("    }\n");
/* 281 */     w.append("    catch (Exception ee) {\n");
/* 282 */     w.append("      throw new dtv.data2.access.exception.DtxException(\"An exception occured while parsing object id string: \" + argObjectIdValue, ee);\n");
/*     */ 
/*     */     
/* 285 */     w.append("    }\n");
/* 286 */     w.append("  }\n");
/* 287 */     w.append("\n");
/*     */   }
/*     */   
/*     */   private void getIdToString(StringBuilder w, DtxDefinition argDtx) {
/* 291 */     w.append("  @Override\n  public String toString() {\n");
/*     */ 
/*     */     
/* 294 */     if ((argDtx.getPrimaryKeyFields()).length == 0) {
/* 295 */       w.append("    return \"" + argDtx.getName() + " does not define primary key fields.\";\n");
/* 296 */       w.append("  }\n\n");
/*     */       
/*     */       return;
/*     */     } 
/* 300 */     w.append("    StringBuilder buff = new StringBuilder(12 * " + (argDtx
/* 301 */         .getPrimaryKeyFields()).length + ");\n\n");
/* 302 */     w.append("    return buff.append(\n");
/*     */     
/* 304 */     int count = 0;
/*     */     
/* 306 */     boolean first = true;
/* 307 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/*     */       
/* 309 */       count++;
/*     */       
/* 311 */       if (!first) {
/* 312 */         w.append("      append(\"::\").append(");
/*     */       } else {
/*     */         
/* 315 */         w.append("      ");
/* 316 */         first = false;
/*     */       } 
/*     */       
/* 319 */       if (field.getType().equals("Date")) {
/* 320 */         w.append(DaoGenUtils.getFieldNameForField(field));
/* 321 */         w.append(" == null ? \"null\" ");
/* 322 */         w.append(": String.valueOf(");
/* 323 */         w.append(DaoGenUtils.getFieldNameForField(field));
/* 324 */         w.append(".getTimeSerializable())).");
/*     */       } else {
/*     */         
/* 327 */         String fieldName = DaoGenUtils.getFieldNameForField(field);
/* 328 */         if (field.getType().equals("String")) {
/* 329 */           w.append(fieldName + ").");
/*     */         }
/* 331 */         else if (field.getType().equals("BigDecimal")) {
/*     */ 
/*     */           
/* 334 */           w.append("new java.text.DecimalFormat(\"0.000000\").format(" + fieldName + ")).");
/*     */         } else {
/*     */           
/* 337 */           w.append("String.valueOf(" + fieldName + ")).");
/*     */         } 
/*     */       } 
/* 340 */       w.append("\n");
/*     */     } 
/*     */ 
/*     */     
/* 344 */     if (count == 0) {
/* 345 */       w.append("      super.toString()\n");
/*     */     }
/*     */     
/* 348 */     w.append("    toString();\n  }\n\n");
/*     */   }
/*     */   
/*     */   private void getIdValidate(StringBuilder w, DtxDefinition argDtx) {
/* 352 */     boolean orgNoded = argDtx.isOrgHierarchical();
/*     */     
/* 354 */     w.append("  public boolean validate() {\n");
/*     */     
/* 356 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 357 */       if (!field.getName().equalsIgnoreCase("organizationId") && (!orgNoded || 
/* 358 */         !DaoGenOrgHierarchyHelper.isOrgHierarchyField(field))) {
/*     */         
/* 360 */         w.append("    if (" + DaoGenUtils.getFieldNameForField(field) + " == null) {\n");
/* 361 */         w.append("      return false;\n");
/* 362 */         w.append("    }\n");
/*     */       } 
/*     */     } 
/* 365 */     w.append("    return true;\n");
/* 366 */     w.append("  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateIds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */