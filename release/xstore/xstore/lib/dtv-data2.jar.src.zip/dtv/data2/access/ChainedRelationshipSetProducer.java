/*    */ package dtv.data2.access;
/*    */ 
/*    */ import dtv.util.ArrayUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChainedRelationshipSetProducer
/*    */   implements IRelationshipSetProducer
/*    */ {
/*    */   private final IRelationshipSetProducer[] _producers;
/*    */   
/*    */   public ChainedRelationshipSetProducer(IRelationshipSetProducer... argRelationshipSetProducers) {
/* 25 */     this._producers = argRelationshipSetProducers;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IDataModelRelationship[] getRelationshipSet() {
/* 31 */     IDataModelRelationship[] relationships = null;
/* 32 */     for (IRelationshipSetProducer producer : this._producers) {
/* 33 */       if (relationships == null) {
/* 34 */         relationships = producer.getRelationshipSet();
/*    */       } else {
/*    */         
/* 37 */         relationships = (IDataModelRelationship[])ArrayUtils.combine((Object[])relationships, (Object[])producer.getRelationshipSet());
/*    */       } 
/*    */     } 
/* 40 */     return (relationships != null) ? relationships : new IDataModelRelationship[0];
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\ChainedRelationshipSetProducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */