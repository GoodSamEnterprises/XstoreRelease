/*     */ package dtv.data2.access.impl.remote;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.IDataModelRelationship;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.AbstractPersistenceStrategy;
/*     */ import dtv.data2.access.query.QueryToken;
/*     */ import dtv.data2.access.transaction.ITransactionalDataSource;
/*     */ import dtv.data2.security.DtvSecurityManager;
/*     */ import dtv.event.EventManager;
/*     */ import dtv.util.Base64;
/*     */ import dtv.util.ByteArray;
/*     */ import dtv.util.EncodingHelper;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.crypto.DtvDecrypter;
/*     */ import dtv.util.crypto.DtvKeyStoreException;
/*     */ import dtv.util.crypto.IDtvDecrypter;
/*     */ import dtv.util.net.DtvHostnameVerifier;
/*     */ import dtv.util.net.SslUtils;
/*     */ import dtv.util.zip.GZipUtils;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.inject.Inject;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHttpDatasource
/*     */   extends AbstractPersistenceStrategy
/*     */   implements ITransactionalDataSource
/*     */ {
/*     */   public static final String HTTP_HEADER_PROP_USER_AGENT = "User-Agent";
/*     */   public static final String GET_OBJECT_BY_ID_URN = "dtx:getObjectById";
/*     */   public static final String GET_OBJECT_BY_QUERY_URN = "dtx:getObjectByQuery";
/*     */   public static final String PROP_URL = "ConnectionURL";
/*     */   public static final String PROP_USER_NAME = "ConnectionUserName";
/*     */   public static final String PROP_PASSWORD = "ConnectionPassword";
/*     */   public static final String PROP_SOAP_ACTION = "SoapAction";
/*     */   public static final String PROP_TIMEOUT = "Timeout";
/*     */   public static final String PROP_KEYSTORE = "keystore";
/*     */   public static final String PROP_KEYSTORE_PASSWORD = "keystorePassword";
/*     */   public static final String PROP_KEY_ALIAS = "keyalias";
/*     */   public static final String PROP_TRUSTSTORE = "truststore";
/*     */   public static final String PROP_TRUSTSTORE_PASSWORD = "truststorePassword";
/*     */   @Deprecated
/*     */   public static final String RESPONSE_OBJECT_NOT_FOUND = "ObjectNotFoundException";
/*     */   public static final String PERSIST_SUCCESS = "DTX_PERSISTENCE_WAS_SUCCESSFUL";
/*     */   public static final String PERSIST_FAILURE = "FAILURE";
/*     */   public static final String TIMOUT_ELEMENT = "Timeout";
/*     */   public static final String TIMOUT_ATTRIBUTE = "t";
/*     */   public static final String TIMOUT_BEGIN = "<Timeout t=\"";
/*     */   public static final String TIMOUT_END = "\"/>";
/*     */   static final String PROP_PREFIX_URLPATH = "UrlPath:";
/*     */   static final String PROP_PREFIX_SOAP_ACTION = "SoapAction:";
/* 123 */   private static final Logger logger_ = Logger.getLogger(AbstractHttpDatasource.class);
/*     */ 
/*     */   
/*     */   private static final String HTTP_HEADER_PROP_ACCEPT = "Accept";
/*     */ 
/*     */   
/*     */   protected String hostUrl_;
/*     */ 
/*     */   
/*     */   protected String userName_;
/*     */ 
/*     */   
/*     */   protected String password_;
/*     */ 
/*     */   
/*     */   protected String soapAction_;
/*     */   
/* 140 */   protected int timeout_ = -1;
/*     */   
/*     */   private String keystore_;
/*     */   
/*     */   private String keystorePassword_;
/*     */   
/*     */   private String keyAlias_;
/*     */   
/*     */   private String truststore_;
/*     */   
/*     */   private String truststorePassword_;
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */   @Inject
/*     */   private EventManager _eventManager;
/*     */   
/*     */   public Object getObjectByRelationship(IDataModelRelationship argRel, QueryToken argQueryToken) {
/* 157 */     IObjectId id = getChildObjectIdForRelationship(argRel);
/* 158 */     if (id == null || !id.validate())
/*     */     {
/* 160 */       return null;
/*     */     }
/* 162 */     return getObjectById(id, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeout() {
/* 170 */     return this.timeout_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullGraphProvided() {
/* 176 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object sendHttpRequest(String argRequest, String argContentType, String argEncodingType, String argPath, Map<String, String> argProperties) throws Exception {
/*     */     byte[] requestBytes;
/* 196 */     if (HttpContentType.BINARY.matches(argContentType)) {
/* 197 */       if (HttpEncodingType.GZIP.matches(argEncodingType)) {
/* 198 */         requestBytes = GZipUtils.zip(EncodingHelper.serialize(argRequest));
/*     */       } else {
/*     */         
/* 201 */         throw new DtxException("Unknown encoding type for binary: " + argEncodingType + " Cannot send http request with object " + argRequest);
/*     */       }
/*     */     
/*     */     }
/* 205 */     else if (HttpContentType.TEXT.matches(argContentType)) {
/* 206 */       if (HttpEncodingType.UTF8.matches(argEncodingType)) {
/* 207 */         requestBytes = StringUtils.getBytes(argRequest);
/*     */       }
/* 209 */       else if (HttpEncodingType.BASE64.matches(argEncodingType)) {
/* 210 */         requestBytes = StringUtils.getBytes(EncodingHelper.encode(argRequest, false));
/*     */       } else {
/*     */         
/* 213 */         throw new DtxException("Unknown encoding type for text: " + argEncodingType + " Cannot send http request with object " + argRequest);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 218 */       throw new DtxException("Unknown content type : " + argContentType + " Cannot send http request with object " + argRequest);
/*     */     } 
/*     */ 
/*     */     
/* 222 */     HttpURLConnection conn = null;
/* 223 */     OutputStream out = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 230 */       URL url = new URL(this.hostUrl_ + argPath);
/*     */       
/* 232 */       conn = (HttpURLConnection)url.openConnection();
/* 233 */       conn.setFixedLengthStreamingMode(requestBytes.length);
/* 234 */       conn.setDoOutput(true);
/* 235 */       conn.setDoInput(true);
/* 236 */       addAuthentication(conn);
/* 237 */       setupHttps(conn);
/* 238 */       conn.setRequestProperty("Accept", "*/*");
/* 239 */       conn.setRequestProperty("User-Agent", getUserAgent(argProperties));
/* 240 */       conn.setRequestProperty("Content-Type", argContentType);
/* 241 */       conn.setRequestProperty("Content-Encoding", argEncodingType);
/* 242 */       addRequestParams(conn);
/* 243 */       conn.setReadTimeout(this.timeout_);
/* 244 */       Map<String, List<String>> requestProps = conn.getRequestProperties();
/*     */       
/* 246 */       out = conn.getOutputStream();
/*     */       
/* 248 */       out.write(requestBytes);
/* 249 */       out.flush();
/*     */       
/* 251 */       Level level = Level.DEBUG;
/* 252 */       Throwable t = null;
/*     */       
/* 254 */       if (SwingUtilities.isEventDispatchThread())
/*     */       {
/* 256 */         DtvSecurityManager.getInstance().isAllowed("XcenterAccessFromUiThread");
/*     */       }
/*     */       
/* 259 */       if (logger_.isEnabledFor((Priority)level)) {
/* 260 */         StringBuilder msg = new StringBuilder(1024);
/* 261 */         msg.append("HTTP Request [Datasource: ");
/* 262 */         msg.append(getDataSourceName());
/* 263 */         msg.append("]\n");
/* 264 */         msg.append("URL: ");
/* 265 */         msg.append(url);
/* 266 */         msg.append("\n");
/* 267 */         msg.append("Header:\n");
/* 268 */         msg.append(formatHeader(requestProps));
/* 269 */         msg.append(argRequest);
/* 270 */         logger_.log((Priority)level, msg.toString(), t);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 276 */       return getServletResponse(conn, argPath);
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 283 */         if (out != null) {
/* 284 */           out.close();
/* 285 */           out = null;
/*     */         }
/*     */       
/* 288 */       } catch (Exception ee) {
/* 289 */         if (logger_.isDebugEnabled()) {
/* 290 */           logger_.debug("Encountered an exception while closing our writer.", ee);
/*     */         }
/*     */       } 
/*     */       try {
/* 294 */         if (conn != null) {
/* 295 */           conn.disconnect();
/* 296 */           conn = null;
/*     */         }
/*     */       
/* 299 */       } catch (Exception ee) {
/* 300 */         logger_.debug("Encountered an exception while closing our HttpURLConnection.", ee);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProps) {
/*     */     try {
/* 309 */       super.setProperties(argProps);
/* 310 */       this.hostUrl_ = getAndValidateSet(argProps, "ConnectionURL");
/* 311 */       this.timeout_ = Integer.parseInt(getAndValidateSet(argProps, "Timeout"));
/* 312 */       this.userName_ = argProps.getProperty("ConnectionUserName");
/* 313 */       this.password_ = argProps.getProperty("ConnectionPassword");
/* 314 */       this.soapAction_ = argProps.getProperty("SoapAction");
/*     */       
/* 316 */       if (isHttps()) {
/*     */         
/*     */         try {
/*     */           
/* 320 */           this.keystore_ = getAndValidateSet(argProps, "keystore");
/*     */           
/* 322 */           this.keystorePassword_ = getProperty(argProps, "keystorePassword");
/* 323 */           this.keyAlias_ = getAndValidateSet(argProps, "keyalias");
/*     */ 
/*     */ 
/*     */           
/* 327 */           this.truststore_ = argProps.getProperty("truststore");
/*     */           
/* 329 */           this.truststorePassword_ = getProperty(argProps, "truststorePassword");
/*     */         }
/* 331 */         catch (Exception ee) {
/* 332 */           logger_.error("An exception occurred while loading properties for datasource: " + 
/* 333 */               getDataSourceName(), ee);
/*     */         }
/*     */       
/*     */       }
/* 337 */     } catch (Exception ee) {
/* 338 */       logger_.error("An exception occurred while loading properties for datasource: " + 
/* 339 */           getDataSourceName(), ee);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     if (!StringUtils.isEmpty(this.userName_) || !StringUtils.isEmpty(this.password_)) {
/* 347 */       validateSet("ConnectionUserName", this.userName_);
/* 348 */       validateSet("ConnectionPassword", this.password_);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(int argTimeout) {
/* 357 */     this.timeout_ = argTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addAuthentication(HttpURLConnection conn) {
/* 365 */     if (!StringUtils.isEmpty(this.userName_)) {
/* 366 */       IDtvDecrypter decrypter = DtvDecrypter.getInstance("config");
/* 367 */       String s = decrypter.decryptIfEncrypted(this.userName_) + ":" + decrypter.decryptIfEncrypted(this.password_);
/* 368 */       s = Base64.byteArrayToBase64(s.getBytes());
/* 369 */       conn.setRequestProperty("Authorization", "Basic " + s);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addRequestParams(HttpURLConnection argConn) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String formatHeader(Map<String, List<String>> argHeader) {
/* 389 */     StringBuilder buff = new StringBuilder(512);
/* 390 */     for (String key : argHeader.keySet()) {
/* 391 */       for (String value : argHeader.get(key)) {
/* 392 */         buff.append(key).append("=").append(value).append("\n");
/*     */       }
/*     */     } 
/* 395 */     return buff.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getAndValidateSet(Properties argProps, String argName) {
/* 405 */     String s = argProps.getProperty(argName);
/* 406 */     validateSet(argName, s);
/* 407 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EventManager getEventManager() {
/* 416 */     return this._eventManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPersistenceDefaults getPersistenceDefaults() {
/* 425 */     return this._persistenceDefaults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getProperty(Properties argProps, String argPropertyName) {
/* 435 */     String value = argProps.getProperty(argPropertyName);
/*     */     
/* 437 */     if (value == null) {
/* 438 */       return null;
/*     */     }
/*     */     
/* 441 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getServletResponse(HttpURLConnection argConnection, String argServletUrl) throws Exception {
/* 455 */     InputStream in = null;
/*     */     try {
/* 457 */       in = argConnection.getInputStream();
/*     */       
/* 459 */       ByteArray response = null;
/*     */       
/* 461 */       int contentLength = argConnection.getContentLength();
/* 462 */       boolean contentLengthApplicable = (contentLength != -1);
/*     */       
/* 464 */       if (contentLengthApplicable) {
/* 465 */         response = new ByteArray(contentLength);
/*     */       } else {
/*     */         
/* 468 */         response = new ByteArray(2048);
/*     */       } 
/*     */ 
/*     */       
/*     */       int read;
/*     */ 
/*     */       
/* 475 */       while ((read = in.read()) != -1) {
/* 476 */         response.append((byte)read);
/*     */       }
/*     */       
/* 479 */       if (contentLengthApplicable && response.length() < contentLength) {
/* 480 */         logger_.warn("We only read " + response.length() + " bytes,  but the content length was reported as: " + contentLength + "bytes. *BYTES MAY HAVE BEEN DROPPED!*");
/*     */       }
/*     */ 
/*     */       
/* 484 */       byte[] data = response.toArray();
/*     */       
/* 486 */       String encoding = argConnection.getContentEncoding();
/*     */       
/* 488 */       if (HttpEncodingType.GZIP.matches(encoding)) {
/* 489 */         return EncodingHelper.deserialize(GZipUtils.unzip(data));
/*     */       }
/* 491 */       if (encoding == null || HttpEncodingType.UTF8.matches(encoding)) {
/* 492 */         return StringUtils.getString(data);
/*     */       }
/*     */       
/* 495 */       String ss = StringUtils.getString(data);
/* 496 */       logger_.warn("Unrecognized content encoding type from servlet: " + encoding + " response bytes as string: " + ss);
/*     */ 
/*     */       
/* 499 */       throw FailoverException.getNewException("Unrecognized encoding type: " + encoding, 
/* 500 */           getDataSourceName());
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/* 508 */         if (in != null) {
/* 509 */           in.close();
/*     */         }
/*     */       }
/* 512 */       catch (Exception ee) {
/* 513 */         if (logger_.isDebugEnabled()) {
/* 514 */           logger_.debug("Encountered an exception while closing our reader.", ee);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSoapAction(String argQueryKey, Map<String, Object> argParams) {
/* 529 */     String compositeKey = "SoapAction:" + argQueryKey;
/* 530 */     if (getProperties().containsKey(compositeKey)) {
/* 531 */       return getProperties().getProperty(compositeKey);
/*     */     }
/*     */     
/* 534 */     if (!StringUtils.isEmpty(this.soapAction_)) {
/* 535 */       return this.soapAction_;
/*     */     }
/*     */     
/* 538 */     return getUrlPath(argQueryKey, argParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getUrlPath(String argQueryKey, Map<String, Object> argParams) {
/* 552 */     String compositeKey = "UrlPath:" + argQueryKey;
/* 553 */     Properties props = getProperties();
/*     */     
/* 555 */     return props.containsKey(compositeKey) ? props.getProperty(compositeKey) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getUserAgent(Map<String, String> argProperties) {
/* 565 */     StringBuilder buff = new StringBuilder(256);
/*     */     
/* 567 */     buff.append(this._persistenceDefaults.getOrganizationId());
/* 568 */     buff.append("::");
/* 569 */     buff.append(this._persistenceDefaults.getRetailLocationId());
/* 570 */     buff.append("::");
/*     */     
/* 572 */     String explicitWorkstationId = argProperties.get("WORKSTATION_ID_PROPERTY");
/* 573 */     if (explicitWorkstationId != null) {
/* 574 */       buff.append(explicitWorkstationId);
/*     */     } else {
/*     */       
/* 577 */       buff.append(this._persistenceDefaults.getWorkstationId());
/*     */     } 
/*     */     
/* 580 */     String timestamp = argProperties.get("TIMESTAMP_PROPERTY");
/*     */     
/* 582 */     if (timestamp != null) {
/* 583 */       buff.append("::");
/* 584 */       buff.append(timestamp);
/*     */     } 
/*     */     
/* 587 */     return buff.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isHttps() {
/* 595 */     return this.hostUrl_.toLowerCase().startsWith("https");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupHttps(HttpURLConnection argConn) throws KeyManagementException, DtvKeyStoreException, NoSuchAlgorithmException {
/* 610 */     if (argConn instanceof HttpsURLConnection) {
/* 611 */       HttpsURLConnection conn = (HttpsURLConnection)argConn;
/*     */       
/* 613 */       IDtvDecrypter decrypter = DtvDecrypter.getInstance("config");
/* 614 */       char[] keypass = decrypter.decryptIfEncrypted(this.keystorePassword_).toCharArray();
/* 615 */       char[] trustpass = decrypter.decryptIfEncrypted(this.truststorePassword_).toCharArray();
/*     */ 
/*     */       
/* 618 */       SSLSocketFactory socketFactory = SslUtils.getSSLSocketFactory(this.keystore_, keypass, this.keyAlias_, this.truststore_, trustpass);
/* 619 */       conn.setSSLSocketFactory(socketFactory);
/* 620 */       conn.setHostnameVerifier((HostnameVerifier)new DtvHostnameVerifier());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateSet(String argName, String argValue) {
/* 631 */     if (StringUtils.isEmpty(argValue))
/* 632 */       throw new DtxException("Property [" + argName + "] is required for datasource [" + getDataSourceName() + "] to function. Check DataSourceConfig.xml."); 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\remote\AbstractHttpDatasource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */