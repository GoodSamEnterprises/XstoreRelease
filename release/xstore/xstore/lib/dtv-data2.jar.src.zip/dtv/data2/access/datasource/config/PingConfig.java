/*    */ package dtv.data2.access.datasource.config;
/*    */ 
/*    */ import dtv.data2.access.config.common.PropertyConfig;
/*    */ import dtv.data2.access.config.common.PropertyConfigConverter;
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PingConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 24 */   private static final Logger logger_ = Logger.getLogger(PingConfig.class);
/*    */   
/* 26 */   private final List<PropertyConfig> properties_ = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   private Class<?> impl_;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPing getPing() {
/* 36 */     IPing ping = null;
/*    */     
/* 38 */     if (this.impl_ == null) {
/* 39 */       throw new Error("No ping implementation specified!");
/*    */     }
/*    */     
/*    */     try {
/* 43 */       ping = (IPing)this.impl_.newInstance();
/*    */     }
/* 45 */     catch (Exception ex) {
/* 46 */       String err = "Invalid IPing implementation: " + this.impl_.getName();
/* 47 */       logger_.error(err, ex);
/* 48 */       throw new Error(err, ex);
/*    */     } 
/*    */     
/* 51 */     if (!this.properties_.isEmpty() && ping != null) {
/* 52 */       ping.setProperties(PropertyConfigConverter.convert(this.properties_, new Properties()));
/*    */     }
/*    */     
/* 55 */     return ping;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 61 */     if ("Property".equalsIgnoreCase(argKey) && argValue instanceof PropertyConfig) {
/* 62 */       this.properties_.add((PropertyConfig)argValue);
/*    */     }
/* 64 */     else if ("ClassName".equalsIgnoreCase(argKey)) {
/* 65 */       Class<?> clazz = ConfigUtils.toClass(argValue);
/* 66 */       if (logger_.isDebugEnabled()) {
/* 67 */         logger_.debug("Ping implementation: " + clazz);
/*    */       }
/* 69 */       this.impl_ = clazz;
/*    */     } else {
/*    */       
/* 72 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\datasource\config\PingConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */