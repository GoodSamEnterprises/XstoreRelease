/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import java.net.DatagramSocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatagramSocketPing
/*    */   extends SocketPing
/*    */ {
/*    */   protected int getDefaultPort() {
/* 22 */     return 1434;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean pingImpl() throws Exception {
/* 30 */     DatagramSocket s = new DatagramSocket();
/* 31 */     s.setSoTimeout(getTimeout());
/* 32 */     s.connect(createSocketAddress());
/* 33 */     s.close();
/*    */     
/* 35 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\DatagramSocketPing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */