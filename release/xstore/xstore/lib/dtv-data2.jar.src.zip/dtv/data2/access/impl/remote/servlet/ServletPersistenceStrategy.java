/*     */ package dtv.data2.access.impl.remote.servlet;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IQueryResult;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.exception.PersistenceCancelledException;
/*     */ import dtv.data2.access.exception.RetryException;
/*     */ import dtv.data2.access.exception.ServletFailoverException;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.impl.remote.AbstractHttpDatasource;
/*     */ import dtv.data2.access.impl.remote.HttpContentType;
/*     */ import dtv.data2.access.impl.remote.HttpEncodingType;
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.data2.access.query.QueryToken;
/*     */ import dtv.data2.access.transaction.DataSourceTransactionManager;
/*     */ import dtv.data2.access.transaction.ITransactionalDataSource;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import dtv.event.EventManager;
/*     */ import dtv.util.ObjectUtils;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ServletPersistenceStrategy
/*     */   extends AbstractHttpDatasource {
/*     */   public static final String PROP_GET_OBJECT_BY_ID_PATH = "GetObjectByIdPath";
/*     */   public static final String PROP_GET_OBJECT_BY_QUERY_PATH = "GetObjectByQueryPath";
/*     */   public static final String PROP_MAKE_PERSISTENT_PATH = "MakePersistentPath";
/*  41 */   private static final Logger logger_ = Logger.getLogger(ServletPersistenceStrategy.class);
/*     */   private static final String PROP_MAKE_PERSISTENT_COMM_TYPE = "MakePersistentCommType";
/*     */   private static final String HEADER_MESSAGE_TYPE = "dtv-msg-type";
/*     */   
/*     */   static boolean isObjectNotFound(String argResponse) {
/*  46 */     return (argResponse.contains("ObjectNotPresentException") || argResponse
/*  47 */       .contains("DataSourceUnavailableException") || argResponse
/*  48 */       .contains("ObjectNotFoundException"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getObjectByIdPath_;
/*     */ 
/*     */   
/*     */   protected String getObjectByQueryPath_;
/*     */   
/*     */   protected String makePersistentPath_;
/*     */   
/*  60 */   private final Map<TransactionToken, List<IPersistable>> makePersistentTransactions_ = new HashMap<>();
/*     */   
/*     */   private MessageType messageType_;
/*  63 */   private MakePersistentCommunicationType makePersistentCommType_ = MakePersistentCommunicationType.GZIP;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkExistence(IObjectId argId, QueryToken argQueryToken) {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase1(TransactionToken argTransToken) {
/*     */     try {
/*  75 */       List<IPersistable> persistables = this.makePersistentTransactions_.get(argTransToken);
/*     */       
/*  77 */       StringBuilder request = new StringBuilder(persistables.size() * 4096);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  82 */       request.append("<Timeout t=\"").append(this.timeout_).append("\"/>");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  87 */       for (IPersistable persistable : persistables) {
/*  88 */         request.append(persistable.toXmlString());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       Object oo = callServlet(request.toString(), getContentType(this.makePersistentCommType_), 
/*  95 */           getEncodingType(this.makePersistentCommType_), this.makePersistentPath_, argTransToken.getProperties());
/*     */       
/*  97 */       if (!(oo instanceof String)) {
/*  98 */         throw new DtxException("Unknown response from callServlet: " + oo);
/*     */       }
/*     */       
/* 101 */       String response = (String)oo;
/*     */       
/* 103 */       if (response.indexOf("DTX_PERSISTENCE_WAS_SUCCESSFUL") != -1) {
/*     */         return;
/*     */       }
/*     */       
/* 107 */       if (FailoverException.isFailover(new Exception(response)) || response
/* 108 */         .contains("No Available Datasources") || response
/* 109 */         .contains(PersistenceCancelledException.class.getName()))
/*     */       {
/* 111 */         throw ServletFailoverException.getNewException(response, getDataSourceName());
/*     */       }
/*     */       
/* 114 */       logger_.error("Could not persist data via DTX Servlet.  THIS IS NOT A CONNECTION FAILOVER, but we will throw a failover so local sources will be tried. Servlet reports: " + response);
/*     */ 
/*     */ 
/*     */       
/* 118 */       throw ServletFailoverException.getNewException(response.toString(), getDataSourceName());
/*     */ 
/*     */     
/*     */     }
/* 122 */     catch (Exception ee) {
/* 123 */       if (RetryException.isRetryException(ee)) {
/* 124 */         throw RetryException.getNewException(ee, getDataSourceName());
/*     */       }
/* 126 */       if (FailoverException.isFailover(ee)) {
/* 127 */         throw FailoverException.getNewException(ee, getDataSourceName());
/*     */       }
/* 129 */       if (ee instanceof ServletFailoverException) {
/* 130 */         throw (ServletFailoverException)ee;
/*     */       }
/*     */       
/* 133 */       logger_.error("Could not persist data via DTX Servlet.  THIS IS NOT A CONNECTION FAILOVER, but we will throw a failover so local sources will be tried.", ee);
/*     */ 
/*     */       
/* 136 */       throw ServletFailoverException.getNewException(ee, getDataSourceName());
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 141 */       this.makePersistentTransactions_.remove(argTransToken);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitPhase2(TransactionToken argTransToken) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageType getMessageType() {
/* 157 */     return this.messageType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDataModel getObjectById(IObjectId argId, QueryToken argQueryToken) {
/* 166 */     this.messageType_ = MessageType.LOOKUP;
/*     */     
/*     */     try {
/* 169 */       StringBuilder request = new StringBuilder(128);
/*     */       
/*     */       try {
/* 172 */         request.append(this.getObjectByIdPath_).append("?").append(URLEncoder.encode("ID", "UTF-8")).append("=")
/* 173 */           .append(URLEncoder.encode(argId.toString(), "UTF-8")).append("&")
/* 174 */           .append(URLEncoder.encode("NAME", "UTF-8")).append("=")
/* 175 */           .append(URLEncoder.encode(argId.getDtxTypeName(), "UTF-8"));
/*     */       }
/* 177 */       catch (Exception ee) {
/* 178 */         throw new DtxException("An unexpected exception occurred while building getObjectById servlet request for id: " + argId, ee);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 186 */       Object oo = callServlet("", HttpContentType.TEXT
/* 187 */           .toString(), HttpEncodingType.UTF8.toString(), request.toString(), new HashMap<>());
/*     */ 
/*     */       
/* 190 */       if (oo instanceof String) {
/* 191 */         if (isObjectNotFound(oo.toString())) {
/* 192 */           return null;
/*     */         }
/*     */         
/* 195 */         logger_.warn("Unrecognized message from servlet while exec getObjectId for id: " + argId + " Servlet message: " + oo);
/*     */         
/* 197 */         throw FailoverException.getNewException("Unrecognized message from servlet: " + oo, 
/* 198 */             getDataSourceName());
/*     */       } 
/*     */       
/* 201 */       if (oo instanceof IDataModel) {
/* 202 */         setOriginDataSource(oo);
/* 203 */         setPersistenceDefaultsOnObject(oo);
/* 204 */         return (IDataModel)oo;
/*     */       } 
/*     */       
/* 207 */       throw new DtxException("Unknown type returned from servlet call. Object toString: " + oo + " Class: " + 
/* 208 */           ObjectUtils.getClassNameFromObject(oo));
/*     */     
/*     */     }
/* 211 */     catch (Exception ee) {
/* 212 */       if (RetryException.isRetryException(ee)) {
/* 213 */         throw RetryException.getNewException(ee, getDataSourceName());
/*     */       }
/* 215 */       if (FailoverException.isFailover(ee)) {
/* 216 */         throw FailoverException.getNewException(ee, getDataSourceName());
/*     */       }
/*     */       
/* 219 */       logger_.warn("Unexpected exception during getObjectById with id: " + argId, ee);
/* 220 */       throw FailoverException.getNewException("Failing " + getDataSourceName() + " over.", ee, 
/* 221 */           getDataSourceName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectByQuery(String argKey, Map<String, Object> argParams, QueryToken argQueryToken) {
/* 237 */     this.messageType_ = MessageType.LOOKUP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 244 */       QueryRequest request = new QueryRequest(argKey, argParams);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       Object oo = callServlet(request.toXmlString(), getContentType(this.makePersistentCommType_), 
/* 251 */           getEncodingType(this.makePersistentCommType_), this.getObjectByQueryPath_, new HashMap<>());
/*     */       
/* 253 */       if (oo instanceof String) {
/* 254 */         if (isObjectNotFound(oo.toString())) {
/* 255 */           return null;
/*     */         }
/*     */         
/* 258 */         logger_.warn("Unrecognized message from servlet while exec query key: " + argKey + " Servlet message: " + oo);
/*     */         
/* 260 */         throw FailoverException.getNewException("Unrecognized message from servlet: " + oo, 
/* 261 */             getDataSourceName());
/*     */       } 
/*     */       
/* 264 */       if (oo instanceof RuntimeException) {
/* 265 */         throw (RuntimeException)oo;
/*     */       }
/*     */       
/* 268 */       setOriginDataSource(oo);
/* 269 */       setPersistenceDefaultsOnObject(oo);
/* 270 */       return oo;
/*     */     
/*     */     }
/* 273 */     catch (Exception ee) {
/* 274 */       if (RetryException.isRetryException(ee)) {
/* 275 */         throw RetryException.getNewException(ee, getDataSourceName());
/*     */       }
/* 277 */       if (FailoverException.isFailover(ee)) {
/* 278 */         throw FailoverException.getNewException(ee, getDataSourceName());
/*     */       }
/*     */       
/* 281 */       logger_.warn("Unexpected exception during getObjectByQuery with key: " + argKey, ee);
/* 282 */       throw FailoverException.getNewException("Failing " + getDataSourceName() + " over.", ee, 
/* 283 */           getDataSourceName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullGraphPersisted() {
/* 291 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(TransactionToken argTransToken) {
/* 297 */     this.makePersistentTransactions_.remove(argTransToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageType(MessageType argMessageType) {
/* 306 */     this.messageType_ = argMessageType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProps) {
/* 312 */     this.getObjectByIdPath_ = getAndValidateSet(argProps, "GetObjectByIdPath");
/* 313 */     this.getObjectByQueryPath_ = getAndValidateSet(argProps, "GetObjectByQueryPath");
/* 314 */     this.makePersistentPath_ = getAndValidateSet(argProps, "MakePersistentPath");
/*     */     
/* 316 */     if (argProps.containsKey("MakePersistentCommType")) {
/* 317 */       this
/* 318 */         .makePersistentCommType_ = MakePersistentCommunicationType.forName(argProps.getProperty("MakePersistentCommType"));
/*     */     }
/* 320 */     super.setProperties(argProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addRequestParams(HttpURLConnection argConnection) {
/* 330 */     super.addRequestParams(argConnection);
/* 331 */     if (this.messageType_ == null) {
/* 332 */       this.messageType_ = MessageType.NOT_SPECIFIED;
/*     */     }
/* 334 */     argConnection.setRequestProperty("dtv-msg-type", this.messageType_.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object callServlet(String argRequest, String argContentType, String argEncodingType, String argServletUrl, Map<String, String> argProperties) {
/*     */     try {
/* 350 */       return sendHttpRequest(argRequest, argContentType, argEncodingType, argServletUrl, argProperties);
/*     */     }
/* 352 */     catch (Exception ee) {
/* 353 */       if (RetryException.isRetryException(ee)) {
/* 354 */         throw RetryException.getNewException(ee, getDataSourceName());
/*     */       }
/* 356 */       if (FailoverException.isFailover(ee)) {
/* 357 */         throw FailoverException.getNewException(ee, getDataSourceName());
/*     */       }
/*     */       
/* 360 */       logger_.warn("ServletPersistenceStrategy encountered an unexpected exception while contacting servlet at: " + argServletUrl, ee);
/*     */       
/* 362 */       throw FailoverException.getNewException("Something is wrong with the servlet, so we're failing it over.", ee, 
/* 363 */           getDataSourceName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getContentType(MakePersistentCommunicationType argType) {
/* 375 */     return (MakePersistentCommunicationType.GZIP == argType) ? HttpContentType.BINARY
/* 376 */       .toString() : HttpContentType.TEXT
/* 377 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getEncodingType(MakePersistentCommunicationType argType) {
/* 387 */     if (MakePersistentCommunicationType.GZIP.equals(argType)) {
/* 388 */       return HttpEncodingType.GZIP.toString();
/*     */     }
/* 390 */     if (MakePersistentCommunicationType.TEXT.equals(argType)) {
/* 391 */       return HttpEncodingType.UTF8.toString();
/*     */     }
/* 393 */     if (MakePersistentCommunicationType.BASE64.equals(argType)) {
/* 394 */       return HttpEncodingType.BASE64.toString();
/*     */     }
/*     */     
/* 397 */     throw new DtxException("Unhandled communication type: " + argType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getUrlPath(String argQueryKey, Map<String, Object> argParams) {
/* 404 */     String urlPath = super.getUrlPath(argQueryKey, argParams);
/* 405 */     return (urlPath == null) ? this.makePersistentPath_ : urlPath;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void makePersistentImpl(TransactionToken argTransToken, IPersistable argPersistable) {
/* 411 */     if (this.messageType_ == null) {
/* 412 */       this.messageType_ = MessageType.PERSIST;
/*     */     }
/*     */     
/* 415 */     if (!(argPersistable instanceof IDataAccessObject) && !(argPersistable instanceof QueryRequest)) {
/* 416 */       throw new DtxException("ServletPersistenceStrategy only supports persisting of IDataAccessObject's & QueryRequest's currently, not " + argPersistable
/*     */           
/* 418 */           .getClass().getName() + " This is a TODO and should be implemented.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 425 */     if (this.makePersistentTransactions_.get(argTransToken) == null) {
/* 426 */       this.makePersistentTransactions_.put(argTransToken, new ArrayList<>());
/*     */       
/* 428 */       DataSourceTransactionManager.getInstance().registerDataSource(argTransToken, (ITransactionalDataSource)this);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     List<IPersistable> transaction = this.makePersistentTransactions_.get(argTransToken);
/*     */     
/* 436 */     transaction.add(argPersistable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setOriginDataSource(Object argResultObject) {
/* 446 */     String dataSourceName = getDataSourceName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 451 */     boolean hasDataModels = argResultObject instanceof IDataModel;
/* 452 */     if (!hasDataModels && argResultObject instanceof java.util.Collection) {
/* 453 */       for (Object result : argResultObject) {
/* 454 */         if (result instanceof IDataModel) {
/* 455 */           hasDataModels = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 461 */     if (hasDataModels) {
/*     */       
/* 463 */       List<? extends IPersistable> persistables = DaoUtils.getPersistables(argResultObject);
/*     */       
/* 465 */       for (Iterator<? extends IPersistable> iter = persistables.iterator(); iter.hasNext(); ) {
/* 466 */         IPersistable nextPersistable = iter.next();
/* 467 */         if (nextPersistable instanceof IDataAccessObject) {
/* 468 */           ((IDataAccessObject)nextPersistable).setOriginDataSource(dataSourceName);
/*     */         }
/*     */         
/* 471 */         iter.remove();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     if (argResultObject instanceof IQueryResult) {
/* 479 */       ((IQueryResult)argResultObject).setDataSource(dataSourceName);
/*     */     }
/* 481 */     else if (argResultObject instanceof java.util.Collection) {
/* 482 */       for (Object result : argResultObject) {
/* 483 */         if (result instanceof IQueryResult) {
/* 484 */           ((IQueryResult)result).setDataSource(dataSourceName);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPersistenceDefaultsOnObject(Object argObject) {
/* 496 */     if (argObject instanceof IDataModelImpl) {
/* 497 */       IPersistenceDefaults persistenceDefaults = getPersistenceDefaults();
/* 498 */       EventManager eventManager = getEventManager();
/* 499 */       IDataModelImpl modelObject = (IDataModelImpl)argObject;
/* 500 */       modelObject.setDependencies(persistenceDefaults, eventManager);
/*     */     }
/* 502 */     else if (argObject instanceof java.util.Collection) {
/* 503 */       for (Object collectionObject : argObject) {
/* 504 */         setPersistenceDefaultsOnObject(collectionObject);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MakePersistentCommunicationType
/*     */   {
/* 519 */     TEXT,
/*     */ 
/*     */     
/* 522 */     BASE64,
/*     */ 
/*     */     
/* 525 */     GZIP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MakePersistentCommunicationType forName(String argName) {
/* 533 */       if ("TEXT".equals(argName)) {
/* 534 */         return TEXT;
/*     */       }
/* 536 */       if ("BASE64".equals(argName)) {
/* 537 */         return BASE64;
/*     */       }
/* 539 */       if ("GZIP".equals(argName)) {
/* 540 */         return GZIP;
/*     */       }
/* 542 */       throw new DtxException("Invalid value for MakePersistentCommType: " + argName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MessageType
/*     */   {
/* 552 */     NOT_SPECIFIED,
/*     */     
/* 554 */     LOOKUP,
/*     */     
/* 556 */     PERSIST,
/*     */     
/* 558 */     REPLICATE;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\remote\servlet\ServletPersistenceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */