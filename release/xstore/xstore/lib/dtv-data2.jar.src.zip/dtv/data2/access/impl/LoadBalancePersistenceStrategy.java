/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IDataModelRelationship;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.query.QueryToken;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.inject.Inject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalancePersistenceStrategy
/*     */   extends AbstractPersistenceStrategy
/*     */ {
/*  36 */   private static Map<String, LoadBalanceHistory> _preLoadedSettings = new HashMap<>(4);
/*     */ 
/*     */   
/*     */   private IPersistenceStrategy _impersonatedStrategy;
/*     */   
/*     */   private String _myDataSourceName;
/*     */   
/*     */   @Inject
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */ 
/*     */   
/*     */   public boolean checkExistence(IObjectId argId, QueryToken argQueryToken) {
/*  48 */     ensureOnline();
/*  49 */     return this._impersonatedStrategy.checkExistence(argId, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/*  55 */     if (this._impersonatedStrategy == null) {
/*  56 */       return this._myDataSourceName;
/*     */     }
/*     */     
/*  59 */     return this._impersonatedStrategy.getDataSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IDataModel getObjectById(IObjectId argId, QueryToken argQueryToken) {
/*  75 */     ensureOnline();
/*  76 */     return this._impersonatedStrategy.getObjectById(argId, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectByQuery(String argKey, Map<String, Object> argParams, QueryToken argQueryToken) {
/*  82 */     ensureOnline();
/*  83 */     return this._impersonatedStrategy.getObjectByQuery(argKey, argParams, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectByRelationship(IDataModelRelationship argRel, QueryToken argQueryToken) {
/*  89 */     ensureOnline();
/*  90 */     return this._impersonatedStrategy.getObjectByRelationship(argRel, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/*  99 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullGraphPersisted() {
/* 105 */     ensureOnline();
/* 106 */     return this._impersonatedStrategy.isFullGraphPersisted();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullGraphProvided() {
/* 112 */     ensureOnline();
/* 113 */     return this._impersonatedStrategy.isFullGraphProvided();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ping() {
/*     */     try {
/* 125 */       ensureOnline();
/* 126 */       return true;
/*     */     }
/* 128 */     catch (FailoverException ee) {
/* 129 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String argName) {
/* 136 */     this._myDataSourceName = argName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties argProps) {
/* 143 */     if (!_preLoadedSettings.containsKey(this._myDataSourceName)) {
/* 144 */       initLoadBalanceHistory(argProps);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     LoadBalanceHistory history = _preLoadedSettings.get(this._myDataSourceName);
/*     */     
/* 155 */     DataSourceDescriptor theChosenOne = null;
/* 156 */     int counter = 0;
/*     */     
/* 158 */     while (theChosenOne == null && counter++ < history.getValidDataSources().size()) {
/* 159 */       theChosenOne = history.getNextDataSource();
/*     */       
/* 161 */       boolean online = StatusMgr.getInstance().isOnline(theChosenOne.getName());
/*     */       
/* 163 */       if (online) {
/* 164 */         this
/* 165 */           ._impersonatedStrategy = this._persistenceStrategyFactory.createStrategy(theChosenOne, isOnlineStrategyType());
/*     */         
/*     */         break;
/*     */       } 
/* 169 */       theChosenOne = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void ensureOnline() {
/* 178 */     if (this._impersonatedStrategy == null) {
/* 179 */       throw FailoverException.getNewException("LoadBalancePersistenceStrategy is failing over because none of the strategies he is balancing are online.", this._myDataSourceName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initLoadBalanceHistory(Properties argProps) {
/* 191 */     if (argProps == null || argProps.isEmpty()) {
/* 192 */       throw new DtxException("No properties were found for datasource: " + this._myDataSourceName + " Check DataSourceConfig.xml");
/*     */     }
/*     */ 
/*     */     
/* 196 */     Collection<Object> datasourceNames = argProps.values();
/* 197 */     List<String> enabledDatasources = new ArrayList<>(5);
/*     */     
/* 199 */     for (Object dataSourceName : datasourceNames) {
/*     */       
/* 201 */       DataSourceDescriptor desc = DataSourceFactory.getInstance().getDataSourceDescriptor(dataSourceName.toString());
/*     */       
/* 203 */       if (desc.isEnabled()) {
/* 204 */         enabledDatasources.add(desc.getName());
/*     */       }
/*     */     } 
/*     */     
/* 208 */     LoadBalanceHistory history = new LoadBalanceHistory();
/* 209 */     history.setValidDataSources(enabledDatasources);
/* 210 */     _preLoadedSettings.put(this._myDataSourceName, history);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void makePersistentImpl(TransactionToken argTransToken, IPersistable argPersistable) {
/* 216 */     ensureOnline();
/* 217 */     this._impersonatedStrategy.makePersistent(argTransToken, argPersistable);
/*     */   }
/*     */   
/*     */   private static class LoadBalanceHistory {
/* 221 */     private final List<DataSourceDescriptor> validDataSources_ = new ArrayList<>(5);
/* 222 */     private int count_ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DataSourceDescriptor getNextDataSource() {
/* 230 */       DataSourceDescriptor datasource = this.validDataSources_.get(this.count_ % this.validDataSources_.size());
/* 231 */       this.count_++;
/* 232 */       if (this.count_ < 0) {
/* 233 */         this.count_ = 0;
/*     */       }
/* 235 */       return datasource;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<DataSourceDescriptor> getValidDataSources() {
/* 242 */       return this.validDataSources_;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValidDataSources(List<String> argValidDataSources) {
/* 249 */       for (String dataSourceName : argValidDataSources) {
/*     */         
/* 251 */         DataSourceDescriptor descriptor = DataSourceFactory.getInstance().getDataSourceDescriptor(dataSourceName);
/*     */         
/* 253 */         if (!this.validDataSources_.contains(descriptor))
/* 254 */           this.validDataSources_.add(descriptor); 
/*     */       } 
/*     */     }
/*     */     
/*     */     private LoadBalanceHistory() {}
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\LoadBalancePersistenceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */