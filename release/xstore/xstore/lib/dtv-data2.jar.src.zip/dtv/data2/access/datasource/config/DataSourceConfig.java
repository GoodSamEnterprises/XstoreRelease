/*    */ package dtv.data2.access.datasource.config;
/*    */ 
/*    */ import dtv.data2.access.config.common.PropertyConfig;
/*    */ import dtv.data2.access.config.common.PropertyConfigConverter;
/*    */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import dtv.util.config.IConfigObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String _dataSourceName;
/*    */   private String _persistenceStrategyName;
/* 28 */   private String _networkScope = "LAN";
/*    */   private IPing _ping;
/*    */   private boolean _highAvailability = false;
/*    */   private boolean _offlineVisible = true;
/*    */   private boolean _enabled = true;
/* 33 */   private final List<PropertyConfig> _properties = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSourceDescriptor getDataSource() {
/* 41 */     Properties props = new Properties();
/* 42 */     props = PropertyConfigConverter.convert(this._properties, props);
/*    */     
/* 44 */     return new DataSourceDescriptor(this._dataSourceName, getEnabled(), this._networkScope, this._persistenceStrategyName, props, this._ping, this._highAvailability, this._offlineVisible);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 51 */     if ("Name".equalsIgnoreCase(argKey)) {
/* 52 */       this._dataSourceName = argValue.toString();
/*    */     }
/* 54 */     else if ("Enabled".equalsIgnoreCase(argKey)) {
/* 55 */       this._enabled = ConfigUtils.toBoolean(argValue);
/*    */     }
/* 57 */     else if ("NetworkScope".equalsIgnoreCase(argKey)) {
/* 58 */       this._networkScope = argValue.toString();
/*    */     }
/* 60 */     else if ("HighAvailability".equalsIgnoreCase(argKey)) {
/* 61 */       this._highAvailability = ConfigUtils.toBoolean(argValue);
/*    */     }
/* 63 */     else if ("OfflineVisible".equalsIgnoreCase(argKey)) {
/* 64 */       this._offlineVisible = ConfigUtils.toBoolean(argValue);
/*    */     }
/* 66 */     else if ("Strategy".equalsIgnoreCase(argKey)) {
/* 67 */       this._persistenceStrategyName = argValue.toString();
/*    */     }
/* 69 */     else if ("Property".equalsIgnoreCase(argKey) && argValue instanceof PropertyConfig) {
/* 70 */       this._properties.add((PropertyConfig)argValue);
/*    */     }
/* 72 */     else if ("Ping".equalsIgnoreCase(argKey) && argValue instanceof PingConfig) {
/* 73 */       this._ping = ((PingConfig)argValue).getPing();
/*    */     } else {
/*    */       
/* 76 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     return (new ToStringBuilder(this)).append(this._dataSourceName).append(getSourceDescription()).toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getName() {
/* 92 */     return this._dataSourceName;
/*    */   }
/*    */   
/*    */   private boolean getEnabled() {
/* 96 */     return this._enabled;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\datasource\config\DataSourceConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */