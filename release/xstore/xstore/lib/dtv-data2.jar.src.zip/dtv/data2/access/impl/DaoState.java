/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DaoState
/*     */ {
/*  21 */   UNDEFINED(0, false, false, false),
/*     */   
/*  23 */   CLEAN(1, false, false, false),
/*     */   
/*  25 */   NEW("INSERT", 16, true, false, false)
/*     */   {
/*     */     protected void applyStateChangesImpl(IDataAccessObject argDao, String argUserId)
/*     */     {
/*  29 */       super.applyStateChangesImpl(argDao, argUserId);
/*  30 */       setCreateFields(argDao, true, argUserId);
/*     */     }
/*     */   },
/*     */   
/*  34 */   UPDATED("UPDATE", 256, false, true, false)
/*     */   {
/*     */     protected void applyStateChangesImpl(IDataAccessObject argDao, String argUserId)
/*     */     {
/*  38 */       super.applyStateChangesImpl(argDao, argUserId);
/*  39 */       setUpdateFields(argDao, false, argUserId);
/*     */     }
/*     */   },
/*     */   
/*  43 */   DELETED("DELETE", 4096, false, false, true),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   INSERT_ONLY(65536, true, false, false)
/*     */   {
/*     */     protected void applyStateChangesImpl(IDataAccessObject argDao, String argUserId)
/*     */     {
/*  52 */       super.applyStateChangesImpl(argDao, argUserId);
/*  53 */       setCreateFields(argDao, true, argUserId);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   INSERT_OR_UPDATE(1048576, true, true, false)
/*     */   {
/*     */     protected int getNewStateImpl(IDataAccessObject argDao, int argAssignedState)
/*     */     {
/*  64 */       int newState = super.getNewStateImpl(argDao, argAssignedState);
/*  65 */       int currentState = argDao.getObjectState();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  70 */       if (NEW.matches(currentState) || UPDATED.matches(currentState)) {
/*  71 */         newState |= currentState;
/*     */       }
/*  73 */       return newState;
/*     */     } };
/*     */   
/*     */   private final String _name;
/*     */   private final int _mask;
/*     */   private final boolean _isCreate;
/*     */   private final boolean _isUpdate;
/*     */   private final boolean _isDelete;
/*     */   private final boolean _isDirty;
/*     */   
/*     */   public static void applyStateChanges(IDataAccessObject argDao, String argUserId) {
/*  84 */     int newStateMask = argDao.getObjectState();
/*     */     
/*  86 */     for (DaoState state : valuesOf(newStateMask)) {
/*  87 */       state.applyStateChangesImpl(argDao, argUserId);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getNewState(IDataAccessObject argDao, int argAssignedState) {
/* 101 */     int newState = argAssignedState;
/*     */     
/* 103 */     for (DaoState state : valuesOf(argAssignedState)) {
/* 104 */       newState = state.getNewStateImpl(argDao, newState);
/*     */     }
/* 106 */     return newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getStateMask(String argStateString) {
/* 117 */     int stateMask = 0;
/* 118 */     String stateString = StringUtils.deleteWhitespace(argStateString);
/* 119 */     if (!stateString.startsWith("|")) {
/* 120 */       stateString = "|" + stateString;
/*     */     }
/* 122 */     if (!stateString.endsWith("|")) {
/* 123 */       stateString = stateString + "|";
/*     */     }
/*     */     
/* 126 */     for (DaoState state : values()) {
/* 127 */       if (StringUtils.containsIgnoreCase(stateString, "|" + state.nameInternal() + "|")) {
/* 128 */         stateMask |= state._mask;
/*     */       }
/*     */     } 
/* 131 */     return stateMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getStateString(int argStateMask) {
/* 141 */     StringBuilder stateString = new StringBuilder();
/*     */     
/* 143 */     for (DaoState state : valuesOf(argStateMask)) {
/* 144 */       stateString.append(state.nameInternal()).append("|");
/*     */     }
/* 146 */     String retVal = StringUtils.removeEnd(stateString.toString(), "|");
/*     */     
/* 148 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isClean(IDataAccessObject argDao) {
/* 158 */     return CLEAN.matches(argDao);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDeleted(IDataAccessObject argDao) {
/* 168 */     return DELETED.matches(argDao);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNew(IDataAccessObject argDao) {
/* 178 */     return NEW.matches(argDao);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUndefined(IDataAccessObject argDao) {
/* 189 */     boolean undefined = UNDEFINED.matches(argDao);
/* 190 */     if (!undefined) {
/* 191 */       undefined = UNDEFINED.equals(valuesOf(argDao.getObjectState()).iterator().next());
/*     */     }
/* 193 */     return undefined;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUpdated(IDataAccessObject argDao) {
/* 203 */     return UPDATED.matches(argDao);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setCreateFields(IDataAccessObject argDao, boolean argOnlyIfNull, String argUserId) {
/* 215 */     if (!argOnlyIfNull || argDao.getCreateUserId() == null) {
/* 216 */       argDao.setCreateUserId(argUserId);
/*     */     }
/* 218 */     if (!argOnlyIfNull || argDao.getCreateDate() == null) {
/* 219 */       argDao.setCreateDate((Date)DaoDateFactory.getInstance().newDate());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setUpdateFields(IDataAccessObject argDao, boolean argOnlyIfNull, String argUserId) {
/* 232 */     if (!argOnlyIfNull || argDao.getUpdateUserId() == null) {
/* 233 */       argDao.setUpdateUserId(argUserId);
/*     */     }
/* 235 */     if (!argOnlyIfNull || argDao.getUpdateDate() == null) {
/* 236 */       argDao.setUpdateDate((Date)DaoDateFactory.getInstance().newDate());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set<DaoState> valuesOf(int argStateMask) {
/* 248 */     Set<DaoState> states = new HashSet<>();
/*     */     
/* 250 */     for (DaoState state : values()) {
/* 251 */       if (state.matches(argStateMask)) {
/* 252 */         states.add(state);
/*     */       }
/*     */     } 
/* 255 */     return states.isEmpty() ? Collections.<DaoState>singleton(UNDEFINED) : states;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DaoState(String argName, int argMask, boolean argCreate, boolean argUpdate, boolean argDelete) {
/* 272 */     this._name = (argName == null) ? name() : argName;
/* 273 */     this._mask = argMask;
/* 274 */     this._isCreate = argCreate;
/* 275 */     this._isUpdate = argUpdate;
/* 276 */     this._isDelete = argDelete;
/* 277 */     this._isDirty = argCreate | argUpdate | argDelete;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int intVal() {
/* 285 */     return this._mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCreate() {
/* 295 */     return this._isCreate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDelete() {
/* 305 */     return this._isDelete;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirty() {
/* 316 */     return this._isDirty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUpdate() {
/* 326 */     return this._isUpdate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(IDataAccessObject argDao) {
/* 337 */     return matches(argDao.getObjectState());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyStateChangesImpl(IDataAccessObject argDao, String argUserId) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getNewStateImpl(IDataAccessObject argDao, int argAssignedState) {
/* 361 */     return argAssignedState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(int argStateMask) {
/* 372 */     return ((this._mask & argStateMask) > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private String nameInternal() {
/* 377 */     return this._name;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\DaoState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */