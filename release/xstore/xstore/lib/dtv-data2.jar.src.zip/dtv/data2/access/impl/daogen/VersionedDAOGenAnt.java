/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.FileUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ import org.apache.tools.ant.types.Resource;
/*     */ import org.apache.tools.ant.types.resources.FileResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionedDAOGenAnt
/*     */   extends Task
/*     */ {
/*     */   private FileSet _source;
/*     */   private File _destination;
/*     */   private String _version;
/*  34 */   private Map<DtxDefinition, String> _classNameCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private Map<String, DtxDefinition> _definitions = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConfiguredFileset(FileSet argSourceSet) {
/*  49 */     this._source = argSourceSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/*  56 */     if (this._source == null) {
/*  57 */       throw new BuildException("Source directory does not exist!");
/*     */     }
/*     */     
/*  60 */     if (this._destination == null) {
/*  61 */       throw new BuildException("Destination is not set!");
/*     */     }
/*  63 */     if (!this._destination.exists()) {
/*  64 */       throw new BuildException("Destination " + this._destination.getAbsolutePath() + " does not exist!");
/*     */     }
/*  66 */     if (!this._destination.isDirectory()) {
/*  67 */       throw new BuildException("Destination " + this._destination.getAbsolutePath() + " is not a directory!");
/*     */     }
/*     */     
/*     */     try {
/*  71 */       DAOParser parser = new DAOParser();
/*     */       
/*  73 */       for (Resource dtxResource : this._source) {
/*  74 */         FileResource dtxFileResource = (FileResource)dtxResource;
/*  75 */         File dtxFile = dtxFileResource.getFile();
/*     */         
/*  77 */         DtxDefinition dtx = parser.parse(dtxFile);
/*  78 */         this._definitions.put(dtx.getName(), dtx);
/*     */       } 
/*     */       
/*  81 */       for (DtxDefinition dtx : this._definitions.values()) {
/*  82 */         handleDtxDefinition(dtx);
/*     */       }
/*     */     }
/*  85 */     catch (BuildException e) {
/*  86 */       throw e;
/*     */     }
/*  88 */     catch (Exception e) {
/*  89 */       e.printStackTrace();
/*  90 */       throw new BuildException("Error happened during DAO generation:", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDestination(File argDestination) {
/* 100 */     this._destination = argDestination.getAbsoluteFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersion(String argVersion) {
/* 109 */     this._version = argVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateDaoField(Writer out, DtxDefinition.DtxDaoField field) throws IOException {
/* 122 */     String fieldVisibility = getClassFieldVisibility(field);
/* 123 */     String fieldType = getClassFieldType(field);
/* 124 */     String fieldName = getClassFieldName(field);
/* 125 */     out.append("  ").append(fieldVisibility).append(' ').append(fieldType).append(' ').append(fieldName);
/*     */     
/* 127 */     String fieldInitialValue = getClassFieldInitialValue(field);
/* 128 */     if (!fieldInitialValue.isEmpty()) {
/* 129 */       out.append(" = ").append(fieldInitialValue);
/*     */     }
/*     */     
/* 132 */     out.append(";\n");
/*     */ 
/*     */     
/* 135 */     DaoGenUtils.appendGetterForField(out, field);
/*     */ 
/*     */     
/* 138 */     DaoGenUtils.appendSetterForField(out, field, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateDaoFields(Writer out, DtxDefinition argDtx) throws IOException {
/* 150 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/* 151 */       generateDaoField(out, field);
/*     */     }
/*     */     
/* 154 */     out.append('\n');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateDaoFooter(Writer out, DtxDefinition argDtx) throws IOException {
/* 167 */     if (!argDtx.isExtended() && argDtx.getExtendsStringType() == null) {
/* 168 */       out.append("  public IObjectId getObjectId() {\n");
/* 169 */       String idType = getIdObjectClass(argDtx);
/* 170 */       out.append("    ").append(idType).append(" id = new ").append(idType).append("();\n");
/*     */       
/* 172 */       for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 173 */         out.append("    id.").append(getSetterName(field)).append("(this.").append(getGetterName(field))
/* 174 */           .append("());\n");
/*     */       }
/*     */       
/* 177 */       out.append("    return id;\n");
/* 178 */       out.append("  }\n\n");
/*     */       
/* 180 */       out.append("  public void setObjectId(IObjectId argObjectId) {\n");
/*     */       
/* 182 */       if ((argDtx.getPrimaryKeyFields()).length > 0) {
/* 183 */         for (DtxDefinition.DtxDaoField f : argDtx.getPrimaryKeyFields()) {
/* 184 */           String getterName = getGetterName(f);
/* 185 */           String setterName = getSetterName(f);
/* 186 */           out.append("    ").append(setterName).append("(((").append(idType).append(") argObjectId).")
/* 187 */             .append(getterName).append("());\n");
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 192 */         out.append(String.format("    // %s does not define a primary key.\n", new Object[] { getName(argDtx) }));
/*     */       } 
/*     */       
/* 195 */       out.append("  }\n\n");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     if (argDtx.isExtended()) {
/* 202 */       out.append("  @Override\n");
/*     */     }
/*     */     
/* 205 */     out.append("  public String toXmlString() {\n");
/* 206 */     int buffSize = 50 * (argDtx.getFields()).length;
/* 207 */     DtxDefinition parent = argDtx.getExtends();
/*     */     
/* 209 */     while (parent != null) {
/* 210 */       buffSize += 50 * (parent.getFields()).length;
/* 211 */       parent = parent.getExtends();
/*     */     } 
/*     */     
/* 214 */     out.append("    StringBuilder buf = new StringBuilder(").append(Integer.toString(buffSize))
/* 215 */       .append(");\n");
/* 216 */     out.append("    buf.append(\"<\").append(DAO_ELEMENT_NAME).append(\" name=\\\"").append(getName(argDtx))
/* 217 */       .append("\\\" cmd=\\\"\" + getObjectStateString() + \"\\\">\");\n");
/* 218 */     out.append("    getFieldsAsXml(buf);\n");
/* 219 */     out.append("    buf.append(\"</\").append(DAO_ELEMENT_NAME).append(\">\");\n\n");
/* 220 */     out.append("    return buf.toString();\n");
/* 221 */     out.append("  }\n");
/*     */ 
/*     */     
/* 224 */     out.append("  @Override\n");
/* 225 */     out.append("  public java.util.Map<String, String> getValues() {\n");
/* 226 */     out.append("    java.util.Map<String, String> values = super.getValues();\n");
/*     */     
/* 228 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/* 229 */       String fieldName = getClassFieldName(field);
/* 230 */       String publicName = getPublicFieldName(field);
/* 231 */       String xmlSafeFieldType = getXmlSafeFieldType(field);
/*     */       
/* 233 */       out.append("    if (").append(fieldName).append(" != null) values.put(").append(publicName)
/* 234 */         .append(", dtv.data2.access.DaoUtils.getXmlSafeFieldValue(").append(xmlSafeFieldType).append(", ")
/* 235 */         .append(fieldName).append("));\n");
/*     */     } 
/* 237 */     out.append("    return values;\n");
/* 238 */     out.append("  }\n\n");
/*     */     
/* 240 */     out.append("  @Override\n");
/* 241 */     out.append("  public void setValues(java.util.Map<String, String> argValues) {\n");
/* 242 */     out.append("    super.setValues(argValues);\n");
/*     */     
/* 244 */     out.append("    for (java.util.Map.Entry<String, String> valueEntry : argValues.entrySet()) {\n");
/*     */     
/* 246 */     out.append("      switch (valueEntry.getKey().hashCode()) {\n");
/*     */     
/* 248 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/* 249 */       String publicName = StringUtils.ensureFirstUpperCase(field.getName());
/* 250 */       out.append("        case ").append(Integer.toString(publicName.hashCode())).append(": { // ")
/* 251 */         .append(publicName).append('\n');
/* 252 */       out.append("          try {\n");
/* 253 */       out.append("            Object value = dtv.data2.access.DaoUtils.getFieldValueForXmlString(")
/* 254 */         .append(getXmlSafeFieldType(field)).append(", valueEntry.getValue());\n");
/* 255 */       out.append("            ").append(getSetterName(field)).append("(").append(makeCast(field))
/* 256 */         .append("value);\n");
/* 257 */       out.append("          } catch (Exception ee) {\n");
/* 258 */       out.append("            throw new dtv.data2.access.exception.DtxException(\"An exception occurred while calling ")
/*     */         
/* 260 */         .append(getSetterName(field))
/* 261 */         .append("() with \" + valueEntry.getValue() + \" on: \" + this + \" \" + ee.toString(), ee);\n");
/* 262 */       out.append("          }\n");
/* 263 */       out.append("          break;\n");
/* 264 */       out.append("        }\n");
/*     */     } 
/*     */     
/* 267 */     out.append("        default: break;\n");
/* 268 */     out.append("      }\n");
/* 269 */     out.append("    }\n");
/* 270 */     out.append("  }\n");
/* 271 */     out.append('}');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String generateDaoHeader(Writer out, DtxDefinition argDtx) throws IOException {
/* 284 */     String packageName = getDaoPackage(argDtx);
/* 285 */     out.append("package ").append(packageName).append(";\n\n");
/*     */     
/* 287 */     out.append("import java.util.Date;\n");
/* 288 */     out.append("import org.apache.log4j.Logger;\n");
/* 289 */     out.append("import dtv.data2.access.IObjectId;\n\n");
/*     */     
/* 291 */     String className = getDaoClassName(argDtx);
/* 292 */     out.append("public class ").append(className).append('\n');
/*     */     
/* 294 */     String baseClass = getBaseClass(argDtx);
/* 295 */     out.append("    extends ").append(baseClass);
/*     */     
/* 297 */     String interfaces = getInterfaces(argDtx);
/* 298 */     if (!interfaces.isEmpty()) {
/* 299 */       out.append("\n    implements ").append(interfaces);
/*     */     }
/*     */     
/* 302 */     out.append(" {\n\n");
/*     */     
/* 304 */     String serialVersionUID = String.valueOf(getName(argDtx).hashCode());
/* 305 */     out.append("  // Fix serialization compatability based on the name of the DAO\n");
/* 306 */     out.append("  private static final long serialVersionUID = ").append(serialVersionUID).append("L;\n");
/*     */     
/* 308 */     out.append("  private static final Logger logger_ = Logger.getLogger(")
/* 309 */       .append(className)
/* 310 */       .append(".class);\n\n");
/*     */     
/* 312 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateIdFields(Writer argWriter, DtxDefinition argDtx) throws IOException {
/* 324 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 325 */       if (!"organizationId".equals(field.getName())) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 330 */         String fieldVisibility = getClassFieldVisibility(field);
/* 331 */         String fieldType = getClassFieldType(field);
/* 332 */         String fieldName = getClassFieldName(field);
/* 333 */         argWriter.append("  ").append(fieldVisibility).append(' ').append(fieldType).append(' ')
/* 334 */           .append(fieldName);
/*     */         
/* 336 */         String fieldInitialValue = getClassFieldInitialValue(field);
/* 337 */         if (!fieldInitialValue.isEmpty()) {
/* 338 */           argWriter.append(" = ").append(fieldInitialValue);
/*     */         }
/*     */         
/* 341 */         argWriter.append(";\n");
/*     */ 
/*     */         
/* 344 */         String getterType = fieldType;
/* 345 */         String getterName = getGetterName(field);
/*     */         
/* 347 */         argWriter.append("  public ").append(getterType).append(' ').append(getterName).append("() {\n");
/* 348 */         argWriter.append("    return ").append(fieldName).append(";\n");
/* 349 */         argWriter.append("  }\n");
/*     */ 
/*     */         
/* 352 */         String setterName = getSetterName(field);
/* 353 */         String setterArgType = getSetterArgType(field);
/* 354 */         String setterArgName = getSetterArgName(field);
/*     */         
/* 356 */         argWriter.append("  public void ").append(setterName).append('(').append(setterArgType).append(' ')
/* 357 */           .append(setterArgName).append(") {\n");
/*     */         
/* 359 */         if ("Date".equalsIgnoreCase(field.getType())) {
/* 360 */           argWriter.append("      if (").append(setterArgName).append(" != null && !(").append(setterArgName)
/* 361 */             .append(" instanceof dtv.util.DtvDate)) {\n");
/* 362 */           argWriter.append("        ").append(setterArgName).append(" = new dtv.util.DtvDate(")
/* 363 */             .append(setterArgName).append(".getTime());\n");
/* 364 */           argWriter.append("      }\n");
/* 365 */           argWriter.append("      ").append(fieldName).append(" = (dtv.util.DtvDate) ").append(setterArgName)
/* 366 */             .append(";\n");
/*     */         } else {
/*     */           
/* 369 */           argWriter.append("      ").append(fieldName).append(" = ").append(setterArgName).append(";\n");
/*     */         } 
/*     */         
/* 372 */         argWriter.append("  }\n\n");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateIdFooter(Writer argWriter, DtxDefinition argDtx) throws IOException {
/* 387 */     argWriter.append("  @Override\n");
/* 388 */     argWriter.append("  public boolean validate() { return false; }\n\n");
/*     */ 
/*     */     
/* 391 */     String idName = getIdClassName(argDtx);
/* 392 */     argWriter.append("  @Override\n");
/* 393 */     argWriter.append("  public boolean equals(Object ob) {\n");
/* 394 */     argWriter.append("    if (this == ob) {\n");
/* 395 */     argWriter.append("      return true;\n");
/* 396 */     argWriter.append("    }\n");
/* 397 */     argWriter.append("    if (!(ob instanceof ").append(idName).append(")) {\n");
/* 398 */     argWriter.append("      return false;\n");
/* 399 */     argWriter.append("    }\n");
/* 400 */     argWriter.append("    ").append(idName).append(" other = (").append(idName).append(") ob;\n");
/* 401 */     argWriter.append("    return\n");
/*     */ 
/*     */     
/* 404 */     boolean first = true;
/* 405 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 406 */       if (first) {
/* 407 */         argWriter.append("           ");
/* 408 */         first = false;
/*     */       } else {
/*     */         
/* 411 */         argWriter.append("        && ");
/*     */       } 
/*     */       
/* 414 */       String fieldName = getClassFieldName(field);
/* 415 */       argWriter.append("java.util.Objects.equals(").append(fieldName).append(", other.").append(fieldName)
/* 416 */         .append(")\n");
/*     */     } 
/*     */     
/* 419 */     argWriter.append("          ;\n  }\n\n");
/*     */ 
/*     */     
/* 422 */     argWriter.append("  @Override\n");
/* 423 */     argWriter.append("  public int hashCode() {\n");
/* 424 */     argWriter.append("    return (\n");
/*     */     
/* 426 */     first = true;
/* 427 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 428 */       if (first) {
/* 429 */         argWriter.append("           ");
/* 430 */         first = false;
/*     */       } else {
/*     */         
/* 433 */         argWriter.append("         + ");
/*     */       } 
/*     */       
/* 436 */       String fieldName = getClassFieldName(field);
/* 437 */       argWriter.append("java.util.Objects.hashCode(").append(fieldName).append(")\n");
/*     */     } 
/*     */     
/* 440 */     argWriter.append("         );\n  }\n");
/*     */ 
/*     */     
/* 443 */     argWriter.append("  public void setValue(String argObjectIdValue) {\n");
/* 444 */     argWriter.append("    String str = argObjectIdValue;\n");
/* 445 */     argWriter.append("    if (dtv.util.StringUtils.isEmpty(str)) {\n");
/* 446 */     argWriter.append("      throw new dtv.data2.access.exception.DtxException(\"argument ")
/* 447 */       .append("passed to setValue() is null or empty - a valid value must be passed\");\n");
/* 448 */     argWriter.append("    }\n");
/*     */     
/* 450 */     argWriter.append("    try {\n");
/*     */     
/* 452 */     argWriter.append("      String[] tokens = str.split(\"::\");\n");
/*     */     
/* 454 */     int fieldIndex = 0;
/* 455 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/* 456 */       argWriter.append("      str = tokens[").append(Integer.toString(fieldIndex)).append("];\n\n");
/*     */       
/* 458 */       String fieldName = getClassFieldName(field);
/* 459 */       if (field.getType().equals("Date")) {
/* 460 */         argWriter.append("      if (\"null\".equals(str)) {\n");
/* 461 */         argWriter.append("        ").append(fieldName).append(" = null;\n");
/* 462 */         argWriter.append("      }\n");
/* 463 */         argWriter.append("      else {\n");
/* 464 */         argWriter.append("        ").append(fieldName).append(" = new dtv.util.DtvDate();\n");
/* 465 */         argWriter.append("        ").append(fieldName)
/* 466 */           .append(".setTimeFromSerialization(Long.parseLong(str));\n");
/* 467 */         argWriter.append("      }\n");
/*     */       }
/* 469 */       else if (field.getType().equals("Long")) {
/* 470 */         argWriter.append("      ").append(fieldName).append(" = java.lang.Long.valueOf(str);\n");
/*     */       }
/* 472 */       else if (field.getType().equals("Integer")) {
/* 473 */         argWriter.append("      ").append(fieldName).append(" = java.lang.Integer.valueOf(str);\n");
/*     */       }
/* 475 */       else if (field.getType().equals("BigDecimal")) {
/* 476 */         argWriter.append("      ").append(fieldName).append(" = new java.math.BigDecimal(str);\n");
/*     */       } else {
/*     */         
/* 479 */         argWriter.append("      if (\"null\".equals(str)) {\n");
/* 480 */         argWriter.append("        ").append(fieldName).append(" = null;\n");
/* 481 */         argWriter.append("      }\n");
/* 482 */         argWriter.append("      else {\n");
/* 483 */         argWriter.append("        ").append(fieldName).append(" = str;\n");
/* 484 */         argWriter.append("      }\n");
/*     */       } 
/*     */       
/* 487 */       fieldIndex++;
/*     */     } 
/*     */     
/* 490 */     argWriter.append("    }\n");
/* 491 */     argWriter.append("    catch (Exception ee) {\n");
/* 492 */     argWriter.append("      throw new dtv.data2.access.exception.DtxException(\"An exception occured while parsing object id string: \" + argObjectIdValue, ee);\n");
/*     */ 
/*     */     
/* 495 */     argWriter.append("    }\n");
/* 496 */     argWriter.append("  }\n");
/*     */ 
/*     */     
/* 499 */     argWriter.append("  public String getDtxTypeName() { return \"").append(getName(argDtx))
/* 500 */       .append("\"; }\n\n");
/*     */ 
/*     */     
/* 503 */     argWriter.append("}\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generateIdHeader(Writer argWriter, DtxDefinition argDtx) throws IOException {
/* 515 */     argWriter.append("package ").append(getIdPackage(argDtx)).append(";\n\n");
/*     */     
/* 517 */     DtxDefinition.DtxDaoField[] primaryKeyFields = argDtx.getPrimaryKeyFields();
/*     */     
/* 519 */     for (DtxDefinition.DtxDaoField primaryKeyField : primaryKeyFields) {
/* 520 */       if (primaryKeyField.getType().equals("Date")) {
/* 521 */         argWriter.append("import java.util.Date;\n");
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 526 */     for (DtxDefinition.DtxDaoField primaryKeyField : primaryKeyFields) {
/* 527 */       if (primaryKeyField.getType().equals("BigDecimal")) {
/* 528 */         argWriter.append("import java.math.BigDecimal;\n");
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 533 */     argWriter.append("import dtv.util.common.CommonConstants;\n\n");
/*     */     
/* 535 */     argWriter.append("public class ").append(getIdObjectType(argDtx));
/* 536 */     argWriter.append("\n    extends dtv.data2.access.AbstractObjectId {\n\n");
/*     */     
/* 538 */     argWriter.append("  // Fix serialization compatability based on the name of the DAO\n");
/* 539 */     argWriter.append("  private static final long serialVersionUID = ");
/* 540 */     argWriter.append(String.valueOf(getName(argDtx).hashCode()));
/* 541 */     argWriter.append("L;\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getBaseClass(DtxDefinition argDtx) {
/* 551 */     if (!StringUtils.isEmpty(argDtx.getExtendsStringType())) {
/* 552 */       DtxDefinition baseDtx = this._definitions.get(argDtx.getExtendsStringType());
/* 553 */       return getDaoPackage(baseDtx) + '.' + getDaoClassName(baseDtx);
/*     */     } 
/*     */     
/* 556 */     return "dtv.data2.access.impl.AbstractDAOImpl";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getClassFieldInitialValue(DtxDefinition.DtxDaoField argField) {
/* 566 */     if ("Boolean".equals(argField.getType()))
/*     */     {
/*     */       
/* 569 */       return "Boolean.FALSE";
/*     */     }
/*     */     
/* 572 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getClassFieldName(DtxDefinition.DtxDaoField argField) {
/* 582 */     return DaoGenUtils.getFieldNameForField(argField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getClassFieldType(DtxDefinition.DtxDaoField argField) {
/* 592 */     return DaoGenUtils.getConcreteDataType(argField.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getClassFieldVisibility(DtxDefinition.DtxDaoField argField) {
/* 602 */     return "private";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDaoClass(DtxDefinition argDtx) {
/* 612 */     return getDaoPackage(argDtx) + '.' + getName(argDtx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDaoClassName(DtxDefinition argDtx) {
/* 622 */     return this._classNameCache.computeIfAbsent(argDtx, k -> getName(k) + "DAO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDaoFilePath(DtxDefinition argDtx) {
/* 632 */     String className = getDaoPackage(argDtx) + '.' + getDaoClassName(argDtx);
/* 633 */     String classFile = className.replace('.', File.separatorChar) + ".java";
/* 634 */     return classFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDaoPackage(DtxDefinition argDtx) {
/* 644 */     return this._version + '.' + argDtx.getPackage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFieldName(DtxDefinition.DtxDaoField argField) {
/* 654 */     return argField.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getGetterName(DtxDefinition.DtxDaoField argField) {
/* 664 */     return DaoGenUtils.getGetterNameForField(argField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getGetterType(DtxDefinition.DtxDaoField argField) {
/* 674 */     return DaoGenUtils.getRawDataType(argField.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIdClassFieldType(DtxDefinition.DtxDaoField argField) {
/* 684 */     return DaoGenUtils.getRawDataType(argField.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIdClassName(DtxDefinition argDtx) {
/* 694 */     return this._version + '.' + argDtx.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIdFilePath(DtxDefinition argDtx) {
/* 704 */     String className = getIdClassName(argDtx);
/* 705 */     String classFile = className.replace('.', File.separatorChar) + ".java";
/* 706 */     return classFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIdObjectClass(DtxDefinition argDtx) {
/* 716 */     return this._version + '.' + argDtx.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIdObjectType(DtxDefinition argDtx) {
/* 726 */     return argDtx.getIdType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIdPackage(DtxDefinition argDtx) {
/* 736 */     return this._version + '.' + argDtx.getInterfacePackage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getInterfaces(DtxDefinition argDtx) {
/* 747 */     boolean hasConfigElementField = Arrays.<DtxDefinition.DtxDaoField>stream(argDtx.getFieldsPlusInheritedPrimaryKeys()).anyMatch(DaoGenConfigElementHelper::isConfigElementField);
/* 748 */     if (hasConfigElementField) {
/* 749 */       return "dtv.data2.access.IHasConfigElement";
/*     */     }
/*     */     
/* 752 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getName(DtxDefinition argDtx) {
/* 762 */     return argDtx.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPublicFieldName(DtxDefinition.DtxDaoField argField) {
/* 772 */     return "\"" + StringUtils.ensureFirstUpperCase(argField.getName()) + "\"";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSetterArgName(DtxDefinition.DtxDaoField argField) {
/* 782 */     return DaoGenUtils.getArgNameForField(argField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSetterArgType(DtxDefinition.DtxDaoField argField) {
/* 792 */     return getGetterType(argField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSetterName(DtxDefinition.DtxDaoField argField) {
/* 802 */     return DaoGenUtils.getSetterNameForField(argField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getXmlSafeFieldType(DtxDefinition.DtxDaoField argField) {
/* 812 */     return Integer.toString(DaoGenUtils.getTypeForField(argField));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleDtxDefinition(DtxDefinition argDtx) {
/* 821 */     File daoFile = new File(this._destination, getDaoFilePath(argDtx));
/* 822 */     daoFile.getParentFile().mkdirs();
/*     */     
/* 824 */     try (Writer writer = FileUtils.getFileWriter(daoFile)) {
/* 825 */       generateDaoHeader(writer, argDtx);
/* 826 */       generateDaoFields(writer, argDtx);
/* 827 */       generateDaoFooter(writer, argDtx);
/*     */     }
/* 829 */     catch (IOException e) {
/* 830 */       e.printStackTrace();
/* 831 */       throw new BuildException("Couldn't write to file: " + daoFile, e);
/*     */     } 
/*     */     
/* 834 */     if (!argDtx.isExtended() && (argDtx.getPrimaryKeyFields()).length > 0) {
/* 835 */       File idFile = new File(this._destination, getIdFilePath(argDtx));
/* 836 */       idFile.getParentFile().mkdirs();
/*     */       
/* 838 */       try (Writer writer = FileUtils.getFileWriter(idFile)) {
/* 839 */         generateIdHeader(writer, argDtx);
/* 840 */         generateIdFields(writer, argDtx);
/* 841 */         generateIdFooter(writer, argDtx);
/*     */       }
/* 843 */       catch (IOException e) {
/* 844 */         e.printStackTrace();
/* 845 */         throw new BuildException("Couldn't write to file: " + idFile, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String makeCast(DtxDefinition.DtxDaoField field) {
/* 857 */     String type = DaoGenUtils.getRawDataType(field.getType());
/* 858 */     if ("Object".equals(type)) {
/* 859 */       return "";
/*     */     }
/* 861 */     return '(' + type + ')';
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\VersionedDAOGenAnt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */