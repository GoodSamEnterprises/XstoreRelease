/*    */ package dtv.data2.access.impl.config;
/*    */ 
/*    */ import dtv.util.config.AbstractParentConfig;
/*    */ import dtv.util.config.ConfigUtils;
/*    */ import dtv.util.config.IConfigObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PmTypeMappingConfig
/*    */   extends AbstractParentConfig
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   static final String MAIN_TAG = "PmTypeMapping";
/*    */   private static final String ID_CLASS_TAG = "ObjectId";
/*    */   private static final String PM_TYPE_TAG = "PmType";
/*    */   private static final String LOAD_PROPERTIES_TAG = "LoadProperties";
/*    */   private String idClass_;
/*    */   private String pmType_;
/* 28 */   private Boolean loadProperties_ = Boolean.FALSE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getIdClass() {
/* 36 */     return this.idClass_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPmType() {
/* 45 */     return this.pmType_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Boolean isLoadPropertiesEnabled() {
/* 54 */     return this.loadProperties_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigObject(String argKey, IConfigObject argValue) {
/* 60 */     if ("ObjectId".equalsIgnoreCase(argKey)) {
/* 61 */       this.idClass_ = argValue.toString();
/*    */     }
/* 63 */     else if ("PmType".equalsIgnoreCase(argKey)) {
/* 64 */       this.pmType_ = argValue.toString();
/*    */     }
/* 66 */     else if ("LoadProperties".equalsIgnoreCase(argKey)) {
/* 67 */       this.loadProperties_ = Boolean.valueOf(ConfigUtils.toBoolean(argValue));
/*    */     } else {
/*    */       
/* 70 */       warnUnsupported(argKey, argValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\config\PmTypeMappingConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */