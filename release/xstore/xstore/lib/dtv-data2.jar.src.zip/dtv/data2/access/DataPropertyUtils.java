/*     */ package dtv.data2.access;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataPropertyUtils
/*     */ {
/*  21 */   private static final Logger _logger = Logger.getLogger(DataPropertyUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getPropertyValue(IHasDataProperty<?> argParent, String argCode) {
/*  32 */     IDataProperty prop = (IDataProperty)argParent.getProperty(argCode);
/*  33 */     return (prop == null) ? null : prop.getPropertyValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPropertyValueType(Object argValue) {
/*  44 */     String valueType = null;
/*     */     
/*  46 */     if (argValue instanceof Boolean) {
/*  47 */       valueType = "BOOLEAN";
/*     */     }
/*  49 */     else if (argValue instanceof Date) {
/*  50 */       valueType = "DATE";
/*     */     }
/*  52 */     else if (argValue instanceof BigDecimal) {
/*  53 */       valueType = "BIGDECIMAL";
/*     */     }
/*  55 */     else if (argValue instanceof String) {
/*  56 */       valueType = "STRING";
/*     */     } 
/*  58 */     return valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPropertyValue(IHasDataProperty<?> argParent, String argCode, Object argValue) {
/*  70 */     IDataProperty prop = (IDataProperty)argParent.getProperty(argCode);
/*     */     
/*  72 */     if (prop != null) {
/*  73 */       prop.setPropertyValue(argValue);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  79 */       String valueType = getPropertyValueType(argValue);
/*     */       
/*  81 */       if ("BOOLEAN".equalsIgnoreCase(valueType)) {
/*  82 */         argParent.setBooleanProperty(argCode, ((Boolean)argValue).booleanValue());
/*     */       }
/*  84 */       else if ("DATE".equalsIgnoreCase(valueType)) {
/*  85 */         argParent.setDateProperty(argCode, (Date)argValue);
/*     */       }
/*  87 */       else if ("BIGDECIMAL".equalsIgnoreCase(valueType)) {
/*  88 */         argParent.setDecimalProperty(argCode, (BigDecimal)argValue);
/*     */       }
/*  90 */       else if ("STRING".equalsIgnoreCase(valueType)) {
/*  91 */         argParent.setStringProperty(argCode, (String)argValue);
/*     */       }
/*  93 */       else if (argValue != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  98 */         _logger.warn("[" + argValue + "] is not of a supported type to assign to model [" + argParent + "].  Converting the value to a string and assigning it as such,  though the calling client should be performing this conversion explicitly.");
/*     */ 
/*     */ 
/*     */         
/* 102 */         argParent.setStringProperty(argCode, argValue.toString());
/* 103 */         valueType = "STRING";
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\DataPropertyUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */