/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import com.google.common.primitives.Primitives;
/*     */ import dtv.data2.access.IGenericQueryResult;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryResultHelper
/*     */ {
/*  29 */   private static final Logger logger_ = Logger.getLogger(QueryResultHelper.class);
/*     */ 
/*     */ 
/*     */   
/*  33 */   private static final QueryResultHelper INSTANCE = new QueryResultHelper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QueryResultHelper getInstance() {
/*  42 */     return INSTANCE;
/*     */   }
/*     */   
/*  45 */   private final ConcurrentHashMap<Class<?>, DataMapping> classMappings_ = new ConcurrentHashMap<>(16, 1.0F, 
/*  46 */       Runtime.getRuntime().availableProcessors());
/*     */   
/*  48 */   private final String PUT_METHOD = "put";
/*     */   
/*  50 */   private final String SETTER_PREFIX = "set";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method findCompatibleMethodForType(Class<?> argClass, String argMethodName, Class<?> argTypeClass) {
/*  65 */     for (Class<?> searchClass = argClass; searchClass != null; searchClass = searchClass.getSuperclass()) {
/*  66 */       for (Method method : searchClass.getDeclaredMethods()) {
/*  67 */         if (method.getName().equals(argMethodName) && (method.getParameterTypes()).length == 1 && (
/*  68 */           ClassUtils.isAssignable(method.getParameterTypes()[0], argTypeClass) || (method
/*  69 */           .getParameterTypes()[0].isArray() && argTypeClass.isArray() && 
/*  70 */           ClassUtils.isAssignable(method.getParameterTypes()[0].getComponentType(), argTypeClass
/*  71 */             .getComponentType())))) {
/*  72 */           return method;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method findMethodAssignableToType(Class<?> argClass, String argMethodName, Class<?> argType) {
/*  91 */     for (Class<?> searchClass = argClass; searchClass != null; searchClass = searchClass.getSuperclass()) {
/*  92 */       for (Method method : searchClass.getDeclaredMethods()) {
/*  93 */         if (method.getName().equals(argMethodName) && (method.getParameterTypes()).length == 1 && 
/*  94 */           ClassUtils.isAssignable(argType, method.getParameterTypes()[0])) {
/*  95 */           return method;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataMapping getMapping(Class<?> argResultClass) {
/* 110 */     DataMapping mapping = this.classMappings_.get(argResultClass);
/* 111 */     if (mapping == null) {
/* 112 */       DataMapping newMapping = new DataMapping(argResultClass);
/* 113 */       DataMapping existingMapping = this.classMappings_.putIfAbsent(argResultClass, newMapping);
/* 114 */       mapping = (existingMapping != null) ? existingMapping : newMapping;
/*     */     } 
/* 116 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getMethodForClass(Class<?> argResultClass, String argFieldName, Object argMethodParameter) {
/* 129 */     String methodName = "set" + argFieldName;
/* 130 */     Object methodParameter = argMethodParameter;
/* 131 */     Class<?> methodParameterClass = methodParameter.getClass();
/*     */ 
/*     */     
/* 134 */     Method modelMethod = getMethodForNameAndType(argResultClass, methodName, new Class[] { methodParameterClass });
/*     */ 
/*     */     
/* 137 */     if (modelMethod == null && methodParameter instanceof dtv.util.DtvDate) {
/* 138 */       modelMethod = getMethodForNameAndType(argResultClass, methodName, new Class[] { Date.class });
/*     */     }
/*     */ 
/*     */     
/* 142 */     if (modelMethod == null && Primitives.isWrapperType(methodParameterClass))
/*     */     {
/* 144 */       modelMethod = getMethodForNameAndType(argResultClass, methodName, new Class[] { Primitives.unwrap(methodParameterClass) });
/*     */     }
/*     */ 
/*     */     
/* 148 */     if (modelMethod == null && methodParameter instanceof Number && !(methodParameter instanceof BigDecimal))
/*     */     {
/* 150 */       modelMethod = getMethodForNameAndType(argResultClass, methodName, new Class[] { BigDecimal.class });
/*     */     }
/*     */ 
/*     */     
/* 154 */     if (modelMethod == null && ClassUtils.isPrimitiveWrapperArray(methodParameterClass)) {
/* 155 */       modelMethod = getMethodForNameAndType(argResultClass, methodName, new Class[] {
/* 156 */             Array.newInstance(Primitives.unwrap(methodParameterClass.getComponentType()), 0).getClass()
/*     */           });
/*     */     }
/*     */     
/* 160 */     if (modelMethod == null && ClassUtils.isPrimitiveArray(methodParameterClass)) {
/* 161 */       modelMethod = getMethodForNameAndType(argResultClass, methodName, new Class[] {
/* 162 */             Array.newInstance(Primitives.wrap(methodParameterClass.getComponentType()), 0).getClass()
/*     */           });
/*     */     }
/*     */ 
/*     */     
/* 167 */     if (modelMethod == null) {
/* 168 */       modelMethod = findCompatibleMethodForType(argResultClass, methodName, methodParameterClass);
/*     */     }
/*     */ 
/*     */     
/* 172 */     if (modelMethod == null && methodParameter instanceof Number) {
/* 173 */       modelMethod = findMethodAssignableToType(argResultClass, methodName, Number.class);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (modelMethod == null && methodParameter instanceof Number) {
/* 179 */       modelMethod = findMethodAssignableToType(argResultClass, methodName, Boolean.class);
/*     */     }
/*     */ 
/*     */     
/* 183 */     if (modelMethod == null && (IGenericQueryResult.class.isAssignableFrom(argResultClass) || Map.class
/* 184 */       .isAssignableFrom(argResultClass)))
/*     */     {
/* 186 */       modelMethod = getMethodForNameAndType(argResultClass, "put", new Class[] { Object.class, Object.class });
/*     */     }
/*     */ 
/*     */     
/* 190 */     if (logger_.isDebugEnabled() && modelMethod != null) {
/* 191 */       logger_.debug("Associated method [" + modelMethod.toString() + "] with query criteria [ResultObject: " + argResultClass + " QueryFieldName: " + argFieldName + " ValueObject: " + argMethodParameter + "]");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     if (modelMethod == null) {
/* 198 */       throw new DtxException("Could not find a method on " + argResultClass.getName() + "meeting query criteria [ResultObject: " + argResultClass + " QueryFieldName: " + argFieldName + " ValueObject: " + argMethodParameter + "]");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 203 */     return modelMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getMethodForNameAndType(Class<?> argClass, String argMethodName, Class<?>... argMethodParameter) {
/* 217 */     for (Class<?> searchClass = argClass; searchClass != null; searchClass = searchClass.getSuperclass()) {
/*     */       try {
/* 219 */         return searchClass.getDeclaredMethod(argMethodName, argMethodParameter);
/*     */       }
/* 221 */       catch (NoSuchMethodException e) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class DataMapping
/*     */   {
/*     */     private final Class<?> modelClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     private final ConcurrentHashMap<String, Method> fieldMappings = new ConcurrentHashMap<>(8, 1.0F, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DataMapping(Class<?> argResultClass) {
/* 250 */       this.modelClass = argResultClass;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getExistingSetterForField(String argFieldName) {
/* 260 */       return this.fieldMappings.get(argFieldName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getSetterForField(String argFieldName, Object argParameter) {
/* 271 */       Method mappingMethod = getExistingSetterForField(argFieldName);
/* 272 */       if (mappingMethod == null) {
/* 273 */         Method newMethod = QueryResultHelper.INSTANCE.getMethodForClass(this.modelClass, argFieldName, argParameter);
/* 274 */         Method existingMethod = this.fieldMappings.putIfAbsent(argFieldName, newMethod);
/* 275 */         mappingMethod = (existingMethod != null) ? existingMethod : newMethod;
/*     */       } 
/* 277 */       return mappingMethod;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getSetterParameterTypeAsString(String argFieldName) {
/* 287 */       Method setterMethod = getExistingSetterForField(argFieldName);
/* 288 */       if (setterMethod != null) {
/* 289 */         if ((setterMethod.getParameterTypes()).length == 2) {
/* 290 */           return setterMethod.getParameterTypes()[1].getSimpleName();
/*     */         }
/*     */         
/* 293 */         return setterMethod.getParameterTypes()[0].getSimpleName();
/*     */       } 
/*     */       
/* 296 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryResultHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */