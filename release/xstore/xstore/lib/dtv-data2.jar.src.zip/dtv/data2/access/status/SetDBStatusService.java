/*    */ package dtv.data2.access.status;
/*    */ 
/*    */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*    */ import dtv.data2.access.datasource.DataSourceFactory;
/*    */ import dtv.data2.access.exception.FailoverException;
/*    */ import dtv.data2.access.exception.ForcedOfflineException;
/*    */ import dtv.ipc.server.IIpcService;
/*    */ import dtv.ipc.server.IpcRequest;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetDBStatusService
/*    */   implements IIpcService
/*    */ {
/*    */   public Map<String, String> invoke(IpcRequest argRequest) {
/* 29 */     StatusMgr statusMgr = StatusMgr.getInstance();
/* 30 */     String dataSourceName = (String)argRequest.getParams().get("dataSourceName");
/*    */ 
/*    */     
/* 33 */     DataSourceDescriptor dataSourceDescriptor = DataSourceFactory.getInstance().getDataSourceDescriptor(dataSourceName);
/*    */     
/* 35 */     if (argRequest.getMethod().equals("forceDataSourceOffline")) {
/* 36 */       dataSourceDescriptor.setForcedOffline(true);
/* 37 */       statusMgr.notifyOffline(dataSourceName, 
/* 38 */           (FailoverException)ForcedOfflineException.getNewException("Forced offline by Xenvironment", dataSourceName));
/*    */     }
/* 40 */     else if (argRequest.getMethod().equals("forceDataSourceOnline")) {
/* 41 */       dataSourceDescriptor.setForcedOffline(false);
/* 42 */       statusMgr.notifyOnline(dataSourceName);
/*    */     } 
/*    */     
/* 45 */     return new HashMap<>();
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\status\SetDBStatusService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */