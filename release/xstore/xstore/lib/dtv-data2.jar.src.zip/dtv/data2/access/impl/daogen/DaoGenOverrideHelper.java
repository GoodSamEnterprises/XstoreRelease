/*    */ package dtv.data2.access.impl.daogen;
/*    */ 
/*    */ import dtv.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DaoGenOverrideHelper
/*    */   extends DaoGenHelper
/*    */ {
/*    */   public void optionalValidate() {}
/*    */   
/*    */   public void setupRelationships() {
/* 34 */     for (DtxDefinition dtxDefinition : this.dtxDefinitions_) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 40 */       String parentType = dtxDefinition.getExtendsStringType();
/* 41 */       if (!StringUtils.isEmpty(parentType)) {
/* 42 */         DtxDefinition parent = this.typeNameToDefinition_.get(parentType);
/*    */         
/* 44 */         if (parent == null) {
/* 45 */           parent = new DtxDefinition();
/*    */ 
/*    */           
/* 48 */           String parentPackage = parentType.substring(0, parentType.lastIndexOf('.'));
/* 49 */           String parentClassName = parentType.substring(parentType.lastIndexOf('.') + 1, parentType.length());
/* 50 */           parent.setName(parentClassName);
/* 51 */           parent.setPackage(parentPackage);
/* 52 */           parent.setPlaceHolder(true);
/*    */         } 
/*    */         
/* 55 */         dtxDefinition.setExtends(parent);
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 62 */       DtxInverseRelationship[] inverseRelationships = dtxDefinition.getInverseRelationships();
/* 63 */       for (DtxInverseRelationship ir : inverseRelationships) {
/*    */         
/* 65 */         DtxDefinition dtxParent = this.typeNameToDefinition_.get(ir.getParentType());
/*    */         
/* 67 */         if (dtxParent == null) {
/* 68 */           throw new RuntimeException("Could not find parent: " + ir.getParentType() + " for inverse relationship: " + ir
/* 69 */               .getName() + "\nfor dtx: " + dtxDefinition.getName());
/*    */         }
/*    */         
/* 72 */         ir.setParent(dtxParent);
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 79 */       for (DtxRelationship relationship : dtxDefinition.getRelationships()) {
/*    */         
/* 81 */         DtxDefinition child = this.typeNameToDefinition_.get(relationship.getChildName());
/*    */         
/* 83 */         if (child == null) {
/* 84 */           throw new RuntimeException("Unknown child type: " + relationship.getChildName() + " on relationship: " + relationship
/* 85 */               .getName() + " in dtx: " + dtxDefinition
/* 86 */               .getSourceDtxFile().getAbsolutePath());
/*    */         }
/*    */         
/* 89 */         relationship.setChild(child);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DaoGenOverrideHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */