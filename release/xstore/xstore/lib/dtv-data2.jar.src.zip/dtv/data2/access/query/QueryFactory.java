/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.config.query.QueryConfigHelper;
/*     */ import dtv.data2.access.config.query.QueryDescriptor;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryFactory
/*     */ {
/*  25 */   private static final Logger logger_ = Logger.getLogger(QueryFactory.class);
/*     */ 
/*     */   
/*     */   private Map<String, QueryDescriptor> descriptorIdx_;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private ISqlQueryDecorator _queryDecorator;
/*     */   
/*     */   @Inject
/*     */   private IQueryHandlerFactory _queryHandlerFactory;
/*     */ 
/*     */   
/*     */   protected QueryFactory() {
/*  39 */     QueryConfigHelper configHelper = new QueryConfigHelper();
/*  40 */     configHelper.initialize();
/*     */     
/*  42 */     this.descriptorIdx_ = configHelper.getQueryDescriptorMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryDescriptor getQueryDescriptor(String argQueryKey) {
/*  52 */     QueryDescriptor queryDescriptor = this.descriptorIdx_.get(argQueryKey);
/*  53 */     if (queryDescriptor == null) {
/*  54 */       logger_.warn("No query found for '" + argQueryKey + "'");
/*     */     }
/*  56 */     else if (logger_.isInfoEnabled()) {
/*  57 */       logger_.info("Using query '" + argQueryKey + "' from " + queryDescriptor.getSourceDescription());
/*     */     } 
/*  59 */     return queryDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IQueryHandler getQueryHandler(String argKey) {
/*  72 */     if (StringUtils.isEmpty(argKey)) {
/*  73 */       throw new DtxException("Cannot load query definition because argQueryKey was NULL or empty");
/*     */     }
/*     */     
/*  76 */     QueryDescriptor descriptor = getQueryDescriptor(argKey);
/*     */     
/*  78 */     if (descriptor == null) {
/*  79 */       throw new DtxException("Could not find query definition for given query key: " + argKey + ". Check QueryConfig.xml or related");
/*     */     }
/*     */ 
/*     */     
/*  83 */     if (descriptor.getQueryHandler() == null) {
/*  84 */       throw new DtxException("There is no query handler class associated with key " + argKey + ". Check QueryConfig.xml or related");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     IQueryHandler handler = null;
/*     */     try {
/*  93 */       handler = this._queryHandlerFactory.getQueryHandler(descriptor.getQueryHandler().getName());
/*  94 */       handler.setQueryDecorator(this._queryDecorator);
/*     */     }
/*  96 */     catch (Exception ex) {
/*  97 */       String msg = "Exception occurred while loading query handler: " + descriptor.getQueryHandler().getName() + ". Associated query key: " + argKey;
/*     */       
/*  99 */       logger_.error(msg, ex);
/* 100 */       throw new DtxException(msg, ex);
/*     */     } 
/*     */     
/* 103 */     Properties props = descriptor.getProperties();
/* 104 */     props.setProperty("Name", argKey);
/*     */     
/* 106 */     handler.setProperties(props);
/* 107 */     handler.setSourceDescription(descriptor.getSourceDescription());
/* 108 */     return handler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reinitialize() {
/* 115 */     QueryConfigHelper configHelper = new QueryConfigHelper();
/* 116 */     configHelper.initialize();
/*     */     
/* 118 */     this.descriptorIdx_ = configHelper.getQueryDescriptorMap();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */