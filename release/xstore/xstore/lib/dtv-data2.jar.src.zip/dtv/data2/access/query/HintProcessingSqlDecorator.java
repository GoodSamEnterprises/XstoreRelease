/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.ArrayUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HintProcessingSqlDecorator
/*     */   implements ISqlQueryDecorator
/*     */ {
/*  23 */   private static final Logger _logger = LogManager.getLogger(HintProcessingSqlDecorator.class);
/*     */   
/*     */   private static final String DEFAULT_HINT_BEGIN = "/*";
/*     */   
/*     */   private static final String DEFAULT_HINT_END = "*/";
/*     */   
/*  29 */   private static final char[] NON_ALPHANUMERIC_ID_CHARS = new char[] { '.', '_', '?', '#', '$' };
/*     */ 
/*     */   
/*     */   private final Map<String, String> _patterns;
/*     */ 
/*     */   
/*     */   private final String _hintEnd;
/*     */   
/*     */   private final String _hintBegin;
/*     */ 
/*     */   
/*     */   public HintProcessingSqlDecorator(Map<String, String> argPatterns) {
/*  41 */     this(argPatterns, "/*", "*/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HintProcessingSqlDecorator(Map<String, String> argPatterns, String argHintBegin, String argHintEnd) {
/*  52 */     this._patterns = argPatterns;
/*  53 */     this._hintBegin = argHintBegin;
/*  54 */     this._hintEnd = argHintEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decorateSql(String argSqlStatement, IPersistenceStrategy argTargetStrategy, IObjectId argObjId) {
/*  61 */     return replaceHints(argSqlStatement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decorateSql(String argSqlStatement, IPersistenceStrategy argTargetStrategy, Map<String, Object> argParams) {
/*  68 */     return replaceHints(argSqlStatement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected char getEnclosingChar(char argChar) {
/*  77 */     switch (argChar) {
/*     */       case '(':
/*  79 */         return ')';
/*     */     } 
/*  81 */     return argChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] getTargetBounds(CharSequence argChars, int argStartSeq) {
/*  95 */     int begin = -1;
/*     */     
/*  97 */     int end = argChars.length();
/*     */     
/*  99 */     StringBuilder seekStack = new StringBuilder();
/* 100 */     for (int i = argStartSeq; i < argChars.length(); i++) {
/* 101 */       char currentChar = argChars.charAt(i);
/*     */ 
/*     */       
/* 104 */       if (begin == -1) {
/* 105 */         if (Character.isWhitespace(currentChar)) {
/*     */           continue;
/*     */         }
/*     */         
/* 109 */         begin = i;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 114 */       boolean isQuote = isQuote(currentChar);
/* 115 */       boolean isOpeningParenthese = isOpeningParenthese(currentChar);
/* 116 */       if (seekStack.length() > 0 || isQuote || isOpeningParenthese) {
/* 117 */         char nextExpectedColsure = (seekStack.length() == 0) ? '0' : seekStack.charAt(seekStack.length() - 1);
/* 118 */         if (isOpeningParenthese || (isQuote && nextExpectedColsure != currentChar))
/*     */         {
/* 120 */           seekStack.append(getEnclosingChar(currentChar));
/*     */         }
/* 122 */         else if (nextExpectedColsure == currentChar)
/*     */         {
/* 124 */           seekStack.deleteCharAt(seekStack.length() - 1);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 131 */       else if (!isIdentifierCharacter(currentChar)) {
/* 132 */         end = i;
/*     */         break;
/*     */       } 
/*     */       continue;
/*     */     } 
/* 137 */     (new int[2])[0] = begin; (new int[2])[1] = end; return (begin == -1 || seekStack.length() > 0) ? null : new int[2];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isIdentifierCharacter(char argChar) {
/* 146 */     if (Character.isLetterOrDigit(argChar) || ArrayUtils.contains(NON_ALPHANUMERIC_ID_CHARS, argChar)) {
/* 147 */       return true;
/*     */     }
/* 149 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOpeningParenthese(char argChar) {
/* 158 */     if (argChar == '(') {
/* 159 */       return true;
/*     */     }
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isQuote(char argChar) {
/* 170 */     if (argChar == '\'' || argChar == '"') {
/* 171 */       return true;
/*     */     }
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String replaceHints(String argInput) {
/* 183 */     int searchIndex = 0;
/* 184 */     StringBuilder queryString = new StringBuilder(argInput);
/* 185 */     boolean replacementsMade = false;
/* 186 */     while (searchIndex < queryString.length() && (
/* 187 */       searchIndex = queryString.indexOf(this._hintBegin, searchIndex)) != -1) {
/*     */       
/* 189 */       int commentStartIndex = searchIndex;
/* 190 */       int commentContentStartIndex = commentStartIndex + this._hintBegin.length();
/* 191 */       int commentContentEndIndex = queryString.indexOf(this._hintEnd, commentContentStartIndex);
/* 192 */       int commentEndIndex = commentContentEndIndex + this._hintEnd.length();
/*     */ 
/*     */       
/* 195 */       boolean replacementMade = false;
/* 196 */       if (commentContentEndIndex != -1) {
/*     */         
/* 198 */         String hint = queryString.substring(commentContentStartIndex, commentContentEndIndex).trim();
/* 199 */         _logger.debug("Found hint [{}] in Query [{}]", hint, argInput);
/*     */ 
/*     */         
/* 202 */         String pattern = this._patterns.get(hint);
/* 203 */         if (pattern != null) {
/*     */ 
/*     */           
/* 206 */           int[] bounds = getTargetBounds(queryString, commentEndIndex);
/* 207 */           if (bounds != null) {
/* 208 */             String content = queryString.substring(bounds[0], bounds[1]);
/* 209 */             queryString.replace(bounds[0], bounds[1], String.format(pattern, new Object[] { content }));
/* 210 */             queryString.delete(commentStartIndex, commentEndIndex);
/* 211 */             replacementMade = true;
/*     */           } else {
/*     */             
/* 214 */             _logger.warn("Could not find substitution target following pattern[{}] in Query [{}]", hint, argInput);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 219 */           _logger.debug("Could not find substitution sequence for hint pattern [{}] in Query [{}]", hint, argInput);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 224 */         _logger.warn("Could not find end of comment sequence in Query [{}]", argInput);
/*     */       } 
/*     */ 
/*     */       
/* 228 */       if (!replacementMade) {
/* 229 */         searchIndex++;
/*     */         continue;
/*     */       } 
/* 232 */       replacementsMade = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 237 */     return replacementsMade ? queryString.toString() : argInput;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\HintProcessingSqlDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */