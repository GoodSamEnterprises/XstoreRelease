/*     */ package dtv.data2.access.impl.jdbc;
/*     */ import dtv.data2.SQLExceptionScrubber;
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.data2.access.IDataModel;
/*     */ import dtv.data2.access.IDataModelRelationship;
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.QueryResultList;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.exception.PrimaryKeyViolationException;
/*     */ import dtv.data2.access.exception.RetryException;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.IRelationshipAdapter;
/*     */ import dtv.data2.access.query.IQueryHandler;
/*     */ import dtv.data2.access.query.QueryToken;
/*     */ import dtv.data2.access.transaction.TransactionToken;
/*     */ import dtv.event.EventManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class JDBCPersistenceStrategy extends AbstractJDBCPersistenceStrategy {
/*  34 */   private static final Logger _logger = Logger.getLogger(JDBCPersistenceStrategy.class);
/*  35 */   private static final boolean _debugLogging = _logger.isDebugEnabled();
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */   
/*     */   @Inject
/*     */   private ISqlQueryDecorator _queryDecorator;
/*     */   
/*     */   @Inject
/*     */   private EventManager _eventManager;
/*     */ 
/*     */   
/*     */   public boolean checkExistence(IObjectId argId, QueryToken argQueryToken) {
/*  49 */     Object result = getObjectById(argId, argQueryToken);
/*  50 */     return (result != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IDataModel> getModelsByQuery(String argSql, List<?> argParams, Class<?> argTemplate, int argMaxRecords, QueryToken argQueryToken) {
/*  68 */     DBConnection conn = JDBCDataSourceMgr.getInstance().getQueryConnection(getDataSourceName(), argQueryToken);
/*  69 */     try (PreparedStatement statement = conn.prepareStatement(argSql)) {
/*  70 */       statement.setMaxRows(argMaxRecords);
/*     */       
/*  72 */       if (argParams != null && !argParams.isEmpty()) {
/*  73 */         for (int i = 0; i < argParams.size(); i++) {
/*  74 */           Object parm = argParams.get(i);
/*     */           
/*  76 */           if (parm == null) {
/*  77 */             throw new DtxException("Null parameter detected for query.  We do not support null parameters for queries. Params given: " + argParams);
/*     */           }
/*     */           
/*  80 */           if (parm instanceof Timestamp) {
/*  81 */             statement.setTimestamp(i + 1, (Timestamp)parm);
/*     */           } else {
/*     */             
/*  84 */             statement.setObject(i + 1, parm);
/*     */           } 
/*     */         } 
/*     */       }
/*  88 */       statement.execute();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  94 */     catch (Exception ex) {
/*     */       try {
/*  96 */         conn.setInvalid();
/*     */       }
/*  98 */       catch (Throwable ex1) {
/*  99 */         _logger.warn("CAUGHT EXCEPTION while marking connection invalid", ex1);
/*     */       } 
/*     */       
/* 102 */       if (FailoverException.isFailover(ex)) {
/* 103 */         throw FailoverException.getNewException(ex, getDataSourceName());
/*     */       }
/*     */       
/* 106 */       String msg = "getModelsByQuery() exception CAUGHT on datasource " + getDataSourceName() + " Class template: " + argTemplate + " executing sql: " + argSql + " params: " + argParams;
/*     */ 
/*     */       
/* 109 */       if (ex instanceof SQLException) {
/* 110 */         SQLException sqlEx = SQLExceptionScrubber.scrub((SQLException)ex);
/* 111 */         JDBCHelper.logSqlException(msg, sqlEx);
/* 112 */         throw new JDBCException(sqlEx);
/*     */       } 
/*     */       
/* 115 */       _logger.error(msg, ex);
/*     */       
/* 117 */       if (ex instanceof DtxException) {
/* 118 */         throw (DtxException)ex;
/*     */       }
/*     */       
/* 121 */       throw new DtxException(msg, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IDataModel> getModelsByQuery(String argSql, List<?> argParams, Class<?> argTemplate, QueryToken argQueryToken) {
/* 141 */     return getModelsByQuery(argSql, argParams, argTemplate, 0, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IDataModel getObjectById(IObjectId argId, QueryToken argQueryToken) {
/* 147 */     IJDBCTableAdapter adapter = getTableAdapter(argId);
/*     */ 
/*     */     
/* 150 */     String sqlToDecorate = adapter.getSelect() + adapter.getSelectWhere();
/* 151 */     String stmt = this._queryDecorator.decorateSql(sqlToDecorate, (IPersistenceStrategy)this, argId);
/*     */     
/* 153 */     if (_debugLogging) {
/* 154 */       _logger.debug("Getting object by id with the following statement: " + stmt + " ((" + argId
/* 155 */           .toString() + "))");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 160 */     DBConnection conn = JDBCDataSourceMgr.getInstance().getQueryConnection(getDataSourceName(), argQueryToken); try {
/* 161 */       List<IDataModel> list; PreparedStatement statement = adapter.writeObjectId(argId, conn.prepareStatement(stmt)); Throwable throwable = null; 
/* 162 */       try { List<IDataModel> models; statement.execute();
/*     */         
/* 164 */         try (ResultSet resultSet = statement.getResultSet()) {
/* 165 */           models = getModelsByResultSet(resultSet, conn, argId.getClass(), stmt);
/*     */         } 
/* 167 */         return (models == null || models.isEmpty()) ? null : models.get(0); } catch (Throwable models) { list = models = null; throw models; }
/* 168 */       finally { if (statement != null) if (list != null) { try { statement.close(); } catch (Throwable throwable1) { list.addSuppressed(throwable1); }  } else { statement.close(); }
/*     */             }
/*     */     
/* 171 */     } catch (Exception ex) {
/* 172 */       if (FailoverException.isFailover(ex)) {
/* 173 */         throw FailoverException.getNewException(ex, getDataSourceName());
/*     */       }
/*     */ 
/*     */       
/* 177 */       String msg = "getObjectById() exception CAUGHT on datasource " + getDataSourceName() + " while looking up id type: " + argId.getClass().getName() + " value: " + argId;
/*     */       
/* 179 */       if (ex instanceof SQLException) {
/* 180 */         SQLException sqlEx = SQLExceptionScrubber.scrub((SQLException)ex);
/* 181 */         JDBCHelper.logSqlException(msg, sqlEx);
/* 182 */         throw new JDBCException(sqlEx);
/*     */       } 
/*     */       
/* 185 */       _logger.error(msg, ex);
/* 186 */       throw new DtxException(msg, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectByQuery(String argQueryKey, Map<String, Object> argParams, QueryToken argQueryToken) {
/* 197 */     IQueryHandler handler = DataFactory.getInstance().getQueryHandler(argQueryKey);
/*     */     try {
/* 199 */       return handler.execute((IPersistenceStrategy)this, argParams, argQueryToken);
/*     */     }
/* 201 */     catch (Exception ex) {
/* 202 */       if (FailoverException.isFailover(ex)) {
/* 203 */         throw FailoverException.getNewException(ex, getDataSourceName());
/*     */       }
/*     */       
/* 206 */       String msg = "getObjectByQuery() exception CAUGHT on datasource " + getDataSourceName() + " while executing query key: " + argQueryKey + " with params: (" + argParams + ")";
/*     */ 
/*     */       
/* 209 */       if (ex instanceof SQLException) {
/* 210 */         SQLException sqlEx = SQLExceptionScrubber.scrub((SQLException)ex);
/* 211 */         JDBCHelper.logSqlException(msg, sqlEx);
/* 212 */         throw new JDBCException(msg, sqlEx);
/*     */       } 
/*     */       
/* 215 */       _logger.error(msg, ex);
/*     */       
/* 217 */       if (ex instanceof DtxException) {
/* 218 */         throw (DtxException)ex;
/*     */       }
/*     */       
/* 221 */       throw new DtxException(msg, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectByRelationship(IDataModelRelationship argRelationship, QueryToken argQueryToken) {
/* 231 */     IDataModelImpl parent = (IDataModelImpl)argRelationship.getParent();
/*     */ 
/*     */ 
/*     */     
/* 235 */     IRelationshipAdapter adapter = AdapterMap.getRelationshipAdapter(parent.getDAO().getClass(), argRelationship.getIdentifier());
/* 236 */     IJDBCRelationshipAdapter jdbcAdapter = null;
/*     */     
/* 238 */     if (adapter == null) {
/* 239 */       throw new DtxException("Could not load relationship: " + argRelationship.getIdentifier() + " for DAO: " + parent
/* 240 */           .getDAO().getClass() + " check associated .dtx's.");
/*     */     }
/* 242 */     if (!(adapter instanceof IJDBCRelationshipAdapter)) {
/* 243 */       throw new DtxException("The AdapterMap produced an adapter that was NOT compatiable with with JDBC for relationship: [" + argRelationship
/* 244 */           .getIdentifier() + "] and DAO: [" + parent
/* 245 */           .getDAO().getClass() + "] Adapter: [" + adapter + "]");
/*     */     }
/*     */     
/* 248 */     jdbcAdapter = (IJDBCRelationshipAdapter)adapter;
/*     */ 
/*     */     
/* 251 */     jdbcAdapter.setParent(parent.getDAO());
/*     */ 
/*     */     
/* 254 */     List<?> parms = jdbcAdapter.getParameterList();
/* 255 */     Iterator<?> it = parms.iterator();
/* 256 */     while (it.hasNext()) {
/* 257 */       if (it.next() == null) {
/* 258 */         return null;
/*     */       }
/*     */     } 
/*     */     
/* 262 */     String callString = jdbcAdapter.getSelect();
/*     */     
/* 264 */     if (jdbcAdapter.isOrgHierarchyJoinRequired())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       callString = this._queryDecorator.decorateSql(jdbcAdapter.getSelect(), (IPersistenceStrategy)this, (IObjectId)null);
/*     */     }
/*     */ 
/*     */     
/* 275 */     List<IDataModel> models = getModelsByQuery(callString, parms, argRelationship.getChild(), argQueryToken);
/*     */     
/* 277 */     if (models != null && IDataModelRelationship.RelationshipType.ONE_TO_ONE
/* 278 */       .equals(argRelationship.getType())) {
/* 279 */       return models.get(0);
/*     */     }
/*     */     
/* 282 */     return models;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullGraphPersisted() {
/* 289 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullGraphProvided() {
/* 295 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void detectUpdateNotEffective(PreparedStatement argStatement, String argSql, List<Object> argParams, IPersistable argPersistable) throws SQLException {
/* 313 */     if (argPersistable instanceof IDataAccessObject) {
/* 314 */       IDataAccessObject argDAO = (IDataAccessObject)argPersistable;
/*     */       
/* 316 */       if ((DaoState.isUpdated(argDAO) || DaoState.INSERT_OR_UPDATE.matches(argDAO)) && argStatement.getUpdateCount() == 0) {
/* 317 */         throw new UpdateNotEffectiveException("Update count was zero while persisting dao: [" + argDAO
/* 318 */             .getClass().getName() + "] id: " + argDAO.getObjectId() + " sql statement: " + 
/* 319 */             PreparedStatementTranslator.getPrettySql(argSql, argParams), getDataSourceName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<IDataModel> getModelsByResultSet(ResultSet argResultSet, DBConnection argConn, Class<?> argTemplate, String argSqlQuery) throws SQLException {
/* 338 */     if (argResultSet == null) {
/* 339 */       throw new DtxException("The result set was unexpectedly NULL for a successful query - this is unexpected jdbc behavior. Class template: [" + argTemplate
/*     */           
/* 341 */           .getName() + "] sql executed: " + argSqlQuery);
/*     */     }
/*     */     
/* 344 */     QueryResultList<IDataModel> results = new QueryResultList(IDataModel.class);
/* 345 */     while (argResultSet.next()) {
/* 346 */       IJDBCTableAdapter adapter = getTableAdapter(argTemplate);
/* 347 */       adapter.getFiller().fill(argResultSet);
/* 348 */       results.add(loadHierarchy(adapter, argConn));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 353 */     if (_debugLogging) {
/* 354 */       boolean warnings = JDBCHelper.handleWarnings(argSqlQuery, argResultSet.getWarnings());
/* 355 */       if (warnings) {
/* 356 */         argResultSet.clearWarnings();
/*     */       }
/*     */     } 
/* 359 */     return results.isEmpty() ? null : (List<IDataModel>)results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPersistable handlePersistenceException(Exception argException, IPersistable argPersistable, String argCurrentSql, List<Object> argCurrentParams) {
/*     */     String msg;
/* 379 */     if (RetryException.isRetryException(argException)) {
/* 380 */       if (_debugLogging) {
/* 381 */         _logger.debug("handlePersistenceException determined this to be a retry exception, throwing a retry. Original exception: " + argException);
/*     */       }
/*     */ 
/*     */       
/* 385 */       throw RetryException.getNewException(argException, getDataSourceName());
/*     */     } 
/*     */ 
/*     */     
/* 389 */     if (FailoverException.isFailover(argException)) {
/* 390 */       if (_debugLogging) {
/* 391 */         _logger.debug("handlePersistenceException determined this to be a failover exception, throwing a failover. Original exception: " + argException);
/*     */       }
/*     */ 
/*     */       
/* 395 */       throw FailoverException.getNewException(argException, getDataSourceName());
/*     */     } 
/*     */ 
/*     */     
/* 399 */     if (argException instanceof UpdateNotEffectiveException)
/*     */     {
/* 401 */       return (IPersistable)handleUpdateNotEffectiveException(argPersistable, argException);
/*     */     }
/*     */ 
/*     */     
/* 405 */     if (PrimaryKeyViolationException.isPrimaryKeyViolation(argException)) {
/*     */       
/* 407 */       if (argPersistable instanceof IDataAccessObject) {
/* 408 */         IDataAccessObject dao = (IDataAccessObject)argPersistable;
/*     */ 
/*     */         
/* 411 */         if (DaoState.INSERT_ONLY.matches(dao)) {
/* 412 */           if (_debugLogging) {
/* 413 */             _logger.debug("A PK violation was detected when processing INSERT_ONLY DAO " + argPersistable
/* 414 */                 .toString() + ". This record already exists and will not be persisted.");
/*     */           }
/*     */           
/* 417 */           IDataAccessObject daoClone = DaoUtils.cloneDao(dao);
/* 418 */           daoClone.setPersistenceDefaults(this._persistenceDefaults);
/* 419 */           daoClone.setObjectState(DaoState.CLEAN.intVal());
/* 420 */           daoClone.setObjectStateRulesApplied(true);
/* 421 */           return (IPersistable)daoClone;
/*     */         } 
/*     */ 
/*     */         
/* 425 */         if (DaoState.INSERT_OR_UPDATE.matches(dao) && !dao.isObjectStateRulesApplied()) {
/* 426 */           if (_debugLogging) {
/* 427 */             _logger.debug("Primary key error attempting to insert DAO, updating instead: key=[" + dao
/* 428 */                 .getObjectId() + "]");
/*     */           }
/*     */ 
/*     */           
/* 432 */           IDataAccessObject daoClone = DaoUtils.cloneDao(dao);
/* 433 */           daoClone.setPersistenceDefaults(this._persistenceDefaults);
/* 434 */           daoClone.setObjectState(DaoState.UPDATED.intVal());
/* 435 */           daoClone.setObjectStateRulesApplied(true);
/* 436 */           return (IPersistable)daoClone;
/*     */         } 
/*     */ 
/*     */         
/* 440 */         if (DaoConversionHelper.isDaoConvertOnPkViolation(dao) && DaoState.isNew(dao)) {
/* 441 */           _logger.warn("Primary key error attempting to insert DAO, updating instead: key=[" + dao
/* 442 */               .getObjectId() + "]");
/*     */ 
/*     */           
/* 445 */           IDataAccessObject daoClone = DaoUtils.cloneDao(dao);
/* 446 */           daoClone.setPersistenceDefaults(this._persistenceDefaults);
/* 447 */           daoClone.setObjectState(DaoState.UPDATED.intVal());
/* 448 */           daoClone.setObjectStateRulesApplied(true);
/* 449 */           return (IPersistable)daoClone;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 455 */       PrimaryKeyViolationException ex = PrimaryKeyViolationException.getNewException(argException, getDataSourceName());
/* 456 */       ex.setOffendingDao((IDataAccessObject)argPersistable);
/* 457 */       throw ex;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     if (argPersistable instanceof IDataAccessObject) {
/* 464 */       IDataAccessObject dao = (IDataAccessObject)argPersistable;
/*     */ 
/*     */       
/* 467 */       msg = "makePersistent() exception caught trying to persist dao of type [" + dao.getClass().getName() + "] with id: " + dao.getObjectId().getClass().getName() + " id value: " + dao.getObjectId() + " on datasource: " + getDataSourceName() + ". Statement: " + argCurrentSql + " Params: " + argCurrentParams;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 472 */       msg = "makePersistent() exception caught trying to persist persistable of type [" + argPersistable.getClass().getName() + "] on datasource: " + getDataSourceName() + ". Statement: " + argCurrentSql + " Params: " + argCurrentParams;
/*     */     } 
/*     */ 
/*     */     
/* 476 */     if (argException instanceof SQLException) {
/* 477 */       SQLException sqlEx = SQLExceptionScrubber.scrub((SQLException)argException);
/* 478 */       JDBCHelper.logSqlException(msg, sqlEx);
/* 479 */       throw new JDBCException(msg, sqlEx);
/*     */     } 
/*     */     
/* 482 */     _logger.error(msg, argException);
/* 483 */     throw new DtxException(msg, argException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDataAccessObject handleUpdateNotEffectiveException(IPersistable argPersistable, Exception argException) {
/* 497 */     if (argPersistable instanceof IDataAccessObject && DaoState.INSERT_OR_UPDATE
/* 498 */       .matches((IDataAccessObject)argPersistable) && 
/* 499 */       !((IDataAccessObject)argPersistable).isObjectStateRulesApplied()) {
/*     */       
/* 501 */       IDataAccessObject daoClone = DaoUtils.cloneDao((IDataAccessObject)argPersistable);
/* 502 */       daoClone.setPersistenceDefaults(this._persistenceDefaults);
/* 503 */       daoClone.setObjectStateRulesApplied(true);
/* 504 */       return daoClone;
/*     */     } 
/*     */     
/* 507 */     _logger.warn("An update was run against datasource: [" + getDataSourceName() + "] that had no effect: " + argException);
/*     */ 
/*     */     
/* 510 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDataModel loadHierarchy(IJDBCTableAdapter argDBAAdapter, DBConnection argConn) throws SQLException {
/* 527 */     IJDBCTableAdapter dbaAdapter = argDBAAdapter;
/* 528 */     IObjectId objectId = dbaAdapter.getObjectId();
/*     */ 
/*     */     
/* 531 */     if (dbaAdapter.isExtensible()) {
/* 532 */       String classNameRoot = dbaAdapter.getImplementingClass();
/* 533 */       String className = classNameRoot + "DBA";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 540 */       if (!className.equals(dbaAdapter.getClass().getName())) {
/* 541 */         IJDBCTableAdapter originalAdapter = dbaAdapter;
/*     */         
/* 543 */         if (_debugLogging) {
/* 544 */           _logger.debug("Getting DBA implementation of " + dbaAdapter.getImplementingClass() + " from " + dbaAdapter
/* 545 */               .getClass().getName());
/*     */         }
/*     */         
/*     */         try {
/* 549 */           dbaAdapter = (IExtendedJDBCAdapter)Class.forName(className).newInstance();
/*     */         }
/* 551 */         catch (Exception ee) {
/* 552 */           handleBadDtxClassName(dbaAdapter, classNameRoot, className, ee);
/*     */         } 
/*     */         
/* 555 */         IExtendedJDBCAdapter subclass = (IExtendedJDBCAdapter)dbaAdapter;
/*     */ 
/*     */         
/*     */         try {
/* 559 */           subclass.fill(originalAdapter);
/*     */         }
/* 561 */         catch (ClassCastException ee) {
/* 562 */           throw new DtxException("A failure occurred while calling fill on [" + subclass.getClass().getName() + "] with [" + dbaAdapter
/* 563 */               .getClass().getName() + "]  check dtv_class_name field - it's probably invalid.", ee);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 569 */     if (dbaAdapter instanceof IExtendedJDBCAdapter) {
/* 570 */       IExtendedJDBCAdapter subclass = (IExtendedJDBCAdapter)dbaAdapter;
/*     */       
/* 572 */       String[] selects = subclass.getAllSelects();
/* 573 */       IFiller[] fillers = subclass.getAllFillers();
/*     */       
/* 575 */       for (int i = 0; i < selects.length; i++) {
/* 576 */         String sql = selects[i] + dbaAdapter.getSelectWhere();
/* 577 */         sql = this._queryDecorator.decorateSql(sql, (IPersistenceStrategy)this, objectId);
/*     */         
/* 579 */         try (PreparedStatement statement = subclass.writeObjectId(objectId, argConn.prepareStatement(sql))) {
/* 580 */           statement.execute();
/* 581 */           try (ResultSet resultSet = statement.getResultSet()) {
/*     */             
/* 583 */             if (resultSet.next()) {
/* 584 */               fillers[i].fill(resultSet);
/*     */             } else {
/*     */               
/* 587 */               _logger.warn("Unable to load a level in the hierarchy. This object will likely be incompletely loaded. SQL failed: " + sql + " object ID type: " + objectId
/*     */                   
/* 589 */                   .getDtxTypeName() + " object ID value: " + objectId);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 597 */     if (dbaAdapter == null) {
/* 598 */       return null;
/*     */     }
/* 600 */     IDataAccessObject dao = dbaAdapter.loadDefaultDAO();
/* 601 */     IDataModelImpl model = DataModelFactory.getModelForDAO(dao);
/*     */     
/* 603 */     dao.setOriginDataSource(getDataSourceName());
/* 604 */     model.setDAO(dao);
/* 605 */     model.setDependencies(this._persistenceDefaults, this._eventManager);
/* 606 */     return (IDataModel)model;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void makePersistentImpl(TransactionToken argTransToken, IPersistable argPersistable) {
/* 612 */     List<JDBCCall> jdbcCalls = getJDBCCallData(argPersistable);
/*     */     
/* 614 */     if (jdbcCalls == null) {
/*     */       return;
/*     */     }
/*     */     
/* 618 */     JDBCCall currentCall = null;
/*     */ 
/*     */     
/* 621 */     DBConnection conn = JDBCDataSourceMgr.getInstance().getConnection(argTransToken, getDataSourceName());
/* 622 */     Savepoint segmentRollbackSavepoint = null;
/*     */ 
/*     */     
/*     */     try {
/* 626 */       if (jdbcCalls.size() > 1) {
/* 627 */         segmentRollbackSavepoint = conn.setSavepoint();
/*     */       }
/*     */ 
/*     */       
/* 631 */       for (JDBCCall jdbcCall : jdbcCalls) {
/* 632 */         currentCall = jdbcCall;
/* 633 */         try (PreparedStatement statement = conn.prepareStatement(jdbcCall.getSqlString())) {
/* 634 */           JDBCHelper.assignParameters(statement, jdbcCall.getParams(), jdbcCall.getTypes());
/* 635 */           statement.execute();
/*     */ 
/*     */           
/* 638 */           detectUpdateNotEffective(statement, jdbcCall.getSqlString(), jdbcCall.getParams(), argPersistable);
/*     */ 
/*     */ 
/*     */           
/* 642 */           if (_debugLogging)
/*     */           {
/* 644 */             boolean warnings = JDBCHelper.handleWarnings(jdbcCall.getSqlString(), statement.getWarnings());
/* 645 */             if (warnings) {
/* 646 */               statement.clearWarnings();
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } 
/* 653 */     } catch (Exception ex) {
/* 654 */       String sql = (currentCall != null) ? currentCall.getSqlString() : null;
/* 655 */       List<Object> params = (currentCall != null) ? currentCall.getParams() : null;
/* 656 */       IPersistable result = handlePersistenceException(ex, argPersistable, sql, params);
/*     */       
/* 658 */       if (result == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 666 */         if (segmentRollbackSavepoint != null) {
/* 667 */           conn.rollback(segmentRollbackSavepoint);
/*     */         }
/*     */       }
/* 670 */       catch (SQLException e) {
/* 671 */         _logger.warn("An error occurred while rolling back to a savepoint.", e);
/*     */       } 
/*     */ 
/*     */       
/* 675 */       makePersistent(argTransToken, result);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleBadDtxClassName(IJDBCTableAdapter argAdapter, String argClassNameRoot, String argClassName, Exception argEx) {
/* 693 */     if (StringUtils.isEmpty(argClassNameRoot)) {
/* 694 */       throw new DtxException("Class name field is not set for a row on table: \"" + argAdapter.getTableName() + "\" (or parent table) - see \"dtv_class_name\" field, probably");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 703 */     throw new DtxException("Failed to instantiate: " + argClassName + ".  There may be a problem with the class name field on table: " + argAdapter
/* 704 */         .getTableName(), argEx);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JDBCPersistenceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */