/*    */ package dtv.data2.access.pm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PmOperationInfo
/*    */ {
/*    */   private boolean offlineDatasourceFound_ = false;
/*    */   
/*    */   public boolean isOfflineDatasourceFound() {
/* 22 */     return this.offlineDatasourceFound_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOfflineDatasourceFound() {
/* 29 */     this.offlineDatasourceFound_ = true;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PmOperationInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */