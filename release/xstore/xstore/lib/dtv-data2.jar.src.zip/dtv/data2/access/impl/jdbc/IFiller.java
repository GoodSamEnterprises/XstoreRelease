package dtv.data2.access.impl.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface IFiller {
  void fill(ResultSet paramResultSet) throws SQLException;
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\IFiller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */