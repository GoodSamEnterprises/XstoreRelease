/*    */ package dtv.data2.access;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistablesPackage
/*    */ {
/*    */   private final List<IPersistable> _persistables;
/*    */   private final Integer _clientTimeout;
/*    */   
/*    */   PersistablesPackage(List<IPersistable> argPersistables, Integer argClientTimeout) {
/* 25 */     this._persistables = argPersistables;
/* 26 */     this._clientTimeout = argClientTimeout;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Integer getClientTimeout() {
/* 35 */     return this._clientTimeout;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<IPersistable> getPersistables() {
/* 44 */     return this._persistables;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\PersistablesPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */