/*     */ package dtv.data2.access;
/*     */ 
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ import org.apache.commons.lang3.builder.ToStringStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataPropertyAccessor<T extends IHasDataProperty<? extends IDataProperty>, VT>
/*     */ {
/*     */   private final String key_;
/*     */   private final Class<T> parentType_;
/*     */   
/*     */   public AbstractDataPropertyAccessor(Class<T> argParentType, String argKey) {
/*  28 */     if (argParentType == null || argKey == null) {
/*  29 */       throw new NullPointerException();
/*     */     }
/*  31 */     this.key_ = argKey;
/*  32 */     this.parentType_ = argParentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getKey() {
/*  41 */     return this.key_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract VT getValue(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract VT getValue(T paramT, VT paramVT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Class<VT> getValueType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty(T argParent) {
/*  75 */     return (validParent(argParent).getProperty(this.key_) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setValue(T paramT, VT paramVT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  89 */     ToStringBuilder tsb = new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
/*  90 */     tsb.append(this.key_);
/*  91 */     return tsb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<T> getParentType() {
/* 100 */     return this.parentType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final T validParent(T argParent) {
/* 112 */     Class<?> clz = argParent.getClass();
/* 113 */     if (!this.parentType_.isAssignableFrom(clz)) {
/* 114 */       throw new IllegalArgumentException("require " + this.parentType_.getName() + ", got " + clz.getName());
/*     */     }
/* 116 */     return argParent;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\AbstractDataPropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */