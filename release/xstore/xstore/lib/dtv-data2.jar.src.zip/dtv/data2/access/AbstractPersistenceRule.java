/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.data2.access.impl.PersistableMetaData;
/*     */ import dtv.data2.access.impl.config.PmTypeMappingConfigHelper;
/*     */ import dtv.data2.access.pm.PersistenceManagerType;
/*     */ import dtv.data2.access.pm.PmTypeDeterminationException;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPersistenceRule
/*     */   implements IPersistenceRule
/*     */ {
/*     */   protected static final String PARAM_SOURCE_DATA_SOURCE = "SourceDataSource";
/*     */   protected static final String PARAM_SOURCE_DATA_SOURCE_EXPRESSION = "SourceDataSourceExpression";
/*     */   protected static final String PARAM_TARGET_DATA_SOURCE = "TargetDataSource";
/*     */   protected static final String PARAM_TARGET_DATA_SOURCE_EXPRESSION = "TargetDataSourceExpression";
/*  59 */   private static final Logger _logger = Logger.getLogger(AbstractPersistenceRule.class);
/*     */   
/*     */   @Inject
/*     */   private PmTypeMappingConfigHelper _cfg;
/*     */   
/*     */   private final boolean _supportsSourceDataSourceParam;
/*     */   
/*     */   private final boolean _supportsTargetDataSourceParam;
/*  67 */   private String _sourceDataSourceName = null;
/*  68 */   private String _sourceDataSourceExpression = null;
/*  69 */   private String _targetDataSourceName = null;
/*  70 */   private String _targetDataSourceExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractPersistenceRule() {
/*  76 */     this(false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractPersistenceRule(boolean argSupportsSourceDataSourceParam, boolean argSupportsTargetDataSourceParam) {
/*  93 */     this._supportsSourceDataSourceParam = argSupportsSourceDataSourceParam;
/*  94 */     this._supportsTargetDataSourceParam = argSupportsTargetDataSourceParam;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isApplicable(PersistableMetaData argPersistableMetaData, Object argObject) {
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String argName, IConfigObject argValue) {
/* 107 */     if ("SourceDataSource".equalsIgnoreCase(argName) && this._supportsSourceDataSourceParam) {
/* 108 */       this._sourceDataSourceName = argValue.toString();
/*     */     }
/* 110 */     else if ("SourceDataSourceExpression".equalsIgnoreCase(argName) && this._supportsSourceDataSourceParam) {
/*     */       
/* 112 */       this._sourceDataSourceExpression = argValue.toString();
/*     */     }
/* 114 */     else if ("TargetDataSource".equalsIgnoreCase(argName) && this._supportsTargetDataSourceParam) {
/* 115 */       this._targetDataSourceName = argValue.toString();
/*     */     }
/* 117 */     else if ("TargetDataSourceExpression".equalsIgnoreCase(argName) && this._supportsTargetDataSourceParam) {
/*     */       
/* 119 */       this._targetDataSourceExpression = argValue.toString();
/*     */     } else {
/*     */       
/* 122 */       _logger.warn("This persistence rule does not support parameters!  [" + argName + "] = [" + argValue + "] is illegal!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPersistenceMgrType getPMTypeByObjectId(Class<? extends Object> argObjectIdClass) {
/* 134 */     String pmTypeString = null;
/*     */     try {
/* 136 */       pmTypeString = this._cfg.getPMType(argObjectIdClass.getName());
/*     */     }
/* 138 */     catch (Exception ex) {
/* 139 */       if (ex instanceof PmTypeDeterminationException) {
/* 140 */         throw (RuntimeException)ex;
/*     */       }
/*     */       
/* 143 */       throw new PmTypeDeterminationException("Unable to determine PM type for id: " + argObjectIdClass
/* 144 */           .getName() + " see cause exception.", ex);
/*     */     } 
/*     */ 
/*     */     
/* 148 */     if (!StringUtils.isEmpty(pmTypeString)) {
/* 149 */       return (IPersistenceMgrType)PersistenceManagerType.forName(pmTypeString);
/*     */     }
/*     */     
/* 152 */     throw new PmTypeDeterminationException("Unable to determine PM type for id: " + argObjectIdClass
/* 153 */         .getName() + " retrieved null or empty PM type string.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSourceDataSourceName() {
/* 164 */     return this._sourceDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getTargetDataSourceName() {
/* 174 */     return this._targetDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesSourceDataSource(String argDataSource, boolean argDefault) {
/* 189 */     String matchExpression = getSourceDataSourceExpression();
/* 190 */     return StringUtils.isEmpty(matchExpression) ? argDefault : argDataSource.matches(matchExpression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesTargetDataSource(String argDataSource, boolean argDefault) {
/* 205 */     String matchExpression = getTargeteDataSourceExpression();
/* 206 */     return StringUtils.isEmpty(matchExpression) ? argDefault : argDataSource.matches(matchExpression);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getSourceDataSourceExpression() {
/* 212 */     return StringUtils.isEmpty(this._sourceDataSourceExpression) ? this._sourceDataSourceName : this._sourceDataSourceExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getTargeteDataSourceExpression() {
/* 218 */     return StringUtils.isEmpty(this._targetDataSourceExpression) ? this._targetDataSourceName : this._targetDataSourceExpression;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\AbstractPersistenceRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */