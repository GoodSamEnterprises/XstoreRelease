/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateCleanbean
/*     */   implements Callable<Void>
/*     */ {
/*  27 */   private static final Logger logger_ = Logger.getLogger(GenerateCleanbean.class);
/*     */ 
/*     */   
/*  30 */   private static final Set<String> _abstractCleanBeanAttrs = new HashSet<String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private static final Set<String> _attrTypesToIgnore = new HashSet<String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*     */   private final DaoGenHelper helper_;
/*     */   
/*     */   private final List<DtxDefinition> dtxDefinitions_;
/*     */   
/*  50 */   Map<DtxDefinition, Set<DtxInverseRelationship>> comprehensiveInverseRelationships_ = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenerateCleanbean(DaoGenHelper argHelper) {
/*  59 */     this.helper_ = argHelper;
/*  60 */     this.dtxDefinitions_ = this.helper_.getDtxDefinitions();
/*     */ 
/*     */     
/*  63 */     Map<String, DtxDefinition> dtxDefsByCleanbeanClassname = new HashMap<>();
/*  64 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/*  65 */       dtxDefsByCleanbeanClassname.put(dtx.getCleanbeanClassname(), dtx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/*  74 */       for (DtxRelationship r : dtx.getRelationships("One-Many")) {
/*  75 */         DtxDefinition childDtx = dtxDefsByCleanbeanClassname.get(r.getChild().getCleanbeanClassname());
/*     */ 
/*     */         
/*  78 */         DtxInverseRelationship invRel = null;
/*  79 */         for (DtxInverseRelationship explicitlyDeclaredInvRel : childDtx.getInverseRelationships()) {
/*  80 */           if (explicitlyDeclaredInvRel.getParent() == dtx) {
/*  81 */             invRel = explicitlyDeclaredInvRel;
/*     */             break;
/*     */           } 
/*     */         } 
/*  85 */         if (invRel == null) {
/*  86 */           invRel = new DtxInverseRelationship();
/*  87 */           invRel.setParentType(dtx.getName());
/*  88 */           invRel.setParent(dtx);
/*  89 */           invRel.setName("parent" + dtx.getName());
/*     */         } 
/*     */         
/*  92 */         Set<DtxInverseRelationship> invRelSet = this.comprehensiveInverseRelationships_.get(childDtx);
/*  93 */         if (invRelSet == null) {
/*  94 */           invRelSet = new HashSet<>();
/*  95 */           this.comprehensiveInverseRelationships_.put(childDtx, invRelSet);
/*     */         } 
/*  97 */         invRelSet.add(invRel);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/* 108 */     logger_.info("Generating cleanbean mappings");
/*     */ 
/*     */     
/* 111 */     Set<String> doNotProcess = new HashSet<String>()
/*     */       {
/*     */       
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 118 */     for (DtxDefinition dtx : this.dtxDefinitions_) {
/* 119 */       if (doNotProcess.contains(dtx.getName())) {
/*     */         continue;
/*     */       }
/*     */       
/* 123 */       if (DaoGenOrgHierarchyHelper.isOrgHierarchical(dtx)) {
/* 124 */         DaoGenOrgHierarchyHelper.addOrgHierarchyTable(dtx.getTable());
/*     */       }
/*     */ 
/*     */       
/* 128 */       File f = new File(this.helper_.getCleanbeanOutPath() + this.helper_.getFilePathCleanbean(dtx) + dtx.getName() + ".java");
/*     */       
/* 130 */       StringBuilder out = new StringBuilder(20480);
/* 131 */       if (dtx.needsGeneration(f)) {
/* 132 */         getCleanbeanHeader(out, dtx);
/* 133 */         getCleanbeanIDMembers(out, dtx);
/* 134 */         getCleanbeanMembers(out, dtx);
/* 135 */         getCleanbeanConstructor(out, dtx);
/* 136 */         getCleanbeanIDMethods(out, dtx);
/* 137 */         getCleanbeanMethods(out, dtx);
/* 138 */         getCleanbeanFooter(out, dtx);
/*     */         
/* 140 */         this.helper_.getWriter().write(f, out.toString());
/*     */       } 
/*     */     } 
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   private void getCleanbeanConstructor(StringBuilder out, DtxDefinition argDtx) {
/* 147 */     out.append("  public ");
/* 148 */     out.append(argDtx.getName());
/* 149 */     out.append("() {}\n\n");
/*     */   }
/*     */   
/*     */   private void getCleanbeanFooter(StringBuilder out, DtxDefinition argDtx) {
/* 153 */     out.append("} ");
/*     */   }
/*     */   
/*     */   private String getCleanbeanHeader(StringBuilder out, DtxDefinition argDtx) {
/* 157 */     out.append("package ");
/* 158 */     out.append(argDtx.getCleanbeanPackageRaw());
/* 159 */     out.append(";\n\n");
/*     */     
/* 161 */     out.append(this.helper_
/* 162 */         .getClassComment("Auto-generated dtx \"Clean Bean\"\n *\n * DO NOT MANUALLY MODIFY THIS FILE."));
/*     */     
/* 164 */     out.append("public class " + argDtx.getName());
/*     */     
/* 166 */     if (argDtx.isExtended()) {
/* 167 */       out.append(" extends ");
/* 168 */       out.append(argDtx.getExtends().getCleanbeanClassname());
/*     */     } else {
/*     */       
/* 171 */       out.append(" extends com.micros_retail.gwt.shared.entity.AbstractCleanBean");
/*     */     } 
/*     */     
/* 174 */     out.append(" {\n\n");
/* 175 */     out.append("  // Fix serialization compatability based on the name of the DAO\n");
/* 176 */     out.append("  private static final long serialVersionUID = " + argDtx.getName().hashCode() + "L;\n");
/*     */     
/* 178 */     out.append("\n");
/* 179 */     return out.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private void getCleanbeanIDMembers(StringBuilder out, DtxDefinition argDtx) {
/* 184 */     DtxDefinition.DtxDaoField[] fields = argDtx.getPrimaryKeyFieldsRaw();
/*     */     
/* 186 */     for (DtxDefinition.DtxDaoField field : fields) {
/* 187 */       String fieldType = DaoGenUtils.getRawDataType(field.getType());
/* 188 */       out.append("  private " + fieldType + " " + DaoGenUtils.getFieldNameForField(field));
/*     */       
/* 190 */       if ("Boolean".equals(field.getType()))
/*     */       {
/*     */         
/* 193 */         out.append(" = Boolean.FALSE");
/*     */       }
/* 195 */       out.append(";\n");
/*     */     } 
/*     */     
/* 198 */     out.append("\n");
/*     */   }
/*     */   
/*     */   private void getCleanbeanIDMethods(StringBuilder out, DtxDefinition argDtx) {
/* 202 */     for (DtxDefinition.DtxDaoField f : argDtx.getPrimaryKeyFieldsRaw()) {
/*     */       
/* 204 */       DaoGenUtils.appendGetterForField(out, f);
/*     */ 
/*     */       
/* 207 */       DaoGenUtils.appendSetterForField(out, f, false, false);
/*     */     } 
/*     */     
/* 210 */     out.append("\n");
/*     */   }
/*     */   
/*     */   private void getCleanbeanMembers(StringBuilder out, DtxDefinition argDtx) {
/* 214 */     for (DtxRelationship rel : argDtx.getRelationships()) {
/* 215 */       if (DtxRelationship.MANY_MANY.equalsIgnoreCase(rel.getType())) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 220 */       String memberName = DaoGenUtils.getFieldNameForRelationship(rel);
/* 221 */       String memberType = DaoGenUtils.getTypeForRelationship(rel, true);
/* 222 */       out.append("  private " + memberType + " " + memberName);
/* 223 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(rel.getType())) {
/* 224 */         String rawElementType = DaoGenUtils.getRawDataType(rel.getChild().getCleanbeanClassname());
/* 225 */         out.append(" = new java.util.ArrayList<" + rawElementType + ">()");
/*     */       } 
/* 227 */       out.append(";\n");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     Set<DtxInverseRelationship> invRels = this.comprehensiveInverseRelationships_.get(argDtx);
/* 234 */     if (invRels != null) {
/* 235 */       for (DtxInverseRelationship invRel : this.comprehensiveInverseRelationships_.get(argDtx)) {
/* 236 */         String memberName = StringUtils.ensureFirstLowerCase(invRel.getName());
/* 237 */         String memberType = invRel.getParent().getCleanbeanClassname();
/* 238 */         out.append("  private " + memberType + " _" + memberName + ";\n");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 243 */     DtxDefinition.DtxDaoField[] fields = argDtx.getFields();
/*     */     
/* 245 */     for (DtxDefinition.DtxDaoField field : fields) {
/* 246 */       if (!shouldIgnoreField(field)) {
/*     */ 
/*     */ 
/*     */         
/* 250 */         String fieldType = DaoGenUtils.getRawDataType(field.getType());
/* 251 */         out.append("  private " + fieldType + " " + DaoGenUtils.getFieldNameForField(field));
/*     */         
/* 253 */         if ("Boolean".equals(field.getType()))
/*     */         {
/*     */           
/* 256 */           out.append(" = Boolean.FALSE");
/*     */         }
/* 258 */         out.append(";\n");
/*     */       } 
/*     */     } 
/* 261 */     out.append("\n");
/*     */   }
/*     */   
/*     */   private void getCleanbeanMethods(StringBuilder out, DtxDefinition argDtx) {
/* 265 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*     */       
/* 267 */       if (DtxRelationship.MANY_MANY.equalsIgnoreCase(relationship.getType())) {
/* 268 */         logger_.warn("Skipping many-many relationship '" + relationship.getName() + "' in " + argDtx.getName() + " because this tool does not support many-many relationships (yet).");
/*     */         
/* 270 */         out.append("  // Many-Many relationship unsupported: ");
/* 271 */         out.append(relationship.getName());
/* 272 */         out.append("\n\n");
/*     */         continue;
/*     */       } 
/* 275 */       if (DtxRelationship.MANY_MANY.equalsIgnoreCase(relationship.getType())) {
/* 276 */         DtxDefinition childDtx = relationship.getChild();
/* 277 */         DtxInverseRelationship invRel = null;
/* 278 */         Set<DtxInverseRelationship> set = this.comprehensiveInverseRelationships_.get(childDtx);
/* 279 */         for (DtxInverseRelationship ir : set) {
/* 280 */           if (ir.getParent().getName().equals(argDtx.getName())) {
/* 281 */             invRel = ir;
/*     */             break;
/*     */           } 
/*     */         } 
/* 285 */         if (invRel == null) {
/*     */           
/* 287 */           logger_.warn("Skipping 1-many relationship '" + relationship.getName() + "' in " + argDtx.getName() + " because there is no InverseRelationship defined in the 'many' side.");
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 294 */       String argName = DaoGenUtils.getArgNameForRelationship(relationship);
/* 295 */       String typeName = DaoGenUtils.getTypeForRelationship(relationship, true);
/* 296 */       String getterName = DaoGenUtils.getGetterNameForRelationship(relationship);
/* 297 */       String setterName = DaoGenUtils.getSetterNameForRelationship(relationship);
/* 298 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*     */ 
/*     */       
/* 301 */       out.append("  public " + typeName + " " + getterName + "() {\n");
/* 302 */       out.append("    return " + fieldName + ";\n");
/* 303 */       out.append("  }\n\n");
/*     */ 
/*     */       
/* 306 */       out.append("  public void " + setterName + "(" + typeName + " " + argName + ") {\n");
/* 307 */       out.append("    " + fieldName + " = " + argName + ";\n");
/* 308 */       out.append("  }\n\n");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     Set<DtxInverseRelationship> invRels = this.comprehensiveInverseRelationships_.get(argDtx);
/* 315 */     if (invRels != null) {
/* 316 */       for (DtxInverseRelationship invRel : this.comprehensiveInverseRelationships_.get(argDtx)) {
/* 317 */         DtxDefinition parentDtx = invRel.getParent();
/*     */ 
/*     */         
/* 320 */         DtxRelationship parentRel = getRelationshipIdentifiedByChildClass(parentDtx, argDtx.getName());
/* 321 */         if (parentRel == null) {
/* 322 */           logger_.warn("Skipping inverse relationship in " + argDtx.getName() + "; \"goofy\" inverse relationships (like the one in TaxRateRuleOverride.dtx) are not supported for Cleanbean code generation.");
/*     */ 
/*     */           
/* 325 */           out.append("  // Relationship unsupported: ");
/* 326 */           out.append(invRel.getName());
/* 327 */           out.append("\n\n");
/*     */           
/*     */           continue;
/*     */         } 
/* 331 */         writeInverseRelationshipGetterAndSetter(out, StringUtils.ensureFirstLowerCase(invRel.getName()), invRel
/* 332 */             .getParent().getCleanbeanClassname());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 337 */     for (DtxDefinition.DtxDaoField field : argDtx.getFields()) {
/* 338 */       if (!shouldIgnoreField(field)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 343 */         DaoGenUtils.appendGetterForField(out, field);
/*     */ 
/*     */         
/* 346 */         DaoGenUtils.appendSetterForField(out, field, false, false);
/*     */       } 
/*     */     } 
/* 349 */     out.append("\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private DtxRelationship getRelationshipIdentifiedByChildClass(DtxDefinition argDtx, String argChildClassName) {
/* 354 */     for (DtxRelationship rel : argDtx.getRelationships()) {
/* 355 */       if (argChildClassName.equals(rel.getChildName())) {
/* 356 */         return rel;
/*     */       }
/*     */     } 
/* 359 */     return null;
/*     */   }
/*     */   
/*     */   private boolean shouldIgnoreField(DtxDefinition.DtxDaoField field) {
/* 363 */     if (field.isPrimaryKey()) {
/* 364 */       return true;
/*     */     }
/*     */     
/* 367 */     if (_abstractCleanBeanAttrs.contains(field.getName())) {
/* 368 */       return true;
/*     */     }
/*     */     
/* 371 */     if (_attrTypesToIgnore.contains(field.getType())) {
/* 372 */       return true;
/*     */     }
/*     */     
/* 375 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeInverseRelationshipGetterAndSetter(StringBuilder out, String memberName, String memberType) {
/* 380 */     String properName = StringUtils.ensureFirstUpperCase(memberName);
/* 381 */     String argName = "arg" + properName;
/* 382 */     String rawType = DaoGenUtils.getRawDataType(memberType);
/*     */ 
/*     */     
/* 385 */     out.append("  public " + rawType + " get" + properName + "() {\n");
/* 386 */     out.append("    return _" + memberName + ";\n");
/* 387 */     out.append("  }\n\n");
/*     */ 
/*     */     
/* 390 */     out.append("  public void set" + properName + "(" + rawType + " " + argName + ") {\n");
/* 391 */     out.append("    _" + memberName + " = " + argName + ";\n");
/* 392 */     out.append("  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateCleanbean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */