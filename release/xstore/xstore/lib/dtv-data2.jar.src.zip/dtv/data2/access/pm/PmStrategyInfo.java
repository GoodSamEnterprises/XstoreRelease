/*    */ package dtv.data2.access.pm;
/*    */ 
/*    */ import dtv.data2.access.impl.IPersistenceStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PmStrategyInfo
/*    */ {
/*    */   private IPersistenceStrategy strategy_;
/*    */   private boolean isCurrentlyAvailable_;
/*    */   
/*    */   public PmStrategyInfo(IPersistenceStrategy argStrategy, boolean argIsAvaliable) {
/* 26 */     this.strategy_ = argStrategy;
/* 27 */     this.isCurrentlyAvailable_ = argIsAvaliable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPersistenceStrategy getStrategy() {
/* 36 */     return this.strategy_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCurrentlyAvailable() {
/* 46 */     return this.isCurrentlyAvailable_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PmStrategyInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */