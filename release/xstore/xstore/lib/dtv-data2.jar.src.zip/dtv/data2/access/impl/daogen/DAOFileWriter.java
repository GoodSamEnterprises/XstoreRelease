/*    */ package dtv.data2.access.impl.daogen;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.nio.file.Files;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DAOFileWriter
/*    */ {
/* 20 */   private final ExecutorService _executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
/* 21 */   private final BlockingQueue<Future<Void>> writeTasks = new LinkedBlockingQueue<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected synchronized void close() {
/*    */     try {
/* 29 */       flush();
/*    */     } finally {
/*    */       
/* 32 */       this._executor.shutdown();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected synchronized void flush() {
/*    */     try {
/* 41 */       Future<Void> nextRecord = null;
/* 42 */       while ((nextRecord = this.writeTasks.poll()) != null) {
/* 43 */         nextRecord.get();
/*    */       }
/*    */     }
/* 46 */     catch (Throwable t) {
/* 47 */       throw new RuntimeException(t);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected synchronized void write(File argFile, String argText) {
/* 58 */     this.writeTasks.add(this._executor.submit(new FileWriter(argFile, argText)));
/*    */   }
/*    */   
/*    */   private class FileWriter
/*    */     implements Callable<Void> {
/*    */     private final File _writeFile;
/*    */     private final String _writeContents;
/*    */     
/*    */     private FileWriter(File argFile, String argContents) {
/* 67 */       this._writeFile = argFile;
/* 68 */       this._writeContents = argContents;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Void call() throws Exception {
/* 75 */       byte[] fileBytes = this._writeContents.getBytes(StandardCharsets.UTF_8);
/* 76 */       if (!this._writeFile.getParentFile().exists()) {
/* 77 */         this._writeFile.getParentFile().mkdirs();
/*    */       }
/* 79 */       Files.write(this._writeFile.toPath(), fileBytes, new java.nio.file.OpenOption[0]);
/* 80 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DAOFileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */