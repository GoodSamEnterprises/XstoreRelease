/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.data2.access.IDataModelRelationship;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtxRelationship
/*     */ {
/*  21 */   public static final String ONE_ONE = IDataModelRelationship.RelationshipType.ONE_TO_ONE.toString();
/*     */ 
/*     */   
/*  24 */   public static final String ONE_MANY = IDataModelRelationship.RelationshipType.ONE_TO_MANY.toString();
/*     */ 
/*     */   
/*  27 */   public static final String MANY_MANY = IDataModelRelationship.RelationshipType.MANY_TO_MANY.toString();
/*     */   
/*  29 */   private final List<DtxRelationshipField> fields_ = new ArrayList<>();
/*     */   
/*     */   private String relationshipName_;
/*     */   
/*     */   private String type_;
/*     */   
/*     */   private String parentType_;
/*     */   
/*     */   private String childName_;
/*     */   
/*     */   private DtxDefinition child_;
/*     */   
/*     */   private String table_;
/*     */   
/*     */   private String elementName_;
/*     */   private DtxDefinition parent_;
/*     */   private boolean useParentPm_ = false;
/*     */   private boolean export_ = true;
/*     */   private boolean dependent_ = false;
/*     */   private boolean propertyRelationship_ = false;
/*     */   private boolean transient_ = false;
/*     */   
/*     */   public void addField(DtxRelationshipField argField) {
/*  52 */     this.fields_.add(argField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxDefinition getChild() {
/*  61 */     return this.child_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChildName() {
/*  70 */     return this.childName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDependent() {
/*  79 */     return this.dependent_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElementName() {
/*  88 */     return this.elementName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxRelationshipField getField(int argIndex) {
/*  98 */     return this.fields_.get(argIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DtxRelationshipField> getFields() {
/* 107 */     return this.fields_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DtxRelationshipField> getFieldsNotShared() {
/* 116 */     if (this.fields_ == null || this.fields_.isEmpty()) {
/* 117 */       return new ArrayList<>(0);
/*     */     }
/*     */     
/* 120 */     List<DtxRelationshipField> nonSharedFields = new ArrayList<>();
/* 121 */     for (DtxRelationshipField aField : this.fields_) {
/* 122 */       if (!aField.getShared()) {
/* 123 */         nonSharedFields.add(aField);
/*     */       }
/*     */     } 
/* 126 */     return nonSharedFields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 135 */     return this.relationshipName_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtxDefinition getParent() {
/* 144 */     return this.parent_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParentAttributeName() {
/* 153 */     return "_" + StringUtils.ensureFirstLowerCase(getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParentType() {
/* 163 */     return this.parentType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTable() {
/* 172 */     return this.table_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 181 */     return this.type_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExported() {
/* 190 */     return this.export_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPropertyRelationship() {
/* 199 */     return this.propertyRelationship_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransient() {
/* 208 */     return this.transient_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseParentPm() {
/* 217 */     return this.useParentPm_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(DtxDefinition argChild) {
/* 226 */     this.child_ = argChild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChildName(String argChildName) {
/* 235 */     this.childName_ = argChildName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDependent(boolean argDependent) {
/* 244 */     this.dependent_ = argDependent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElementName(String argElementName) {
/* 253 */     this.elementName_ = argElementName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExported(boolean argExport) {
/* 262 */     this.export_ = argExport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String argRelationshipName) {
/* 271 */     this.relationshipName_ = argRelationshipName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(DtxDefinition argParent) {
/* 280 */     this.parent_ = argParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentType(String argParent) {
/* 289 */     this.parentType_ = argParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyRelationship(boolean argPropertyRelationship) {
/* 298 */     this.propertyRelationship_ = argPropertyRelationship;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTable(String argTable) {
/* 307 */     this.table_ = argTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransient(boolean argTransient) {
/* 316 */     this.transient_ = argTransient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String argType) {
/* 325 */     this.type_ = argType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseParentPm(boolean argUseParentPm) {
/* 334 */     this.useParentPm_ = argUseParentPm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() {
/* 343 */     if (StringUtils.isEmpty(getName())) {
/* 344 */       throw new RuntimeException("There is no relationship name specified.");
/*     */     }
/*     */     
/* 347 */     if (StringUtils.isEmpty(getType())) {
/* 348 */       throw new RuntimeException("The relationship: " + getName() + " does not define a relationship type.");
/*     */     }
/*     */     
/* 351 */     if (!getType().equalsIgnoreCase(ONE_ONE) && !getType().equalsIgnoreCase(ONE_MANY) && 
/* 352 */       !getType().equalsIgnoreCase(MANY_MANY))
/*     */     {
/* 354 */       throw new RuntimeException("The relationship: " + getName() + " defines an unknown type: " + getType());
/*     */     }
/*     */     
/* 357 */     if (StringUtils.isEmpty(getChildName())) {
/* 358 */       throw new RuntimeException("The relationship: " + getName() + " does not define a child type.");
/*     */     }
/*     */     
/* 361 */     if (this.child_ == null) {
/* 362 */       throw new RuntimeException("The relationship: " + 
/* 363 */           getName() + " does not have its child_ DtxDefinition set");
/*     */     }
/*     */     
/* 366 */     if (this.parent_ == null) {
/* 367 */       throw new RuntimeException("The relationship: " + 
/* 368 */           getName() + " does not have its parent_ DtxDefinition set");
/*     */     }
/*     */     
/* 371 */     if (getType().equalsIgnoreCase(MANY_MANY) && StringUtils.isEmpty(getTable())) {
/* 372 */       throw new RuntimeException("The relationship: " + 
/* 373 */           getName() + " is a MANY-MANY but does not define the table attribute");
/*     */     }
/*     */     
/* 376 */     if (!StringUtils.isEmpty(getParentType())) {
/* 377 */       throw new RuntimeException("The relationship: " + 
/* 378 */           getName() + " defines the parent: " + getParent() + " but does not need to");
/*     */     }
/*     */     
/* 381 */     if (!getType().equalsIgnoreCase(ONE_ONE) && getDependent()) {
/* 382 */       throw new RuntimeException("The relationship: " + getName() + " is marked as dependent but should not be.  The dependent attribute only applies to ONE-ONE relationships");
/*     */     }
/*     */ 
/*     */     
/* 386 */     Set<String> parentFieldNames = new HashSet<>();
/* 387 */     Set<String> childFieldNames = new HashSet<>();
/*     */     
/* 389 */     for (DtxRelationshipField field : this.fields_) {
/*     */       
/* 391 */       if (!getType().equalsIgnoreCase(ONE_ONE) && 
/* 392 */         field.getShared()) {
/* 393 */         throw new RuntimeException("The relationship: " + getName() + " defines a field which is marked as shared.  *Shared only applies to ONE-ONE relationships.*");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 398 */       if (ONE_ONE.equalsIgnoreCase(getType())) {
/*     */ 
/*     */         
/* 401 */         for (DtxDefinition.DtxDaoField key : this.parent_.getPrimaryKeyFields()) {
/* 402 */           if (!getDependent() && !field.getShared() && field.getParent().equals(key.getName())) {
/* 403 */             throw new RuntimeException("The relationship: " + getName() + " defines a NON-SHARED field " + field
/* 404 */                 .getParent() + " WHICH IS A PRIMARY KEY OF THE PARENT.  this is problematic because the primary key will be altered as this relationship changes.");
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 415 */         if ((this.child_.getPrimaryKeyFields()).length == this.fields_.size()) {
/* 416 */           for (int ii = 0; ii < (this.child_.getPrimaryKeyFields()).length; ii++) {
/*     */             
/* 418 */             String childField = this.child_.getPrimaryKeyFields()[ii].getName();
/* 419 */             String relField = ((DtxRelationshipField)this.fields_.get(ii)).getChild();
/*     */             
/* 421 */             if (!childField.equals(relField))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 427 */               for (DtxRelationshipField thisField : this.fields_) {
/* 428 */                 if (thisField.getChild().equals(this.child_.getPrimaryKeyFields()[ii].getName())) {
/* 429 */                   throw new RuntimeException((new StringBuilder(200)).append("Relationship [").append(getName())
/* 430 */                       .append("] in dtx [").append(this.parent_.getName())
/* 431 */                       .append("] has primary key fields in a different order than its child [")
/* 432 */                       .append(this.child_.getName()).append("]. This causes problems with object id parsing.")
/* 433 */                       .toString());
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 443 */       if (!MANY_MANY.equalsIgnoreCase(getType())) {
/* 444 */         if (!StringUtils.isEmpty(field.getXrefField())) {
/* 445 */           throw new RuntimeException("The relationship: " + getName() + " defines an xref field but is not MANY-MANY.  Only MANY-MANY's have xref fields.");
/*     */         }
/*     */ 
/*     */         
/* 449 */         if (StringUtils.isEmpty(field.getParent())) {
/* 450 */           throw new RuntimeException("The relationship: " + 
/* 451 */               getName() + " does not define a parent type, but should.");
/*     */         }
/* 453 */         if (StringUtils.isEmpty(field.getChild())) {
/* 454 */           throw new RuntimeException("The relationship: " + 
/* 455 */               getName() + " does not define a child type, but should.");
/*     */         }
/*     */       } 
/*     */       
/* 459 */       field.validate();
/*     */       
/* 461 */       if (!StringUtils.isEmpty(field.getParent())) {
/* 462 */         if (parentFieldNames.contains(field.getParent())) {
/* 463 */           throw new RuntimeException("The relationship: " + getName() + " defines the same parent field name twice: " + field
/* 464 */               .getParent());
/*     */         }
/* 466 */         parentFieldNames.add(field.getParent());
/*     */       } 
/*     */       
/* 469 */       if (!StringUtils.isEmpty(field.getChild())) {
/* 470 */         if (childFieldNames.contains(field.getChild())) {
/* 471 */           throw new RuntimeException("The relationship: " + getName() + " defines the same child field name twice: " + field
/* 472 */               .getChild());
/*     */         }
/* 474 */         childFieldNames.add(field.getChild());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 492 */       if (!StringUtils.isEmpty(field.getChild()) && 
/* 493 */         this.child_.findField(field.getChild()) == null) {
/* 494 */         throw new RuntimeException("The relationship: " + getName() + " has a field which references non-existent child field: " + field
/* 495 */             .getParent());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class DtxRelationshipField
/*     */   {
/*     */     private String fieldParent_;
/*     */     
/*     */     private String fieldChild_;
/*     */     
/*     */     private String xrefField_;
/*     */     
/*     */     private String value_;
/*     */     
/*     */     private boolean sharedSet_ = false;
/*     */     
/*     */     private boolean shared_ = false;
/*     */ 
/*     */     
/*     */     public String getChild() {
/* 518 */       return this.fieldChild_;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getParent() {
/* 527 */       return this.fieldParent_;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean getShared() {
/* 537 */       if (!this.sharedSet_) {
/*     */         
/* 539 */         if (DtxRelationship.ONE_ONE.equalsIgnoreCase(DtxRelationship.this.getType())) {
/* 540 */           for (DtxDefinition.DtxDaoField key : DtxRelationship.this.parent_.getPrimaryKeyFields()) {
/* 541 */             if (getParent().equals(key.getName())) {
/* 542 */               this.shared_ = true;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/* 547 */         this.sharedSet_ = true;
/*     */       } 
/* 549 */       return this.shared_;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 558 */       return this.value_;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getXrefField() {
/* 567 */       return this.xrefField_;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setChild(String argChild) {
/* 581 */       this.fieldChild_ = argChild;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setParent(String argParent) {
/* 590 */       this.fieldParent_ = argParent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(String argValue) {
/* 599 */       this.value_ = argValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setXrefField(String argXrefField) {
/* 608 */       this.xrefField_ = argXrefField;
/*     */     }
/*     */     
/*     */     public void validate() {}
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DtxRelationship.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */