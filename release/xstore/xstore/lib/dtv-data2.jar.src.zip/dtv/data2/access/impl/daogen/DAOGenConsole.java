/*    */ package dtv.data2.access.impl.daogen;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DAOGenConsole
/*    */ {
/*    */   public static void main(String[] args) throws Exception {
/* 25 */     File inDir = new File(".");
/* 26 */     File outDir = new File(".");
/* 27 */     File cleanbeanOutDir = new File(".");
/* 28 */     File sourcesDir = new File(".");
/* 29 */     File tempDir = new File(".");
/*    */ 
/*    */     
/* 32 */     for (int i = 0; i < args.length; i++) {
/* 33 */       if ("-dir".equals(args[i]) && ++i < args.length) {
/* 34 */         inDir = new File(args[i]);
/*    */       }
/* 36 */       else if ("-dest".equals(args[i]) && ++i < args.length) {
/* 37 */         outDir = new File(args[i]);
/*    */       }
/* 39 */       else if ("-cleanbeanDest".equals(args[i]) && ++i < args.length) {
/* 40 */         cleanbeanOutDir = new File(args[i]);
/*    */       }
/* 42 */       else if ("-cleanbeanDest".equals(args[i]) && ++i < args.length) {
/* 43 */         cleanbeanOutDir = new File(args[i]);
/*    */       }
/* 45 */       else if ("-sourcesDir".equals(args[i]) && ++i < args.length) {
/* 46 */         sourcesDir = new File(args[i]);
/*    */       }
/* 48 */       else if ("-tempDir".equals(args[i]) && ++i < args.length) {
/* 49 */         tempDir = new File(args[i]);
/*    */       } else {
/*    */         
/* 52 */         usageError();
/*    */       } 
/*    */     } 
/*    */     
/* 56 */     DAOGen main = new DAOGen(inDir, outDir, cleanbeanOutDir, sourcesDir, tempDir, false);
/* 57 */     main.call();
/*    */   }
/*    */   
/*    */   private static void usageError() {
/* 61 */     System.err.println("Usage: DAOGen [-dir <source directory>] [-dest <source directory>] [-modDir <modDir directory>]");
/*    */     
/* 63 */     System.err.println("\t-dir           Folder to search for .dtx files (default: .)");
/* 64 */     System.err.println("\t-dest          Folder to write DAO and or Model code (default: same as source)\n");
/* 65 */     System.err.println("\t-cleanbeanDest Folder to write Cleanbean code (default: same as source)\n");
/* 66 */     System.err.println("\t-modDir        Folder containing customized models");
/* 67 */     System.err.println("\t-sourcesDir    Folder containing sources that should be considered during model generation");
/*    */     
/* 69 */     System.err.println("\t-tempDir       Folder used as scratch space during generation");
/* 70 */     throw new RuntimeException("Invalid command line parameters.");
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DAOGenConsole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */