/*    */ package dtv.data2.access.query;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MssqlConcatDecorator
/*    */   extends AbstractMssqlDecorator
/*    */ {
/*    */   protected String decorate(String argSqlStatement) {
/* 25 */     return argSqlStatement.replaceAll("\\|\\|", "+");
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\MssqlConcatDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */