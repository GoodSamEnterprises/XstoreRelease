/*      */ package dtv.data2.access.impl.daogen;
/*      */ 
/*      */ import dtv.data2.access.exception.DtxException;
/*      */ import dtv.data2.access.impl.AbstractDataModelImpl;
/*      */ import dtv.data2.access.impl.AbstractDataModelPropertiesImpl;
/*      */ import dtv.data2.access.impl.AbstractDataModelWithPropertyImpl;
/*      */ import dtv.util.StringUtils;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ModelGeneratorWithJavaDtj
/*      */   implements IModelGenerator
/*      */ {
/*      */   private final DaoGenHelper _helper;
/*      */   private Class<?> _baseModelClass;
/*      */   
/*      */   public ModelGeneratorWithJavaDtj(DaoGenHelper argHelper) {
/*   38 */     this._helper = argHelper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String generateModel(DtxDefinition argDtxDefinition) throws IOException {
/*      */     try {
/*   50 */       String baseModelClassName = argDtxDefinition.getPackage() + "." + argDtxDefinition.getName() + "BaseModel";
/*   51 */       this._baseModelClass = this._helper.getPrecompileClassloader().loadClass(baseModelClassName);
/*      */     }
/*   53 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   58 */     StringBuilder sb = new StringBuilder(20480);
/*   59 */     generateHeader(sb, argDtxDefinition);
/*   60 */     generateFields(sb, argDtxDefinition);
/*   61 */     generateDaoMethods(sb, argDtxDefinition);
/*      */     
/*   63 */     List<DtxRelationship> relationships = argDtxDefinition.getRelationships();
/*      */     
/*   65 */     if (DaoGenHelper.isPropertyChildNeeded(argDtxDefinition)) {
/*   66 */       generateNewPropertyMethod(sb, argDtxDefinition);
/*      */     }
/*      */     
/*   69 */     generateRelationshipFields(sb, relationships);
/*   70 */     generateRelationshipMethods(sb, argDtxDefinition, relationships);
/*      */     
/*   72 */     if (!argDtxDefinition.isProperties()) {
/*   73 */       generateExtensionMethods(sb, argDtxDefinition);
/*      */     }
/*      */     
/*   76 */     generateTransactionMethods(sb, argDtxDefinition);
/*   77 */     generateFooter(sb, argDtxDefinition);
/*      */     
/*   79 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addListInitializer(StringBuilder out, DtxRelationship relationship, String argInitializeWith, String argElseSetList) {
/*   92 */     String initializeFieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*   93 */     out.append("    if (").append(initializeFieldName).append(" == null) {\n");
/*   94 */     out.append("      ").append(initializeFieldName).append(" = new HistoricalList<")
/*   95 */       .append(relationship.getChild().getInterface()).append(">(").append(argInitializeWith).append(");\n");
/*   96 */     out.append("    }");
/*   97 */     if (argElseSetList != null) {
/*   98 */       out.append(" else { \n");
/*   99 */       out.append("      ").append(initializeFieldName).append(".setCurrentList(").append(argInitializeWith)
/*  100 */         .append(");\n");
/*  101 */       out.append("    }");
/*      */     } 
/*  103 */     out.append("\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateCustomSerialization(StringBuilder out, DtxDefinition argDtx) {
/*  113 */     out.append("  private void readObject(java.io.ObjectInputStream argStream)\n");
/*  114 */     out.append("                         throws java.io.IOException, ClassNotFoundException {\n");
/*  115 */     out.append("    argStream.defaultReadObject();\n");
/*  116 */     out.append("  }\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateDaoMethods(StringBuilder out, DtxDefinition argDtx) {
/*  126 */     if (!argDtx.isExtended()) {
/*  127 */       out.append("  @Override\n");
/*  128 */       out.append("  public String toString() {\n");
/*  129 */       out.append("    return super.toString() + \" Id: \" + this.getObjectId();\n");
/*  130 */       out.append("  }\n\n");
/*      */     } 
/*      */     
/*  133 */     out.append("  @Override\n");
/*  134 */     out.append("  public void initDAO() {\n");
/*  135 */     out.append("    setDAO(new ");
/*  136 */     out.append(argDtx.getName());
/*  137 */     out.append("DAO());\n");
/*  138 */     out.append("  }\n\n");
/*      */     
/*  140 */     out.append("  /**\n");
/*  141 */     out.append("   * Return the data access object associated with this data model\n");
/*  142 */     out.append("   * @return our DAO, properly casted\n");
/*  143 */     out.append("   */\n");
/*  144 */     out.append("  private ");
/*  145 */     out.append(argDtx.getName());
/*  146 */     out.append("DAO getDAO_() {\n");
/*  147 */     out.append("     return (");
/*  148 */     out.append(argDtx.getName());
/*  149 */     out.append("DAO) _daoImpl;\n");
/*  150 */     out.append("  }\n\n");
/*      */     
/*  152 */     for (DtxDefinition.DtxDaoField field : argDtx.getFieldsPlusInheritedPrimaryKeys()) {
/*      */ 
/*      */       
/*  155 */       if (!argDtx.isExtended() || !field.isPrimaryKey() || 
/*  156 */         !argDtx.getRelationships(DtxRelationship.ONE_MANY).isEmpty()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  161 */         generateFieldGetter(out, argDtx, field);
/*  162 */         generateFieldSetter(out, argDtx, field);
/*  163 */         generateEncryptedFieldGetter(out, argDtx, field);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateEncryptedFieldGetter(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField argField) {
/*  175 */     String getterName = DaoGenUtils.getGetterNameForField(argField);
/*  176 */     String encryptedGetterName = DaoGenUtils.getGetterNameForField(argField) + "Encrypted";
/*      */ 
/*      */     
/*  179 */     if (getBaseModelMethod(getterName, new Class[0]) != null || StringUtils.isEmpty(argField.getEncrypt()) || 
/*  180 */       !"String".equalsIgnoreCase(argField.getType())) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  191 */     out.append("  /**\n   * Gets the value of the ");
/*      */     
/*  193 */     out.append(argField.getColumn());
/*  194 */     out.append(" field.\n   * @return The value of the field.\n   */\n  public ");
/*      */ 
/*      */ 
/*      */     
/*  198 */     out.append(DaoGenUtils.getVariableType(argField.getType()));
/*  199 */     out.append(" ");
/*  200 */     out.append(encryptedGetterName);
/*  201 */     out.append("() {\n");
/*      */     
/*  203 */     out.append("    return getDAO_().");
/*  204 */     out.append(getterName);
/*  205 */     out.append("()");
/*  206 */     out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  207 */     out.append(";\n");
/*      */     
/*  209 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateExtensionMethods(StringBuilder out, DtxDefinition argDtx) {
/*  219 */     out.append("  public IDataModel get" + argDtx.getName() + "Ext() {\n");
/*  220 */     out.append("    return _myExtension;\n");
/*  221 */     out.append("  }\n\n");
/*      */     
/*  223 */     out.append("  public void set" + argDtx.getName() + "Ext(IDataModel argExt) {\n");
/*  224 */     out.append("    _myExtension = argExt;\n");
/*  225 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFieldGetter(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField argField) {
/*  239 */     String getterName = DaoGenUtils.getGetterNameForField(argField);
/*      */ 
/*      */     
/*  242 */     if (getBaseModelMethod(getterName, new Class[0]) != null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  250 */     out.append("  /**\n");
/*  251 */     out.append("   * Gets the value of the ");
/*  252 */     out.append(argField.getColumn());
/*  253 */     out.append(" field.\n");
/*  254 */     out.append("   * @return The value of the field.\n");
/*  255 */     out.append("   */\n");
/*  256 */     out.append("  public ");
/*  257 */     out.append(DaoGenUtils.getVariableType(argField.getType()));
/*  258 */     out.append(" ");
/*  259 */     out.append(getterName);
/*  260 */     out.append("() {\n");
/*      */     
/*  262 */     if ("Boolean".equalsIgnoreCase(argField.getType())) {
/*  263 */       out.append("    if (getDAO_().");
/*  264 */       out.append(getterName);
/*  265 */       out.append("() != null) {\n");
/*  266 */       out.append("      return getDAO_().");
/*  267 */       out.append(getterName);
/*  268 */       out.append("()");
/*  269 */       out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  270 */       out.append(";\n");
/*  271 */       out.append("    }\n");
/*  272 */       out.append("    else {\n");
/*  273 */       out.append("      return false;\n");
/*  274 */       out.append("    }\n");
/*      */     }
/*  276 */     else if ("Integer".equalsIgnoreCase(argField.getType()) || "Long"
/*  277 */       .equalsIgnoreCase(argField.getType())) {
/*      */       
/*  279 */       out.append("    if (getDAO_().");
/*  280 */       out.append(getterName);
/*  281 */       out.append("() != null) {\n");
/*  282 */       out.append("      return getDAO_().");
/*  283 */       out.append(getterName);
/*  284 */       out.append("()");
/*  285 */       out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  286 */       out.append(";\n");
/*  287 */       out.append("    }\n");
/*  288 */       out.append("    else {\n");
/*      */       
/*  290 */       if (argField.getDefaultValueIfNull() == null) {
/*  291 */         out.append("      return 0; // no default specified in the dtx; we default to 0\n");
/*      */       }
/*  293 */       else if (argField.getDefaultValueIfNull() instanceof Long) {
/*  294 */         out.append("      return ");
/*  295 */         out.append(argField.getDefaultValueIfNull());
/*  296 */         out.append("l; // <<< default specified in .dtx\n");
/*      */       } else {
/*      */         
/*  299 */         out.append("      return ");
/*  300 */         out.append(argField.getDefaultValueIfNull());
/*  301 */         out.append("; // <<< default specified in .dtx\n");
/*      */       } 
/*      */       
/*  304 */       out.append("    }\n");
/*      */     
/*      */     }
/*  307 */     else if (!StringUtils.isEmpty(argField.getEncrypt()) && "String".equalsIgnoreCase(argField.getType())) {
/*  308 */       out.append("    return decryptField(\"");
/*  309 */       out.append(argField.getEncrypt());
/*  310 */       out.append("\", ");
/*  311 */       out.append("getDAO_().");
/*  312 */       out.append(getterName);
/*  313 */       out.append("())");
/*  314 */       out.append(";\n");
/*      */     } else {
/*      */       
/*  317 */       out.append("    return getDAO_().");
/*  318 */       out.append(getterName);
/*  319 */       out.append("()");
/*  320 */       out.append(DaoGenUtils.toPrimitive(argField.getType()));
/*  321 */       out.append(";\n");
/*      */     } 
/*      */ 
/*      */     
/*  325 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFields(StringBuilder out, DtxDefinition argDtx) {
/*  338 */     for (DtxInverseRelationship rel : argDtx.getInverseRelationships()) {
/*  339 */       out.append("  private ");
/*  340 */       out.append(rel.getParent().getInterface());
/*  341 */       out.append(" _");
/*  342 */       out.append(StringUtils.ensureFirstLowerCase(rel.getName()));
/*  343 */       out.append(";\n");
/*      */     } 
/*      */     
/*  346 */     if ((argDtx.getInverseRelationships()).length > 0) {
/*  347 */       out.append("\n");
/*      */     }
/*      */     
/*  350 */     out.append("\n  private transient boolean _alreadyInStart = false;\n  private transient boolean _alreadyInCommit = false;\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  358 */     out.append("  private IDataModel _myExtension;\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFieldSetter(StringBuilder out, DtxDefinition argDtx, DtxDefinition.DtxDaoField argField) {
/*  373 */     boolean childPrimaryKey = false;
/*      */     
/*  375 */     if (argDtx.isExtended() && argField.isPrimaryKey() && 
/*  376 */       !argDtx.getRelationships(DtxRelationship.ONE_MANY).isEmpty())
/*      */     {
/*      */ 
/*      */       
/*  380 */       childPrimaryKey = true;
/*      */     }
/*      */ 
/*      */     
/*  384 */     String getterName = DaoGenUtils.getGetterNameForField(argField);
/*  385 */     String setterName = DaoGenUtils.getSetterNameForField(argField);
/*  386 */     String arg = DaoGenUtils.getArgNameForField(argField);
/*      */     
/*  388 */     String obj = DaoGenUtils.wrapStatementWithObject(arg, argField.getType());
/*  389 */     out.append("  /**\n");
/*  390 */     out.append("   * Sets the value of the ").append(argField.getColumn()).append(" field.\n");
/*  391 */     out.append("   * @param ").append(arg).append(" The new value for the field.\n");
/*  392 */     out.append("   */\n");
/*  393 */     out.append("  public void ").append(setterName).append("(").append(DaoGenUtils.getVariableType(argField.getType()))
/*  394 */       .append(" ").append(arg).append(") {\n");
/*      */ 
/*      */     
/*  397 */     if (getBaseModelMethod(setterName, new Class[] { DaoGenUtils.getClassForType(argField.getType()) }) != null) {
/*  398 */       out.append("    super.");
/*  399 */       out.append(setterName);
/*  400 */       out.append("(");
/*  401 */       out.append(arg);
/*  402 */       out.append(");\n\n");
/*      */     } 
/*      */     
/*  405 */     out.append("    if (").append(setterName).append("_noev(").append(arg).append(")) {\n");
/*      */     
/*  407 */     if (!argField.isSuppressed()) {
/*  408 */       out.append("      if (_events != null) {\n");
/*  409 */       out.append("        if (postEventsForChanges()) {\n");
/*  410 */       out.append("          _events.post(").append(argDtx.getInterface()).append(".SET_")
/*  411 */         .append(argField.getName().toUpperCase()).append(", ").append(obj).append(");\n");
/*  412 */       out.append("        }\n");
/*  413 */       out.append("      }\n");
/*      */     } else {
/*      */       
/*  416 */       out.append("      // suppress-event is specified for this field.\n");
/*      */     } 
/*  418 */     out.append("    }\n");
/*  419 */     out.append("  }\n");
/*  420 */     out.append("\n");
/*      */ 
/*      */ 
/*      */     
/*  424 */     out.append("  public boolean ").append(setterName).append("_noev(")
/*  425 */       .append(DaoGenUtils.getVariableType(argField.getType())).append(" ").append(arg).append(") {\n");
/*  426 */     out.append("    boolean ev_postable = false;\n");
/*  427 */     out.append("\n");
/*      */     
/*  429 */     if (!childPrimaryKey) {
/*  430 */       out.append("    if ((getDAO_().").append(getterName).append("() == null && ").append(obj)
/*  431 */         .append(" != null) ||\n");
/*  432 */       out.append("        (getDAO_().").append(getterName).append("() != null && !getDAO_().")
/*  433 */         .append(getterName).append("().equals(").append(obj).append("))) {\n");
/*  434 */       if (!StringUtils.isEmpty(argField.getEncrypt()) && "String".equalsIgnoreCase(argField.getType())) {
/*  435 */         out.append("      getDAO_().").append(setterName).append("(").append("encryptField(\"")
/*  436 */           .append(argField.getEncrypt()).append("\", ").append(obj).append("));\n");
/*      */       } else {
/*      */         
/*  439 */         out.append("      getDAO_().").append(setterName).append("(").append(obj).append(");\n");
/*      */       } 
/*      */       
/*  442 */       out.append("      ev_postable = true;\n");
/*      */     } else {
/*      */       
/*  445 */       out.append("\n").append("    if (super.").append(setterName).append("_noev(").append(arg)
/*  446 */         .append(")) {\n");
/*      */     } 
/*      */ 
/*      */     
/*  450 */     for (DtxRelationship rel : argDtx.getRelationships(DtxRelationship.ONE_MANY)) {
/*  451 */       for (DtxRelationship.DtxRelationshipField fld : rel.getFields()) {
/*  452 */         if (fld.getParent().equals(argField.getName())) {
/*  453 */           String properChild = StringUtils.ensureFirstUpperCase(fld.getChild());
/*  454 */           out.append("      if (" + rel.getParentAttributeName()).append(" != null) {\n");
/*  455 */           out.append("        // Propagate changes to related objects in relation " + rel.getName())
/*  456 */             .append(".\n");
/*  457 */           out.append("        java.util.Iterator it = " + rel.getParentAttributeName() + ".iterator();\n");
/*  458 */           out.append("        while(it.hasNext()) {\n");
/*  459 */           out.append("          // Use the non-eventing setter directly.\n");
/*  460 */           out.append("          ((" + rel.getChild().getModel() + ") it.next()).set" + properChild + "_noev(" + arg + ");\n");
/*      */           
/*  462 */           out.append("        }\n");
/*  463 */           out.append("      }\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  469 */     for (DtxRelationship rel : argDtx.getRelationships(DtxRelationship.ONE_ONE)) {
/*  470 */       if (!rel.getDependent()) {
/*      */         continue;
/*      */       }
/*  473 */       for (DtxRelationship.DtxRelationshipField fld : rel.getFields()) {
/*  474 */         if (fld.getParent().equals(argField.getName())) {
/*  475 */           String properChild = StringUtils.ensureFirstUpperCase(fld.getChild());
/*  476 */           out.append("      if (" + rel.getParentAttributeName()).append(" != null) {\n");
/*  477 */           out.append("        // Propagate changes to related objects in relation " + rel.getName())
/*  478 */             .append(".\n");
/*  479 */           out.append("          // Use the non-eventing setter directly.\n");
/*  480 */           out.append("          ((" + rel.getChild().getModel() + ")" + rel.getParentAttributeName() + ").set" + properChild + "_noev(" + arg + ");\n");
/*      */           
/*  482 */           out.append("      }\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  487 */     out.append("    }\n");
/*  488 */     out.append("\n");
/*  489 */     out.append("    return ev_postable;\n");
/*  490 */     out.append("  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateFooter(StringBuilder out, DtxDefinition dtx) {
/*  501 */     out.append("\n");
/*  502 */     out.append("}\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateHeader(StringBuilder out, DtxDefinition argDtx) {
/*  512 */     out.append("package " + argDtx.getPackage() + ";\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  517 */     out.append("import java.math.BigDecimal;\n");
/*  518 */     out.append("import java.util.*;\n");
/*  519 */     out.append("import dtv.data2.access.impl.*;\n");
/*      */ 
/*      */     
/*  522 */     if (this._baseModelClass != null) {
/*  523 */       out.append("import ");
/*  524 */       out.append(this._baseModelClass.getName());
/*  525 */       out.append(";\n");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  531 */     out.append("import dtv.data2.access.IDataModel;\n");
/*  532 */     out.append("import dtv.data2.access.ModelEventor;\n");
/*      */     
/*  534 */     boolean historicalListImported = false;
/*      */     
/*  536 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*  537 */       if (DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType())) {
/*  538 */         out.append("import " + relationship.getChild().getInterface() + ";\n");
/*      */         continue;
/*      */       } 
/*  541 */       if (!historicalListImported) {
/*  542 */         out.append("import dtv.util.HistoricalList;\n");
/*  543 */         out.append("import dtv.data2.access.*;\n");
/*      */         
/*  545 */         historicalListImported = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  553 */     if (!argDtx.isExtended()) {
/*  554 */       out.append("import ");
/*  555 */       out.append(argDtx.getId());
/*  556 */       out.append(";\n");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  562 */     out.append(this._helper.getClassCommentWithSuppressWarnings("Auto Generated Model"));
/*      */     
/*  564 */     out.append("public class ");
/*  565 */     out.append(argDtx.getName());
/*  566 */     out.append("Model \n");
/*      */     
/*  568 */     if (this._baseModelClass != null) {
/*  569 */       out.append("    extends ");
/*  570 */       out.append(this._baseModelClass.getSimpleName());
/*  571 */       out.append("\n");
/*      */       
/*  573 */       if (argDtx.isExtended() && 
/*  574 */         !this._baseModelClass.getSuperclass().getName().equals(argDtx.getExtends().getModel())) {
/*  575 */         throw new DtxException("A base data model was provided for a data model that is an extension of another, but the base data model was not declared to extend the ancestor data model. For instance, a NonPhysicalItemBaseModel must extend ItemModel since NonPhysicalItem extends Item.");
/*      */       }
/*      */ 
/*      */       
/*  579 */       if (DaoGenHelper.isPropertyChildNeeded(argDtx) && 
/*  580 */         !this._baseModelClass.getSuperclass().equals(AbstractDataModelWithPropertyImpl.class)) {
/*  581 */         throw new DtxException("A base data model [" + this._baseModelClass.getName() + "] was provided for a data model that requires a property child [" + argDtx
/*  582 */             .getModel() + "], but the base model does not extend " + AbstractDataModelWithPropertyImpl.class
/*  583 */             .getName() + ".");
/*      */       
/*      */       }
/*      */     }
/*  587 */     else if (argDtx.isExtended()) {
/*      */ 
/*      */       
/*  590 */       out.append("    extends ");
/*  591 */       out.append(argDtx.getExtends().getModel());
/*  592 */       out.append("\n");
/*      */     }
/*  594 */     else if (DaoGenHelper.isPropertyChildNeeded(argDtx)) {
/*  595 */       out.append("    extends ");
/*  596 */       out.append(AbstractDataModelWithPropertyImpl.class.getName());
/*  597 */       out.append("<");
/*  598 */       out.append(DaoGenHelper.getPropertyInterfaceName(argDtx));
/*  599 */       out.append(">\n");
/*      */     }
/*  601 */     else if (argDtx.isProperties()) {
/*  602 */       out.append("    extends ");
/*  603 */       out.append(AbstractDataModelPropertiesImpl.class.getName());
/*  604 */       out.append("\n");
/*      */     } else {
/*      */       
/*  607 */       out.append("    extends ");
/*  608 */       out.append(AbstractDataModelImpl.class.getName());
/*  609 */       out.append("\n");
/*      */     } 
/*      */     
/*  612 */     out.append("    implements ");
/*  613 */     out.append(argDtx.getInterface());
/*  614 */     out.append(" {\n\n  // Fix serialization compatability based on the name of the DAO\n  private static final long serialVersionUID = ");
/*      */ 
/*      */     
/*  617 */     out.append(argDtx.getName().hashCode());
/*  618 */     out.append("L;\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateNewPropertyMethod(StringBuilder out, DtxDefinition argDtx) {
/*  628 */     String propertyName = DaoGenHelper.getPropertyName(argDtx);
/*  629 */     DtxDefinition child = this._helper.getTypeNameDefinition(propertyName);
/*      */ 
/*      */     
/*  632 */     out.append("  protected ");
/*  633 */     out.append(child.getInterface());
/*  634 */     out.append(" newProperty(String argPropertyName)  {\n");
/*      */     
/*  636 */     out.append("    ");
/*  637 */     out.append(child.getId());
/*  638 */     out.append(" id = new ");
/*  639 */     out.append(child.getId());
/*  640 */     out.append("();\n\n");
/*      */     
/*  642 */     for (DtxDefinition.DtxDaoField field : argDtx.getPrimaryKeyFields()) {
/*  643 */       if (!field.getName().equals("organizationId")) {
/*  644 */         out.append("    id.");
/*  645 */         out.append(DaoGenUtils.getSetterNameForField(field));
/*  646 */         out.append("(");
/*  647 */         out.append(DaoGenUtils.wrapStatementWithObject(DaoGenUtils.getGetterNameForField(field) + "()", field.getType()));
/*  648 */         out.append(");\n");
/*      */       } 
/*      */     } 
/*      */     
/*  652 */     out.append("    id.setPropertyCode(argPropertyName);\n\n");
/*  653 */     out.append("    ");
/*  654 */     out.append(child.getInterface());
/*  655 */     out.append(" prop = dtv.data2.access.DataFactory.getInstance().createNewObject(id, ");
/*  656 */     out.append(child.getInterface());
/*  657 */     out.append(".class);\n");
/*  658 */     out.append("    return prop;\n");
/*  659 */     out.append("  }\n");
/*  660 */     out.append("\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateRelationshipFields(StringBuilder out, List<DtxRelationship> argRelationships) {
/*  672 */     for (DtxRelationship relationship : argRelationships) {
/*      */ 
/*      */       
/*  675 */       String typeName = DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType()) ? relationship.getChild().getInterfaceTypeOnly() : ("HistoricalList<" + relationship.getChild().getInterface() + ">");
/*  676 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*  677 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*  678 */       out.append("  private " + typeName + " " + fieldName + ";\n");
/*  679 */       out.append("  // So that rollback() reverts to proper value\n");
/*  680 */       out.append("  private transient " + typeName + " " + savepointFieldName + ";\n");
/*      */     } 
/*  682 */     out.append("\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateRelationshipMethods(StringBuilder out, DtxDefinition argDtx, List<DtxRelationship> argRelationships) {
/*  694 */     StringBuilder persistenceDefaultsBuilder = new StringBuilder();
/*      */     
/*  696 */     persistenceDefaultsBuilder.append("  @Override\n");
/*  697 */     persistenceDefaultsBuilder.append("  public void setDependencies(dtv.data2.IPersistenceDefaults argPD, dtv.event.EventManager argEM) {\n");
/*      */ 
/*      */     
/*  700 */     if (argDtx.getExtends() == null) {
/*  701 */       persistenceDefaultsBuilder.append("    _persistenceDefaults = argPD;\n");
/*  702 */       persistenceDefaultsBuilder.append("    _daoImpl.setPersistenceDefaults(argPD);\n");
/*  703 */       persistenceDefaultsBuilder.append("    _eventManager = argEM;\n");
/*  704 */       persistenceDefaultsBuilder.append("    _events = new ModelEventor(this, argEM);\n");
/*  705 */       persistenceDefaultsBuilder
/*  706 */         .append("    _eventCascade = new dtv.event.handler.CascadingHandler(this);\n");
/*      */     } else {
/*      */       
/*  709 */       persistenceDefaultsBuilder.append("    super.setDependencies(argPD, argEM);\n");
/*      */     } 
/*      */     
/*  712 */     for (DtxRelationship relationship : argRelationships) {
/*  713 */       DtxDefinition child = relationship.getChild();
/*  714 */       String argName = DaoGenUtils.getArgNameForRelationship(relationship);
/*  715 */       String typeName = DaoGenUtils.getTypeForRelationship(relationship, false);
/*  716 */       String getterName = DaoGenUtils.getGetterNameForRelationship(relationship);
/*  717 */       String setterName = DaoGenUtils.getSetterNameForRelationship(relationship);
/*  718 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/*  719 */       String relationshipName = StringUtils.ensureFirstUpperCase(relationship.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  724 */       persistenceDefaultsBuilder.append("    if (" + fieldName + " != null) {\n");
/*  725 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType()) || DtxRelationship.MANY_MANY
/*  726 */         .equalsIgnoreCase(relationship.getType())) {
/*  727 */         persistenceDefaultsBuilder.append("      for (")
/*  728 */           .append(relationship.getChild().getInterface() + " relationship : ").append(fieldName)
/*  729 */           .append(") {\n");
/*  730 */         persistenceDefaultsBuilder.append("        ((dtv.data2.access.impl.IDataModelImpl)relationship).setDependencies(argPD, argEM);\n");
/*      */         
/*  732 */         persistenceDefaultsBuilder.append("      }\n");
/*      */       } else {
/*      */         
/*  735 */         persistenceDefaultsBuilder.append("      ((dtv.data2.access.impl.IDataModelImpl)" + fieldName + ").setDependencies(argPD, argEM);\n");
/*      */       } 
/*      */       
/*  738 */       persistenceDefaultsBuilder.append("    }\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  746 */       Method baseModelGetter = getBaseModelMethod(getterName, new Class[0]);
/*  747 */       if (baseModelGetter == null) {
/*  748 */         out.append("  @Relationship(name=\"").append(relationshipName).append("\")\n");
/*  749 */         out.append("  public ").append(typeName).append(" ").append(getterName).append("() {\n");
/*  750 */         if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType()) || DtxRelationship.MANY_MANY
/*  751 */           .equalsIgnoreCase(relationship.getType())) {
/*  752 */           addListInitializer(out, relationship, "null", null);
/*      */         }
/*  754 */         out.append("    return ").append(fieldName).append(";\n");
/*  755 */         out.append("  }\n\n");
/*      */       } 
/*      */       
/*  758 */       if (DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType())) {
/*      */ 
/*      */ 
/*      */         
/*  762 */         out.append("  public void ").append(setterName).append("( ").append(child.getInterface());
/*  763 */         out.append(" ");
/*  764 */         out.append(argName);
/*  765 */         out.append(") {\n");
/*      */ 
/*      */         
/*      */         try {
/*  769 */           Class<?> parameterClass = this._helper.getPrecompileClassloader().loadClass(child.getInterface());
/*      */           
/*  771 */           if (getBaseModelMethod(setterName, new Class[] { parameterClass }) != null) {
/*  772 */             out.append("    super.");
/*  773 */             out.append(setterName);
/*  774 */             out.append("(");
/*  775 */             out.append(argName);
/*  776 */             out.append(");\n\n");
/*      */           }
/*      */         
/*  779 */         } catch (ClassNotFoundException ex) {
/*  780 */           throw new DtxException(child.getInterface() + " class was not found when generating data model [" + argDtx
/*  781 */               .getName() + "].");
/*      */         } 
/*      */         
/*  784 */         out.append("    // null out keys that define this relationship\n");
/*  785 */         out.append("    if( ");
/*  786 */         out.append(argName);
/*  787 */         out.append(" == null) {\n");
/*      */         
/*  789 */         if (relationship.getFieldsNotShared().isEmpty()) {
/*  790 */           out.append("      // all the fields that define this relationship are shared.  It cannot be broken.\n");
/*      */           
/*  792 */           out.append("      if (");
/*  793 */           out.append(fieldName);
/*  794 */           out.append(" != null) {\n");
/*  795 */           out.append("        throw new dtv.data2.access.exception.DtxException(\"An Attempt was made to break a ONE-ONE");
/*      */           
/*  797 */           out.append(" relationship that cannot be broken because all fields that define the relationship are");
/*      */           
/*  799 */           out.append(" primary keys on the parent data object.\");\n");
/*  800 */           out.append("      }\n");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  805 */         if (!relationship.getDependent()) {
/*  806 */           out.append("      // null out the keys that define this relationship of two independent objects.\n");
/*      */           
/*  808 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFieldsNotShared()) {
/*  809 */             out.append("      getDAO_().set");
/*  810 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  811 */             out.append("(null);\n");
/*      */           } 
/*      */         } 
/*      */         
/*  815 */         out.append("      if ( ");
/*  816 */         out.append(fieldName);
/*  817 */         out.append(" != null) {\n");
/*      */         
/*  819 */         out.append("        // De-register from the previous child.\n");
/*  820 */         out.append("        if (postEventsForChanges()) {\n");
/*  821 */         out.append("          _eventManager.deregisterEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */         
/*  823 */         out.append(fieldName).append("));\n");
/*  824 */         out.append("        }\n");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  829 */         if (relationship.getDependent()) {
/*  830 */           out.append("        super.addDeletedObject(");
/*  831 */           out.append(fieldName);
/*  832 */           out.append(");\n");
/*      */         } 
/*  834 */         out.append("      }\n    }\n    else {\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  842 */         if (relationship.getDependent()) {
/*  843 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFields()) {
/*  844 */             out.append("      ");
/*  845 */             out.append(argName);
/*  846 */             out.append(".set");
/*  847 */             out.append(StringUtils.ensureFirstUpperCase(field.getChild()));
/*  848 */             out.append("(this.get");
/*  849 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  850 */             out.append("());\n");
/*      */           } 
/*  852 */           out.append("\n");
/*      */         } else {
/*      */           
/*  855 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFieldsNotShared()) {
/*  856 */             DtxDefinition.DtxDaoField theRealField = relationship.getChild().findField(field.getChild());
/*      */             
/*  858 */             out.append("      getDAO_().set");
/*  859 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/*  860 */             out.append("(");
/*  861 */             out.append(DaoGenUtils.wrapStatementWithObject(argName + ".get" + 
/*  862 */                   StringUtils.ensureFirstUpperCase(field.getChild()) + "()", theRealField
/*  863 */                   .getType()));
/*  864 */             out.append(");\n");
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  870 */         DtxInverseRelationship inverseRelationship = child.getInverseRelationship(argDtx);
/*  871 */         if (inverseRelationship != null) {
/*  872 */           out.append("      // notify children with inverse relationships that they have a parent.\n");
/*  873 */           out.append("      " + argName + "." + inverseRelationship.getSetMethodName() + "(this);\n\n");
/*      */         } 
/*      */         
/*  876 */         out.append("      // Register the cascading event handler to receive events from the new child.\n      if (postEventsForChanges()) {\n        _eventManager.registerEventHandler(_eventCascade, new dtv.event.EventDescriptor(" + argName + "));\n      }\n    }\n\n    ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  883 */         out.append(fieldName);
/*  884 */         out.append(" = ");
/*  885 */         out.append(argName);
/*  886 */         out.append(";\n");
/*  887 */         out.append("    if (postEventsForChanges()) {\n");
/*  888 */         out.append("      _events.post(");
/*  889 */         out.append(argDtx.getInterface());
/*  890 */         out.append(".SET_");
/*  891 */         out.append(relationship.getName().toUpperCase());
/*  892 */         out.append(", ");
/*  893 */         out.append(argName);
/*  894 */         out.append(");\n");
/*  895 */         out.append("    }\n");
/*  896 */         out.append("  }\n\n");
/*      */         continue;
/*      */       } 
/*  899 */       if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType()) || DtxRelationship.MANY_MANY
/*  900 */         .equalsIgnoreCase(relationship.getType())) {
/*  901 */         String addRemoveArgName = DaoGenUtils.getArgNameForRelationshipAddRemove(relationship);
/*  902 */         String childInterface = relationship.getChild().getInterface();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  907 */         out.append("  public void ").append(setterName).append("( ").append(typeName);
/*  908 */         out.append(" ").append(argName).append(") {\n");
/*      */ 
/*      */         
/*  911 */         if (getBaseModelMethod(setterName, new Class[] { List.class }) != null) {
/*  912 */           out.append("    super.").append(setterName).append("(").append(argName).append(");\n\n");
/*      */         }
/*      */         
/*  915 */         addListInitializer(out, relationship, argName, argName);
/*      */ 
/*      */         
/*  918 */         DtxInverseRelationship inverseRelationship = child.getInverseRelationship(argDtx);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  923 */         if (inverseRelationship != null) {
/*  924 */           out.append("    // notify children with inverse relationships that they have a parent.\n");
/*  925 */           out.append("    for( ").append(childInterface).append(" child : ").append(fieldName)
/*  926 */             .append(") {\n");
/*  927 */           out.append("      child.").append(inverseRelationship.getSetMethodName()).append("(this);\n");
/*  928 */           out.append("    }\n\n");
/*      */         } 
/*      */ 
/*      */         
/*  932 */         String childType = child.getInterface();
/*  933 */         String childModel = child.getModel();
/*  934 */         if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType())) {
/*  935 */           out.append("    // Propagate identification information through the graph.\n");
/*  936 */           out.append("    for( ").append(childType).append(" child : ").append(fieldName).append(") {\n");
/*  937 */           out.append("      ").append(childModel).append(" model = (").append(childModel)
/*  938 */             .append(") child;\n");
/*      */           
/*  940 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFields()) {
/*  941 */             String parentName = StringUtils.ensureFirstUpperCase(field.getParent());
/*  942 */             String childName = StringUtils.ensureFirstUpperCase(field.getChild());
/*  943 */             out.append("      model.set").append(childName).append("_noev(this.get").append(parentName)
/*  944 */               .append("());\n");
/*      */           } 
/*      */           
/*  947 */           out.append("      if (child instanceof IDataModelImpl) {\n");
/*  948 */           out.append("        IDataAccessObject childDao = ((IDataModelImpl) child).getDAO();\n");
/*  949 */           out.append("        if (dtv.util.StringUtils.isEmpty(childDao.getOriginDataSource()) && \n");
/*  950 */           out.append("            !dtv.util.StringUtils.isEmpty(this.getDAO().getOriginDataSource())) {\n");
/*  951 */           out.append("          childDao.setOriginDataSource(this.getDAO().getOriginDataSource());\n");
/*  952 */           out.append("        }\n");
/*  953 */           out.append("      }\n");
/*      */ 
/*      */           
/*  956 */           out.append("      if (postEventsForChanges()) {\n");
/*  957 */           out.append("        _eventManager.registerEventHandler(_eventCascade, child);\n");
/*  958 */           out.append("      }\n");
/*  959 */           out.append("    }\n");
/*      */         } 
/*      */         
/*  962 */         out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  967 */         String adderMethodName = DaoGenUtils.getAdderNameForRelationship(relationship);
/*  968 */         out.append("  public void ");
/*  969 */         out.append(adderMethodName);
/*  970 */         out.append("(");
/*  971 */         out.append(relationship.getChild().getInterface());
/*  972 */         out.append(" ");
/*  973 */         out.append(addRemoveArgName);
/*  974 */         out.append(") {\n");
/*      */ 
/*      */         
/*      */         try {
/*  978 */           Class<?> parameterClass = this._helper.getPrecompileClassloader().loadClass(childInterface);
/*      */           
/*  980 */           if (getBaseModelMethod(adderMethodName, new Class[] { parameterClass }) != null) {
/*  981 */             out.append("    super.");
/*  982 */             out.append(adderMethodName);
/*  983 */             out.append("(");
/*  984 */             out.append(addRemoveArgName);
/*  985 */             out.append(");\n\n");
/*      */           }
/*      */         
/*  988 */         } catch (ClassNotFoundException ex) {
/*  989 */           throw new DtxException(childInterface + " class was not found when generating data model [" + argDtx
/*  990 */               .getName() + "].");
/*      */         } 
/*      */         
/*  993 */         if (inverseRelationship != null) {
/*  994 */           out.append("    // notify children with inverse relationships that they have a parent.\n");
/*  995 */           out.append("    ");
/*  996 */           out.append(addRemoveArgName);
/*  997 */           out.append(".");
/*  998 */           out.append(inverseRelationship.getSetMethodName());
/*  999 */           out.append("(this);\n");
/*      */         } 
/*      */         
/* 1002 */         addListInitializer(out, relationship, "null", null);
/*      */ 
/*      */         
/* 1005 */         if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType())) {
/* 1006 */           for (DtxRelationship.DtxRelationshipField field : relationship.getFields()) {
/* 1007 */             out.append("    ");
/* 1008 */             out.append(addRemoveArgName);
/* 1009 */             out.append(".set");
/* 1010 */             out.append(StringUtils.ensureFirstUpperCase(field.getChild()));
/* 1011 */             out.append("(this.get");
/* 1012 */             out.append(StringUtils.ensureFirstUpperCase(field.getParent()));
/* 1013 */             out.append("());\n");
/*      */           } 
/*      */ 
/*      */           
/* 1017 */           out.append("    if (");
/* 1018 */           out.append(addRemoveArgName);
/* 1019 */           out.append(" instanceof IDataModelImpl) {\n");
/* 1020 */           out.append("      IDataAccessObject childDao = ((IDataModelImpl) ");
/* 1021 */           out.append(addRemoveArgName);
/* 1022 */           out.append(").getDAO();\n");
/* 1023 */           out.append("      if (dtv.util.StringUtils.isEmpty(childDao.getOriginDataSource()) && \n");
/* 1024 */           out.append("          !dtv.util.StringUtils.isEmpty(this.getDAO().getOriginDataSource())) {\n");
/* 1025 */           out.append("        childDao.setOriginDataSource(this.getDAO().getOriginDataSource());\n");
/* 1026 */           out.append("      }\n");
/* 1027 */           out.append("    }\n\n");
/*      */           
/* 1029 */           out.append("    // Register the _handleChildEvent method to receive events from the new child.\n");
/* 1030 */           out.append("    if (postEventsForChanges()) {\n");
/* 1031 */           out.append("      _eventManager.registerEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */           
/* 1033 */           out.append(addRemoveArgName + "));\n");
/* 1034 */           out.append("    }\n\n");
/*      */         } 
/*      */         
/* 1037 */         out.append("    ");
/* 1038 */         out.append(fieldName);
/* 1039 */         out.append(".add(");
/* 1040 */         out.append(addRemoveArgName);
/* 1041 */         out.append(");\n");
/* 1042 */         out.append("    if (postEventsForChanges()) {\n");
/* 1043 */         out.append("      _events.post(");
/* 1044 */         out.append(argDtx.getInterface());
/* 1045 */         out.append(".ADD_");
/* 1046 */         out.append(relationship.getName().toUpperCase());
/* 1047 */         out.append(", ");
/* 1048 */         out.append(addRemoveArgName);
/* 1049 */         out.append(");\n");
/* 1050 */         out.append("    }\n");
/* 1051 */         out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1056 */         String removerMethodName = DaoGenUtils.getRemoverNameForRelationship(relationship);
/* 1057 */         out.append("  public void ");
/* 1058 */         out.append(DaoGenUtils.getRemoverNameForRelationship(relationship));
/* 1059 */         out.append("(");
/* 1060 */         out.append(relationship.getChild().getInterface());
/* 1061 */         out.append(" ");
/* 1062 */         out.append(addRemoveArgName);
/* 1063 */         out.append(") {\n");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1069 */           Class<?> parameterClass = this._helper.getPrecompileClassloader().loadClass(childInterface);
/*      */           
/* 1071 */           if (getBaseModelMethod(removerMethodName, new Class[0]) != null) {
/* 1072 */             out.append("    super.");
/* 1073 */             out.append(removerMethodName);
/* 1074 */             out.append("(");
/* 1075 */             out.append(addRemoveArgName);
/* 1076 */             out.append(");\n\n");
/*      */           }
/*      */         
/* 1079 */         } catch (ClassNotFoundException ex) {
/* 1080 */           throw new DtxException(childInterface + " class was not found when generating data model [" + argDtx
/* 1081 */               .getName() + "].");
/*      */         } 
/*      */         
/* 1084 */         out.append("    if (");
/* 1085 */         out.append(fieldName);
/* 1086 */         out.append(" != null) {\n");
/* 1087 */         out.append("    // De-Register the _handleChildEvent method from receiving the child events.\n");
/* 1088 */         out.append("    if (postEventsForChanges()) {\n");
/* 1089 */         out.append("      _eventManager.deregisterEventHandler(_eventCascade, new dtv.event.EventDescriptor(");
/*      */         
/* 1091 */         out.append(addRemoveArgName + "));\n");
/* 1092 */         out.append("    }\n");
/* 1093 */         out.append("      ");
/* 1094 */         out.append(fieldName);
/* 1095 */         out.append(".remove(");
/* 1096 */         out.append(addRemoveArgName);
/* 1097 */         out.append(");\n");
/*      */         
/* 1099 */         if (inverseRelationship != null) {
/* 1100 */           out.append("    // notify children with inverse relationships that they have a parent.\n");
/* 1101 */           out.append("    ").append(addRemoveArgName).append(".")
/* 1102 */             .append(inverseRelationship.getSetMethodName()).append("(null);\n");
/*      */         } 
/*      */         
/* 1105 */         out.append("      if (postEventsForChanges()) {\n");
/* 1106 */         out.append("        _events.post(");
/* 1107 */         out.append(argDtx.getInterface());
/* 1108 */         out.append(".REMOVE_");
/* 1109 */         out.append(relationship.getName().toUpperCase());
/* 1110 */         out.append(", ");
/* 1111 */         out.append(addRemoveArgName);
/* 1112 */         out.append(");\n");
/* 1113 */         out.append("      }\n");
/* 1114 */         out.append("    }\n  }\n\n");
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1119 */       throw new Error("*** UNKNOWN RELATIONSHIP TYPE: " + relationship.getType() + " in file: " + argDtx
/* 1120 */           .getSourceDtxFile().getAbsolutePath());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1128 */     for (DtxInverseRelationship inverseRelationship : argDtx.getInverseRelationships()) {
/*      */       
/* 1130 */       String argName = "arg" + StringUtils.ensureFirstUpperCase(inverseRelationship.getName());
/* 1131 */       String fieldName = "_" + StringUtils.ensureFirstLowerCase(inverseRelationship.getName());
/*      */       
/* 1133 */       out.append("  public void ");
/* 1134 */       out.append(inverseRelationship.getSetMethodName());
/* 1135 */       out.append("(");
/* 1136 */       out.append(inverseRelationship.getParent().getInterface());
/* 1137 */       out.append(" ");
/* 1138 */       out.append(argName);
/* 1139 */       out.append(") {\n    ");
/*      */       
/* 1141 */       out.append(fieldName);
/* 1142 */       out.append(" = ");
/* 1143 */       out.append(argName);
/* 1144 */       out.append(";\n  }\n\n  public ");
/*      */ 
/*      */ 
/*      */       
/* 1148 */       out.append(inverseRelationship.getParent().getInterface());
/* 1149 */       out.append(" ");
/* 1150 */       out.append(inverseRelationship.getGetMethodName());
/* 1151 */       out.append("() {\n    return " + fieldName + ";\n  }\n\n");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1162 */     out.append("  @Override\n  public Object getValue(String argFieldId) {\n");
/*      */ 
/*      */     
/* 1165 */     boolean ifPrinted = false;
/* 1166 */     for (DtxRelationship relationship : argRelationships) {
/*      */       
/* 1168 */       if (!ifPrinted) {
/* 1169 */         out.append("    if (");
/* 1170 */         ifPrinted = true;
/*      */       } else {
/*      */         
/* 1173 */         out.append("    else if (");
/*      */       } 
/*      */       
/* 1176 */       out.append("\"");
/* 1177 */       out.append(StringUtils.ensureFirstUpperCase(relationship.getName()));
/* 1178 */       out.append("\".equals(argFieldId)) {\n      return ");
/*      */       
/* 1180 */       out.append(DaoGenUtils.getGetterNameForRelationship(relationship));
/* 1181 */       out.append("();\n    }\n");
/*      */     } 
/*      */ 
/*      */     
/* 1185 */     if (argRelationships.size() == 0) {
/* 1186 */       out.append("    if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } else {
/*      */       
/* 1189 */       out.append("    else if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } 
/*      */     
/* 1192 */     out.append("      return _myExtension;\n");
/* 1193 */     out.append("    }\n");
/*      */     
/* 1195 */     out.append("    else {\n      return super.getValue(argFieldId);\n    }\n  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1205 */     out.append("  @Override\n  public void setValue(String argFieldId, Object argValue) {\n");
/*      */ 
/*      */     
/* 1208 */     ifPrinted = false;
/* 1209 */     for (DtxRelationship relationship : argRelationships) {
/*      */       
/* 1211 */       if (!ifPrinted) {
/* 1212 */         out.append("    if (");
/* 1213 */         ifPrinted = true;
/*      */       } else {
/*      */         
/* 1216 */         out.append("    else if (");
/*      */       } 
/*      */       
/* 1219 */       out.append("\"");
/* 1220 */       out.append(StringUtils.ensureFirstUpperCase(relationship.getName()));
/* 1221 */       out.append("\".equals(argFieldId)) {\n");
/*      */       
/* 1223 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1224 */         out.append("      ");
/* 1225 */         out.append(DaoGenUtils.getSetterNameForRelationship(relationship));
/* 1226 */         out.append("((");
/* 1227 */         out.append(relationship.getChild().getInterface());
/* 1228 */         out.append(")argValue);\n");
/*      */       } else {
/*      */         
/* 1231 */         out.append("      ");
/* 1232 */         out.append(DaoGenUtils.getSetterNameForRelationship(relationship));
/* 1233 */         out.append("(changeToList(argValue,");
/* 1234 */         out.append(relationship.getChild().getInterface());
/* 1235 */         out.append(".class));\n");
/*      */       } 
/*      */       
/* 1238 */       out.append("    }\n");
/*      */     } 
/*      */     
/* 1241 */     if (argRelationships.size() == 0) {
/* 1242 */       out.append("    if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } else {
/*      */       
/* 1245 */       out.append("    else if (\"" + argDtx.getName() + "Extension\".equals(argFieldId)) {\n");
/*      */     } 
/*      */     
/* 1248 */     out.append("      _myExtension = (IDataModel)argValue;\n");
/* 1249 */     out.append("    }\n");
/*      */     
/* 1251 */     out.append("    else {\n      super.setValue(argFieldId, argValue);\n    }\n  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1258 */     persistenceDefaultsBuilder.append("  }\n\n");
/* 1259 */     out.append(persistenceDefaultsBuilder.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateTransactionMethods(StringBuilder out, DtxDefinition argDtx) {
/* 1276 */     out.append("  @Override\n  public void startTransaction() {\n    if (_alreadyInStart) {\n      return;\n    }\n    else {\n      _alreadyInStart = true;\n    }\n\n    super.startTransaction();\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1288 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*      */       
/* 1290 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/* 1291 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*      */ 
/*      */       
/* 1294 */       out.append("    ");
/* 1295 */       out.append(savepointFieldName);
/* 1296 */       out.append(" = ");
/* 1297 */       out.append(fieldName);
/* 1298 */       out.append(";\n    if (");
/*      */       
/* 1300 */       out.append(fieldName);
/* 1301 */       out.append(" != null) {\n");
/*      */       
/* 1303 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1304 */         out.append("      ");
/* 1305 */         out.append(fieldName);
/* 1306 */         out.append(".startTransaction();\n");
/*      */       }
/* 1308 */       else if ("One-Many".equalsIgnoreCase(relationship.getType()) || "Many-Many"
/* 1309 */         .equalsIgnoreCase(relationship.getType())) {
/*      */ 
/*      */         
/* 1312 */         out.append("      ");
/* 1313 */         out.append(savepointFieldName);
/* 1314 */         out.append(" = new HistoricalList<");
/* 1315 */         out.append(relationship.getChild().getInterface());
/* 1316 */         out.append(">(");
/* 1317 */         out.append(fieldName);
/* 1318 */         out.append(");\n      java.util.Iterator it = ");
/*      */         
/* 1320 */         out.append(fieldName);
/* 1321 */         out.append(".iterator();\n      while (it.hasNext()) {\n        ((dtv.data2.access.IDataModel)it.next()).startTransaction();\n      }\n");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1326 */       out.append("    }\n\n");
/*      */     } 
/*      */     
/* 1329 */     out.append("    \n    _alreadyInStart = false;\n  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1337 */     out.append("  @Override\n  public void rollbackChanges() {\n    if (isAlreadyRolledBack())\n      return;\n\n    super.rollbackChanges();\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1345 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*      */       
/* 1347 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/* 1348 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*      */ 
/*      */       
/* 1351 */       out.append("    ");
/* 1352 */       out.append(fieldName);
/* 1353 */       out.append(" = ");
/* 1354 */       out.append(savepointFieldName);
/* 1355 */       out.append(";\n    ");
/*      */       
/* 1357 */       out.append(savepointFieldName);
/* 1358 */       out.append(" = null;\n    if (");
/*      */       
/* 1360 */       out.append(fieldName);
/* 1361 */       out.append(" != null) {\n");
/*      */       
/* 1363 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1364 */         out.append("      ");
/* 1365 */         out.append(fieldName);
/* 1366 */         out.append(".rollbackChanges();\n");
/*      */       }
/* 1368 */       else if ("One-Many".equalsIgnoreCase(relationship.getType()) || "Many-Many"
/* 1369 */         .equalsIgnoreCase(relationship.getType())) {
/*      */         
/* 1371 */         out.append("      java.util.Iterator it = ");
/* 1372 */         out.append(fieldName);
/* 1373 */         out.append(".iterator();\n      while (it.hasNext()) {\n        ((dtv.data2.access.IDataModel)it.next()).rollbackChanges();\n      }\n");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1379 */       out.append("    }\n\n");
/*      */     } 
/*      */     
/* 1382 */     out.append("  }\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1387 */     out.append("  @Override\n  public void commitTransaction() {\n    if (_alreadyInCommit) {\n      return;\n    } else {\n      _alreadyInCommit = true;\n    }\n\n    super.commitTransaction();\n\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1398 */     for (DtxRelationship relationship : argDtx.getRelationships()) {
/*      */       
/* 1400 */       String fieldName = DaoGenUtils.getFieldNameForRelationship(relationship);
/* 1401 */       String savepointFieldName = DaoGenUtils.getFieldNameForRelationship(relationship) + "Savepoint";
/*      */ 
/*      */       
/* 1404 */       out.append("    ");
/* 1405 */       out.append(savepointFieldName);
/* 1406 */       out.append(" = ");
/* 1407 */       out.append(fieldName);
/* 1408 */       out.append(";\n    if (");
/*      */       
/* 1410 */       out.append(fieldName);
/* 1411 */       out.append(" != null) {\n");
/*      */       
/* 1413 */       if ("One-One".equalsIgnoreCase(relationship.getType())) {
/* 1414 */         out.append("      ");
/* 1415 */         out.append(fieldName);
/* 1416 */         out.append(".commitTransaction();\n");
/*      */       }
/* 1418 */       else if ("One-Many".equalsIgnoreCase(relationship.getType()) || "Many-Many"
/* 1419 */         .equalsIgnoreCase(relationship.getType())) {
/*      */ 
/*      */         
/* 1422 */         out.append("      java.util.Iterator it = ");
/* 1423 */         out.append(fieldName);
/* 1424 */         out.append(".iterator();\n      while (it.hasNext()) {\n        ((dtv.data2.access.IDataModel)it.next()).commitTransaction();\n      }\n");
/*      */ 
/*      */ 
/*      */         
/* 1428 */         out.append("      ");
/* 1429 */         out.append(fieldName);
/* 1430 */         out.append(" = new HistoricalList<");
/* 1431 */         out.append(relationship.getChild().getInterface());
/* 1432 */         out.append(">(");
/* 1433 */         out.append(fieldName);
/* 1434 */         out.append(");\n");
/*      */       } 
/* 1436 */       out.append("    }\n\n");
/*      */     } 
/*      */     
/* 1439 */     for (int i = 0; i < (argDtx.getFields()).length; i++) {
/* 1440 */       DtxDefinition.DtxDaoField field = argDtx.getFields()[i];
/*      */       
/* 1442 */       if (field.getIncrementField()) {
/* 1443 */         out.append("    getDAO_().setInit");
/* 1444 */         out.append(StringUtils.ensureFirstUpperCase(field.getName()));
/* 1445 */         out.append("(");
/* 1446 */         out.append(DaoGenUtils.wrapStatementWithObject(DaoGenUtils.getGetterNameForField(field) + "()", field.getType()));
/* 1447 */         out.append(");\n");
/*      */         
/* 1449 */         if (i == (argDtx.getFields()).length - 1) {
/* 1450 */           out.append("\n");
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1455 */     out.append("    \n    _alreadyInCommit = false;\n  }\n\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Method getBaseModelMethod(String argMethodName, Class<?>... argParameterTypes) {
/* 1469 */     Method method = null;
/*      */     
/* 1471 */     if (this._baseModelClass != null) {
/*      */       try {
/* 1473 */         method = this._baseModelClass.getDeclaredMethod(argMethodName, argParameterTypes);
/* 1474 */         return method;
/*      */       }
/* 1476 */       catch (NoSuchMethodException noSuchMethodException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1481 */     return method;
/*      */   }
/*      */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\ModelGeneratorWithJavaDtj.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */