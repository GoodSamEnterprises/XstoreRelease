/*    */ package dtv.data2.access.impl.jdbc;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JNDIConnectionProvider
/*    */   implements JDBCConnectionProvider
/*    */ {
/*    */   static final String JNDI_URL_PREFIX = "jndi:";
/*    */   private final String _datasourceName;
/*    */   private final DataSource _jndiDatasource;
/*    */   
/*    */   protected JNDIConnectionProvider(JDBCConnectionTemplate argTemplate) throws NamingException {
/* 35 */     String jndiUrl = argTemplate.getUrl().replaceFirst("jndi:", "");
/* 36 */     Context initContext = new InitialContext();
/*    */     try {
/* 38 */       this._jndiDatasource = (DataSource)initContext.lookup(jndiUrl);
/*    */     } finally {
/*    */       
/* 41 */       initContext.close();
/*    */     } 
/* 43 */     this._datasourceName = argTemplate.getDataSourceName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Connection getConnection() throws SQLException {
/* 50 */     return this._jndiDatasource.getConnection();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 56 */     return this._datasourceName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPoolSize() {
/* 62 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JNDIConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */