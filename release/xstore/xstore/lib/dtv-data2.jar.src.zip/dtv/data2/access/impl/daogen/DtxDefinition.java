/*      */ package dtv.data2.access.impl.daogen;
/*      */ 
/*      */ import dtv.util.ArrayUtils;
/*      */ import dtv.util.StringUtils;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DtxDefinition
/*      */ {
/*   22 */   private static final Logger _logger = Logger.getLogger(DtxDefinition.class);
/*   23 */   private final List<DtxDaoField> fields_ = new ArrayList<>();
/*      */   
/*      */   private String name_;
/*      */   private String package_;
/*      */   private String table_;
/*      */   private boolean extensible_ = false;
/*      */   private String extendsString_;
/*      */   private DtxDefinition extends_;
/*      */   private File sourceDtxFile_;
/*      */   private File dtj_;
/*   33 */   private List<DtxRelationship> relationships_ = new ArrayList<>();
/*   34 */   private List<DtxInverseRelationship> inverseRelationships_ = new ArrayList<>();
/*   35 */   private String implements_ = null;
/*   36 */   private String _modelGenerator = DefaultModelGenerator.class.getName();
/*      */ 
/*      */   
/*      */   private boolean isProperties = false;
/*      */ 
/*      */   
/*      */   private boolean customerExtension_ = false;
/*      */ 
/*      */   
/*      */   private boolean placeHolder_;
/*      */   
/*      */   private boolean needsGeneration_ = true;
/*      */ 
/*      */   
/*      */   public void addField(DtxDaoField argField) {
/*   51 */     this.fields_.add(argField);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRelationship(DtxRelationship argRelationship) {
/*   60 */     argRelationship.setParent(this);
/*   61 */     this.relationships_.add(argRelationship);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDaoField findField(String argFieldName) {
/*   71 */     DtxDaoField[] fields = getFields();
/*      */     
/*   73 */     for (DtxDaoField field : fields) {
/*   74 */       if (field.getName().equals(argFieldName)) {
/*   75 */         return field;
/*      */       }
/*      */     } 
/*      */     
/*   79 */     if (isExtended()) {
/*   80 */       return this.extends_.findField(argFieldName);
/*      */     }
/*      */     
/*   83 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDaoField[] getAllFields() {
/*   92 */     if (isExtended()) {
/*   93 */       DtxDaoField[] parentFields = this.extends_.getAllFields();
/*   94 */       DtxDaoField[] myFields = getFields();
/*      */       
/*   96 */       return (DtxDaoField[])ArrayUtils.combine(DtxDaoField.class, (Object[])parentFields, (Object[])myFields);
/*      */     } 
/*      */     
/*   99 */     return getFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DtxRelationship> getAllRelationships() {
/*  110 */     if (isExtended()) {
/*  111 */       List<DtxRelationship> parentRels = this.extends_.getAllRelationships();
/*  112 */       List<DtxRelationship> myRels = getRelationships();
/*  113 */       List<DtxRelationship> allRels = new ArrayList<>();
/*  114 */       allRels.addAll(parentRels);
/*  115 */       allRels.addAll(myRels);
/*      */       
/*  117 */       return allRels;
/*      */     } 
/*      */     
/*  120 */     return getRelationships();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCleanbeanClassname() {
/*  130 */     return getCleanbeanPackageRaw() + "." + getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCleanbeanPackageRaw() {
/*  139 */     if (this.package_.contains(".dao.")) {
/*  140 */       return this.package_.replace(".dao.", ".cleanbean.");
/*      */     }
/*  142 */     return this.package_ + ".cleanbean";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getColumnForFieldName(String argFieldName) {
/*  153 */     DtxDaoField field = findField(argFieldName);
/*      */     
/*  155 */     if (field == null) {
/*  156 */       throw new RuntimeException("Could not get column name for field: " + argFieldName + " on dtx: " + 
/*  157 */           getName());
/*      */     }
/*      */     
/*  160 */     return field.getColumn();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDao() {
/*  169 */     return getPackage() + "." + getName() + "DAO";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDba() {
/*  178 */     return getPackage() + "." + getName() + "DBA";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getDtj() {
/*  187 */     return this.dtj_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDefinition getExtends() {
/*  196 */     return this.extends_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getExtendsStringType() {
/*  205 */     return this.extendsString_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDaoField[] getFields() {
/*  214 */     return this.fields_.<DtxDaoField>toArray(new DtxDaoField[this.fields_.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDaoField[] getFieldsPlusInheritedPrimaryKeys() {
/*  223 */     if (!isExtended() || this.extends_.isPlaceHolder()) {
/*  224 */       return getFields();
/*      */     }
/*      */     
/*  227 */     List<DtxDaoField> fieldsPlusPrimarys = new ArrayList<>();
/*  228 */     for (DtxDaoField key : getPrimaryKeyFields()) {
/*  229 */       fieldsPlusPrimarys.add(key);
/*      */     }
/*      */     
/*  232 */     for (DtxDaoField f : this.fields_) {
/*  233 */       fieldsPlusPrimarys.add(f);
/*      */     }
/*      */     
/*  236 */     return fieldsPlusPrimarys.<DtxDaoField>toArray(new DtxDaoField[fieldsPlusPrimarys.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getId() {
/*  246 */     return getId(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getIdType() {
/*  255 */     if (!isExtended()) {
/*  256 */       return getName() + "Id";
/*      */     }
/*      */     
/*  259 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getImplementingClassField() {
/*  269 */     return getImplementingClassField(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getImplementingClassField(boolean argTraverseTree) {
/*  279 */     for (DtxDaoField field : this.fields_) {
/*  280 */       if ("className".equalsIgnoreCase(field.getName())) {
/*  281 */         return field.getName();
/*      */       }
/*      */     } 
/*      */     
/*  285 */     if (argTraverseTree && isExtended()) {
/*  286 */       return this.extends_.getImplementingClassField();
/*      */     }
/*      */     
/*  289 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getImplements() {
/*  298 */     return this.implements_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInterface() {
/*  307 */     return getInterfacePackage() + "." + getInterfaceTypeOnly();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInterfacePackage() {
/*  316 */     return getPackage().replaceAll(".impl", "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInterfaceTypeOnly() {
/*  325 */     return "I" + getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxInverseRelationship getInverseRelationship(DtxDefinition argPotentialParent) {
/*  336 */     DtxInverseRelationship[] inverseRels = getInverseRelationships();
/*      */     
/*  338 */     for (DtxInverseRelationship inverseRel : inverseRels) {
/*  339 */       if (inverseRel.getParent().getName().equals(argPotentialParent.getName())) {
/*  340 */         return inverseRel;
/*      */       }
/*      */     } 
/*  343 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxInverseRelationship[] getInverseRelationships() {
/*  352 */     return this.inverseRelationships_.<DtxInverseRelationship>toArray(new DtxInverseRelationship[this.inverseRelationships_.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getModel() {
/*  361 */     return getPackage() + "." + getName() + "Model";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getModelGenerator() {
/*  370 */     return this._modelGenerator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  379 */     return this.name_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DtxDaoField> getNonPkFields() {
/*  388 */     if (this.fields_ == null) {
/*  389 */       return new ArrayList<>(0);
/*      */     }
/*      */     
/*  392 */     List<DtxDaoField> nonPkFields = new ArrayList<>(this.fields_.size());
/*      */     
/*  394 */     for (DtxDaoField field : this.fields_) {
/*  395 */       if (!field.isPrimaryKey()) {
/*  396 */         nonPkFields.add(field);
/*      */       }
/*      */     } 
/*      */     
/*  400 */     return nonPkFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPackage() {
/*  409 */     return this.package_ + ".impl";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPackageDomain() {
/*  418 */     return this.package_.substring(this.package_.lastIndexOf('.') + 1, this.package_.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPackageRaw() {
/*  427 */     return this.package_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDaoField[] getPrimaryKeyFields() {
/*  436 */     if (isExtended() && !this.extends_.isPlaceHolder()) {
/*  437 */       return this.extends_.getPrimaryKeyFields();
/*      */     }
/*      */     
/*  440 */     return getPrimaryKeyFieldsRaw();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDaoField[] getPrimaryKeyFieldsRaw() {
/*  449 */     List<DtxDaoField> primaryKeys = new ArrayList<>(5);
/*      */     
/*  451 */     for (DtxDaoField field : this.fields_) {
/*  452 */       if (field.isPrimaryKey()) {
/*  453 */         primaryKeys.add(field);
/*      */       }
/*      */     } 
/*      */     
/*  457 */     return primaryKeys.<DtxDaoField>toArray(new DtxDaoField[primaryKeys.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DtxRelationship> getRelationships() {
/*  466 */     return this.relationships_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DtxRelationship> getRelationships(String argType) {
/*  476 */     List<DtxRelationship> tempList = new ArrayList<>();
/*  477 */     for (DtxRelationship rel : this.relationships_) {
/*  478 */       if (rel.getType().equalsIgnoreCase(argType)) {
/*  479 */         tempList.add(rel);
/*      */       }
/*      */     } 
/*      */     
/*  483 */     return tempList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getSourceDtxFile() {
/*  492 */     return this.sourceDtxFile_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTable() {
/*  501 */     return this.table_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DtxDefinition getTopMostParent() {
/*  510 */     if (isExtended()) {
/*  511 */       return this.extends_.getTopMostParent();
/*      */     }
/*      */     
/*  514 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasIncrementalField() {
/*  524 */     for (DtxDaoField field : this.fields_) {
/*  525 */       if (field.getIncrementField()) {
/*  526 */         return true;
/*      */       }
/*      */     } 
/*      */     
/*  530 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCustomerExtension() {
/*  544 */     return this.customerExtension_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isExtended() {
/*  553 */     return (this.extends_ != null && !isCustomerExtension());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isExtensible() {
/*  562 */     return this.extensible_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOrgHierarchical() {
/*  571 */     return DaoGenOrgHierarchyHelper.isOrgHierarchical(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPlaceHolder() {
/*  580 */     return this.placeHolder_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isProperties() {
/*  589 */     return this.isProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needsGeneration(File argFile) {
/*  599 */     return this.needsGeneration_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomerExtension(boolean argCustomerExtension) {
/*  613 */     this.customerExtension_ = argCustomerExtension;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExtends(DtxDefinition argExtends) {
/*  622 */     this.extends_ = argExtends;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExtendsString(String argExtendsString) {
/*  631 */     this.extendsString_ = argExtendsString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExtensible(boolean argExtensible) {
/*  640 */     this.extensible_ = argExtensible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImplements(String impl) {
/*  649 */     this.implements_ = impl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInverseRelationships(List<DtxInverseRelationship> argInverseRelationships) {
/*  658 */     this.inverseRelationships_ = argInverseRelationships;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIsProperties(boolean isProps) {
/*  667 */     this.isProperties = isProps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setModelGenerator(String argModelGenerator) {
/*  676 */     this._modelGenerator = argModelGenerator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String argName) {
/*  685 */     this.name_ = argName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNeedsGeneration(boolean argNeedsGeneration) {
/*  694 */     this.needsGeneration_ = argNeedsGeneration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPackage(String argPackage) {
/*  703 */     this.package_ = argPackage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlaceHolder(boolean argPlaceHolder) {
/*  712 */     this.placeHolder_ = argPlaceHolder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRelationships(List<DtxRelationship> argRelationships) {
/*  721 */     if (argRelationships != null) {
/*  722 */       for (DtxRelationship r : argRelationships) {
/*  723 */         r.setParent(this);
/*      */       }
/*      */     }
/*      */     
/*  727 */     this.relationships_ = argRelationships;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceDtxFile(File argSourceDtxFile) {
/*  736 */     this.sourceDtxFile_ = argSourceDtxFile;
/*  737 */     this.dtj_ = new File(this.sourceDtxFile_.getPath().replaceAll("\\.dtx$", ".dtj"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(String argTable) {
/*  746 */     this.table_ = argTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() {
/*  755 */     if (StringUtils.isEmpty(getName())) {
/*  756 */       throw new RuntimeException("DTX: " + 
/*  757 */           getSourceDtxFile().getAbsolutePath() + " does not define a DAO name.");
/*      */     }
/*  759 */     if (StringUtils.isEmpty(getTable())) {
/*  760 */       throw new RuntimeException("DTX: " + 
/*  761 */           getSourceDtxFile().getAbsolutePath() + " does not define a table.");
/*      */     }
/*  763 */     if (StringUtils.isEmpty(getPackage())) {
/*  764 */       throw new RuntimeException("DTX: " + 
/*  765 */           getSourceDtxFile().getAbsolutePath() + " does not define a package.");
/*      */     }
/*  767 */     if ((getPrimaryKeyFields()).length < 1) {
/*  768 */       _logger
/*  769 */         .warn("DTX: " + getSourceDtxFile().getAbsolutePath() + " does not define any primary key fields.");
/*      */     }
/*  771 */     if (isExtensible() && StringUtils.isEmpty(getImplementingClassField())) {
/*  772 */       throw new RuntimeException("DTX: " + getSourceDtxFile().getAbsolutePath() + " is marked as extensible, but does not declare a className field");
/*      */     }
/*      */     
/*  775 */     if (!isExtensible() && !StringUtils.isEmpty(getImplementingClassField(false))) {
/*  776 */       throw new RuntimeException("DTX: " + getSourceDtxFile().getAbsolutePath() + " is NOT marked as extensible, but declares a className field");
/*      */     }
/*      */     
/*  779 */     if (!isExtensible() && !StringUtils.isEmpty(getImplementingClassField(false))) {
/*  780 */       throw new RuntimeException("DTX: " + getSourceDtxFile().getAbsolutePath() + " is NOT marked as extensible, but declares a className field");
/*      */     }
/*      */ 
/*      */     
/*  784 */     if ("dtv.data2.access.IDataModel".equals(getImplements())) {
/*  785 */       throw new RuntimeException("DTX: " + getSourceDtxFile().getAbsolutePath() + " should not declare 'implements dtv.data2.access.IDataModel' because this is implied. Remove the implements attribute if needed");
/*      */     }
/*      */ 
/*      */     
/*  789 */     if (!StringUtils.isEmpty(getId(false)) && isExtended()) {
/*  790 */       throw new RuntimeException("DTX: " + getSourceDtxFile().getAbsolutePath() + " should not declare an ID because it is a child of another dtx.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  796 */     if (isExtended() && (getPrimaryKeyFieldsRaw()).length > 0 && !this.extends_.isPlaceHolder()) {
/*  797 */       throw new RuntimeException("DTX: " + getSourceDtxFile().getAbsolutePath() + " declares primary key fields, but should not because it is a child.  It inherits the PARENTS primary key fields.");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  803 */       for (DtxDaoField f : this.fields_) {
/*  804 */         f.validate();
/*      */       }
/*      */       
/*  807 */       for (DtxRelationship r : getRelationships()) {
/*  808 */         r.validate();
/*  809 */         if (r.getName().equals(getName() + "Extension")) {
/*  810 */           throw new RuntimeException("DTX: " + 
/*  811 */               getSourceDtxFile().getAbsolutePath() + " contains an illegal retlationship name: " + r
/*  812 */               .getName() + ". This is a reserved relationship name.");
/*      */         }
/*      */       } 
/*      */       
/*  816 */       for (DtxInverseRelationship ir : this.inverseRelationships_) {
/*  817 */         ir.validate();
/*      */       }
/*      */     }
/*  820 */     catch (Exception ee) {
/*  821 */       throw new RuntimeException("Validation failed for DTX: " + getSourceDtxFile().getAbsolutePath(), ee);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String getId(boolean argSearchParents) {
/*  826 */     if (isExtended()) {
/*  827 */       if (argSearchParents) {
/*  828 */         return this.extends_.getId();
/*      */       }
/*      */       
/*  831 */       return null;
/*      */     } 
/*      */     
/*  834 */     return this.package_ + "." + getName() + "Id";
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DtxDaoField
/*      */   {
/*      */     private String name_;
/*      */     
/*      */     private String column_;
/*      */     private String type_;
/*      */     private boolean sensitive_ = false;
/*      */     private String encrypt_;
/*      */     private boolean primaryKey_ = false;
/*      */     private boolean export_ = true;
/*      */     private boolean incrementField_ = false;
/*      */     private Object defaultValueIfNull_;
/*      */     private boolean suppression_ = false;
/*  851 */     private String comment_ = new String();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getColumn() {
/*  859 */       return this.column_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getComment() {
/*  868 */       return this.comment_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Number getDefaultValueIfNull() {
/*  877 */       if (this.defaultValueIfNull_ == null) {
/*  878 */         return null;
/*      */       }
/*      */       
/*  881 */       if ("Integer".equalsIgnoreCase(getType()) || "Int".equalsIgnoreCase(getType())) {
/*  882 */         return Integer.valueOf(this.defaultValueIfNull_.toString());
/*      */       }
/*  884 */       if ("Long".equalsIgnoreCase(getType())) {
/*  885 */         return Long.valueOf(this.defaultValueIfNull_.toString());
/*      */       }
/*      */       
/*  888 */       throw new RuntimeException("Unknown type: " + 
/*  889 */           getType() + " this should have been caught during validation.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getEncrypt() {
/*  899 */       return this.encrypt_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean getExported() {
/*  908 */       return this.export_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean getIncrementField() {
/*  917 */       return this.incrementField_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  926 */       return this.name_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getType() {
/*  935 */       return this.type_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isPrimaryKey() {
/*  944 */       return this.primaryKey_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSensitive() {
/*  953 */       return this.sensitive_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSuppressed() {
/*  962 */       return this.suppression_;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setColumn(String argColumn) {
/*  971 */       this.column_ = argColumn;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setComment(String comment) {
/*  980 */       this.comment_ = comment;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setDefaultValueIfNull(Object argDefaultValueIfNull) {
/*  989 */       this.defaultValueIfNull_ = argDefaultValueIfNull;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setEncrypt(String argEncrypt) {
/*  998 */       this.encrypt_ = argEncrypt;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setExported(boolean xpt) {
/* 1007 */       this.export_ = xpt;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setIncrementField(boolean argIncrementField) {
/* 1016 */       this.incrementField_ = argIncrementField;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setName(String argName) {
/* 1025 */       this.name_ = argName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setPrimaryKey(boolean argPrimaryKey) {
/* 1034 */       this.primaryKey_ = argPrimaryKey;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setSensitive(boolean argSensitive) {
/* 1043 */       this.sensitive_ = argSensitive;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setSuppressed(boolean value) {
/* 1052 */       this.suppression_ = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setType(String argType) {
/* 1061 */       this.type_ = argType;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1067 */       return "(Field: " + this.name_ + " type: " + this.type_ + " pk: " + this.primaryKey_ + " sensitive: " + this.sensitive_ + ")";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void validate() {
/* 1077 */       if (StringUtils.isEmpty(getName())) {
/* 1078 */         throw new RuntimeException("A field does not definte a field name.");
/*      */       }
/* 1080 */       if (StringUtils.isEmpty(getColumn())) {
/* 1081 */         throw new RuntimeException("FIELD: " + this.name_ + " does not define a column.");
/*      */       }
/* 1083 */       if (StringUtils.isEmpty(getType())) {
/* 1084 */         throw new RuntimeException("FIELD: " + this.name_ + " does not define a type.");
/*      */       }
/*      */       
/* 1087 */       if (Character.isUpperCase(this.name_.charAt(0))) {
/* 1088 */         throw new RuntimeException("FIELD: " + this.name_ + " should start with a lowercase letter, NOT uppercase.");
/*      */       }
/*      */ 
/*      */       
/* 1092 */       if (this.defaultValueIfNull_ != null && !StringUtils.isEmpty(this.defaultValueIfNull_.toString()))
/* 1093 */         if ("Integer".equalsIgnoreCase(getType())) {
/*      */           try {
/* 1095 */             Integer.parseInt(this.defaultValueIfNull_.toString());
/*      */           }
/* 1097 */           catch (Exception ee) {
/* 1098 */             throw new RuntimeException("Invalid default value (" + this.defaultValueIfNull_ + ") specified for field " + this.name_ + " " + ee
/* 1099 */                 .getMessage());
/*      */           }
/*      */         
/*      */         }
/* 1103 */         else if ("Long".equalsIgnoreCase(getType())) {
/*      */           try {
/* 1105 */             Long.parseLong(this.defaultValueIfNull_.toString());
/*      */           }
/* 1107 */           catch (RuntimeException ee) {
/* 1108 */             throw new RuntimeException("Invalid default value (" + this.defaultValueIfNull_ + ") specified for field " + this.name_ + " " + ee
/* 1109 */                 .getMessage());
/*      */           } 
/*      */         } else {
/*      */           
/* 1113 */           throw new RuntimeException("Field: " + this.name_ + " specifies a default value for a " + getType() + " field.  Default value is not supported for " + 
/* 1114 */               getType() + " fields.");
/*      */         }  
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DtxDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */