/*     */ package dtv.data2.access.datasource.config;
/*     */ 
/*     */ import dtv.data2.access.config.common.PropertyConfig;
/*     */ import dtv.data2.access.config.common.PropertyConfigConverter;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.util.config.AbstractSetConfig;
/*     */ import dtv.util.config.IConfigObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceSetConfig
/*     */   extends AbstractSetConfig<DataSourceConfig>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  26 */   private final List<PropertyConfig> _properties = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private Map<String, DataSourceDescriptor> _dataSources;
/*     */ 
/*     */   
/*     */   public String getChildTag() {
/*  33 */     return "DataSource";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, DataSourceDescriptor> getDataSources() {
/*  42 */     if (this._dataSources == null) {
/*  43 */       this._dataSources = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  51 */       Map<String, DataSourceConfig> tempMap = new HashMap<>();
/*  52 */       for (DataSourceConfig config : this.childList_) {
/*  53 */         tempMap.put(config.getName(), config);
/*     */       }
/*     */       
/*  56 */       for (DataSourceConfig config : tempMap.values()) {
/*  57 */         DataSourceDescriptor descriptor = mergeProperties(config.getDataSource());
/*  58 */         descriptor.setSourceDescription(config.getSourceDescription());
/*  59 */         this._dataSources.put(descriptor.getName(), descriptor);
/*     */       } 
/*     */       
/*  62 */       this.childList_ = null;
/*     */     } 
/*  64 */     return this._dataSources;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigObject(String argKey, IConfigObject argValue) {
/*  70 */     if ("Property".equalsIgnoreCase(argKey) && argValue instanceof PropertyConfig) {
/*  71 */       this._properties.add((PropertyConfig)argValue);
/*     */     } else {
/*     */       
/*  74 */       super.setConfigObject(argKey, argValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataSourceDescriptor mergeProperties(DataSourceDescriptor argSourceDescriptor) {
/*  87 */     DataSourceDescriptor sourceDescriptor = argSourceDescriptor;
/*     */     
/*  89 */     if (!this._properties.isEmpty()) {
/*  90 */       Properties sourceProps = argSourceDescriptor.getProperties();
/*  91 */       Properties setProps = PropertyConfigConverter.convert(this._properties, new Properties());
/*     */       
/*  93 */       for (Map.Entry<Object, Object> setProp : setProps.entrySet()) {
/*     */ 
/*     */         
/*  96 */         if (!sourceProps.containsKey(setProp.getKey())) {
/*  97 */           sourceProps.setProperty(setProp.getKey().toString(), setProp.getValue().toString());
/*     */         }
/*     */       } 
/*     */     } 
/* 101 */     return sourceDescriptor;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\datasource\config\DataSourceSetConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */