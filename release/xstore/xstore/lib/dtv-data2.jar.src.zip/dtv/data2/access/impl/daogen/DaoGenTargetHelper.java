/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DaoGenTargetHelper
/*     */ {
/*     */   public static String getClassName(Class<?> argClazz, String argDefault) {
/*  27 */     String retVal = null;
/*  28 */     if (argClazz == null) {
/*  29 */       return argDefault;
/*     */     }
/*  31 */     retVal = System.getProperty(argClazz.getName());
/*  32 */     if (retVal == null || retVal.length() == 0) {
/*  33 */       return argDefault;
/*     */     }
/*  35 */     int i = retVal.lastIndexOf(".");
/*  36 */     if (i < 0) {
/*  37 */       return retVal;
/*     */     }
/*  39 */     return retVal.substring(i + 1, retVal.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDirectoryName(Class<?> argClazz, String argDefault) {
/*  51 */     if (argClazz == null) {
/*  52 */       return argDefault;
/*     */     }
/*  54 */     String retVal = System.getProperty(argClazz.getName());
/*  55 */     if (retVal == null || retVal.length() == 0) {
/*  56 */       return argDefault;
/*     */     }
/*  58 */     int i = retVal.lastIndexOf(".");
/*  59 */     if (i < 0) {
/*  60 */       return File.separator;
/*     */     }
/*  62 */     retVal = File.separator + retVal.substring(0, i + 1).replace(".", File.separator);
/*  63 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFileName(Class<?> argClazz, String argDefault) {
/*  75 */     if (argDefault == null) {
/*  76 */       return argDefault;
/*     */     }
/*     */     
/*  79 */     String temp = argDefault.replace(".java", "");
/*  80 */     String name = getClassName(argClazz, temp);
/*  81 */     if (name != null) {
/*  82 */       return name + ".java";
/*     */     }
/*  84 */     return argDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Class<?> argClazz, String argDefault) {
/*  96 */     String retVal = "";
/*  97 */     if (argClazz == null) {
/*  98 */       return argDefault;
/*     */     }
/* 100 */     String name = System.getProperty(argClazz.getName());
/* 101 */     if (name == null || name.length() == 0) {
/* 102 */       return argDefault;
/*     */     }
/* 104 */     int i = name.lastIndexOf(".");
/* 105 */     if (i >= 0) {
/* 106 */       retVal = name.substring(0, i);
/*     */     }
/* 108 */     return retVal;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DaoGenTargetHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */