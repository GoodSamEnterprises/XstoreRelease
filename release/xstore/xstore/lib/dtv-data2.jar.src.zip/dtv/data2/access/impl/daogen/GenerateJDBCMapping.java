/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.data2.access.impl.jdbc.JDBCAdapterMap;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateJDBCMapping
/*     */   implements Callable<Void>
/*     */ {
/*  20 */   private static final Logger logger_ = Logger.getLogger(GenerateJDBCMapping.class);
/*     */   
/*  22 */   private static final Class<?> DEFAULT_TARGET = JDBCAdapterMap.class;
/*     */   private static final String DEFAULT_CLASS_NAME = "JDBCAdapterMapImpl";
/*     */   private static final String DEFAULT_FILE_NAME = "JDBCAdapterMapImpl.java";
/*     */   private static final String DEFAULT_DIRECTORY = "/dtv/data2/access/impl/jdbc/";
/*     */   private static final String DEFAULT_PACKAGE = "dtv.data2.access.impl.jdbc";
/*     */   private static GenerateJDBCMapping INSTANCE;
/*     */   protected DaoGenHelper helper_;
/*     */   
/*     */   static {
/*     */     try {
/*  32 */       String className = System.getProperty(GenerateJDBCMapping.class.getName(), GenerateJDBCMapping.class.getName());
/*  33 */       INSTANCE = (GenerateJDBCMapping)Class.forName(className).newInstance();
/*     */     }
/*  35 */     catch (Exception ee) {
/*  36 */       System.err.println(ee);
/*  37 */       logger_.error("STACK", ee);
/*     */       
/*  39 */       if (ee instanceof RuntimeException) {
/*  40 */         throw (RuntimeException)ee;
/*     */       }
/*     */       
/*  43 */       throw new RuntimeException(ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GenerateJDBCMapping getInstance() {
/*  54 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  76 */     logger_.info("Generating JDBC mapping class");
/*     */     
/*  78 */     Writer stringWriter = new StringWriter(10240);
/*     */     
/*  80 */     writePackageDeclaration(stringWriter);
/*  81 */     writeImportDeclaration(stringWriter);
/*     */     
/*  83 */     stringWriter.append("@SuppressWarnings(\"all\")\n");
/*  84 */     writeClassDeclaration(stringWriter);
/*  85 */     stringWriter.append("\n");
/*     */     
/*  87 */     writeVariableDeclaration(stringWriter);
/*  88 */     writeStaticDeclaration(stringWriter);
/*     */     
/*  90 */     writeAdditionalMethods(stringWriter);
/*     */     
/*  92 */     stringWriter.append("}\n\n");
/*     */ 
/*     */     
/*  95 */     File f = new File(this.helper_.getOutPath() + DaoGenTargetHelper.getDirectoryName(DEFAULT_TARGET, "/dtv/data2/access/impl/jdbc/") + getFileName());
/*     */     
/*  97 */     this.helper_.getWriter().write(f, stringWriter.toString());
/*     */     
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHelper(DaoGenHelper argHelper) {
/* 108 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFileName() {
/* 117 */     return DaoGenTargetHelper.getFileName(DEFAULT_TARGET, "JDBCAdapterMapImpl.java");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeAdditionalMethods(Writer argW) throws IOException {
/* 128 */     writeAddAdapterMethod(argW);
/* 129 */     writeAddRelationshipAdapterMethod(argW);
/* 130 */     writeAdapterMethod(argW);
/* 131 */     writeRelationshipAdapterMethod(argW);
/* 132 */     writeInternalRelationshipAdapterMethod(argW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeClassDeclaration(Writer argW) throws IOException {
/* 143 */     argW.append("public class ");
/* 144 */     argW.append(DaoGenTargetHelper.getClassName(DEFAULT_TARGET, "JDBCAdapterMapImpl"));
/* 145 */     argW.append(" extends JDBCAdapterMap {\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeImportDeclaration(Writer argW) throws IOException {
/* 156 */     argW.append("import dtv.data2.access.exception.DtxException;\nimport dtv.data2.access.AbstractInstanceGenerator;\nimport dtv.data2.access.impl.IRelationshipAdapter;\nimport dtv.data2.access.impl.jdbc.IJDBCTableAdapter;\nimport dtv.data2.access.impl.jdbc.IJDBCRelationshipAdapter;\nimport dtv.data2.access.impl.jdbc.JDBCAdapterMap;\nimport java.util.HashMap;\nimport java.util.Map;\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writePackageDeclaration(Writer argW) throws IOException {
/* 175 */     if (argW == null) {
/*     */       return;
/*     */     }
/* 178 */     String name = DaoGenTargetHelper.getPackageName(DEFAULT_TARGET, "dtv.data2.access.impl.jdbc");
/* 179 */     if (name != null && name.length() > 0) {
/* 180 */       argW.append("package ");
/* 181 */       argW.append(name);
/* 182 */       argW.append(";\n\n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeStaticDeclaration(Writer argW) throws IOException {
/* 194 */     if (this.helper_.getDtxDefinitions() == null || this.helper_.getDtxDefinitions().isEmpty()) {
/*     */       return;
/*     */     }
/* 197 */     argW.append("  {\n");
/* 198 */     argW.append("    // populate the adapter map\n");
/* 199 */     argW.append("    AbstractInstanceGenerator<IJDBCTableAdapter> generator;\n");
/* 200 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/* 201 */       String adapterClass = dtx.getDba() + ".class";
/* 202 */       argW.append("    generator = new AbstractInstanceGenerator<IJDBCTableAdapter>() {\n");
/* 203 */       argW.append("      protected Class<? extends IJDBCTableAdapter> getType() {\n");
/* 204 */       argW.append("        return " + adapterClass + ";\n");
/* 205 */       argW.append("      }\n");
/* 206 */       argW.append("    };\n");
/* 207 */       if (!dtx.isExtended()) {
/* 208 */         argW.append("    addAdapter(\"" + dtx.getId() + "\", generator);\n");
/*     */       }
/* 210 */       argW.append("    addAdapter(\"" + dtx.getDao() + "\", generator);\n");
/* 211 */       argW.append("    addAdapter(\"" + dtx.getInterface() + "\", generator);\n");
/* 212 */       argW.append("    addAdapter(\"" + dtx.getName() + "\", generator);\n");
/*     */     } 
/*     */     
/* 215 */     argW.append("\n\n    // populate the relationship adapter map\n");
/* 216 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/* 217 */       if (!dtx.getRelationships().isEmpty()) {
/* 218 */         for (DtxRelationship relationship : dtx.getRelationships()) {
/* 219 */           String relationshipAdapterClass = dtx.getPackage() + "." + dtx.getName() + relationship.getName() + "RelationshipDBA" + ".class";
/*     */           
/* 221 */           argW.append("    addRelationshipAdapter(\"" + dtx.getDao() + "-" + relationship.getName() + "\", new AbstractInstanceGenerator<IJDBCRelationshipAdapter>() {\n");
/*     */           
/* 223 */           argW.append("      protected Class<? extends IJDBCRelationshipAdapter> getType() {\n");
/* 224 */           argW.append("        return " + relationshipAdapterClass + ";\n");
/* 225 */           argW.append("      }\n");
/* 226 */           argW.append("    });\n");
/*     */         } 
/*     */       }
/*     */       
/* 230 */       if (dtx.isCustomerExtension()) {
/* 231 */         String extRelationshipName = dtx.getExtends().getName() + "Extension";
/* 232 */         String relationshipAdapterClass = dtx.getPackage() + "." + dtx.getName() + extRelationshipName + "RelationshipDBA" + ".class";
/*     */         
/* 234 */         argW.append("    addRelationshipAdapter(\"" + dtx.getExtends().getDao() + "-" + extRelationshipName + "\", new AbstractInstanceGenerator<IJDBCRelationshipAdapter>() {\n");
/*     */         
/* 236 */         argW.append("      protected Class<? extends IJDBCRelationshipAdapter> getType() {\n");
/* 237 */         argW.append("        return " + relationshipAdapterClass + ";\n");
/* 238 */         argW.append("      }\n");
/* 239 */         argW.append("    });\n");
/*     */       } 
/*     */     } 
/* 242 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeVariableDeclaration(Writer argW) throws IOException {
/* 254 */     argW.append("  private final Map<String,AbstractInstanceGenerator<? extends IJDBCTableAdapter>> adapterMap = new HashMap<>();\n");
/*     */     
/* 256 */     argW.append("  private final Map<String,AbstractInstanceGenerator<? extends IJDBCRelationshipAdapter>> relationshipAdapterMap = new HashMap<>();\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendOverrides(Writer argW) throws IOException {
/* 263 */     argW.append("  @Override\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAdapterMethod(Writer argW) throws IOException {
/* 268 */     appendOverrides(argW);
/* 269 */     argW.append("  public IJDBCTableAdapter getTableAdapterImpl(String argIdentifier) {\n");
/* 270 */     argW.append("    AbstractInstanceGenerator<? extends IJDBCTableAdapter> adapterClass = adapterMap.get(argIdentifier);\n");
/*     */     
/* 272 */     argW.append("    try {\n");
/* 273 */     argW.append("      return adapterClass != null ? adapterClass.newInstance() : null;\n");
/* 274 */     argW.append("    }\n");
/* 275 */     argW.append("    catch (InstantiationException | IllegalAccessException ex) {\n");
/* 276 */     argW.append("      throw new DtxException(\"Could not instantiate adapter for: \" + argIdentifier, ex);\n");
/*     */     
/* 278 */     argW.append("    }\n");
/* 279 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddAdapterMethod(Writer argW) throws IOException {
/* 284 */     argW.append("  protected void addAdapter(String argKey, AbstractInstanceGenerator<? extends IJDBCTableAdapter> argClass) {\n");
/*     */     
/* 286 */     argW.append("    adapterMap.put(argKey, argClass);\n");
/* 287 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddRelationshipAdapterMethod(Writer argW) throws IOException {
/* 292 */     argW.append("  protected void addRelationshipAdapter(String argKey, AbstractInstanceGenerator<? extends IJDBCRelationshipAdapter> argClass) {\n");
/*     */     
/* 294 */     argW.append("    relationshipAdapterMap.put(argKey, argClass);\n");
/* 295 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeInternalRelationshipAdapterMethod(Writer argW) throws IOException {
/* 300 */     argW.append("  private IJDBCRelationshipAdapter getRelationshipAdapterImplInternal(Class<?> argClass, String argIdentifier) {\n\n");
/*     */     
/* 302 */     argW.append("    AbstractInstanceGenerator<? extends IJDBCRelationshipAdapter> relationshipAdapterClass = relationshipAdapterMap.get(argClass.getName() + \"-\" + argIdentifier);\n");
/*     */     
/* 304 */     argW.append("    try {\n");
/* 305 */     argW.append("      if (relationshipAdapterClass != null) {\n");
/* 306 */     argW.append("        return relationshipAdapterClass.newInstance();\n");
/* 307 */     argW.append("      }\n");
/* 308 */     argW.append("    }\n");
/* 309 */     argW.append("    catch (InstantiationException | IllegalAccessException ex) {\n");
/* 310 */     argW.append("      throw new DtxException(\"Could not instantiate relationship adapter for class: [\" + argClass.getName() + \"] identifier: [\" + argIdentifier + \"]\", ex);\n");
/*     */     
/* 312 */     argW.append("    }\n\n");
/* 313 */     argW.append("    Class<?> parent = argClass.getSuperclass();\n");
/* 314 */     argW.append("    if (parent != null && !(parent.getName().startsWith(\"java.\"))) {\n");
/* 315 */     argW.append("      return getRelationshipAdapterImplInternal(parent, argIdentifier);\n");
/* 316 */     argW.append("    }\n");
/* 317 */     argW.append("     else {\n");
/* 318 */     argW.append("      return null;\n");
/* 319 */     argW.append("    }\n");
/* 320 */     argW.append("  }\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeRelationshipAdapterMethod(Writer argW) throws IOException {
/* 325 */     appendOverrides(argW);
/* 326 */     argW.append("  public IRelationshipAdapter getRelationshipAdapterImpl(Class argClass, String argIdentifier) {\n\n");
/*     */     
/* 328 */     argW.append("    IJDBCRelationshipAdapter adapter = getRelationshipAdapterImplInternal(argClass, argIdentifier);\n");
/*     */     
/* 330 */     argW.append("    if (adapter == null) {\n");
/* 331 */     argW.append("      return null;\n");
/* 332 */     argW.append("    }\n");
/* 333 */     argW.append("    return adapter;\n");
/* 334 */     argW.append("  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateJDBCMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */