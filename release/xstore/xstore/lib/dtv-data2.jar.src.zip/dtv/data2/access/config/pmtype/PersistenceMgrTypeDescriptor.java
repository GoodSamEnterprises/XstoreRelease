/*     */ package dtv.data2.access.config.pmtype;
/*     */ 
/*     */ import dtv.data2.access.IPersistenceRule;
/*     */ import dtv.data2.access.IPersistenceRuleFactory;
/*     */ import dtv.util.config.ParameterConfig;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceMgrTypeDescriptor
/*     */ {
/*  22 */   private static final Logger _logger = Logger.getLogger(PersistenceMgrTypeDescriptor.class);
/*     */ 
/*     */   
/*     */   private final String name_;
/*     */ 
/*     */   
/*     */   private final List<DataSourceLocationConfig> onlineLookupLocations_;
/*     */ 
/*     */   
/*     */   private final List<DataSourceLocationConfig> offlineLookupLocations_;
/*     */ 
/*     */   
/*     */   private final List<DataSourceLocationConfig> trainingLookupLocations_;
/*     */ 
/*     */   
/*     */   private final List<DataSourceLocationConfig> onlinePersistenceLocations_;
/*     */ 
/*     */   
/*     */   private final List<DataSourceLocationConfig> offlinePersistenceLocations_;
/*     */ 
/*     */   
/*     */   private final List<DataSourceLocationConfig> trainingPersistenceLocations_;
/*     */ 
/*     */   
/*     */   private final boolean writeJournalOnline_;
/*     */ 
/*     */   
/*     */   private final List<IPersistenceRule> _persistenceManagerRules;
/*     */ 
/*     */   
/*     */   private final List<IPersistenceRule> _persistenceStrategyRules;
/*     */ 
/*     */   
/*     */   private IPersistenceRuleFactory _persistenceRuleFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceMgrTypeDescriptor(String argName, List<DataSourceLocationConfig> argOnlineLookup, List<DataSourceLocationConfig> argOnlinePersistence, List<DataSourceLocationConfig> argOfflineLookup, List<DataSourceLocationConfig> argOfflinePersistence, List<DataSourceLocationConfig> argTrainingLookup, List<DataSourceLocationConfig> argTrainingPersistence, boolean argOnlineJournal, PersistenceRuleGroupConfig argPersistenceManagerRules, PersistenceRuleGroupConfig argPersistenceStrategyRules, IPersistenceRuleFactory argRuleFactory) {
/*  60 */     this.name_ = argName;
/*  61 */     this.onlineLookupLocations_ = argOnlineLookup;
/*  62 */     this.offlineLookupLocations_ = argOfflineLookup;
/*  63 */     this.onlinePersistenceLocations_ = argOnlinePersistence;
/*  64 */     this.offlinePersistenceLocations_ = argOfflinePersistence;
/*  65 */     this.trainingLookupLocations_ = argTrainingLookup;
/*  66 */     this.trainingPersistenceLocations_ = argTrainingPersistence;
/*  67 */     this.writeJournalOnline_ = argOnlineJournal;
/*  68 */     this._persistenceRuleFactory = argRuleFactory;
/*  69 */     this._persistenceManagerRules = buildPersistenceRulesFromConfig(argPersistenceManagerRules);
/*  70 */     this._persistenceStrategyRules = buildPersistenceRulesFromConfig(argPersistenceStrategyRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  79 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataSourceLocationConfig> getOfflineLookupLocations() {
/*  87 */     return this.offlineLookupLocations_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataSourceLocationConfig> getOfflinePersistenceLocations() {
/*  95 */     return this.offlinePersistenceLocations_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataSourceLocationConfig> getOnlineLookupLocations() {
/* 103 */     return this.onlineLookupLocations_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataSourceLocationConfig> getOnlinePersistenceLocations() {
/* 111 */     return this.onlinePersistenceLocations_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IPersistenceRule> getPersistenceManagerRules() {
/* 120 */     return this._persistenceManagerRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IPersistenceRule> getPersistenceStrategyRules() {
/* 130 */     return this._persistenceStrategyRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataSourceLocationConfig> getTrainingLookupLocations() {
/* 138 */     if (this.trainingLookupLocations_ == null) {
/* 139 */       return this.onlineLookupLocations_;
/*     */     }
/* 141 */     return this.trainingLookupLocations_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DataSourceLocationConfig> getTrainingPersistenceLocations() {
/* 149 */     if (this.trainingPersistenceLocations_ == null) {
/* 150 */       return this.onlinePersistenceLocations_;
/*     */     }
/* 152 */     return this.trainingPersistenceLocations_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getWriteJournalOnline() {
/* 160 */     return this.writeJournalOnline_;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<IPersistenceRule> buildPersistenceRulesFromConfig(PersistenceRuleGroupConfig argRuleGroupConfig) {
/* 165 */     List<IPersistenceRule> rules = new ArrayList<>();
/*     */     
/* 167 */     if (argRuleGroupConfig == null) {
/* 168 */       return rules;
/*     */     }
/*     */     
/* 171 */     for (PersistenceRuleConfig ruleConfig : argRuleGroupConfig.getPersistenceRuleConfigs()) {
/* 172 */       IPersistenceRule rule = null;
/*     */       
/*     */       try {
/* 175 */         rule = this._persistenceRuleFactory.getRule(ruleConfig.getRuleBeanName());
/*     */       }
/* 177 */       catch (Exception ex) {
/* 178 */         _logger.error("Error instantiating persistence rule class.  Ensure class implements IPersistenceRule", ex);
/*     */       } 
/*     */ 
/*     */       
/* 182 */       if (rule != null) {
/* 183 */         for (ParameterConfig parameter : ruleConfig.getParameters()) {
/* 184 */           rule.setParameter(parameter.getName(), parameter.getValue());
/*     */         }
/*     */         
/* 187 */         rules.add(rule);
/*     */       } 
/*     */     } 
/*     */     
/* 191 */     return rules;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\pmtype\PersistenceMgrTypeDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */