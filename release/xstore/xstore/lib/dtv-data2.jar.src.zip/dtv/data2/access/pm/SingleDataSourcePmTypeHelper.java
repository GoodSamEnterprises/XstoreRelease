/*     */ package dtv.data2.access.pm;
/*     */ 
/*     */ import dtv.data2.access.IPersistable;
/*     */ import dtv.data2.access.IPersistenceMgrType;
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.PersistenceStrategyFactory;
/*     */ import dtv.data2.access.impl.config.PmTypeMappingConfigHelper;
/*     */ import dtv.data2.access.status.StatusMgr;
/*     */ import dtv.data2.dataloader.ConfigParameters;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleDataSourcePmTypeHelper
/*     */   extends PmTypeHelper
/*     */ {
/*  36 */   private static final Logger logger_ = Logger.getLogger(SingleDataSourcePmTypeHelper.class);
/*     */ 
/*     */   
/*     */   private static DataSourceDescriptor myDataSourceTemplate_;
/*     */ 
/*     */   
/*     */   private static IPersistenceMgrType defaultPmType_;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private PersistenceStrategyFactory _persistenceStrategyFactory;
/*     */ 
/*     */   
/*     */   @Inject
/*     */   private PersistenceMgrTypeFactory _persistenceMgrTypeFactory;
/*     */   
/*     */   @Inject
/*     */   private ConfigParameters _configParameters;
/*     */ 
/*     */   
/*     */   protected SingleDataSourcePmTypeHelper(PmTypeMappingConfigHelper argCfg) {
/*  57 */     super(argCfg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PmStrategyInfo> getPersistenceStrategies(IPersistable argPersistable) {
/*  69 */     return getPrioritizedStratgies(null, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeByQueryKey(String argQueryKey, Map<?, ?> argParams) {
/*  75 */     return defaultPmType_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IPersistenceMgrType getPMTypeForPersistable(IPersistable argPersistable) {
/*  81 */     return defaultPmType_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  88 */     String DATA_SOURCE_NAME = this._configParameters.getDataSource();
/*     */     
/*  90 */     if (StringUtils.isEmpty(DATA_SOURCE_NAME)) {
/*  91 */       String msg = "SingleDataSourcePmTypeHelper could not locate a datasource name from configuration. It is null or empty.";
/*     */ 
/*     */       
/*  94 */       logger_.fatal(msg);
/*  95 */       throw new DtxException(msg);
/*     */     } 
/*     */     
/*  98 */     myDataSourceTemplate_ = DataSourceFactory.getInstance().getDataSourceDescriptor(DATA_SOURCE_NAME);
/*     */     
/* 100 */     if (myDataSourceTemplate_ == null) {
/* 101 */       String msg = "SingleDataSourcePmTypeHelper is pointed towards a datasource [" + DATA_SOURCE_NAME + "] that does not exist. This datasource must be configured to function.";
/*     */ 
/*     */       
/* 104 */       logger_.fatal(msg);
/* 105 */       throw new DtxException(msg);
/*     */     } 
/*     */     
/* 108 */     if (!myDataSourceTemplate_.isEnabled()) {
/*     */ 
/*     */       
/* 111 */       String msg = "SingleDataSourcePmTypeHelper is pointed towards a datasource [" + DATA_SOURCE_NAME + "] that is NOT enabled. This datasource must be enabled to function. See: " + myDataSourceTemplate_.getSourceDescription();
/*     */       
/* 113 */       logger_.fatal(msg);
/* 114 */       throw new DtxException(msg);
/*     */     } 
/*     */     
/* 117 */     String DEFAULT_PM_TYPE_NAME = "REGISTER_CORE";
/*     */     
/*     */     try {
/* 120 */       defaultPmType_ = PersistenceManagerType.forName("REGISTER_CORE");
/*     */ 
/*     */       
/* 123 */       this._persistenceMgrTypeFactory.getPersistenceMgrTypeDescriptor(defaultPmType_);
/*     */     }
/* 125 */     catch (Exception ee) {
/* 126 */       if (PersistenceManagerType.getInstances() != null && (
/* 127 */         PersistenceManagerType.getInstances()).length > 0) {
/* 128 */         defaultPmType_ = PersistenceManagerType.getInstances()[0];
/* 129 */         logger_.warn("An exception occurred while loading default pm type [REGISTER_CORE]. Failing over to pm type: [" + defaultPmType_
/* 130 */             .getName() + "]", ee);
/*     */       } else {
/*     */         
/* 133 */         logger_.error("SingleDataSourcePmTypeHelper cannot load a default pm type (did PersistenceManagerConfig load?)");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<PmStrategyInfo> getPrioritizedStratgies(IPersistenceMgrType argPmType, boolean argLookup, boolean argOnline) {
/* 152 */     List<PmStrategyInfo> singleDataSource = new ArrayList<>(1);
/* 153 */     IPersistenceStrategy strategy = this._persistenceStrategyFactory.createStrategy(myDataSourceTemplate_, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     singleDataSource
/* 161 */       .add(new PmStrategyInfo(strategy, StatusMgr.getInstance().isOnline(strategy.getDataSourceName())));
/*     */     
/* 163 */     return singleDataSource;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\SingleDataSourcePmTypeHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */