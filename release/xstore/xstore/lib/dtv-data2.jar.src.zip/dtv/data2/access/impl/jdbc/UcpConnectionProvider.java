/*     */ package dtv.data2.access.impl.jdbc;
/*     */ 
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.crypto.DtvDecrypter;
/*     */ import dtv.util.crypto.IDtvDecrypter;
/*     */ import dtv.util.net.InetUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.ucp.UniversalConnectionPoolAdapter;
/*     */ import oracle.ucp.UniversalConnectionPoolException;
/*     */ import oracle.ucp.admin.UniversalConnectionPoolManager;
/*     */ import oracle.ucp.admin.UniversalConnectionPoolManagerImpl;
/*     */ import oracle.ucp.jdbc.JDBCConnectionPoolStatistics;
/*     */ import oracle.ucp.jdbc.PoolDataSource;
/*     */ import oracle.ucp.jdbc.PoolDataSourceFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UcpConnectionProvider
/*     */   implements JDBCConnectionProvider
/*     */ {
/*  33 */   private static final Logger _logger = Logger.getLogger(UcpConnectionProvider.class);
/*     */ 
/*     */   
/*     */   public static final String CONNECTION_PROPERTY_MSSQL_ENCRYPT = "Encrypt";
/*     */ 
/*     */   
/*     */   public static final String CONNECTION_PROPERTY_MSSQL_TRUST_SERVER_CERTIFICATE = "TrustServerCertificate";
/*     */ 
/*     */   
/*  42 */   private static Map<String, Boolean> LOCALHOST_ADDRESS_CACHE = new HashMap<>();
/*     */   
/*     */   private static void appendProperties(StringBuilder sb, Object argTarget) {
/*  45 */     if (argTarget == null) {
/*     */       return;
/*     */     }
/*  48 */     Method[] declaredMethods = argTarget.getClass().getDeclaredMethods();
/*  49 */     for (Method method : declaredMethods) {
/*  50 */       if (method.getName().startsWith("get") && (method
/*  51 */         .getReturnType() == String.class || method.getReturnType() == int.class) && method
/*  52 */         .getParameterCount() == 0 && 
/*  53 */         !"getUser".equalsIgnoreCase(method.getName()))
/*     */       {
/*     */         
/*  56 */         if (!"getPassword".equalsIgnoreCase(method.getName())) {
/*     */           
/*     */           try {
/*     */             
/*  60 */             Object results = method.invoke(argTarget, new Object[0]);
/*  61 */             if (results != null) {
/*  62 */               sb.append("\n\t " + method.getName().substring(3) + "=" + results);
/*     */             }
/*     */           }
/*  65 */           catch (Throwable ex) {
/*  66 */             _logger.error("CAUGHT EXCEPTION", ex);
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _datasourceName;
/*     */ 
/*     */   
/*     */   private final PoolDataSource _pool;
/*     */ 
/*     */ 
/*     */   
/*     */   public UcpConnectionProvider(JDBCConnectionTemplate argTemplate) throws SQLException {
/*  84 */     PoolDataSource pds = PoolDataSourceFactory.getPoolDataSource();
/*  85 */     pds.setConnectionFactoryClassName(argTemplate.getConnectionFactoryClassName());
/*     */ 
/*     */     
/*  88 */     pds.setConnectionPoolName(argTemplate.getDataSourceName());
/*  89 */     pds.setURL(argTemplate.getUrl());
/*     */     
/*  91 */     IDtvDecrypter decrypter = DtvDecrypter.getInstance("config");
/*  92 */     pds.setUser(decrypter.decryptIfEncrypted(argTemplate.getUser()));
/*  93 */     pds.setPassword(decrypter.decryptIfEncrypted(argTemplate.getPassword()));
/*     */ 
/*     */     
/*  96 */     pds.setMinPoolSize(argTemplate.getConnectionPoolMinSize());
/*  97 */     pds.setMaxPoolSize(argTemplate.getConnectionPoolMaxSize());
/*     */     
/*  99 */     boolean validateConnectionOnBorrow = argTemplate.getValidateConnectionOnBorrow();
/* 100 */     pds.setValidateConnectionOnBorrow(validateConnectionOnBorrow);
/* 101 */     String sqlForValidateConnection = argTemplate.getSqlForValidateConnection();
/* 102 */     if (validateConnectionOnBorrow && !StringUtils.isEmpty(sqlForValidateConnection)) {
/* 103 */       pds.setSQLForValidateConnection(sqlForValidateConnection);
/*     */     }
/*     */     
/* 106 */     pds.setMaxIdleTime(argTemplate.getConnectionMaxIdleTime());
/* 107 */     pds.setMaxConnectionReuseCount(argTemplate.getMaxConnectionReuseCount());
/* 108 */     pds.setMaxStatements(argTemplate.getPreparedStatementCacheMaxSize());
/* 109 */     pds.setConnectionWaitTimeout(argTemplate.getConnectionWaitTimeout());
/*     */ 
/*     */     
/* 112 */     if (argTemplate.isForOracle()) {
/* 113 */       setSecureConnectionPropertiesForOracle(argTemplate, pds);
/*     */     
/*     */     }
/* 116 */     else if (argTemplate.isForMSSQL()) {
/* 117 */       setSecureConnectionPropertiesForMSSQL(argTemplate, pds);
/*     */     } 
/*     */ 
/*     */     
/* 121 */     int transactionIsolation = argTemplate.getTransactionIsolation();
/* 122 */     if (transactionIsolation != -1) {
/* 123 */       if (_logger.isDebugEnabled()) {
/* 124 */         _logger.debug("A transaction isolation level value of " + transactionIsolation + " was provided in DatasourceConfig for  the " + argTemplate
/* 125 */             .getDataSourceName() + " datasource.  Setting it on the pool.");
/*     */       }
/*     */ 
/*     */       
/* 129 */       pds.registerConnectionInitializationCallback(conn -> conn.setTransactionIsolation(transactionIsolation));
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 134 */       UniversalConnectionPoolManager ucpMgr = UniversalConnectionPoolManagerImpl.getUniversalConnectionPoolManager();
/* 135 */       ucpMgr.createConnectionPool((UniversalConnectionPoolAdapter)pds);
/*     */     }
/* 137 */     catch (UniversalConnectionPoolException ex) {
/* 138 */       throw new SQLException("error registering connection pool", ex);
/*     */     } 
/*     */     
/* 141 */     this._pool = pds;
/* 142 */     this._datasourceName = argTemplate.getDataSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 150 */       UniversalConnectionPoolManager ucpMgr = UniversalConnectionPoolManagerImpl.getUniversalConnectionPoolManager();
/* 151 */       ucpMgr.stopConnectionPool(this._datasourceName);
/* 152 */       ucpMgr.destroyConnectionPool(this._datasourceName);
/*     */     }
/* 154 */     catch (UniversalConnectionPoolException ex) {
/* 155 */       _logger.error("CAUGHT EXCEPTION", (Throwable)ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/* 163 */     return this._pool.getConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 169 */     return this._datasourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPoolSize() {
/* 175 */     JDBCConnectionPoolStatistics statistics = this._pool.getStatistics();
/* 176 */     if (statistics != null) {
/* 177 */       return statistics.getTotalConnectionsCount();
/*     */     }
/*     */     try {
/* 180 */       return this._pool.getBorrowedConnectionsCount() + this._pool.getAvailableConnectionsCount();
/*     */     }
/* 182 */     catch (SQLException ex) {
/* 183 */       _logger.error("CAUGHT EXCEPTION", ex);
/* 184 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharSequence getStats() {
/* 191 */     StringBuilder sb = new StringBuilder(100);
/* 192 */     appendProperties(sb, this._pool.getStatistics());
/* 193 */     appendProperties(sb, this._pool);
/* 194 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSecureConnectionPropertiesForMSSQL(JDBCConnectionTemplate argTemplate, PoolDataSource pds) throws SQLException {
/* 206 */     String url = argTemplate.getUrl();
/*     */ 
/*     */     
/*     */     try {
/* 210 */       MssqlConnectionString connection = new MssqlConnectionString(url);
/* 211 */       String databaseServerAddress = connection.getHost();
/* 212 */       if (databaseServerAddress != null && LOCALHOST_ADDRESS_CACHE.get(databaseServerAddress) == null)
/*     */       {
/* 214 */         LOCALHOST_ADDRESS_CACHE.put(databaseServerAddress, Boolean.valueOf(InetUtils.isLocalhost(databaseServerAddress)));
/*     */       }
/* 216 */       if (!((Boolean)LOCALHOST_ADDRESS_CACHE.get(databaseServerAddress)).booleanValue() && 
/* 217 */         connection.getParameter("Encrypt") == null && connection
/* 218 */         .getParameter("TrustServerCertificate") == null)
/*     */       {
/*     */ 
/*     */         
/* 222 */         pds.setURL(url + ";" + "Encrypt" + "=true;" + "TrustServerCertificate" + "=true;");
/*     */ 
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 228 */     catch (Exception ex) {
/* 229 */       _logger.error("While trying to set secure connection properties, failed to parse the following connection string for MSSQL server: " + url, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSecureConnectionPropertiesForOracle(JDBCConnectionTemplate argTemplate, PoolDataSource pds) throws SQLException {
/* 246 */     String databaseServerAddress = null;
/*     */     
/*     */     try {
/* 249 */       databaseServerAddress = argTemplate.getUrl().split("@")[1].split(":")[0];
/*     */     }
/* 251 */     catch (Exception ex) {
/* 252 */       _logger.error("While trying to set secure connection properties, failed to parse the following url for Oracle database: " + argTemplate
/*     */           
/* 254 */           .getUrl());
/*     */       
/*     */       return;
/*     */     } 
/* 258 */     String ojdbcThinClientEncryptionLevel = argTemplate.getOjdbcThinClientEncryptionLevel();
/* 259 */     String ojdbcThinClientChecksumLevel = argTemplate.getOjdbcThinClientEncryptionLevel();
/*     */ 
/*     */     
/* 262 */     if (ojdbcThinClientEncryptionLevel == null) {
/* 263 */       if (databaseServerAddress != null && LOCALHOST_ADDRESS_CACHE.get(databaseServerAddress) == null)
/*     */       {
/* 265 */         LOCALHOST_ADDRESS_CACHE.put(databaseServerAddress, Boolean.valueOf(InetUtils.isLocalhost(databaseServerAddress)));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 270 */       ojdbcThinClientEncryptionLevel = Boolean.TRUE.equals(LOCALHOST_ADDRESS_CACHE.get(databaseServerAddress)) ? "ACCEPTED" : "REQUESTED";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     if (ojdbcThinClientChecksumLevel == null) {
/* 277 */       if (databaseServerAddress != null && LOCALHOST_ADDRESS_CACHE.get(databaseServerAddress) == null) {
/* 278 */         LOCALHOST_ADDRESS_CACHE.put(databaseServerAddress, Boolean.valueOf(InetUtils.isLocalhost(databaseServerAddress)));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 283 */       ojdbcThinClientChecksumLevel = Boolean.TRUE.equals(LOCALHOST_ADDRESS_CACHE.get(databaseServerAddress)) ? "ACCEPTED" : "REQUESTED";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 288 */     pds.setConnectionProperty("oracle.net.encryption_client", ojdbcThinClientEncryptionLevel);
/*     */     
/* 290 */     pds.setConnectionProperty("oracle.net.crypto_checksum_client", ojdbcThinClientChecksumLevel);
/*     */     
/* 292 */     pds.setConnectionProperty("oracle.net.encryption_types_client", argTemplate
/* 293 */         .getOjdbcThinClientEncryptionTypes());
/* 294 */     pds.setConnectionProperty("oracle.net.crypto_checksum_types_client", argTemplate
/* 295 */         .getOjdbcThinClientChecksumTypes());
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\UcpConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */