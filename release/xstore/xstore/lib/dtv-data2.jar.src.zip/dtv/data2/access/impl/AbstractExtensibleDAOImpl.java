package dtv.data2.access.impl;

public abstract class AbstractExtensibleDAOImpl extends AbstractDAOImpl implements IExtensibleDataAccessObjectImpl {
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractExtensibleDAOImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */