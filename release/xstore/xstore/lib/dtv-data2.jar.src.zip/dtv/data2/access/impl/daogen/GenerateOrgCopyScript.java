/*    */ package dtv.data2.access.impl.daogen;
/*    */ 
/*    */ import dtv.util.StringUtils;
/*    */ import java.io.File;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerateOrgCopyScript
/*    */   implements Callable<Object>
/*    */ {
/* 22 */   private static final Logger logger_ = Logger.getLogger(GenerateOrgCopyScript.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private final DaoGenHelper helper_;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   GenerateOrgCopyScript(DaoGenHelper argHelper) {
/* 32 */     this.helper_ = argHelper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object call() throws Exception {
/* 40 */     logger_.info("Generating Org Copy Script");
/*    */     
/* 42 */     StringBuilder w = new StringBuilder(5120);
/*    */     
/* 44 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/* 45 */       if (!StringUtils.isEmpty(dtx.getTable())) {
/* 46 */         getOrgCopy(dtx, w);
/*    */       }
/*    */     } 
/*    */     
/* 50 */     File file = new File(this.helper_.getOutPath() + File.separator + "org_copy.sql");
/* 51 */     this.helper_.getWriter().write(file, w.toString());
/*    */     
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void getOrgCopy(DtxDefinition dtx, StringBuilder buff) {
/* 64 */     buff.append("INSERT INTO ").append(dtx.getTable()).append("(");
/*    */ 
/*    */     
/* 67 */     for (DtxDefinition.DtxDaoField field : dtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 68 */       buff.append(field.getColumn()).append(", ");
/*    */     }
/*    */ 
/*    */     
/* 72 */     buff.setLength(buff.length() - 2);
/* 73 */     buff.append(") ");
/*    */ 
/*    */     
/* 76 */     buff.append("SELECT ");
/*    */     
/* 78 */     for (DtxDefinition.DtxDaoField field : dtx.getFieldsPlusInheritedPrimaryKeys()) {
/* 79 */       if (field.getColumn().equals("organization_id")) {
/* 80 */         buff.append("NEW_ORG_ID, ");
/*    */       } else {
/*    */         
/* 83 */         buff.append(field.getColumn()).append(", ");
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 88 */     buff.setLength(buff.length() - 2);
/* 89 */     buff.append(" FROM ").append(dtx.getTable());
/* 90 */     buff.append(" WHERE organization_id = EXISTING_ORG_ID;\n");
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateOrgCopyScript.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */