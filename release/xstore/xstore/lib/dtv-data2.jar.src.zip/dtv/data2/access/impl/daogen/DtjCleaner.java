/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.FileUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.concurrent.Callable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtjCleaner
/*     */   implements Callable<Void>
/*     */ {
/*     */   private static final String HEADER = "//DTJ-START $Header";
/*     */   private static final String FOOTER = "//DTJ-END $Header";
/*     */   private final File rootDir_;
/*     */   
/*     */   public static void main(String[] args) {
/*  28 */     int status = process(args);
/*  29 */     System.exit(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int process(String[] args) {
/*     */     try {
/*  40 */       switch (args.length) {
/*     */         case 0:
/*  42 */           showUsage(System.out);
/*  43 */           return 1;
/*     */         case 1:
/*  45 */           (new DtjCleaner(new File(args[0]))).call();
/*  46 */           return 0;
/*     */       } 
/*  48 */       showUsage(System.err);
/*  49 */       return 1;
/*     */     
/*     */     }
/*  52 */     catch (Throwable ex) {
/*  53 */       System.err.println("CAUGHT EXCEPTION");
/*  54 */       ex.printStackTrace();
/*  55 */       return 2;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void showUsage(PrintStream out) {
/*  60 */     out.println("USAGE: to recursively process *.dtj under <config-directory>, pass the location as an argument, e.g.");
/*     */     
/*  62 */     out.println("\t" + DtjCleaner.class.getName() + " <config-directory>");
/*  63 */     out.println("The exising files will be renamed with a .bak extension.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DtjCleaner(File argRootDir) {
/*  74 */     this.rootDir_ = argRootDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  82 */     processDir(this.rootDir_);
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processDir(File dir) throws IOException {
/*  89 */     System.out.println("traversing " + dir);
/*  90 */     for (File f : dir.listFiles()) {
/*  91 */       if (!f.isDirectory()) {
/*  92 */         if (f.getAbsolutePath().toLowerCase().endsWith(".dtj")) {
/*  93 */           processDtj(f);
/*     */         }
/*     */       } else {
/*     */         
/*  97 */         processDir(f);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processDtj(File argF) throws IOException {
/* 105 */     boolean needsHeader = true;
/* 106 */     int headerLinesToRemove = 0;
/* 107 */     boolean needsFooter = true;
/* 108 */     RandomAccessFile raf = new RandomAccessFile(argF, "r");
/* 109 */     String line = raf.readLine();
/* 110 */     if (line.startsWith("//DTJ-START $Header") && line.indexOf('$', "//DTJ-START $Header".length()) > -1) {
/* 111 */       needsHeader = false;
/*     */     } else {
/*     */       
/* 114 */       line = line.trim();
/* 115 */       while (line != null && line.length() == 0) {
/* 116 */         headerLinesToRemove++;
/* 117 */         line = raf.readLine();
/* 118 */         if (line != null) {
/* 119 */           line = line.trim();
/*     */         }
/*     */       } 
/* 122 */       if (line == null) {
/* 123 */         raf.close();
/*     */         return;
/*     */       } 
/* 126 */       line = line.toUpperCase();
/* 127 */       if ((line.startsWith("//$ID") || line.startsWith("// $ID")) && 
/* 128 */         line.endsWith("$")) {
/* 129 */         headerLinesToRemove++;
/*     */       }
/*     */     } 
/*     */     
/* 133 */     long fromEnd = raf.length() - 50L;
/* 134 */     if (fromEnd < 0L) {
/* 135 */       fromEnd = 0L;
/*     */     }
/* 137 */     raf.seek(fromEnd);
/* 138 */     byte[] buff = new byte[50];
/* 139 */     raf.readFully(buff);
/* 140 */     String tail = (new String(buff, "UTF-8")).trim();
/* 141 */     if (tail.endsWith("$") && tail.lastIndexOf("//DTJ-END $Header", 48) > -1) {
/* 142 */       needsFooter = false;
/*     */     }
/* 144 */     raf.close();
/* 145 */     if (!needsHeader && !needsFooter) {
/*     */       return;
/*     */     }
/* 148 */     File newFile = new File(argF.getAbsolutePath() + ".tmp");
/* 149 */     System.out.println("writing " + newFile);
/* 150 */     BufferedWriter w = new BufferedWriter(FileUtils.getFileWriter(newFile));
/* 151 */     BufferedReader r = new BufferedReader(FileUtils.getFileReader(argF));
/* 152 */     if (needsHeader) {
/* 153 */       w.write("//DTJ-START $Header");
/* 154 */       w.write("$");
/* 155 */       w.newLine();
/*     */     } 
/* 157 */     while ((line = r.readLine()) != null) {
/* 158 */       if (headerLinesToRemove > 0) {
/* 159 */         headerLinesToRemove--;
/*     */         continue;
/*     */       } 
/* 162 */       w.write(line);
/* 163 */       w.newLine();
/*     */     } 
/*     */     
/* 166 */     r.close();
/* 167 */     if (needsFooter) {
/* 168 */       w.write("//DTJ-END $Header");
/* 169 */       w.write("$");
/* 170 */       w.newLine();
/*     */     } 
/* 172 */     w.close();
/* 173 */     File bakFile = new File(argF.getAbsolutePath() + ".bak");
/* 174 */     bakFile.delete();
/* 175 */     argF.renameTo(bakFile);
/* 176 */     newFile.renameTo(argF);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DtjCleaner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */