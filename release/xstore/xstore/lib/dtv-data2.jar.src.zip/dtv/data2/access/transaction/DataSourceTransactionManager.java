/*     */ package dtv.data2.access.transaction;
/*     */ 
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.exception.PersistenceException;
/*     */ import dtv.service.ServiceException;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceTransactionManager
/*     */ {
/*  22 */   private static final Logger logger_ = Logger.getLogger(DataSourceTransactionManager.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   private static DataSourceTransactionManager instance_ = new DataSourceTransactionManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataSourceTransactionManager getInstance() {
/*  37 */     return instance_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commit(TransactionToken argToken) {
/*  52 */     Set<ITransactionalDataSource> datasourceSet = argToken.drainDataSources();
/*  53 */     if (datasourceSet.size() == 0) {
/*  54 */       if (logger_.isDebugEnabled()) {
/*  55 */         logger_.debug("Commit was called on token " + argToken.toString() + " but no datasources were registered on that token.  Commit for this token cannot be handled by this manager .");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  64 */     for (ITransactionalDataSource source : datasourceSet) {
/*     */       try {
/*  66 */         source.commitPhase1(argToken);
/*     */       }
/*  68 */       catch (ServiceException ee) {
/*  69 */         logger_.warn("An unexpected Service exception occurred while committing to datasource: " + source, (Throwable)ee);
/*     */       
/*     */       }
/*  72 */       catch (Exception ee) {
/*  73 */         logger_.error("An unexpected exception occurred while committing on datasource: " + source + " datasource name: " + source
/*  74 */             .getDataSourceName(), ee);
/*     */ 
/*     */         
/*  77 */         for (ITransactionalDataSource datasource : datasourceSet) {
/*  78 */           argToken.registerDataSource(datasource);
/*     */         }
/*     */ 
/*     */         
/*  82 */         if (ee instanceof dtv.data2.access.exception.FailoverException) {
/*  83 */           throw ee;
/*     */         }
/*  85 */         if (ee instanceof RuntimeException) {
/*  86 */           throw (RuntimeException)ee;
/*     */         }
/*     */         
/*  89 */         throw new PersistenceException("An exception occuring while committing.", ee);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     for (ITransactionalDataSource source : datasourceSet) {
/*     */       try {
/* 100 */         source.commitPhase2(argToken);
/*     */       }
/* 102 */       catch (ServiceException ee) {
/* 103 */         logger_.warn("An unexpected Service exception occured while committing to datasource:" + source, (Throwable)ee);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDataSourcesRegistered(TransactionToken argToken) {
/* 116 */     return argToken.hasDatasources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerDataSource(TransactionToken argToken, ITransactionalDataSource argDataSource) {
/* 131 */     if (argToken == null) {
/* 132 */       throw new DataSourceTransactionException("transaction token is null - a value must be provided. Cannot register data source " + argDataSource);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 137 */     argToken.registerDataSource(argDataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(TransactionToken argToken) {
/* 146 */     Set<ITransactionalDataSource> datasourceSet = argToken.drainDataSources();
/* 147 */     if (datasourceSet == null) {
/* 148 */       if (logger_.isDebugEnabled()) {
/* 149 */         logger_.debug("Rollback was called on token " + argToken.toString() + " but no datasources were registered with the DatasourceTransactionManager for that token.  Rollback for this token cannot be handled by this manager .");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 155 */     for (ITransactionalDataSource source : datasourceSet) {
/*     */       try {
/* 157 */         source.rollback(argToken);
/*     */       }
/* 159 */       catch (Exception ee) {
/* 160 */         logger_.warn("Exception while rolling back. " + ee);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(TransactionToken argToken, String argDataSourceName) {
/* 172 */     ITransactionalDataSource datasource = argToken.removeDatasource(argDataSourceName);
/* 173 */     if (datasource == null) {
/* 174 */       if (logger_.isDebugEnabled()) {
/* 175 */         logger_.debug("Rollback was called on token " + argToken.toString() + " but no datasource with that name is registered on that token.  Rollback cannot be completed..");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 182 */       datasource.rollback(argToken);
/*     */     }
/* 184 */     catch (Exception ee) {
/* 185 */       logger_.warn("Exception while rolling back. " + ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionToken startTransaction(IObjectId argObjectId) {
/* 200 */     if (argObjectId != null) {
/* 201 */       return new TransactionToken(argObjectId.toString().hashCode());
/*     */     }
/*     */     
/* 204 */     return new TransactionToken(hashCode());
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\transaction\DataSourceTransactionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */