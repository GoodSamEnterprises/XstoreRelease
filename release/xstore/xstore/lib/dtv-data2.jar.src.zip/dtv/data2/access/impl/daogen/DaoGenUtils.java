/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DaoGenUtils
/*     */ {
/*  24 */   private static final Logger logger_ = Logger.getLogger(DaoGenUtils.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TYPE_STRING = "String";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TYPE_CLASS = "Class";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TYPE_CLOB = "Clob";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TYPE_DATE = "Date";
/*     */ 
/*     */   
/*     */   public static final String TYPE_LONG = "Long";
/*     */ 
/*     */   
/*     */   public static final String TYPE_INTEGER = "Integer";
/*     */ 
/*     */   
/*     */   public static final String TYPE_OBJECT = "Object";
/*     */ 
/*     */   
/*     */   public static final String TYPE_BIG_DECIMAL = "BigDecimal";
/*     */ 
/*     */   
/*     */   public static final String TYPE_BOOLEAN = "Boolean";
/*     */ 
/*     */   
/*     */   public static final String RELATIONSHIP_DBA = "RelationshipDBA";
/*     */ 
/*     */   
/*     */   public static final int BIG_DECIMAL_DIFF_SCALE = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendGetterForField(Appendable argAppendable, DtxDefinition.DtxDaoField argField) {
/*     */     try {
/*  67 */       String name = getGetterNameForField(argField);
/*  68 */       String type = getRawDataType(argField.getType());
/*  69 */       String field = getFieldNameForField(argField);
/*     */       
/*  71 */       argAppendable.append("  public ").append(type).append(" ").append(name).append("() {\n");
/*  72 */       argAppendable.append("    return ").append(field).append(";\n");
/*  73 */       argAppendable.append("  }\n\n");
/*     */     }
/*  75 */     catch (IOException ex) {
/*  76 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendSetterForField(Appendable argAppendable, DtxDefinition.DtxDaoField argField, boolean checkChanged, boolean filterData) {
/*     */     try {
/*  91 */       String name = getSetterNameForField(argField);
/*  92 */       String type = getRawDataType(argField.getType());
/*  93 */       String arg = getArgNameForField(argField);
/*  94 */       String field = getFieldNameForField(argField);
/*     */ 
/*     */       
/*  97 */       argAppendable.append("  public void ").append(name).append("(").append(type).append(" ").append(arg)
/*  98 */         .append(") {\n");
/*     */ 
/*     */       
/* 101 */       if (checkChanged) {
/* 102 */         argAppendable.append("    if (changed(").append(arg).append(", ").append(field).append(", \"")
/* 103 */           .append(argField.getName()).append("\")) {\n");
/*     */       }
/*     */ 
/*     */       
/* 107 */       String baseIndent = checkChanged ? "      " : "    ";
/* 108 */       argAppendable.append(baseIndent).append(field).append(" = ");
/* 109 */       if ("Date".equalsIgnoreCase(argField.getType()) && filterData) {
/*     */         
/* 111 */         argAppendable.append("(").append(arg).append(" == null || ").append(arg)
/* 112 */           .append(" instanceof dtv.util.DtvDate) ? \n");
/*     */         
/* 114 */         argAppendable.append(baseIndent).append("    (dtv.util.DtvDate) ").append(arg).append(" : ");
/*     */         
/* 116 */         argAppendable.append("new dtv.util.DtvDate(").append(arg).append(");\n");
/*     */       }
/* 118 */       else if ("String".equalsIgnoreCase(argField.getType()) && argField.isPrimaryKey() && filterData) {
/*     */ 
/*     */         
/* 121 */         argAppendable.append("(").append(arg).append(" != null && MANAGE_CASE) ? ").append(arg)
/* 122 */           .append(".toUpperCase() : ").append(arg).append(";\n");
/*     */       }
/*     */       else {
/*     */         
/* 126 */         argAppendable.append(arg).append(";\n");
/*     */       } 
/*     */ 
/*     */       
/* 130 */       if (checkChanged) {
/* 131 */         argAppendable.append("    }\n");
/*     */       }
/*     */ 
/*     */       
/* 135 */       argAppendable.append("  }\n\n");
/*     */     }
/* 137 */     catch (IOException ex) {
/* 138 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAdderNameForRelationship(DtxRelationship argRel) {
/* 149 */     String elementName = getBaseNameForRelationshipAddRemove(argRel);
/* 150 */     return "add" + elementName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getArgNameForField(DtxDefinition.DtxDaoField argField) {
/* 160 */     return getArgNameForString(argField.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getArgNameForRelationship(DtxRelationship argRel) {
/* 170 */     return getArgNameForString(argRel.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getArgNameForRelationshipAddRemove(DtxRelationship argRel) {
/* 180 */     String elementName = getBaseNameForRelationshipAddRemove(argRel);
/* 181 */     return getArgNameForString(elementName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getClassForType(String argFieldType) {
/* 197 */     if ("String".equalsIgnoreCase(argFieldType) || "Clob".equalsIgnoreCase(argFieldType) || "Class"
/* 198 */       .equalsIgnoreCase(argFieldType)) {
/* 199 */       return String.class;
/*     */     }
/* 201 */     if ("Integer".equalsIgnoreCase(argFieldType)) {
/* 202 */       return int.class;
/*     */     }
/* 204 */     if ("Date".equalsIgnoreCase(argFieldType)) {
/* 205 */       return Date.class;
/*     */     }
/* 207 */     if ("BigDecimal".equalsIgnoreCase(argFieldType)) {
/* 208 */       return BigDecimal.class;
/*     */     }
/* 210 */     if ("Long".equalsIgnoreCase(argFieldType)) {
/* 211 */       return long.class;
/*     */     }
/* 213 */     if ("Boolean".equalsIgnoreCase(argFieldType)) {
/* 214 */       return boolean.class;
/*     */     }
/* 216 */     if ("Object".equalsIgnoreCase(argFieldType)) {
/* 217 */       return Object.class;
/*     */     }
/*     */     
/* 220 */     logger_.error("getVariableType()::UNKNOWN TYPE : " + argFieldType);
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getConcreteDataType(String argType) {
/* 232 */     return "Date".equalsIgnoreCase(argType) ? "dtv.util.DtvDate" : getRawDataType(argType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEtter(String argFieldType, int argIndex) {
/* 243 */     if ("Class".equalsIgnoreCase(argFieldType)) {
/* 244 */       return "etString(" + argIndex + ")";
/*     */     }
/* 246 */     if ("Integer".equalsIgnoreCase(argFieldType)) {
/* 247 */       return "etInt(" + argIndex + ")";
/*     */     }
/* 249 */     if ("Object".equalsIgnoreCase(argFieldType)) {
/* 250 */       return "etBytes(" + argIndex + ")";
/*     */     }
/*     */     
/* 253 */     return "et" + argFieldType + "(" + argIndex + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEtterInputObject(String argFieldType, int argIndex, String argAddIn) {
/* 268 */     if ("Class".equalsIgnoreCase(argFieldType)) {
/* 269 */       return "etString(" + argIndex + ", " + argAddIn + ")";
/*     */     }
/* 271 */     if ("Integer".equalsIgnoreCase(argFieldType)) {
/* 272 */       return "etInt(" + argIndex + ", " + argAddIn + ")";
/*     */     }
/* 274 */     if ("Date".equalsIgnoreCase(argFieldType)) {
/*     */       
/* 276 */       String ss = "etTimestamp(${argIndex}, new java.sql.Timestamp(${argAddIn}.getTime()))";
/*     */       
/* 278 */       Map<String, String> params = new HashMap<>(2);
/* 279 */       params.put("argIndex", String.valueOf(argIndex));
/* 280 */       params.put("argAddIn", argAddIn);
/* 281 */       return StringUtils.replaceVariables(ss, params);
/*     */     } 
/*     */     
/* 284 */     return "et" + argFieldType + "(" + argIndex + ", " + argAddIn + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFieldNameForField(DtxDefinition.DtxDaoField argField) {
/* 295 */     return getFieldNameForString(argField.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFieldNameForRelationship(DtxRelationship argRel) {
/* 305 */     return getFieldNameForString(argRel.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGetterNameForField(DtxDefinition.DtxDaoField argField) {
/* 315 */     return getGetterNameForString(argField.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGetterNameForRelationship(DtxRelationship argRel) {
/* 325 */     return getGetterNameForString(argRel.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRawDataType(String type) {
/* 335 */     if (type.equals("Class")) {
/* 336 */       return "String";
/*     */     }
/* 338 */     if (type.equals("Clob")) {
/* 339 */       return "String";
/*     */     }
/* 341 */     if (type.equals("BigDecimal")) {
/* 342 */       return "java.math.BigDecimal";
/*     */     }
/* 344 */     if (type.equals("Date")) {
/* 345 */       return "java.util.Date";
/*     */     }
/*     */     
/* 348 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRemoverNameForRelationship(DtxRelationship argRel) {
/* 359 */     String elementName = getBaseNameForRelationshipAddRemove(argRel);
/* 360 */     return "remove" + elementName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSetterNameForField(DtxDefinition.DtxDaoField argField) {
/* 370 */     return getSetterNameForString(argField.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSetterNameForRelationship(DtxRelationship argRel) {
/* 380 */     return getSetterNameForString(argRel.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTypeForField(DtxDefinition.DtxDaoField argField) {
/* 390 */     String type = argField.getType();
/*     */     
/* 392 */     if ("String".equalsIgnoreCase(type)) {
/* 393 */       return 12;
/*     */     }
/* 395 */     if ("Clob".equalsIgnoreCase(type)) {
/* 396 */       return 2005;
/*     */     }
/* 398 */     if ("Integer".equalsIgnoreCase(type)) {
/* 399 */       return 4;
/*     */     }
/* 401 */     if ("Date".equalsIgnoreCase(type)) {
/* 402 */       return 91;
/*     */     }
/* 404 */     if ("Class".equalsIgnoreCase(type)) {
/* 405 */       return 12;
/*     */     }
/* 407 */     if ("BigDecimal".equalsIgnoreCase(type)) {
/* 408 */       return 3;
/*     */     }
/* 410 */     if ("Long".equalsIgnoreCase(type)) {
/* 411 */       return -5;
/*     */     }
/* 413 */     if ("Boolean".equalsIgnoreCase(type))
/*     */     {
/* 415 */       return -7;
/*     */     }
/* 417 */     if ("Object".equalsIgnoreCase(type)) {
/* 418 */       return -4;
/*     */     }
/*     */     
/* 421 */     logger_.error("getTypeForField()::UNKNOWN TYPE: " + type);
/* 422 */     return 1111;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTypeForRelationship(DtxRelationship argRel, boolean isCleanBean) {
/* 435 */     String type = isCleanBean ? getRawDataType(argRel.getChild().getCleanbeanClassname()) : argRel.getChild().getInterface();
/* 436 */     if (DtxRelationship.ONE_MANY.equalsIgnoreCase(argRel.getType()) || DtxRelationship.MANY_MANY
/* 437 */       .equalsIgnoreCase(argRel.getType())) {
/* 438 */       type = "java.util.List<" + type + ">";
/*     */     }
/* 440 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVariableType(String argFieldType) {
/* 450 */     if ("String".equalsIgnoreCase(argFieldType) || "Clob".equalsIgnoreCase(argFieldType)) {
/* 451 */       return "String";
/*     */     }
/* 453 */     if ("Integer".equalsIgnoreCase(argFieldType)) {
/* 454 */       return "int";
/*     */     }
/* 456 */     if ("Date".equalsIgnoreCase(argFieldType)) {
/* 457 */       return "Date";
/*     */     }
/* 459 */     if ("Class".equalsIgnoreCase(argFieldType)) {
/* 460 */       return "String";
/*     */     }
/* 462 */     if ("BigDecimal".equalsIgnoreCase(argFieldType)) {
/* 463 */       return "java.math.BigDecimal";
/*     */     }
/* 465 */     if ("Long".equalsIgnoreCase(argFieldType)) {
/* 466 */       return "long";
/*     */     }
/* 468 */     if ("Boolean".equalsIgnoreCase(argFieldType)) {
/* 469 */       return "boolean";
/*     */     }
/* 471 */     if ("Object".equalsIgnoreCase(argFieldType)) {
/* 472 */       return "Object";
/*     */     }
/*     */     
/* 475 */     logger_.error("getVariableType()::UNKNOWN TYPE : " + argFieldType);
/* 476 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getXmlTypeForField(DtxDefinition.DtxDaoField argField) {
/* 487 */     String type = argField.getType();
/*     */     
/* 489 */     if ("String".equalsIgnoreCase(type)) {
/* 490 */       return "string";
/*     */     }
/* 492 */     if ("Clob".equalsIgnoreCase(type)) {
/* 493 */       return "string";
/*     */     }
/* 495 */     if ("Integer".equalsIgnoreCase(type)) {
/* 496 */       return "int";
/*     */     }
/* 498 */     if ("Date".equalsIgnoreCase(type)) {
/* 499 */       return "dateTime";
/*     */     }
/* 501 */     if ("Class".equalsIgnoreCase(type)) {
/* 502 */       return "string";
/*     */     }
/* 504 */     if ("BigDecimal".equalsIgnoreCase(type)) {
/* 505 */       return "decimal";
/*     */     }
/* 507 */     if ("Long".equalsIgnoreCase(type)) {
/* 508 */       return "long";
/*     */     }
/* 510 */     if ("Boolean".equalsIgnoreCase(type)) {
/* 511 */       return "boolean";
/*     */     }
/* 513 */     if ("Object".equalsIgnoreCase(type)) {
/* 514 */       return "base64Binary";
/*     */     }
/*     */     
/* 517 */     logger_.error("getTypeForField()::UNKNOWN TYPE: " + type);
/* 518 */     return "anyType";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPrimitive(DtxDefinition.DtxDaoField argField) {
/* 529 */     String type = argField.getType();
/*     */     
/* 531 */     if ("Integer".equalsIgnoreCase(type)) {
/* 532 */       return argField.getName() + "().intValue()";
/*     */     }
/* 534 */     if ("Long".equalsIgnoreCase(type)) {
/* 535 */       return argField.getName() + "().longValue()";
/*     */     }
/* 537 */     if ("Boolean".equalsIgnoreCase(type)) {
/* 538 */       return argField.getName() + "().booleanValue()";
/*     */     }
/*     */     
/* 541 */     return argField.getName() + "()";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPrimitive(String argtType) {
/* 551 */     String type = argtType;
/*     */     
/* 553 */     if ("Integer".equalsIgnoreCase(type)) {
/* 554 */       return ".intValue()";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 559 */     if ("Long".equalsIgnoreCase(type)) {
/* 560 */       return ".longValue()";
/*     */     }
/* 562 */     if ("Boolean".equalsIgnoreCase(type)) {
/* 563 */       return ".booleanValue()";
/*     */     }
/*     */     
/* 566 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String wrapStatementWithObject(String argToWrap, String type) {
/* 577 */     if ("Integer".equalsIgnoreCase(type)) {
/* 578 */       return "Integer.valueOf(" + argToWrap + ")";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 584 */     if ("Long".equalsIgnoreCase(type)) {
/* 585 */       return "Long.valueOf(" + argToWrap + ")";
/*     */     }
/* 587 */     if ("Boolean".equalsIgnoreCase(type)) {
/* 588 */       return "Boolean.valueOf(" + argToWrap + ")";
/*     */     }
/*     */     
/* 591 */     return argToWrap;
/*     */   }
/*     */   
/*     */   private static String getArgNameForString(String argString) {
/* 595 */     String elementName = StringUtils.ensureFirstUpperCase(argString);
/* 596 */     return "arg" + elementName;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getBaseNameForRelationshipAddRemove(DtxRelationship argRel) {
/* 601 */     String elementName = (argRel.getElementName() != null && argRel.getElementName().length() > 0) ? argRel.getElementName() : argRel.getChildName();
/* 602 */     return StringUtils.ensureFirstUpperCase(elementName);
/*     */   }
/*     */   
/*     */   private static String getFieldNameForString(String argString) {
/* 606 */     return "_" + StringUtils.ensureFirstLowerCase(argString);
/*     */   }
/*     */   
/*     */   private static String getGetterNameForString(String argString) {
/* 610 */     String proper = StringUtils.ensureFirstUpperCase(argString);
/* 611 */     return "get" + proper;
/*     */   }
/*     */   
/*     */   private static String getSetterNameForString(String argString) {
/* 615 */     String proper = StringUtils.ensureFirstUpperCase(argString);
/* 616 */     return "set" + proper;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DaoGenUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */