/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.IObjectId;
/*     */ import dtv.data2.access.IPersistenceMgrType;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.transaction.DataSourceTransactionException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryToken
/*     */ {
/*     */   private static final String NODE_SEPARATOR = ":";
/*     */   private static final String GET_BY_ID_PREFIX = "getById:";
/*     */   private static final String GET_BY_QUERY_PREFIX = "getByQuery:";
/*     */   private final String _uniqueId;
/*  28 */   private final Set<IQueryResource> _queryResources = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryToken(IObjectId argId, IPersistenceMgrType argType) {
/*  37 */     StringBuilder buf = new StringBuilder(128);
/*  38 */     buf.append("getById:");
/*  39 */     buf.append(argId.toString()).append(":");
/*  40 */     buf.append(argId.hashCode()).append(":");
/*  41 */     buf.append(argType.getName()).append(":");
/*  42 */     buf.append(argType.hashCode()).append(":");
/*  43 */     buf.append(System.currentTimeMillis()).append(":");
/*  44 */     buf.append(Thread.currentThread().getId()).append(":");
/*  45 */     buf.append(ThreadLocalRandom.current().nextFloat());
/*  46 */     this._uniqueId = buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryToken(QueryRequest argQueryRequest) {
/*  55 */     StringBuilder buf = new StringBuilder(128);
/*  56 */     buf.append("getByQuery:");
/*  57 */     buf.append(argQueryRequest.toString()).append(":");
/*  58 */     buf.append(argQueryRequest.hashCode()).append(":");
/*  59 */     buf.append(System.currentTimeMillis()).append(":");
/*  60 */     buf.append(Thread.currentThread().getId()).append(":");
/*  61 */     buf.append(ThreadLocalRandom.current().nextFloat());
/*  62 */     this._uniqueId = buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<IQueryResource> drainQueryResources() {
/*  71 */     synchronized (this._queryResources) {
/*  72 */       Set<IQueryResource> datasources = new HashSet<>(this._queryResources);
/*  73 */       this._queryResources.clear();
/*  74 */       return datasources;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  81 */     if (this == obj) {
/*  82 */       return true;
/*     */     }
/*  84 */     if (obj == null) {
/*  85 */       return false;
/*     */     }
/*  87 */     if (getClass() != obj.getClass()) {
/*  88 */       return false;
/*     */     }
/*  90 */     QueryToken other = (QueryToken)obj;
/*  91 */     if (this._uniqueId == null) {
/*  92 */       if (other._uniqueId != null) {
/*  93 */         return false;
/*     */       }
/*     */     }
/*  96 */     else if (!this._uniqueId.equals(other._uniqueId)) {
/*  97 */       return false;
/*     */     } 
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IQueryResource> T getQueryResource(String argDataSource, Class<T> argType) {
/* 113 */     if (argDataSource == null) {
/* 114 */       throw new DtxException("getQueryResource was called without a datasource name.  This is not supported.");
/*     */     }
/*     */     
/* 117 */     if (argType == null) {
/* 118 */       throw new DtxException("getQueryResource was called without a type parameter.  This is not supported.");
/*     */     }
/*     */     
/* 121 */     synchronized (this._queryResources) {
/* 122 */       for (IQueryResource resource : this._queryResources) {
/* 123 */         if (argDataSource.equals(resource.getDataSourceName()) && argType.isInstance(resource)) {
/* 124 */           return (T)resource;
/*     */         }
/*     */       } 
/*     */     } 
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 134 */     int prime = 31;
/* 135 */     int result = 1;
/* 136 */     result = 31 * result + ((this._uniqueId == null) ? 0 : this._uniqueId.hashCode());
/* 137 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerQueryResource(IQueryResource argCloseableResource) {
/* 146 */     if (argCloseableResource == null) {
/* 147 */       throw new DataSourceTransactionException("Cannot register a null query resource to QueryToken " + this);
/*     */     }
/*     */     
/* 150 */     synchronized (this._queryResources) {
/*     */       
/* 152 */       this._queryResources.add(argCloseableResource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     synchronized (this._queryResources) {
/* 160 */       return "QueryToken [_uniqueId=" + this._uniqueId + ", queryResources=" + this._queryResources + "]";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */