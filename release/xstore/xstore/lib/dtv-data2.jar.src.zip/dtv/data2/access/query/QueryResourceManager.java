/*    */ package dtv.data2.access.query;
/*    */ 
/*    */ import dtv.data2.access.transaction.DataSourceTransactionException;
/*    */ import java.util.Set;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryResourceManager
/*    */ {
/* 22 */   private static final Logger logger_ = Logger.getLogger(QueryResourceManager.class);
/* 23 */   private static QueryResourceManager instance_ = new QueryResourceManager();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static QueryResourceManager getInstance() {
/* 31 */     return instance_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void closeQueryResources(QueryToken argQueryToken) {
/* 42 */     Set<IQueryResource> queryResources = argQueryToken.drainQueryResources();
/* 43 */     if (queryResources.size() == 0) {
/* 44 */       if (logger_.isDebugEnabled()) {
/* 45 */         logger_.debug("closeQueryResources was called on token " + argQueryToken.toString() + " but no datasources were registered on that token.  This is not necessarily an indication of any issue, as not all query implementations use tokens.");
/*    */       }
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 51 */     for (IQueryResource resource : queryResources) {
/*    */       try {
/* 53 */         resource.close();
/*    */       }
/* 55 */       catch (Exception ex) {
/* 56 */         logger_.warn("An error occurred when closing query resources.", ex);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerQueryResource(QueryToken argQueryToken, IQueryResource argCloseableResource) {
/* 69 */     if (argQueryToken == null) {
/* 70 */       throw new DataSourceTransactionException("Cannot register query resource to null QueryToken.");
/*    */     }
/*    */ 
/*    */     
/* 74 */     argQueryToken.registerQueryResource(argCloseableResource);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryResourceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */