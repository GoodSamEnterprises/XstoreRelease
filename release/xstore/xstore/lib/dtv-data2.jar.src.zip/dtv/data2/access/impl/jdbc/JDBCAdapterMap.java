/*    */ package dtv.data2.access.impl.jdbc;
/*    */ 
/*    */ import dtv.data2.access.exception.DtxException;
/*    */ import dtv.data2.access.impl.AdapterMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JDBCAdapterMap
/*    */   extends AdapterMap
/*    */ {
/*    */   public static final IJDBCTableAdapter getTableAdapter(String argIdentifier) {
/* 25 */     if (adapterMap_ instanceof JDBCAdapterMap) {
/*    */       try {
/* 27 */         IJDBCTableAdapter adapter = ((JDBCAdapterMap)adapterMap_).getTableAdapterImpl(argIdentifier);
/* 28 */         if (adapter != null) {
/* 29 */           return adapter;
/*    */         }
/*    */       }
/* 32 */       catch (DtxException ex) {
/* 33 */         logger_.debug(ex);
/*    */       } 
/*    */     }
/* 36 */     throw new DtxException("Could not find table adapter for: " + argIdentifier);
/*    */   }
/*    */   
/*    */   public abstract IJDBCTableAdapter getTableAdapterImpl(String paramString);
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JDBCAdapterMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */