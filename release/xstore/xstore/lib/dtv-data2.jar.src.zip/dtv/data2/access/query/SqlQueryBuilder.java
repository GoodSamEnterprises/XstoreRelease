/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.PersistenceConstants;
/*     */ import dtv.data2.access.impl.jdbc.JDBCCall;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.util.DtvDate;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlQueryBuilder
/*     */ {
/*     */   public static final String DIRECT_REPLACEMENT_VAR_PREFIX = "$";
/*  32 */   private static final Logger logger_ = Logger.getLogger(SqlQueryBuilder.class);
/*     */   private static final String DISABLE_CASE_HANDLING = "DisableCaseHandling";
/*  34 */   private static final Pattern COMMA = Pattern.compile(",\\s*");
/*     */ 
/*     */   
/*     */   private static final String DB_WILDCARD = "%";
/*     */ 
/*     */   
/*     */   private static final String SPACE = " ";
/*     */ 
/*     */   
/*     */   private static final String DB_VARPREFIX = "@";
/*     */ 
/*     */   
/*     */   private static final String DB_ESCVAR = "@@";
/*     */ 
/*     */   
/*     */   public static final String buildBaseQuery(Properties argProperties, Map<String, Object> argParams, int argQueryCount) {
/*  50 */     StringBuilder baseQuery = new StringBuilder(6144);
/*     */ 
/*     */     
/*  53 */     for (int i = 1; i <= argQueryCount; i++) {
/*     */       
/*  55 */       String identifier = "SQL" + i;
/*  56 */       String queryElement = argProperties.getProperty(identifier);
/*     */       
/*  58 */       if (isRequired(identifier, argProperties) || 
/*  59 */         isParametersPresent(argProperties.getProperty("Parameters" + i), argParams)) {
/*  60 */         if (!StringUtils.isEmpty(queryElement)) {
/*  61 */           baseQuery.append(queryElement).append(" ");
/*     */         }
/*     */         
/*  64 */         String optionalWhereClause = buildOptionalWhere(argProperties, argParams, i);
/*     */         
/*  66 */         if (!StringUtils.isEmpty(optionalWhereClause)) {
/*  67 */           if (baseQuery.length() > 0 && 
/*  68 */             "".equals(argProperties.getProperty("QueryType", ""))) {
/*  69 */             baseQuery.append(" AND ");
/*     */           }
/*     */ 
/*     */           
/*  73 */           baseQuery.append(optionalWhereClause);
/*     */         } 
/*     */       } else {
/*     */         
/*  77 */         logger_.debug("Missing required parameters for [" + identifier + "], ignoring.");
/*     */       } 
/*     */     } 
/*  80 */     return baseQuery.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String buildOptionalWhere(Properties argProperties, Map<String, Object> argParams, int argQueryCount) {
/*  94 */     StringBuilder where = new StringBuilder();
/*  95 */     StringBuilder sbTemp = new StringBuilder();
/*  96 */     Set<String> keys = argParams.keySet();
/*     */     
/*  98 */     if (keys != null && !keys.isEmpty()) {
/*     */ 
/*     */       
/* 101 */       for (String key : keys) {
/* 102 */         sbTemp.setLength(0);
/* 103 */         String identifier = "SQL.";
/*     */         
/* 105 */         if (argQueryCount > 0) {
/* 106 */           identifier = "SQL" + argQueryCount + ".";
/*     */         }
/*     */         
/* 109 */         sbTemp.append(identifier).append(key);
/* 110 */         String tempWhere = argProperties.getProperty(sbTemp.toString());
/*     */         
/* 112 */         if (tempWhere == null || tempWhere.length() < 1) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 117 */         if ("Procedure".equals(argProperties.getProperty("QueryType", ""))) {
/* 118 */           where.append(" " + tempWhere + " ");
/*     */           continue;
/*     */         } 
/* 121 */         where.append(" (").append(tempWhere).append(") AND");
/*     */       } 
/*     */ 
/*     */       
/* 125 */       if (where.length() > 1 && 
/* 126 */         "".equals(argProperties.getProperty("QueryType", ""))) {
/* 127 */         where.delete(where.length() - 3, where.length());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 132 */     return where.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String cleanSqlString(String argSql) {
/* 154 */     if (argSql == null) {
/* 155 */       return argSql;
/*     */     }
/*     */     
/* 158 */     String cleanedSql = StringUtils.removeLineFeeds(argSql, " ");
/* 159 */     cleanedSql = StringUtils.replaceAll(new StringBuilder(cleanedSql), "\t", " ").toString();
/* 160 */     return cleanedSql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final JDBCCall getJDBCCall(IPersistenceStrategy argStrategy, String argBaseSqlString, Properties argProperties, Map<String, Object> argParams) {
/* 177 */     StringBuilder sql = new StringBuilder(1024);
/* 178 */     List<String> paramNames = getParameterNames(argProperties, argParams);
/*     */ 
/*     */ 
/*     */     
/* 182 */     if (!StringUtils.isEmpty(argBaseSqlString)) {
/* 183 */       sql.append(argBaseSqlString);
/*     */     }
/*     */ 
/*     */     
/* 187 */     String optionalWhereClause = buildOptionalWhere(argProperties, argParams, 0);
/*     */     
/* 189 */     if (!StringUtils.isEmpty(optionalWhereClause)) {
/* 190 */       if (sql.length() > 0) {
/* 191 */         sql.append(" AND ");
/*     */       }
/* 193 */       sql.append(optionalWhereClause);
/*     */     } 
/*     */ 
/*     */     
/* 197 */     String suffixString = argProperties.getProperty("Suffix");
/*     */     
/* 199 */     if (!StringUtils.isEmpty(suffixString)) {
/* 200 */       sql.append(' ').append(suffixString);
/*     */     }
/*     */ 
/*     */     
/* 204 */     if (argProperties.getProperty("Constant.Suffix") != null) {
/* 205 */       String constantSuffix = argProperties.getProperty("Constant.Suffix");
/* 206 */       String parameterSuffix = argProperties.getProperty("Parameters.Suffix");
/*     */       
/* 208 */       if (parameterSuffix.contains(",")) {
/* 209 */         String[] ps = COMMA.split(parameterSuffix.toString());
/*     */         
/* 211 */         if (argParams.get(ps[0]) != null) {
/* 212 */           for (String element : ps) {
/* 213 */             constantSuffix = constantSuffix.replaceFirst("\\?", argParams.get(element.trim()).toString());
/* 214 */             argParams.remove(element);
/*     */           } 
/*     */         }
/*     */         
/* 218 */         if (!StringUtils.isEmpty(constantSuffix)) {
/* 219 */           sql.append(constantSuffix);
/*     */         
/*     */         }
/*     */       }
/* 223 */       else if (argParams.get(parameterSuffix) != null) {
/* 224 */         constantSuffix = constantSuffix.replaceFirst("\\?", argParams.get(parameterSuffix).toString());
/* 225 */         argParams.remove(parameterSuffix);
/*     */         
/* 227 */         if (!StringUtils.isEmpty(constantSuffix)) {
/* 228 */           sql.append(constantSuffix);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 234 */     sql.append(getCustomHaving(argProperties, argParams));
/* 235 */     sql.append(getCustomSort(argProperties, argParams));
/* 236 */     List<Object> finalizedParams = getParametersFinalized(paramNames, argProperties, argParams);
/*     */     
/* 238 */     replaceVariables(sql, (Map)argParams);
/*     */     
/* 240 */     buildInStatement(sql, finalizedParams, paramNames, argProperties);
/* 241 */     JDBCCall call = new JDBCCall();
/* 242 */     call.setSqlString(sql.toString());
/* 243 */     call.setParams(finalizedParams);
/* 244 */     call.setTypes(JDBCHelper.getJDBCTypesForList(finalizedParams));
/* 245 */     call.setParamNames(paramNames);
/* 246 */     return call;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final JDBCCall getJDBCCall(String argBaseSqlString, Properties argProperties, Map<String, Object> argParams) {
/* 261 */     return getJDBCCall(null, argBaseSqlString, argProperties, argParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String toSqlInClauseArgs(List<String> argValues) {
/* 272 */     return toSqlInClauseArgs(argValues, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String toSqlInClauseArgs(List<String> argValues, boolean argAllUpper) {
/* 284 */     StringBuilder inClauseArgs = new StringBuilder();
/*     */     
/* 286 */     for (int i = 0, n = argValues.size(); i < n; i++) {
/* 287 */       inClauseArgs.append("'").append(argAllUpper ? ((String)argValues.get(i)).toUpperCase() : argValues.get(i))
/* 288 */         .append("'");
/*     */       
/* 290 */       if (i < n - 1) {
/* 291 */         inClauseArgs.append(",");
/*     */       }
/*     */     } 
/* 294 */     return inClauseArgs.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getCustomHaving(Properties argProperties, Map<String, Object> argParameters) {
/* 305 */     StringBuilder str = new StringBuilder(96);
/* 306 */     int appended = 0;
/*     */     
/* 308 */     for (int i = 1;; i++) {
/* 309 */       String base = "Having" + i;
/* 310 */       String sql = argProperties.getProperty(base);
/* 311 */       String field = argProperties.getProperty(base + ".Field");
/* 312 */       String parameters = argProperties.getProperty(base + ".Parameters");
/*     */       
/* 314 */       if (field == null || sql == null || parameters == null) {
/*     */         break;
/*     */       }
/*     */       
/* 318 */       if (isParametersPresent(parameters, argParameters)) {
/* 319 */         if (appended == 0) {
/* 320 */           str.append(" HAVING ");
/*     */         }
/* 322 */         else if (appended > 0) {
/* 323 */           str.append(" AND ");
/*     */         } 
/*     */         
/* 326 */         str.append(field);
/* 327 */         str.append(" ").append(sql);
/* 328 */         appended++;
/*     */       } 
/*     */     } 
/*     */     
/* 332 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getCustomSort(Properties argProperties, Map<String, Object> argParams) {
/* 346 */     StringBuilder str = new StringBuilder(96);
/* 347 */     int appended = 0;
/*     */     
/* 349 */     for (int i = 1;; i++) {
/* 350 */       String base = "Sort" + i;
/* 351 */       String field = argProperties.getProperty(base);
/*     */       
/* 353 */       if (field == null) {
/*     */         break;
/*     */       }
/*     */       
/* 357 */       String requiredString = argProperties.getProperty(base + "." + "RequiredSort");
/* 358 */       boolean isRequired = (requiredString != null) ? Boolean.valueOf(requiredString).booleanValue() : true;
/*     */       
/* 360 */       if (isRequired || argParams.containsKey(field)) {
/* 361 */         if (appended == 0) {
/* 362 */           str.append(" ORDER BY ");
/*     */         }
/* 364 */         else if (appended > 0) {
/* 365 */           str.append(", ");
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 370 */         if (argParams.containsKey(field)) {
/* 371 */           str.append(argParams.get(field));
/*     */         } else {
/*     */           
/* 374 */           str.append(field);
/*     */         } 
/*     */         
/* 377 */         String order = argProperties.getProperty(base + "." + "Order");
/*     */         
/* 379 */         if (order != null) {
/* 380 */           if (argParams.containsKey(order)) {
/* 381 */             str.append(" ").append(argParams.get(order));
/*     */           } else {
/*     */             
/* 384 */             str.append(" ").append(order);
/*     */           } 
/*     */         }
/*     */         
/* 388 */         appended++;
/*     */       } 
/*     */     } 
/*     */     
/* 392 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void buildInStatement(StringBuilder sqlToModify, List<Object> argFinalizedParams, List<String> argParamNames, Properties argProperties) {
/* 406 */     if (argParamNames == null || argParamNames.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 420 */     StringTokenizer sqlTokens = new StringTokenizer(sqlToModify.toString(), "?");
/* 421 */     StringBuilder newSql = new StringBuilder(sqlToModify.length());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     if (argParamNames.size() < sqlTokens.countTokens() - 1 || argParamNames
/* 432 */       .size() > sqlTokens.countTokens()) {
/* 433 */       StringBuilder str = new StringBuilder(512);
/* 434 */       str.append("The number of parameters does not match the number of ");
/* 435 */       str.append("tokens! Number of parameters: [").append(argParamNames.size());
/* 436 */       str.append("], number of tokens: [").append(sqlTokens.countTokens());
/* 437 */       str.append("]. Parameter list: ").append(argParamNames);
/* 438 */       logger_.warn(str.toString());
/*     */     } 
/*     */     
/* 441 */     int paramNameIndex = 0;
/* 442 */     ListIterator<Object> paramIterator = argFinalizedParams.listIterator();
/* 443 */     while (paramIterator.hasNext()) {
/* 444 */       String paramName = argParamNames.get(paramNameIndex++);
/* 445 */       paramName = paramName.replaceFirst("@@", "");
/* 446 */       paramName = paramName.replaceAll("%", "");
/* 447 */       Object tValue = paramIterator.next();
/* 448 */       newSql = newSql.append(sqlTokens.nextToken());
/*     */ 
/*     */       
/* 451 */       if (paramName.startsWith("@") && !paramName.startsWith("@@")) {
/* 452 */         newSql.append('(');
/* 453 */         Collection<?> inParameters = (Collection)tValue;
/* 454 */         paramIterator.remove();
/*     */         
/* 456 */         Iterator<?> innerParameterIterator = inParameters.iterator();
/* 457 */         while (innerParameterIterator.hasNext()) {
/* 458 */           Object innerParam = innerParameterIterator.next();
/* 459 */           paramIterator.add(innerParam);
/* 460 */           newSql.append('?');
/*     */           
/* 462 */           if (innerParameterIterator.hasNext()) {
/* 463 */             newSql.append(", ");
/*     */           }
/*     */         } 
/*     */         
/* 467 */         newSql.append(')');
/*     */         continue;
/*     */       } 
/* 470 */       newSql.append('?');
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 475 */     if (sqlTokens.hasMoreTokens()) {
/* 476 */       newSql.append(sqlTokens.nextToken());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 483 */     while (sqlTokens.hasMoreTokens()) {
/* 484 */       newSql.append('?').append(sqlTokens.nextToken());
/*     */     }
/*     */     
/* 487 */     sqlToModify.setLength(0);
/* 488 */     sqlToModify.append(newSql);
/*     */   }
/*     */   
/*     */   private static Object filterType(Object argValue) {
/* 492 */     if (argValue instanceof Object[]) {
/* 493 */       return ((Object[])argValue)[0];
/*     */     }
/* 495 */     if (argValue instanceof Date && !(argValue instanceof DtvDate)) {
/* 496 */       return new DtvDate(((Date)argValue).getTime());
/*     */     }
/*     */     
/* 499 */     return argValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List<String> getParameterNames(Properties argProperties, Map<String, Object> argParams) {
/* 514 */     StringBuilder parameterNameList = new StringBuilder(128);
/* 515 */     StringBuilder parameterKey = new StringBuilder(32);
/* 516 */     int queryCount = Integer.parseInt(argProperties.getProperty("QueryCount", "0"));
/* 517 */     Set<String> keys = argParams.keySet();
/*     */ 
/*     */     
/* 520 */     if (queryCount == 0) {
/*     */       
/* 522 */       String requiredParameterList = argProperties.getProperty("Parameters");
/*     */       
/* 524 */       if (!StringUtils.isEmpty(requiredParameterList)) {
/* 525 */         parameterNameList.append(requiredParameterList);
/* 526 */         parameterNameList.append(", ");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 531 */       if (keys != null && !keys.isEmpty())
/*     */       {
/*     */         
/* 534 */         for (String key : keys) {
/* 535 */           parameterKey.setLength(0);
/* 536 */           parameterKey.append("Parameters").append(".").append(key);
/* 537 */           String tempParams = argProperties.getProperty(parameterKey.toString());
/*     */           
/* 539 */           if (tempParams != null && tempParams.length() > 0) {
/* 540 */             parameterNameList.append(tempParams).append(", ");
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     } else {
/*     */       
/* 547 */       for (int j = 1; j <= queryCount; j++) {
/*     */         
/* 549 */         parameterKey.setLength(0);
/* 550 */         parameterKey.append("Parameters").append(j);
/*     */         
/* 552 */         String requiredParameterList = argProperties.getProperty(parameterKey.toString(), "");
/*     */ 
/*     */ 
/*     */         
/* 556 */         if (isRequired("SQL" + j, argProperties) || 
/* 557 */           isParametersPresent(argProperties.getProperty(parameterKey.toString()), argParams)) {
/*     */ 
/*     */ 
/*     */           
/* 561 */           if (!"".equals(requiredParameterList)) {
/* 562 */             parameterNameList.append(requiredParameterList);
/* 563 */             parameterNameList.append(", ");
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 568 */           if (keys != null && !keys.isEmpty()) {
/* 569 */             for (String key : keys) {
/* 570 */               parameterKey.setLength(0);
/* 571 */               parameterKey.append("Parameters").append(j).append(".").append(key);
/* 572 */               String tempParams = argProperties.getProperty(parameterKey.toString(), "");
/*     */               
/* 574 */               if (!"".equals(tempParams)) {
/* 575 */                 parameterNameList.append(tempParams).append(", ");
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 583 */     for (int i = 1;; i++) {
/* 584 */       String base = "Having" + i;
/* 585 */       String sql = argProperties.getProperty(base);
/* 586 */       String field = argProperties.getProperty(base + ".Field");
/* 587 */       String tempParams = argProperties.getProperty(base + ".Parameters");
/*     */       
/* 589 */       if (field == null || sql == null || tempParams == null) {
/*     */         break;
/*     */       }
/* 592 */       if (isParametersPresent(tempParams, argParams)) {
/* 593 */         parameterNameList.append(tempParams).append(", ");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 598 */     if (parameterNameList.length() > 1) {
/* 599 */       parameterNameList.delete(parameterNameList.length() - 2, parameterNameList.length());
/*     */     }
/*     */ 
/*     */     
/* 603 */     if (!StringUtils.isEmpty(parameterNameList.toString())) {
/* 604 */       String[] parameterNames = COMMA.split(parameterNameList.toString());
/* 605 */       List<String> finalNames = new ArrayList<>();
/*     */       
/* 607 */       for (int ii = 0; ii < parameterNames.length; ii++) {
/*     */ 
/*     */         
/* 610 */         if (!parameterNames[ii].trim().startsWith("$")) {
/* 611 */           finalNames.add(parameterNames[ii].trim());
/*     */         }
/*     */       } 
/*     */       
/* 615 */       return finalNames;
/*     */     } 
/*     */     
/* 618 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List<Object> getParametersFinalized(List<String> argParameterNames, Properties argProperties, Map<String, Object> argParams) {
/* 634 */     List<Object> parameterValues = new ArrayList();
/*     */ 
/*     */     
/* 637 */     if (argParameterNames == null || argParameterNames.size() == 0) {
/* 638 */       return new ArrayList(0);
/*     */     }
/*     */ 
/*     */     
/* 642 */     String caseMgmtDisabled = argProperties.getProperty("DisableCaseHandling");
/* 643 */     boolean disableCaseHandling = (caseMgmtDisabled == null) ? false : Boolean.parseBoolean(caseMgmtDisabled);
/*     */     
/* 645 */     for (String paramName : argParameterNames) {
/*     */ 
/*     */       
/* 648 */       boolean prefixVar = paramName.startsWith("@@");
/* 649 */       paramName = paramName.replaceFirst("@@", "");
/*     */       
/* 651 */       boolean prefixWildcard = paramName.startsWith("%");
/* 652 */       boolean postfixWildcard = paramName.endsWith("%");
/* 653 */       paramName = paramName.replaceAll("%", "");
/* 654 */       Object value = null;
/*     */ 
/*     */       
/* 657 */       if (argParams.containsKey(paramName)) {
/* 658 */         value = argParams.get(paramName);
/*     */       } else {
/*     */         
/* 661 */         throw new DtxException("Null value was detected for required query parameter: [" + paramName + "]. Query key: [" + argProperties
/* 662 */             .get("Name") + "]");
/*     */       } 
/*     */ 
/*     */       
/* 666 */       if (value instanceof String) {
/* 667 */         if (prefixVar) {
/* 668 */           value = "@@" + value;
/*     */         }
/*     */         
/* 671 */         if (prefixWildcard) {
/* 672 */           value = "%" + value;
/*     */         }
/*     */         
/* 675 */         if (postfixWildcard) {
/* 676 */           value = value + "%";
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 681 */       value = filterType(value);
/* 682 */       value = massageValue(value, disableCaseHandling);
/* 683 */       parameterValues.add(value);
/*     */     } 
/*     */     
/* 686 */     return parameterValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isParametersPresent(String argParameterList, Map<String, Object> argParameters) {
/* 697 */     if (!StringUtils.isEmpty(argParameterList)) {
/* 698 */       for (String parameter : COMMA.split(argParameterList)) {
/* 699 */         if (!argParameters.containsKey(parameter.trim())) {
/* 700 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 705 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isRequired(String argIdentifier, Properties argProperties) {
/* 709 */     boolean result = true;
/* 710 */     String key = argIdentifier + "." + "Required";
/* 711 */     if (argProperties.getProperty(key) != null) {
/* 712 */       result = Boolean.valueOf(argProperties.getProperty(key)).booleanValue();
/*     */     }
/*     */     
/* 715 */     return result;
/*     */   }
/*     */   
/*     */   private static Object massageValue(Object argValue, boolean argDisableCaseHandling) {
/* 719 */     if (PersistenceConstants.MANAGE_CASE && !argDisableCaseHandling) {
/* 720 */       if (argValue instanceof Collection) {
/* 721 */         Collection<?> inParameters = (Collection)argValue;
/* 722 */         if (inParameters.stream().filter(e -> e instanceof String).count() > 0L) {
/* 723 */           return inParameters.stream().map(e -> (e instanceof String) ? ((String)e).toUpperCase() : e)
/* 724 */             .collect(Collectors.toList());
/*     */         }
/*     */       }
/* 727 */       else if (argValue instanceof String) {
/* 728 */         String inParameter = (String)argValue;
/* 729 */         return inParameter.toUpperCase();
/*     */       } 
/*     */     }
/* 732 */     return argValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final StringBuilder replaceVariables(StringBuilder argTarget, Map<? extends Object, ? extends Object> argVariableLookupMap) {
/* 748 */     int foundStart = argTarget.indexOf("{$");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 753 */     while (foundStart != -1) {
/* 754 */       int foundEnd = argTarget.indexOf("}", foundStart + 1);
/* 755 */       String variableName = argTarget.substring(foundStart + 1, foundEnd);
/* 756 */       String variableValue = StringUtils.nonNull(argVariableLookupMap.get(variableName));
/* 757 */       argTarget.replace(foundStart, foundEnd + 1, variableValue);
/*     */ 
/*     */       
/* 760 */       foundStart = argTarget.indexOf("{$", foundStart + 1);
/*     */     } 
/*     */     
/* 763 */     return argTarget;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\SqlQueryBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */