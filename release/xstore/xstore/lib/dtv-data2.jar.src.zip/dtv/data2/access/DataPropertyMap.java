/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.util.ObjectUtils;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataPropertyMap<T extends IDataProperty>
/*     */   extends AbstractMap<String, T>
/*     */ {
/*     */   final IDataPropertyParent<T> parent_;
/*     */   
/*     */   public DataPropertyMap(IDataPropertyParent<T> argParent) {
/*  32 */     this.parent_ = argParent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, T>> entrySet() {
/*  38 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T put(String argKey, T argValue) {
/*  60 */     if (!argValue.getPropertyCode().equals(argKey)) {
/*  61 */       throw new IllegalArgumentException("v.getPropertyCode()->'" + argValue
/*  62 */           .getPropertyCode() + "' != key->'" + argKey + "'");
/*     */     }
/*     */     
/*  65 */     IDataProperty iDataProperty = (IDataProperty)remove(argKey);
/*     */     
/*  67 */     this.parent_.getProperties().add(argValue);
/*     */     
/*  69 */     return (T)iDataProperty;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Entry<V extends IDataProperty>
/*     */     implements Map.Entry<String, V>
/*     */   {
/*     */     private final V prop_;
/*     */ 
/*     */     
/*     */     Entry(V argDataProperty) {
/*  80 */       this.prop_ = argDataProperty;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object argOther) {
/*  86 */       if (argOther == this) {
/*  87 */         return true;
/*     */       }
/*  89 */       if (!(argOther instanceof Map.Entry)) {
/*  90 */         return false;
/*     */       }
/*  92 */       Map.Entry<?, ?> other = (Map.Entry<?, ?>)argOther;
/*     */       
/*  94 */       return ObjectUtils.equivalent(other.getValue(), getValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 100 */       return this.prop_.getPropertyCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public V getValue() {
/* 106 */       return this.prop_;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 112 */       Object v = getValue();
/* 113 */       if (v == null) {
/* 114 */         return 0;
/*     */       }
/* 116 */       return v.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public V setValue(V value) {
/* 122 */       throw new UnsupportedOperationException(getClass().getName() + ".setValue not allowed");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class EntrySet
/*     */     extends AbstractSet<Map.Entry<String, T>>
/*     */   {
/*     */     private EntrySet() {}
/*     */ 
/*     */     
/*     */     public Iterator<Map.Entry<String, T>> iterator() {
/* 135 */       return new DataPropertyMap.EntrySetIterator(DataPropertyMap.this.parent_);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 141 */       return DataPropertyMap.this.parent_.getProperties().size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class EntrySetIterator
/*     */     implements Iterator<Map.Entry<String, T>>
/*     */   {
/*     */     private final Iterator<T> _target;
/*     */ 
/*     */     
/*     */     EntrySetIterator(IDataPropertyParent<T> argParent) {
/* 154 */       this._target = argParent.getProperties().iterator();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 160 */       return this._target.hasNext();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Map.Entry<String, T> next() {
/* 166 */       IDataProperty iDataProperty = (IDataProperty)this._target.next();
/* 167 */       return new DataPropertyMap.Entry<>((T)iDataProperty);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 173 */       this._target.remove();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\DataPropertyMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */