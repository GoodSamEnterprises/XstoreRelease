/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.access.DataPropertyMap;
/*     */ import dtv.data2.access.IDataProperty;
/*     */ import dtv.data2.access.IDataPropertyParent;
/*     */ import dtv.data2.access.IHasDataProperty;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataModelWithPropertyImpl<T extends IDataProperty>
/*     */   extends AbstractDataModelImpl
/*     */   implements IDataPropertyParent<T>, IHasDataProperty<T>
/*     */ {
/*     */   private static final long serialVersionUID = 6666677777L;
/*     */   private transient Map<String, T> _propertyMap;
/*     */   
/*     */   public boolean deleteProperty(String argPropertyName) {
/*  29 */     return (getPropertyMap().remove(argPropertyName) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String argPropertyName) {
/*  35 */     return getBooleanProperty(argPropertyName, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String argPropertyName, boolean argDefault) {
/*  41 */     T prop = getProperty(argPropertyName);
/*  42 */     return (prop == null) ? argDefault : prop.getBooleanValue(argDefault);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDateProperty(String argPropertyName) {
/*  48 */     return getDateProperty(argPropertyName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDateProperty(String argPropertyName, Date argDefault) {
/*  54 */     T prop = getProperty(argPropertyName);
/*  55 */     return (prop == null) ? argDefault : prop.getDateValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BigDecimal getDecimalProperty(String argPropertyName) {
/*  61 */     return getDecimalProperty(argPropertyName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BigDecimal getDecimalProperty(String argPropertyName, BigDecimal argDefault) {
/*  67 */     T prop = getProperty(argPropertyName);
/*  68 */     return (prop == null) ? argDefault : prop.getDecimalValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract List<T> getProperties();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getProperty(String argPropertyName) {
/*  83 */     return getPropertyMap().get(argPropertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String argPropertyName) {
/*  89 */     return getStringProperty(argPropertyName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String argPropertyName, String argDefault) {
/*  95 */     T prop = getProperty(argPropertyName);
/*  96 */     return (prop == null) ? argDefault : prop.getStringValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(String argPropertyName) {
/* 102 */     T prop = getProperty(argPropertyName);
/* 103 */     return (prop == null) ? null : prop.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBooleanProperty(String argPropertyName, boolean argValue) {
/* 109 */     T prop = getOrCreateProperty(argPropertyName);
/* 110 */     prop.setType("BOOLEAN");
/* 111 */     prop.setBooleanValue(argValue);
/* 112 */     setProperty(prop);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateProperty(String argPropertyName, Date argValue) {
/* 118 */     if (argValue == null) {
/* 119 */       deleteProperty(argPropertyName);
/*     */     } else {
/*     */       
/* 122 */       T prop = getOrCreateProperty(argPropertyName);
/* 123 */       prop.setType("DATE");
/* 124 */       prop.setDateValue(argValue);
/* 125 */       setProperty(prop);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDecimalProperty(String argPropertyName, BigDecimal argValue) {
/* 132 */     if (argValue == null) {
/* 133 */       deleteProperty(argPropertyName);
/*     */     } else {
/*     */       
/* 136 */       T prop = getOrCreateProperty(argPropertyName);
/* 137 */       prop.setType("BIGDECIMAL");
/* 138 */       prop.setDecimalValue(argValue);
/* 139 */       setProperty(prop);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setProperties(List<T> paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStringProperty(String argPropertyName, String argValue) {
/* 155 */     if (argValue == null) {
/* 156 */       deleteProperty(argPropertyName);
/*     */     } else {
/*     */       
/* 159 */       T prop = getOrCreateProperty(argPropertyName);
/* 160 */       prop.setType("STRING");
/* 161 */       prop.setStringValue(argValue);
/* 162 */       setProperty(prop);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T getOrCreateProperty(String argPropertyName) {
/* 173 */     T prop = getProperty(argPropertyName);
/* 174 */     if (prop == null) {
/* 175 */       return newProperty(argPropertyName);
/*     */     }
/*     */     
/* 178 */     return prop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Map<String, T> getPropertyMap() {
/* 188 */     if (this._propertyMap == null) {
/* 189 */       this._propertyMap = (Map<String, T>)new DataPropertyMap(this);
/*     */     }
/* 191 */     return this._propertyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T newProperty(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(T argProperty) {
/* 209 */     getPropertyMap().put(argProperty.getPropertyCode(), argProperty);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractDataModelWithPropertyImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */