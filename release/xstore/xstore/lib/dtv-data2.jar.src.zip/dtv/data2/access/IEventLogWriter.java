package dtv.data2.access;

import java.util.Date;

public interface IEventLogWriter {
  void writeEventLog(long paramLong1, long paramLong2, long paramLong3, String paramString1, String paramString2, String paramString3, Date paramDate, String paramString4, String paramString5, boolean paramBoolean);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\IEventLogWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */