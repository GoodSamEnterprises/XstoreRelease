package dtv.data2.access.impl.daogen;

import java.util.List;

public interface IHasConfigElementTables {
  List<String> getConfigElementTables();
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\IHasConfigElementTables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */