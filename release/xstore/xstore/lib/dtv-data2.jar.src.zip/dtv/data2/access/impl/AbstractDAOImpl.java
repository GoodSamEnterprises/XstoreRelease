/*     */ package dtv.data2.access.impl;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.DaoUtils;
/*     */ import dtv.data2.access.IDataAccessObject;
/*     */ import dtv.util.ObjectUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDAOImpl
/*     */   implements IDataAccessObject
/*     */ {
/*     */   public static final String DAO_ELEMENT_NAME = "dao";
/*     */   protected static final String XML_TAG_FIELD = "<fld id=\"";
/*     */   protected static final String REDACTED = "[REDACTED]";
/*  36 */   protected static final boolean MANAGE_CASE = PersistenceConstants.MANAGE_CASE;
/*     */   
/*     */   private static final long serialVersionUID = 4444477777L;
/*     */   
/*     */   private static final String TRANSIENT_OBJECT_FIELD_NAME = "TransientObject";
/*     */   
/*  42 */   private int _objectState = DaoState.CLEAN.intVal();
/*  43 */   private transient int _lastObjectState = DaoState.UNDEFINED.intVal();
/*     */ 
/*     */   
/*     */   private transient boolean _objectStateRulesApplied = false;
/*     */ 
/*     */   
/*     */   private transient boolean _suppressStateChanges = true;
/*     */ 
/*     */   
/*     */   private boolean _transientObject = false;
/*     */ 
/*     */   
/*     */   private transient String _originDataSource;
/*     */   
/*     */   private transient IPersistenceDefaults _persistenceDefaults;
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*  61 */     return super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastObjectState() {
/*  67 */     return this._lastObjectState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getObjectState() {
/*  74 */     return this._transientObject ? DaoState.CLEAN.intVal() : this._objectState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOriginDataSource() {
/*  85 */     return this._originDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isObjectStateRulesApplied() {
/*  91 */     return this._objectStateRulesApplied;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransientObject() {
/*  97 */     return this._transientObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void revertObjectState() {
/* 103 */     if (this._lastObjectState != DaoState.UNDEFINED.intVal()) {
/* 104 */       this._objectState = this._lastObjectState;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectState(int argState) {
/* 111 */     this._lastObjectState = this._objectState;
/* 112 */     this._objectState = DaoState.getNewState(this, argState);
/* 113 */     if (!this._suppressStateChanges) {
/* 114 */       DaoState.applyStateChanges(this, getPersistenceDefaults().getUserId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectState(String argObjectState) {
/* 121 */     int stateMask = DaoState.getStateMask(argObjectState);
/* 122 */     setObjectState(stateMask);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectStateRulesApplied(boolean argObjectStateRulesApplied) {
/* 128 */     this._objectStateRulesApplied = argObjectStateRulesApplied;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOriginDataSource(String argDataSourceName) {
/* 134 */     if (argDataSourceName != null && !argDataSourceName.equalsIgnoreCase(this._originDataSource)) {
/* 135 */       this._originDataSource = argDataSourceName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceDefaults(IPersistenceDefaults argPD) {
/* 150 */     this._suppressStateChanges = false;
/* 151 */     this._persistenceDefaults = argPD;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransientObject(boolean argTransientObject) {
/* 157 */     this._transientObject = argTransientObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(Map<String, String> argValues) {
/* 163 */     String value = argValues.get("TransientObject");
/* 164 */     Object fieldValue = DaoUtils.getFieldValueForXmlString(16, value);
/* 165 */     this._transientObject = (value == null) ? false : ((Boolean)fieldValue).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void suppressStateChanges(boolean argSuppress) {
/* 171 */     this._suppressStateChanges = argSuppress;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 177 */     return super.toString() + "Object Id: [" + getObjectId() + "} DaoState: [" + 
/* 178 */       DaoState.getStateString(getObjectState()) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean changed(boolean argOne, boolean argTwo, String argFieldKey) {
/* 193 */     boolean changed = (argOne != argTwo);
/* 194 */     if (changed) {
/* 195 */       handleChange();
/*     */     }
/* 197 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean changed(int argOne, int argTwo, String argFieldKey) {
/* 212 */     boolean changed = (argOne != argTwo);
/* 213 */     if (changed) {
/* 214 */       handleChange();
/*     */     }
/* 216 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean changed(long argOne, long argTwo, String argFieldKey) {
/* 231 */     boolean changed = (argOne != argTwo);
/* 232 */     if (changed) {
/* 233 */       handleChange();
/*     */     }
/* 235 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean changed(Object argOne, Object argTwo, String argFieldKey) {
/* 248 */     boolean changed = false;
/*     */ 
/*     */     
/* 251 */     if (argOne == "") {
/* 252 */       changed = (argTwo != null && argTwo != "");
/*     */     }
/* 254 */     else if (argTwo == "") {
/* 255 */       changed = (argOne != null && argOne != "");
/*     */     } else {
/*     */       
/* 258 */       changed = !ObjectUtils.equivalent(argOne, argTwo);
/*     */     } 
/*     */     
/* 261 */     if (changed) {
/* 262 */       handleChange();
/*     */     }
/* 264 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void getFieldsAsXml(StringBuilder argBuffer) {
/* 274 */     Map<String, String> values = getValues();
/* 275 */     Set<String> fieldNames = values.keySet();
/*     */     
/* 277 */     for (String fieldName : fieldNames) {
/* 278 */       argBuffer.append("<fld id=\"").append(fieldName).append("\" val=\"").append(values.get(fieldName))
/* 279 */         .append("\"/>");
/*     */     }
/*     */     
/* 282 */     if (!StringUtils.isEmpty(getOriginDataSource())) {
/* 283 */       argBuffer.append("<").append("originDS").append(">").append(getOriginDataSource()).append("</")
/* 284 */         .append("originDS").append(">");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getObjectStateString() {
/* 295 */     return DaoState.getStateString(getObjectState());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPersistenceDefaults getPersistenceDefaults() {
/* 304 */     return this._persistenceDefaults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, String> getValues() {
/* 314 */     Map<String, String> values = new HashMap<>();
/* 315 */     values.put("TransientObject", DaoUtils.getXmlSafeFieldValue(-7, Boolean.valueOf(this._transientObject)));
/* 316 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleChange() {
/* 327 */     if (this._objectState == DaoState.CLEAN.intVal()) {
/* 328 */       setObjectState(DaoState.UPDATED.intVal());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 337 */     in.defaultReadObject();
/* 338 */     this._lastObjectState = DaoState.UNDEFINED.intVal();
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractDAOImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */