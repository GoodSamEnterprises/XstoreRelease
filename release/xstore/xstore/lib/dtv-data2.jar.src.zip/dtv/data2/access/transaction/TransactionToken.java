/*     */ package dtv.data2.access.transaction;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionToken
/*     */ {
/*     */   public static final String TIMESTAMP_PROPERTY = "TIMESTAMP_PROPERTY";
/*     */   public static final String WORKSTATION_ID_PROPERTY = "WORKSTATION_ID_PROPERTY";
/*  26 */   private static transient long _counter = (new SecureRandom()).nextLong();
/*     */ 
/*     */ 
/*     */   
/*  30 */   private static final transient Object sync_ = new Object();
/*     */   private final String _uniqueId;
/*  32 */   private final Set<ITransactionalDataSource> _datasources = new LinkedHashSet<>();
/*  33 */   private final Map<String, String> _properties = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionToken(int argIdHash) {
/*  45 */     StringBuilder buf = new StringBuilder(64);
/*  46 */     buf.append(argIdHash);
/*  47 */     buf.append(System.currentTimeMillis());
/*     */     
/*  49 */     synchronized (sync_) {
/*  50 */       buf.append(++_counter);
/*     */     } 
/*     */     
/*  53 */     this._uniqueId = buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ITransactionalDataSource> drainDataSources() {
/*  62 */     synchronized (this._datasources) {
/*  63 */       Set<ITransactionalDataSource> datasources = new LinkedHashSet<>(this._datasources);
/*  64 */       this._datasources.clear();
/*  65 */       return datasources;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object argObject) {
/*  77 */     if (argObject instanceof TransactionToken) {
/*  78 */       return this._uniqueId.equals(((TransactionToken)argObject)._uniqueId);
/*     */     }
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITransactionalDataSource getDataSource(String argDataSource) {
/*  91 */     return getDataSource(argDataSource, ITransactionalDataSource.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ITransactionalDataSource> T getDataSource(String argDataSource, Class<T> argType) {
/* 105 */     if (argDataSource == null) {
/* 106 */       throw new DtxException("getDataSource was called without a datasource name.  This is not supported.");
/*     */     }
/* 108 */     if (argType == null) {
/* 109 */       throw new DtxException("getDataSource was called without a type parameter.  This is not supported.");
/*     */     }
/*     */     
/* 112 */     synchronized (this._datasources) {
/* 113 */       for (ITransactionalDataSource datasource : this._datasources) {
/* 114 */         if (argDataSource.equals(datasource.getDataSourceName()) && argType.isInstance(datasource)) {
/* 115 */           return (T)datasource;
/*     */         }
/*     */       } 
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 128 */     return this._properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String argPropertyName) {
/* 138 */     return this._properties.get(argPropertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 147 */     return this._uniqueId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDatasources() {
/* 156 */     synchronized (this._datasources) {
/* 157 */       return (this._datasources.size() > 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 168 */     return this._uniqueId.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerDataSource(ITransactionalDataSource argDataSource) {
/* 177 */     if (argDataSource == null) {
/* 178 */       throw new DataSourceTransactionException("datasource is null - a value must be provided. Cannot register null data source for token" + this);
/*     */     }
/*     */ 
/*     */     
/* 182 */     synchronized (this._datasources) {
/*     */       
/* 184 */       this._datasources.add(argDataSource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITransactionalDataSource removeDatasource(String argDatasourceName) {
/* 197 */     return removeDatasource(argDatasourceName, ITransactionalDataSource.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ITransactionalDataSource> T removeDatasource(String argDatasourceName, Class<T> argType) {
/* 212 */     synchronized (this._datasources) {
/* 213 */       Iterator<ITransactionalDataSource> iter = this._datasources.iterator();
/* 214 */       while (iter.hasNext()) {
/* 215 */         ITransactionalDataSource datasource = iter.next();
/* 216 */         if (datasource.getDataSourceName().equals(argDatasourceName) && argType.isInstance(datasource)) {
/* 217 */           iter.remove();
/* 218 */           return (T)datasource;
/*     */         } 
/*     */       } 
/*     */     } 
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String argPropertyName, String argPropertyValue) {
/* 232 */     this._properties.put(argPropertyName, argPropertyValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 242 */     synchronized (this._datasources) {
/* 243 */       return "TransactionToken [_uniqueId=" + this._uniqueId + ", _datasources=" + this._datasources + "]";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\transaction\TransactionToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */