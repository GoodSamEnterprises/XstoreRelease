/*    */ package dtv.data2.access.impl.jdbc;
/*    */ 
/*    */ import dtv.util.DateUtils;
/*    */ import java.util.Collection;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreparedStatementTranslator
/*    */ {
/*    */   public static String getPrettySql(String sql, Collection<Object> logParams) {
/* 26 */     StringTokenizer st = new StringTokenizer(sql, "?");
/* 27 */     StringBuilder statement = new StringBuilder(256);
/*    */     
/* 29 */     int count = 0;
/* 30 */     while (st.hasMoreTokens()) {
/* 31 */       statement.append(st.nextToken());
/* 32 */       if (count < logParams.size()) {
/* 33 */         Object currentParameter = logParams.toArray()[count];
/* 34 */         if (currentParameter != null) {
/* 35 */           if (currentParameter instanceof Number) {
/* 36 */             statement.append(currentParameter);
/*    */           }
/* 38 */           else if (currentParameter instanceof Date) {
/*    */ 
/*    */ 
/*    */             
/* 42 */             statement.append("to_date('").append(DateUtils.formatIsoDateTime((Date)currentParameter))
/* 43 */               .append("', 'YYYY-MM-DD\"T\"HH24:MI:SS')");
/*    */           }
/* 45 */           else if (currentParameter instanceof String && ((String)currentParameter)
/* 46 */             .startsWith("[SQL NULL of type ")) {
/* 47 */             statement.append("null");
/*    */           } else {
/*    */             
/* 50 */             statement.append("'").append(currentParameter).append("'");
/*    */           }
/*    */         
/*    */         } else {
/*    */           
/* 55 */           statement.append("null");
/*    */         
/*    */         }
/*    */       
/*    */       }
/* 60 */       else if (st.hasMoreTokens()) {
/* 61 */         statement.append("? ").append("(missing variable # ").append(count).append(") ");
/*    */       } 
/*    */       
/* 64 */       count++;
/*    */     } 
/* 66 */     return statement.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getPrettySql(String sql, Map<Object, Object> logParams) {
/* 77 */     return getPrettySql(sql, logParams.values());
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\PreparedStatementTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */