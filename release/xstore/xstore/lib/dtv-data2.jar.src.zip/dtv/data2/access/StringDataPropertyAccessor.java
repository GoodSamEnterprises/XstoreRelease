/*    */ package dtv.data2.access;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringDataPropertyAccessor<T extends IHasDataProperty<? extends IDataProperty>>
/*    */   extends AbstractDataPropertyAccessor<T, String>
/*    */ {
/*    */   public StringDataPropertyAccessor(Class<T> argParentType, String argKey) {
/* 22 */     super(argParentType, argKey);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue(T argParent) {
/* 31 */     return getValue(argParent, "");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue(T argParent, String argDefault) {
/* 37 */     String value = validParent(argParent).getStringProperty(getKey());
/* 38 */     if (value == null) {
/* 39 */       return argDefault;
/*    */     }
/* 41 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<String> getValueType() {
/* 50 */     return String.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(T argParent, String argValue) {
/* 56 */     validParent(argParent).setStringProperty(getKey(), argValue);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\StringDataPropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */