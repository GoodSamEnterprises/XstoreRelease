/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.query.QueryRequest;
/*     */ import dtv.util.NumberUtils;
/*     */ import dtv.util.StringUtils;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlPersistablesParser
/*     */ {
/*     */   public static final String XML_HEADER_PREFIX = "<?xml";
/*     */   public static final String XML_TIMEOUT_PREFIX = "<Timeout";
/*     */   public static final String XML_DAO_PREFIX = "<dao";
/*     */   public static final String XML_DAO_NAME_ATTR = "name";
/*     */   public static final String XML_DAO_CMD_ATTR = "cmd";
/*     */   public static final String XML_DAO_FIELD_ID_ATTR = "id";
/*     */   public static final String XML_DAO_FIELD_VAL_ATTR = "val";
/*     */   public static final String QUERY_REQUEST_PREFIX = "<QueryRequest";
/*     */   public static final String XML_BEGIN_TAG = "<req>";
/*     */   public static final String XML_END_TAG = "</req>";
/*     */   public static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
/*     */   private final String _xml;
/*     */   private Integer _timeout;
/*     */   
/*     */   public static String normalizeXml(String argXml) {
/*  71 */     if (argXml.startsWith("<?xml")) {
/*  72 */       return argXml;
/*     */     }
/*     */ 
/*     */     
/*  76 */     String trimmedXml = argXml.trim();
/*  77 */     StringBuilder builder = new StringBuilder(trimmedXml);
/*     */ 
/*     */     
/*  80 */     if (trimmedXml.startsWith("<dao") || trimmedXml.startsWith("<Timeout") || trimmedXml
/*  81 */       .startsWith("<QueryRequest")) {
/*  82 */       builder.insert(0, "<req>");
/*  83 */       builder.append("</req>");
/*     */     } 
/*     */ 
/*     */     
/*  87 */     if (!trimmedXml.startsWith("<?xml")) {
/*  88 */       builder.insert(0, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */     }
/*     */     
/*  91 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private final List<IPersistable> _persistables = new ArrayList<>(8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlPersistablesParser(String argXml) {
/* 105 */     this._xml = argXml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistablesPackage getPersistablePackage() {
/*     */     try {
/* 115 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 116 */       factory.setProperty("javax.xml.stream.supportDTD", Boolean.valueOf(false));
/* 117 */       String maxAttributeSizeProperty = "com.ctc.wstx.maxAttributeSize";
/* 118 */       if (factory.isPropertySupported("com.ctc.wstx.maxAttributeSize")) {
/* 119 */         String prop = System.getProperty("com.ctc.wstx.maxAttributeSize");
/* 120 */         if (NumberUtils.isInteger(prop)) {
/* 121 */           Integer origValue = (Integer)factory.getProperty("com.ctc.wstx.maxAttributeSize");
/* 122 */           Integer value = Integer.valueOf(prop);
/* 123 */           value = (value.intValue() >= origValue.intValue()) ? value : origValue;
/* 124 */           factory.setProperty("com.ctc.wstx.maxAttributeSize", value);
/*     */         } 
/*     */       } 
/* 127 */       XMLStreamReader reader = factory.createXMLStreamReader(new StringReader(normalizeXml(this._xml)));
/*     */       try {
/* 129 */         readDocument(reader);
/* 130 */         return new PersistablesPackage(this._persistables, this._timeout);
/*     */       } finally {
/*     */         
/* 133 */         reader.close();
/*     */       }
/*     */     
/* 136 */     } catch (Exception e) {
/* 137 */       throw new DtxException("An exception occurred when parsing persistables.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseDaoFieldFromReader(XMLStreamReader argReader, Map<String, String> fieldValues) {
/* 148 */     String id = null;
/* 149 */     String val = null;
/* 150 */     for (int i = 0; i < argReader.getAttributeCount(); i++) {
/* 151 */       switch (argReader.getAttributeLocalName(i)) {
/*     */         case "id":
/* 153 */           id = argReader.getAttributeValue(i);
/*     */           break;
/*     */         case "val":
/* 156 */           val = argReader.getAttributeValue(i);
/*     */           break;
/*     */       } 
/*     */     } 
/* 160 */     fieldValues.put(id, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseDaoFromReader(XMLStreamReader argReader) throws XMLStreamException {
/* 171 */     String name = null;
/* 172 */     String cmd = null;
/* 173 */     for (int i = 0; i < argReader.getAttributeCount(); i++) {
/* 174 */       switch (argReader.getAttributeLocalName(i)) {
/*     */         case "name":
/* 176 */           name = argReader.getAttributeValue(i);
/*     */           break;
/*     */         case "cmd":
/* 179 */           cmd = argReader.getAttributeValue(i);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 185 */     IDataAccessObject dao = DataModelFactory.getDaoForDaoName(name);
/* 186 */     Map<String, String> fieldValues = new HashMap<>();
/* 187 */     while (argReader.hasNext()) {
/* 188 */       int eventType = argReader.nextTag();
/* 189 */       if (eventType == 1) {
/*     */         
/* 191 */         if ("originDS".equalsIgnoreCase(argReader.getLocalName())) {
/* 192 */           String originDataSource = argReader.getElementText();
/* 193 */           if (!StringUtils.isEmpty(originDataSource)) {
/* 194 */             dao.setOriginDataSource(originDataSource);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 199 */         parseDaoFieldFromReader(argReader, fieldValues);
/*     */         continue;
/*     */       } 
/* 202 */       if (eventType == 2 && argReader
/* 203 */         .getLocalName().equals("dao")) {
/*     */         
/* 205 */         dao.setValues(fieldValues);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         dao.setObjectState(DaoState.CLEAN.intVal());
/* 215 */         dao.setObjectState(cmd);
/*     */ 
/*     */         
/* 218 */         this._persistables.add(dao);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseQueryRequestFromReader(XMLStreamReader argReader) throws XMLStreamException {
/* 232 */     QueryRequest request = new QueryRequest();
/* 233 */     request.unmarshall(argReader);
/* 234 */     this._persistables.add(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readDocument(XMLStreamReader argReader) throws XMLStreamException {
/* 245 */     while (argReader.hasNext()) {
/* 246 */       int elementType = argReader.next();
/* 247 */       if (elementType == 1) {
/* 248 */         readElements(argReader); continue;
/*     */       } 
/* 250 */       if (elementType == 2) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readElements(XMLStreamReader argReader) throws XMLStreamException {
/* 265 */     while (argReader.hasNext()) {
/* 266 */       int eventType = argReader.next();
/* 267 */       if (eventType == 1) {
/* 268 */         switch (argReader.getLocalName()) {
/*     */           case "dao":
/* 270 */             parseDaoFromReader(argReader);
/*     */             continue;
/*     */           case "QueryRequest":
/* 273 */             parseQueryRequestFromReader(argReader);
/*     */             continue;
/*     */           case "Timeout":
/* 276 */             parseTimeoutFromReader(argReader);
/*     */             continue;
/*     */         } 
/* 279 */         throw new DtxException("Unknown element detected in persistables XML: " + argReader
/* 280 */             .getLocalName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseTimeoutFromReader(XMLStreamReader argReader) {
/* 291 */     for (int i = 0; i < argReader.getAttributeCount(); i++) {
/* 292 */       if (argReader.getAttributeLocalName(i).equals("t")) {
/* 293 */         String timeoutString = argReader.getAttributeValue(i);
/* 294 */         if (!StringUtils.isEmpty(timeoutString))
/* 295 */           this._timeout = Integer.valueOf(timeoutString); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\XmlPersistablesParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */