/*     */ package dtv.data2.access;
/*     */ 
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.PersistenceException;
/*     */ import dtv.data2.access.exception.SpecialActionException;
/*     */ import dtv.data2.access.impl.DaoState;
/*     */ import dtv.data2.access.impl.IDataModelImpl;
/*     */ import dtv.data2.access.impl.IDataModelRelationshipImpl;
/*     */ import dtv.data2.access.impl.IExtensibleDataAccessObjectImpl;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.util.DateUtils;
/*     */ import dtv.util.DtvDate;
/*     */ import dtv.util.EncodingHelper;
/*     */ import dtv.util.HistoricalList;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.XmlUtils;
/*     */ import dtv.util.crypto.EncString;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DaoUtils
/*     */ {
/*     */   private static final String SERIALIZED_NULL = "nul";
/*     */   public static final String QUERY_DEBUGGER = "DtxQueryDebugger";
/*     */   private static final String RESTRICTED_CLASS = "dtv.pos.storecalendar.AbsoluteDtvDateRange";
/*  39 */   private static final Logger failedPersistenceLogger_ = Logger.getLogger("FAILED_PERSISTENCE_LOG");
/*     */ 
/*     */   
/*  42 */   private static ThreadLocal<SimpleDateFormat> DATE_TIME_FORMAT = new ThreadLocal<SimpleDateFormat>()
/*     */     {
/*     */       protected synchronized SimpleDateFormat initialValue()
/*     */       {
/*  46 */         return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean anyInState(Object argObject, DaoState argState) {
/*  60 */     boolean anyFound = false;
/*     */     
/*  62 */     for (IPersistable persistable : getPersistables(argObject)) {
/*  63 */       if (persistable instanceof IDataAccessObject && 
/*  64 */         argState.matches((IDataAccessObject)persistable)) {
/*  65 */         anyFound = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  70 */     return anyFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDataAccessObject cloneDao(IDataAccessObject argDaoToClone) {
/*  80 */     if (argDaoToClone == null) {
/*  81 */       throw new DtxException("cloneDao cannot accept a null argDaoToClone. Please pass a valid, non-null dao.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  86 */       IDataAccessObject daoClone = (IDataAccessObject)argDaoToClone.clone();
/*  87 */       daoClone.setOriginDataSource(argDaoToClone.getOriginDataSource());
/*  88 */       return daoClone;
/*     */     }
/*  90 */     catch (CloneNotSupportedException ee) {
/*  91 */       throw new DtxException("Unexpected problem cloning dao [" + argDaoToClone.getClass().getName() + "] id: " + argDaoToClone
/*  92 */           .getObjectId(), ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(Collection<?> argObjs, IDataModel argDataModel) {
/* 105 */     boolean contains = false;
/*     */     
/* 107 */     if (argDataModel != null && argObjs != null) {
/* 108 */       for (Object obj : argObjs) {
/* 109 */         if (obj instanceof IDataModel && equivalent((IDataModel)obj, argDataModel)) {
/* 110 */           contains = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 115 */     return contains;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean equivalent(IDataModel argObject1, IDataModel argObject2) {
/* 128 */     if (argObject1 == argObject2) {
/* 129 */       return true;
/*     */     }
/*     */     
/* 132 */     if (argObject1 == null || argObject2 == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     return argObject1.getObjectId().equals(argObject2.getObjectId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<? extends PersistableLink> getAllPersistables(Object argObject) {
/* 149 */     return getPersistableLinks(argObject, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <D extends IDataAccessObject> D getDao(IDataModel argModel, Class<D> argDaoType) {
/* 162 */     return (argModel instanceof IDataModelImpl) ? (D)((IDataModelImpl)argModel).getDAO() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getFieldValueForXmlString(int argDataType, String argFieldValue) {
/* 174 */     if (argFieldValue == null || argFieldValue.equals("nul")) {
/* 175 */       return null;
/*     */     }
/* 177 */     Object result = null;
/*     */     
/* 179 */     switch (argDataType)
/*     */     { case -7:
/*     */       case 16:
/* 182 */         if (argFieldValue.equals("1")) {
/* 183 */           result = Boolean.valueOf(true);
/*     */         }
/* 185 */         else if (argFieldValue.equals("0")) {
/* 186 */           result = Boolean.valueOf(false);
/*     */         } else {
/*     */           
/* 189 */           result = Boolean.valueOf(argFieldValue);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 263 */         return result;case -6: case 4: case 5: try { result = Integer.valueOf(argFieldValue); } catch (NumberFormatException ex) { result = Long.valueOf(argFieldValue); }  return result;case -5: result = Long.valueOf(argFieldValue); return result;case 3: case 6: case 7: case 8: result = new BigDecimal(argFieldValue); return result;case 91: case 92: case 93: try { result = new DtvDate(); ((DtvDate)result).setTimeFromSerialization(Long.valueOf(argFieldValue).longValue()); } catch (NumberFormatException ee) { Date parsedDate = DateUtils.parseIso(argFieldValue); if (parsedDate == null) try { parsedDate = ((SimpleDateFormat)DATE_TIME_FORMAT.get()).parse(argFieldValue); } catch (Exception ee2) { parsedDate = DateUtils.parseDate(argFieldValue); }   if (parsedDate != null) { result = new DtvDate(parsedDate.getTime()); } else { throw new DtxException("Could not parse date string: " + argFieldValue); }  }  return result;case -4: result = EncodingHelper.decodeObject(argFieldValue, false); return result; }  result = argFieldValue; return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistablesPackage getPersistablePackageForXml(String argXml) {
/* 273 */     XmlPersistablesParser persistables = new XmlPersistablesParser(argXml);
/* 274 */     return persistables.getPersistablePackage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<IPersistable> getPersistables(Object argObject) {
/* 284 */     Object obj = (argObject instanceof Object[]) ? Arrays.<Object>asList((Object[])argObject) : argObject;
/*     */     
/* 286 */     LinkedHashMap<PersistableKey, IPersistable> map = new LinkedHashMap<>();
/* 287 */     getPersistablesImpl(obj, map);
/*     */ 
/*     */     
/* 290 */     List<IPersistable> list = new ArrayList<>(map.values());
/*     */     
/* 292 */     for (IPersistable persistable : list) {
/* 293 */       setDaoClassName(persistable);
/*     */     }
/* 295 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<IPersistable> getPersistablesForXml(String argXml) {
/* 305 */     return getPersistablePackageForXml(argXml).getPersistables();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<? extends PersistableLink> getRootPersistables(Object argObject) {
/* 317 */     return getPersistableLinks(argObject, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDataAccessObject getSampleDao(Object argObject) throws PersistenceException {
/* 332 */     if (argObject == null) {
/* 333 */       throw new PersistenceException("Cannot start transaction for null object!");
/*     */     }
/*     */     
/* 336 */     if (argObject instanceof IDataModelImpl) {
/* 337 */       return ((IDataModelImpl)argObject).getDAO();
/*     */     }
/* 339 */     if (argObject instanceof IDataAccessObject) {
/* 340 */       return (IDataAccessObject)argObject;
/*     */     }
/* 342 */     if (argObject instanceof Collection) {
/* 343 */       Collection<?> col = (Collection)argObject;
/* 344 */       if (col.isEmpty()) {
/* 345 */         throw new PersistenceException("Cannot retrieve models from an empty collection!");
/*     */       }
/*     */       
/* 348 */       Iterator<?> it = col.iterator();
/* 349 */       Object firstObject = null;
/* 350 */       while (it.hasNext()) {
/* 351 */         firstObject = it.next();
/* 352 */         if (!(firstObject instanceof IDataAccessObject))
/*     */         {
/* 354 */           firstObject = null;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 361 */       if (firstObject == null) {
/* 362 */         return null;
/*     */       }
/*     */       
/* 365 */       if (firstObject instanceof Collection) {
/* 366 */         throw new PersistenceException("Cannot start a transaction for a collection within a collection: cannot determine model class.");
/*     */       }
/*     */ 
/*     */       
/* 370 */       return getSampleDao(firstObject);
/*     */     } 
/*     */ 
/*     */     
/* 374 */     throw new PersistenceException("Cannot start a transaction for type: " + argObject
/* 375 */         .getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getXmlSafeFieldValue(int argDataType, Object argFieldValue) {
/* 388 */     String result = null;
/*     */     
/* 390 */     if (argFieldValue == null) {
/* 391 */       return "nul";
/*     */     }
/* 393 */     if (argFieldValue instanceof DtvDate) {
/* 394 */       return String.valueOf(((DtvDate)argFieldValue).getTimeSerializable());
/*     */     }
/* 396 */     if (argFieldValue instanceof Boolean) {
/* 397 */       return ((Boolean)argFieldValue).booleanValue() ? "1" : "0";
/*     */     }
/* 399 */     if (argFieldValue instanceof BigDecimal) {
/* 400 */       BigDecimal dec = ((BigDecimal)argFieldValue).stripTrailingZeros();
/* 401 */       return dec.toPlainString();
/*     */     } 
/* 403 */     if (argFieldValue instanceof Number) {
/* 404 */       return argFieldValue.toString();
/*     */     }
/*     */     
/* 407 */     if (argDataType == -4) {
/* 408 */       result = EncodingHelper.encodeObject(argFieldValue, false);
/*     */     } else {
/*     */       
/* 411 */       result = argFieldValue.toString();
/*     */     } 
/*     */     
/* 414 */     return XmlUtils.toXmlSafe(new StringBuilder(result)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isClean(IPersistable argPersistable) {
/* 424 */     boolean clean = false;
/* 425 */     if (argPersistable instanceof IDataAccessObject) {
/* 426 */       clean = DaoState.isClean((IDataAccessObject)argPersistable);
/*     */     }
/* 428 */     else if (argPersistable instanceof IDataModelImpl) {
/* 429 */       clean = DaoState.isClean(((IDataModelImpl)argPersistable).getDAO());
/*     */     } 
/* 431 */     return clean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSetter(Method argMethod) {
/* 442 */     return (argMethod.getName().startsWith("set") && !argMethod.getName().equals("setValues"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTreeDirty(Object argObject) {
/* 455 */     boolean dirty = false;
/*     */     
/* 457 */     for (PersistableLink modelData : getAllPersistables(argObject)) {
/* 458 */       if (!isClean(modelData.getPersistable())) {
/* 459 */         dirty = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 463 */     return dirty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IObjectId loadIDFromValueMap(IObjectId argId, Map<String, String> argValues) {
/* 477 */     Method[] idMethods = argId.getClass().getMethods();
/*     */     
/* 479 */     for (Method method : idMethods) {
/* 480 */       if (isSetter(method)) {
/* 481 */         String value = argValues.get(getKeyFromSetter(method));
/*     */         try {
/* 483 */           if (value != null) {
/* 484 */             Object valueCorrectType = getValueWithCorrectType(value, method);
/* 485 */             method.invoke(argId, new Object[] { valueCorrectType });
/*     */           }
/*     */         
/* 488 */         } catch (Exception e) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 493 */     return argId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void logFailedPersistence(Throwable argEx, Object argObject) {
/* 506 */     failedPersistenceLogger_
/* 507 */       .error("Persistence Failed: " + SpecialActionException.getFullExceptionString(argEx));
/*     */     
/* 509 */     StringBuilder buff = new StringBuilder(1024);
/* 510 */     for (IPersistable persistable : getPersistables(argObject)) {
/*     */       
/* 512 */       if (isClean(persistable)) {
/*     */         continue;
/*     */       }
/* 515 */       buff.append(persistable.toXmlString());
/*     */     } 
/*     */     
/* 518 */     buff.insert(0, "<FailedPersistence>");
/* 519 */     buff.append("</FailedPersistence>");
/*     */     
/* 521 */     failedPersistenceLogger_.error(buff.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void massageQueryParams(Map<String, Object> argParams, Long argOrgId) {
/* 531 */     if (argParams == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 536 */     DtvDate.ensureProperDates(argParams);
/*     */     
/* 538 */     for (Map.Entry<String, Object> entry : argParams.entrySet()) {
/* 539 */       Object oo = entry.getValue();
/*     */ 
/*     */ 
/*     */       
/* 543 */       if (oo instanceof EncString) {
/* 544 */         entry.setValue(EncString.getSensitiveData(oo));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 549 */       if (oo != null && "dtv.pos.storecalendar.AbsoluteDtvDateRange".equals(oo.getClass().getName())) {
/* 550 */         throw new DtxException("Illegal query parameter detected.  Class [dtv.pos.storecalendar.AbsoluteDtvDateRange] is not allowed as a query parameter. Object: [" + oo + "] Parameters: " + argParams);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 558 */     if (!argParams.containsKey("argOrganizationId")) {
/* 559 */       argParams.put("argOrganizationId", argOrgId);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDataSourceOnAll(IDataModel argModel, String argDataSource) {
/* 572 */     for (IPersistable persistable : getPersistables(argModel)) {
/* 573 */       if (persistable instanceof IDataAccessObject) {
/* 574 */         ((IDataAccessObject)persistable).setOriginDataSource(argDataSource);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void getPersistablesImpl(Object argObject, LinkedHashMap<PersistableKey, IPersistable> argPersistablesMap) {
/* 592 */     if (argObject instanceof IDataAccessObject) {
/* 593 */       IDataAccessObject dao = (IDataAccessObject)argObject;
/* 594 */       PersistableKey key = new PersistableKey(dao);
/*     */ 
/*     */ 
/*     */       
/* 598 */       argPersistablesMap.remove(key);
/*     */       
/* 600 */       argPersistablesMap.put(key, dao);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 606 */     if (argObject instanceof HistoricalList) {
/*     */ 
/*     */ 
/*     */       
/* 610 */       List<?> removedElements = ((HistoricalList)argObject).getDeletedItems();
/* 611 */       if (removedElements != null) {
/* 612 */         for (int ii = 0; ii < removedElements.size(); ii++) {
/* 613 */           IDataModelImpl deleteMe = (IDataModelImpl)removedElements.get(ii);
/* 614 */           deleteMe.getDAO().setObjectState(DaoState.DELETED.intVal());
/* 615 */           getPersistablesImpl(deleteMe, argPersistablesMap);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 621 */       Iterator<?> it = ((HistoricalList)argObject).iterator();
/*     */       
/* 623 */       while (it.hasNext()) {
/* 624 */         getPersistablesImpl(it.next(), argPersistablesMap);
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 631 */     if (argObject instanceof Collection) {
/* 632 */       Collection<?> currentCollection = (Collection)argObject;
/* 633 */       Iterator<?> it = currentCollection.iterator();
/*     */       
/* 635 */       while (it.hasNext()) {
/* 636 */         getPersistablesImpl(it.next(), argPersistablesMap);
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 643 */     if (argObject instanceof IDataModelImpl) {
/* 644 */       IDataModelImpl model = (IDataModelImpl)argObject;
/* 645 */       IDataAccessObject dao = model.getDAO();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 651 */       if (argPersistablesMap.putIfAbsent(new PersistableKey(model), dao) != null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 659 */       IDataModelRelationship[] rels = DataModelFactory.getModelRelationships(model.getDAO());
/*     */       
/* 661 */       if (rels != null)
/*     */       {
/* 663 */         for (IDataModelRelationship rel : rels) {
/* 664 */           IDataModelRelationshipImpl relationship = (IDataModelRelationshipImpl)rel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 670 */           if (relationship instanceof dtv.data2.access.impl.ManyToManyRelationship);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 678 */           Object relatedObject = model.getValue(relationship.getIdentifier());
/*     */           
/* 680 */           if (relatedObject != null) {
/* 681 */             if (relatedObject instanceof HistoricalList) {
/* 682 */               HistoricalList<?> historicalList = (HistoricalList)relatedObject;
/* 683 */               if (!historicalList.isEmpty() || historicalList.getDeletedItems() != null) {
/* 684 */                 getPersistablesImpl(relatedObject, argPersistablesMap);
/*     */ 
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 690 */             else if (relatedObject instanceof Collection) {
/* 691 */               if (!((Collection)relatedObject).isEmpty()) {
/* 692 */                 getPersistablesImpl(relatedObject, argPersistablesMap);
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 699 */               getPersistablesImpl(relatedObject, argPersistablesMap);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 707 */       Set<?> deletedBag = model.getAndClearDeletedObjects();
/*     */       
/* 709 */       if (deletedBag != null && !deletedBag.isEmpty()) {
/* 710 */         getPersistablesImpl(deletedBag, argPersistablesMap);
/*     */ 
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 716 */     else if (argObject instanceof dtv.data2.access.query.QueryRequest) {
/* 717 */       argPersistablesMap.put(new PersistableKey(argObject), argObject);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 722 */     else if (argObject instanceof dtv.data2.access.query.SqlQueryRequest) {
/* 723 */       argPersistablesMap.put(new PersistableKey(argObject), argObject);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 729 */       if (argObject instanceof IRunQueryKey) {
/* 730 */         throw new DtxException("Sorry! action queries are depracted. Key " + ((IRunQueryKey)argObject)
/* 731 */             .getQueryKey().getName());
/*     */       }
/*     */       
/* 734 */       throw new DtxException("Unknown type passed to getPersistables(): " + argObject.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setDaoClassName(IPersistable argDao) {
/* 747 */     if (argDao instanceof IExtensibleDataAccessObjectImpl) {
/* 748 */       IExtensibleDataAccessObjectImpl daoExstensible = (IExtensibleDataAccessObjectImpl)argDao;
/*     */       
/* 750 */       if (StringUtils.isEmpty(daoExstensible.getImplementingClass())) {
/* 751 */         String className = daoExstensible.getClass().getName();
/* 752 */         if (!className.endsWith("DAO")) {
/* 753 */           throw new DtxException("Cannot determine proper value for class name field based on class named: " + className + ". We expect this to end in 'DAO', like ItemDAO");
/*     */         }
/*     */         
/* 756 */         daoExstensible.setClassName(className.substring(0, className.length() - 3));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getKeyFromSetter(Method m) {
/* 768 */     return m.getName().substring(3);
/*     */   }
/*     */   
/*     */   private static Collection<? extends PersistableLink> getPersistableLinks(Object argRoot, boolean argDeep) {
/* 772 */     Set<PersistableLink> modelRelationships = new LinkedHashSet<>();
/* 773 */     getPersistableLinks(argRoot, null, null, modelRelationships, argDeep);
/*     */     
/* 775 */     return modelRelationships;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void getPersistableLinks(Object argObject, IDataModelImpl argParent, String argRelationship, Set<PersistableLink> argLinks, boolean argDeep) {
/* 783 */     if (argObject instanceof IDataModelImpl) {
/* 784 */       IDataModelImpl model = (IDataModelImpl)argObject;
/*     */       
/* 786 */       PersistableLink link = new PersistableLink((IPersistable)model, (IPersistable)argParent, argRelationship);
/* 787 */       if (argLinks.add(link))
/*     */       {
/* 789 */         if (argDeep) {
/* 790 */           IDataModelRelationship[] rels = DataModelFactory.getModelRelationships(model.getDAO());
/* 791 */           if (rels != null) {
/* 792 */             for (IDataModelRelationship relationship : rels) {
/* 793 */               String relationshipName = relationship.getIdentifier();
/* 794 */               Object relatedObjects = model.getValue(relationshipName);
/*     */               
/* 796 */               getPersistableLinks(relatedObjects, model, relationshipName, argLinks, argDeep);
/*     */             }
/*     */           
/*     */           }
/*     */         } 
/*     */       }
/* 802 */     } else if (argObject instanceof IPersistable) {
/*     */ 
/*     */ 
/*     */       
/* 806 */       PersistableLink link = new PersistableLink((IPersistable)argObject);
/* 807 */       argLinks.add(link);
/*     */     }
/* 809 */     else if (argObject instanceof HistoricalList) {
/* 810 */       HistoricalList<?> objects = (HistoricalList)argObject;
/* 811 */       if (!objects.isEmpty() || objects.getDeletedItems() != null) {
/* 812 */         for (Object entry : objects) {
/* 813 */           getPersistableLinks(entry, argParent, argRelationship, argLinks, argDeep);
/*     */         }
/*     */       }
/*     */     }
/* 817 */     else if (argObject instanceof Collection) {
/* 818 */       for (Object entry : argObject) {
/* 819 */         getPersistableLinks(entry, argParent, argRelationship, argLinks, argDeep);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getValueWithCorrectType(String value, Method method) throws Exception {
/* 837 */     Class<?>[] paramTypes = method.getParameterTypes();
/* 838 */     if (paramTypes.length == 0 || paramTypes.length > 1) {
/* 839 */       throw new Exception("Method: " + method.getName() + " does not appear to be a setter");
/*     */     }
/* 841 */     Class<?> paramType = paramTypes[0];
/* 842 */     int jdbcType = JDBCHelper.getJDBCTypeForTypeName(paramType.getSimpleName());
/*     */     
/* 844 */     return getFieldValueForXmlString(jdbcType, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PersistableLink
/*     */   {
/*     */     private final IPersistable _persistable;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final IPersistable _parent;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _relationship;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PersistableLink(IPersistable argPersistable) {
/* 870 */       this(argPersistable, null, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PersistableLink(IPersistable argPersistable, IPersistable argParent, String argRelationship) {
/* 883 */       this._persistable = argPersistable;
/* 884 */       this._parent = argParent;
/* 885 */       this._relationship = argRelationship;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object argObj) {
/* 891 */       if (argObj == null || getClass() != argObj.getClass()) {
/* 892 */         return false;
/*     */       }
/* 894 */       PersistableLink other = (PersistableLink)argObj;
/* 895 */       return (Objects.equals(this._persistable, other._persistable) && Objects.equals(this._parent, other._parent) && 
/* 896 */         Objects.equals(this._relationship, other._relationship));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IPersistable getParent() {
/* 905 */       return this._parent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IPersistable getPersistable() {
/* 913 */       return this._persistable;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getRelationship() {
/* 923 */       return this._relationship;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 929 */       return Objects.hash(new Object[] { this._persistable, this._parent, this._relationship });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 935 */       return this._parent + " -> " + this._persistable + " [" + this._relationship + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PersistableKey
/*     */   {
/*     */     private final IObjectId id_;
/*     */ 
/*     */     
/*     */     private final int objectState_;
/*     */ 
/*     */     
/*     */     private final String queryIdentifier_;
/*     */ 
/*     */     
/*     */     public PersistableKey(Object argObject) {
/* 953 */       if (argObject == null) {
/* 954 */         throw new DtxException("null is not an acceptable param for PersistableKey constructor.");
/*     */       }
/*     */       
/* 957 */       if (argObject instanceof IDataModelImpl) {
/* 958 */         this.id_ = ((IDataModelImpl)argObject).getObjectId();
/* 959 */         this.objectState_ = ((IDataModelImpl)argObject).getDAO().getObjectState();
/* 960 */         this.queryIdentifier_ = null;
/*     */       }
/* 962 */       else if (argObject instanceof IDataAccessObject) {
/* 963 */         this.id_ = ((IDataAccessObject)argObject).getObjectId();
/* 964 */         this.objectState_ = ((IDataAccessObject)argObject).getObjectState();
/* 965 */         this.queryIdentifier_ = null;
/*     */       }
/* 967 */       else if (argObject instanceof IPersistable) {
/* 968 */         this.id_ = null;
/* 969 */         this.objectState_ = DaoState.UNDEFINED.intVal();
/* 970 */         this.queryIdentifier_ = argObject.toString();
/*     */       } else {
/*     */         
/* 973 */         throw new DtxException("Unknown object passed to constuctor of PersistableKey: [" + argObject + "]");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object argObject) {
/* 980 */       if (argObject == null || getClass() != argObject.getClass()) {
/* 981 */         return false;
/*     */       }
/* 983 */       PersistableKey other = (PersistableKey)argObject;
/* 984 */       return (Objects.equals(this.id_, other.id_) && Objects.equals(Integer.valueOf(this.objectState_), Integer.valueOf(other.objectState_)) && 
/* 985 */         Objects.equals(this.queryIdentifier_, other.queryIdentifier_));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 990 */       return Objects.hash(new Object[] { this.id_, Integer.valueOf(this.objectState_), this.queryIdentifier_ });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 995 */       return getClass().getSimpleName() + "[object id: " + this.id_ + " Object state: " + this.objectState_ + " Query Id: " + this.queryIdentifier_ + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\DaoUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */