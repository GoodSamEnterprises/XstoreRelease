/*    */ package dtv.data2.access.config.query;
/*    */ 
/*    */ import dtv.util.config.AbstractSetConfig;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuerySetConfig
/*    */   extends AbstractSetConfig<QueryConfig>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public String getChildTag() {
/* 25 */     return "Query";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<QueryDescriptor> getQueryDescriptors() {
/* 34 */     List<QueryDescriptor> descriptors = new ArrayList<>();
/* 35 */     for (QueryConfig config : getChildren()) {
/* 36 */       descriptors.add(config.getQueryDescriptor());
/*    */     }
/* 38 */     return descriptors;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\query\QuerySetConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */