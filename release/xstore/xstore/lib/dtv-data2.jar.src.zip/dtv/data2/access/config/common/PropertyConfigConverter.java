/*    */ package dtv.data2.access.config.common;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyConfigConverter
/*    */ {
/*    */   public static Properties convert(List<PropertyConfig> argConfigs) {
/* 24 */     return convert(argConfigs, new Properties());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Properties convert(List<PropertyConfig> argConfigs, Properties argTarget) {
/* 35 */     if (argConfigs == null || argConfigs.isEmpty()) {
/* 36 */       return argTarget;
/*    */     }
/*    */     
/* 39 */     PropertyConfig[] configs = new PropertyConfig[argConfigs.size()];
/* 40 */     configs = argConfigs.<PropertyConfig>toArray(configs);
/* 41 */     return convert(configs, argTarget);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Properties convert(PropertyConfig[] argConfigs) {
/* 52 */     return convert(argConfigs, new Properties());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Properties convert(PropertyConfig[] argConfigs, Properties argTarget) {
/* 63 */     if (argConfigs == null || argConfigs.length < 1) {
/* 64 */       return argTarget;
/*    */     }
/*    */     
/* 67 */     for (PropertyConfig argConfig : argConfigs) {
/* 68 */       if (argConfig.getKey() != null && argConfig.getValue() != null) {
/* 69 */         argTarget.setProperty(argConfig.getKey(), argConfig.getValue());
/*    */       }
/*    */     } 
/*    */     
/* 73 */     return argTarget;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\config\common\PropertyConfigConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */