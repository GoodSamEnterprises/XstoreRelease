/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.data2.access.DataModelFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateDataModelFactoryImpl
/*     */   implements Callable<Void>
/*     */ {
/*  21 */   private static final Logger logger_ = Logger.getLogger(GenerateDataModelFactoryImpl.class);
/*  22 */   private static final Class<?> DEFAULT_TARGET = DataModelFactory.class;
/*     */   private static final String DEFAULT_CLASS_NAME = "DataModelFactoryImpl";
/*     */   private static final String DEFAULT_FILE_NAME = "DataModelFactoryImpl.java";
/*     */   private static final String DEFAULT_DIRECTORY = "/dtv/data2/access/impl/";
/*     */   private static final String DEFAULT_PACKAGE = "dtv.data2.access.impl";
/*     */   private static GenerateDataModelFactoryImpl INSTANCE;
/*     */   
/*     */   static {
/*     */     try {
/*  31 */       String className = System.getProperty(GenerateDataModelFactoryImpl.class.getName(), GenerateDataModelFactoryImpl.class
/*  32 */           .getName());
/*  33 */       INSTANCE = (GenerateDataModelFactoryImpl)Class.forName(className).newInstance();
/*     */     }
/*  35 */     catch (Exception ee) {
/*  36 */       System.err.println(ee);
/*  37 */       logger_.error("STACK", ee);
/*  38 */       if (ee instanceof RuntimeException) {
/*  39 */         throw (RuntimeException)ee;
/*     */       }
/*     */       
/*  42 */       throw new RuntimeException(ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GenerateDataModelFactoryImpl getInstance() {
/*  59 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*  63 */   protected DaoGenHelper helper_ = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  81 */     logger_.info("Generating DataModelFactoryImpl");
/*     */     
/*  83 */     Writer w = new StringWriter(10240);
/*     */     
/*  85 */     writePackageDeclaration(w);
/*  86 */     writeImportDeclaration(w);
/*     */     
/*  88 */     w.append("@SuppressWarnings(\"all\")\n");
/*  89 */     writeClassName(w);
/*  90 */     w.append("\n");
/*     */     
/*  92 */     writeVariableDeclaration(w);
/*  93 */     writeStaticDeclaration(w);
/*     */     
/*  95 */     writeAdditionalMethods(w);
/*     */     
/*  97 */     w.append("}\n\n");
/*     */ 
/*     */     
/* 100 */     File f = new File(this.helper_.getOutPath() + DaoGenTargetHelper.getDirectoryName(DEFAULT_TARGET, "/dtv/data2/access/impl/") + getFileName());
/* 101 */     this.helper_.getWriter().write(f, w.toString());
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHelper(DaoGenHelper argHelper) {
/* 111 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFileName() {
/* 120 */     return DaoGenTargetHelper.getFileName(DEFAULT_TARGET, "DataModelFactoryImpl.java");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeAdditionalMethods(Writer argW) throws IOException {
/* 131 */     writeAddRelationshipsMethod(argW);
/* 132 */     writeAddDaosMethod(argW);
/* 133 */     writeAddObjectIdsMethod(argW);
/* 134 */     writeAddDataModelsMethod(argW);
/* 135 */     writeAddInterfacesMethod(argW);
/* 136 */     writeGetRelationshipInternalMethod(argW);
/*     */     
/* 138 */     writeGetRelationshipImplMethod(argW);
/* 139 */     writeGetDaoForDaoNameImplMethod(argW);
/* 140 */     writeGetIdForDaoNameImplMethod(argW);
/* 141 */     writeGetModelForDAOImplMethod(argW);
/* 142 */     writeGetModelForInterfaceImplMethod(argW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeClassName(Writer argWriter) throws IOException {
/* 153 */     argWriter.append("public class ");
/* 154 */     argWriter.append(DaoGenTargetHelper.getClassName(DEFAULT_TARGET, "DataModelFactoryImpl"));
/* 155 */     argWriter.append(" extends DataModelFactory {\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeImportDeclaration(Writer argW) throws IOException {
/* 166 */     argW.append("import dtv.data2.access.exception.DtxException;\n");
/* 167 */     argW.append("import dtv.data2.access.*;\n");
/* 168 */     argW.append("import dtv.data2.access.impl.*;\n");
/* 169 */     argW.append("import java.util.HashMap;\n");
/* 170 */     argW.append("import java.util.Map;\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writePackageDeclaration(Writer argW) throws IOException {
/* 181 */     if (argW == null) {
/*     */       return;
/*     */     }
/* 184 */     String name = DaoGenTargetHelper.getPackageName(DEFAULT_TARGET, "dtv.data2.access.impl");
/* 185 */     if (name != null && name.length() > 0) {
/* 186 */       argW.append("package ");
/* 187 */       argW.append(name);
/* 188 */       argW.append(";\n\n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeStaticDeclaration(Writer argW) throws IOException {
/* 200 */     if (this.helper_.getDtxDefinitions() == null || this.helper_.getDtxDefinitions().isEmpty()) {
/*     */       return;
/*     */     }
/* 203 */     argW.append("  {\n");
/* 204 */     argW.append("    IRelationshipSetProducer relationshipProducer;\n");
/* 205 */     argW.append("    String parentClassName = null;\n\n");
/* 206 */     argW.append("    IRelationshipSetProducer baseRelationshipProducer;\n");
/* 207 */     argW.append("    IRelationshipSetProducer custRelationshipProducer;\n");
/* 208 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/*     */       
/* 210 */       List<DtxRelationship> allRelationships = dtx.getAllRelationships();
/* 211 */       if (!allRelationships.isEmpty()) {
/* 212 */         argW.append("    relationshipProducer = new IRelationshipSetProducer() {\n");
/* 213 */         argW.append("      public IDataModelRelationship[] getRelationshipSet() {\n");
/* 214 */         argW.append("        IDataModelRelationship[] rels = new IDataModelRelationship[");
/* 215 */         argW.append(String.valueOf(allRelationships.size()));
/* 216 */         argW.append("];\n");
/*     */         
/* 218 */         int counter = 0;
/* 219 */         for (DtxRelationship relationship : allRelationships) {
/* 220 */           argW.append("        rels[");
/* 221 */           argW.append(String.valueOf(counter));
/* 222 */           argW.append("] = new ");
/* 223 */           if (DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType())) {
/* 224 */             argW.append("OneToOneRelationship");
/*     */           }
/* 226 */           else if (DtxRelationship.ONE_MANY.equalsIgnoreCase(relationship.getType())) {
/* 227 */             argW.append("OneToManyRelationship");
/*     */           }
/* 229 */           else if (DtxRelationship.MANY_MANY.equalsIgnoreCase(relationship.getType())) {
/* 230 */             argW.append("ManyToManyRelationship");
/*     */           } 
/*     */           
/* 233 */           argW.append("(\"");
/* 234 */           argW.append(relationship.getName());
/* 235 */           argW.append("\", ");
/* 236 */           argW.append(relationship.getChild().getId());
/* 237 */           argW.append(".class");
/* 238 */           if (DtxRelationship.ONE_ONE.equalsIgnoreCase(relationship.getType()) && relationship
/* 239 */             .isUseParentPm()) {
/* 240 */             argW.append(", true");
/*     */           } else {
/*     */             
/* 243 */             argW.append(", false");
/*     */           } 
/* 245 */           if (relationship.isTransient()) {
/* 246 */             argW.append(", true");
/*     */           } else {
/*     */             
/* 249 */             argW.append(", false");
/*     */           } 
/* 251 */           if (relationship.isPropertyRelationship()) {
/* 252 */             argW.append(", true");
/*     */           }
/* 254 */           argW.append(");\n");
/*     */           
/* 256 */           counter++;
/*     */         } 
/* 258 */         argW.append("        return rels;\n");
/* 259 */         argW.append("      }\n");
/* 260 */         argW.append("    };\n");
/* 261 */         argW.append("    addRelationshipProducer(\"" + dtx.getDao() + "\", relationshipProducer);\n");
/*     */       } 
/* 263 */       if (dtx.isCustomerExtension()) {
/* 264 */         argW.append("    parentClassName = " + dtx.getExtends().getDao() + ".class.getName();\n");
/* 265 */         argW.append("    baseRelationshipProducer = getRelationshipsInternal(parentClassName);\n");
/* 266 */         argW.append("    custRelationshipProducer = new IRelationshipSetProducer() {\n");
/* 267 */         argW.append("      public IDataModelRelationship[] getRelationshipSet() {\n");
/* 268 */         argW.append("        return new IDataModelRelationship[] {new OneToOneRelationship(\"" + dtx
/* 269 */             .getExtends().getName() + "Extension\", " + dtx.getId() + ".class, true, false)};\n");
/* 270 */         argW.append("      }\n");
/* 271 */         argW.append("    };\n");
/*     */         
/* 273 */         argW.append("    if (baseRelationshipProducer != null) {\n");
/* 274 */         argW.append("      addRelationshipProducer(parentClassName, new dtv.data2.access.ChainedRelationshipSetProducer(custRelationshipProducer, baseRelationshipProducer));\n");
/*     */         
/* 276 */         argW.append("    }\n");
/* 277 */         argW.append("    else {\n");
/* 278 */         argW.append("      addRelationshipProducer(parentClassName, custRelationshipProducer);\n");
/* 279 */         argW.append("    }\n");
/*     */       } 
/*     */ 
/*     */       
/* 283 */       String modelClass = dtx.getModel() + ".class";
/* 284 */       argW.append("    addDataModels(\"" + dtx
/* 285 */           .getDao() + "\", new AbstractInstanceGenerator<IDataModelImpl>(){\n");
/* 286 */       argW.append("      protected Class<? extends IDataModelImpl> getType() {\n");
/* 287 */       argW.append("        return " + modelClass + ";\n");
/* 288 */       argW.append("      }\n");
/* 289 */       argW.append("    });\n");
/*     */       
/* 291 */       argW.append("    addInterfaces(\"" + dtx
/* 292 */           .getInterface() + "\", new AbstractInstanceGenerator<IDataModel>(){\n");
/* 293 */       argW.append("      protected Class<? extends IDataModel> getType() {\n");
/* 294 */       argW.append("        return " + modelClass + ";\n");
/* 295 */       argW.append("      }\n");
/* 296 */       argW.append("    });\n");
/*     */       
/* 298 */       String daoClass = dtx.getDao() + ".class";
/* 299 */       argW.append("    addDaos(\"" + dtx
/* 300 */           .getName() + "\", new AbstractInstanceGenerator<IDataAccessObject>(){\n");
/* 301 */       argW.append("      protected Class<? extends IDataAccessObject> getType() {\n");
/* 302 */       argW.append("        return " + daoClass + ";\n");
/* 303 */       argW.append("      }\n");
/* 304 */       argW.append("    });\n");
/*     */       
/* 306 */       String idClass = dtx.getId() + ".class";
/* 307 */       argW.append("    addObjectIds(\"" + dtx
/* 308 */           .getName() + "\", new AbstractInstanceGenerator<IObjectId>(){\n");
/* 309 */       argW.append("      protected Class<? extends IObjectId> getType() {\n");
/* 310 */       argW.append("        return " + idClass + ";\n");
/* 311 */       argW.append("      }\n");
/* 312 */       argW.append("    });\n");
/*     */     } 
/*     */     
/* 315 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeVariableDeclaration(Writer argW) throws IOException {
/* 327 */     argW.append("  private final Map<String, IRelationshipSetProducer> relationshipProducerMap = new HashMap<>();\n");
/*     */     
/* 329 */     argW.append("  private final Map<String, AbstractInstanceGenerator<? extends IDataAccessObject>> daoForDaoNameMap = new HashMap<>();\n");
/*     */     
/* 331 */     argW.append("  private final Map<String, AbstractInstanceGenerator<? extends IObjectId>> idForDaoNameMap = new HashMap<>();\n");
/*     */     
/* 333 */     argW.append("  private final Map<String, AbstractInstanceGenerator<? extends IDataModelImpl>> modelForDaoMap = new HashMap<>();\n");
/*     */     
/* 335 */     argW.append("  private final Map<String, AbstractInstanceGenerator<? extends IDataModel>> modelForInterfaceMap = new HashMap<>();\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendOverrides(Writer argW) throws IOException {
/* 342 */     argW.append("  @Override\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddDaosMethod(Writer argW) throws IOException {
/* 347 */     argW.append("  protected void addDaos(String argKey, AbstractInstanceGenerator<? extends IDataAccessObject> argDataAccessObject) {\n");
/*     */     
/* 349 */     argW.append("    daoForDaoNameMap.put(argKey, argDataAccessObject);\n");
/* 350 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddDataModelsMethod(Writer argW) throws IOException {
/* 355 */     argW.append("  protected void addDataModels(String argKey, AbstractInstanceGenerator<? extends IDataModelImpl> argDataModel) {\n");
/*     */     
/* 357 */     argW.append("    modelForDaoMap.put(argKey, argDataModel);\n");
/* 358 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddInterfacesMethod(Writer argW) throws IOException {
/* 363 */     argW.append("  protected void addInterfaces(String argKey, AbstractInstanceGenerator<? extends IDataModel> argDataModel) {\n");
/*     */     
/* 365 */     argW.append("    modelForInterfaceMap.put(argKey, argDataModel);\n");
/* 366 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddObjectIdsMethod(Writer argW) throws IOException {
/* 371 */     argW.append("  protected void addObjectIds(String argKey, AbstractInstanceGenerator<? extends IObjectId> argObjectId) {\n");
/*     */     
/* 373 */     argW.append("    idForDaoNameMap.put(argKey, argObjectId);\n");
/* 374 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddRelationshipsMethod(Writer argW) throws IOException {
/* 379 */     argW.append("  protected void addRelationshipProducer(String argKey, IRelationshipSetProducer argRelationshipProducer) {\n");
/*     */     
/* 381 */     argW.append("    relationshipProducerMap.put(argKey, argRelationshipProducer);\n");
/* 382 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetDaoForDaoNameImplMethod(Writer argW) throws IOException {
/* 387 */     appendOverrides(argW);
/* 388 */     argW.append("  public IDataAccessObject getDaoForDaoNameImpl(String argDaoName) {\n");
/* 389 */     argW.append("    AbstractInstanceGenerator<? extends IDataAccessObject> daoClass = daoForDaoNameMap.get(argDaoName);\n");
/*     */     
/* 391 */     argW.append("    try {\n");
/* 392 */     argW.append("      return daoClass != null ? daoClass.newInstance() : null;\n");
/* 393 */     argW.append("    }\n");
/* 394 */     argW.append("    catch (InstantiationException | IllegalAccessException ex) {\n");
/* 395 */     argW.append("      throw new DtxException(\"Could not instantiate DAO for: \" + argDaoName, ex);\n");
/* 396 */     argW.append("    }\n");
/* 397 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetIdForDaoNameImplMethod(Writer argW) throws IOException {
/* 402 */     appendOverrides(argW);
/* 403 */     argW.append("  public IObjectId getIdForDaoNameImpl(String argDaoName) {\n");
/* 404 */     argW.append("    AbstractInstanceGenerator<? extends IObjectId> idClass = idForDaoNameMap.get(argDaoName);\n");
/*     */     
/* 406 */     argW.append("    try {\n");
/* 407 */     argW.append("      return idClass != null ? idClass.newInstance() : null;\n");
/* 408 */     argW.append("    }\n");
/* 409 */     argW.append("    catch (InstantiationException | IllegalAccessException ex) {\n");
/* 410 */     argW.append("      throw new DtxException(\"Could not instantiate object Id for: \" + argDaoName, ex);\n");
/*     */     
/* 412 */     argW.append("    }\n");
/* 413 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetModelForDAOImplMethod(Writer argW) throws IOException {
/* 418 */     appendOverrides(argW);
/* 419 */     argW.append("  public IDataModelImpl getModelForDAOImpl(String argDaoClassName) {\n");
/* 420 */     argW.append("    AbstractInstanceGenerator<? extends IDataModelImpl> modelClass = modelForDaoMap.get(argDaoClassName);\n");
/*     */     
/* 422 */     argW.append("    try {\n");
/* 423 */     argW.append("      return modelClass != null ? modelClass.newInstance() : null;\n");
/* 424 */     argW.append("    }\n");
/* 425 */     argW.append("    catch (InstantiationException | IllegalAccessException ex) {\n");
/* 426 */     argW.append("      throw new DtxException(\"Could not instantiate model for: \" + argDaoClassName, ex);\n");
/*     */     
/* 428 */     argW.append("    }\n");
/* 429 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetModelForInterfaceImplMethod(Writer argW) throws IOException {
/* 434 */     appendOverrides(argW);
/* 435 */     argW.append("  public <T extends IDataModel> T getModelForInterfaceImpl(Class<T> argInterfaceClass) {\n");
/* 436 */     argW.append("    AbstractInstanceGenerator<? extends IDataModel> modelClass = modelForInterfaceMap.get(argInterfaceClass.getName());\n");
/*     */     
/* 438 */     argW.append("    try {\n");
/* 439 */     argW.append("      return modelClass != null ? (T) modelClass.newInstance() : null;\n");
/* 440 */     argW.append("    }\n");
/* 441 */     argW.append("    catch (InstantiationException | IllegalAccessException ex) {\n");
/* 442 */     argW.append("      throw new DtxException(\"Could not instantiate model for: \" + argInterfaceClass.getName(), ex);\n");
/*     */     
/* 444 */     argW.append("    }\n");
/* 445 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetRelationshipImplMethod(Writer argW) throws IOException {
/* 450 */     appendOverrides(argW);
/* 451 */     argW.append("  public IDataModelRelationship[] getRelationshipsImpl(String argClassName) {\n");
/* 452 */     argW.append("    IRelationshipSetProducer producer = relationshipProducerMap.get(argClassName);\n");
/* 453 */     argW.append("    return producer != null ? producer.getRelationshipSet() : null;\n");
/* 454 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetRelationshipInternalMethod(Writer argW) throws IOException {
/* 459 */     argW.append("  public IRelationshipSetProducer getRelationshipsInternal(String argClassName) {\n");
/* 460 */     argW.append("    return relationshipProducerMap.get(argClassName);\n");
/* 461 */     argW.append("  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateDataModelFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */