/*     */ package dtv.data2.access.status;
/*     */ 
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.data2.access.datasource.DataSourceFactory;
/*     */ import dtv.data2.access.datasource.config.IPing;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.pm.PersistenceManagerStatus;
/*     */ import dtv.util.DtvThreadFactory;
/*     */ import dtv.util.XmlUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusMgr
/*     */   implements IStatusMgr
/*     */ {
/*  31 */   private static final Logger adminLogger_ = Logger.getLogger("dtv.sysadmin.data.failover");
/*  32 */   private static final StatusMgr instance_ = new StatusMgr();
/*  33 */   private static final Logger logger_ = Logger.getLogger(StatusMgr.class);
/*     */   private final ScheduledExecutorService dataSourceConnectionExecutor_;
/*     */   private List<IOfflineCountListener> countListeners_;
/*     */   private int dataSourceCount_;
/*     */   private Map<String, PersistenceManagerStatus> dataSourceStatusMap_;
/*     */   
/*     */   public static StatusMgr getInstance() {
/*  40 */     return instance_;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, Long> lastCheckMap_;
/*     */   
/*     */   private Map<String, FailoverException> offlineCauseMap_;
/*     */   
/*     */   private Map<String, Integer> offlineCountMap_;
/*     */   
/*     */   private long offlineInterval_;
/*     */   
/*     */   private List<IDataSourceStatusListener> statusListeners_;
/*     */   
/*     */   private StatusMgr() {
/*  55 */     initialize();
/*     */     
/*  57 */     this
/*  58 */       .dataSourceConnectionExecutor_ = Executors.newSingleThreadScheduledExecutor((ThreadFactory)DtvThreadFactory.makeForDaemons(getClass().getSimpleName()));
/*  59 */     this.dataSourceConnectionExecutor_.scheduleAtFixedRate(new DatasourceConnectionTask(), this.offlineInterval_, this.offlineInterval_, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, PersistenceManagerStatus> getAllDataSourceStatuses() {
/*  69 */     return Collections.unmodifiableMap(this.dataSourceStatusMap_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDataSourceCount() {
/*  77 */     return this.dataSourceCount_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceManagerStatus getDataSourceStatus(String argDataSource) {
/*  86 */     return this.dataSourceStatusMap_.get(argDataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getForcedOfflineCount() {
/*  95 */     return ((Long)this.offlineCauseMap_.entrySet().stream()
/*  96 */       .filter(e -> e.getValue() instanceof dtv.data2.access.exception.ForcedOfflineException)
/*  97 */       .collect(Collectors.counting()))
/*  98 */       .intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FailoverException getOfflineCause(String argDataSourceName) {
/* 108 */     return this.offlineCauseMap_.get(argDataSourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOfflineCount() {
/* 114 */     int returnValue = 0;
/*     */     
/* 116 */     Collection<Integer> offlineCounts = this.offlineCountMap_.values();
/* 117 */     for (Integer offlineCount : offlineCounts) {
/* 118 */       returnValue += offlineCount.intValue();
/*     */     }
/* 120 */     return returnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOfflineCount(String argNetworkScope) {
/* 126 */     Integer offlineCount = this.offlineCountMap_.get(argNetworkScope.toUpperCase());
/* 127 */     return (offlineCount == null) ? 0 : offlineCount.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getOfflineCountMap() {
/* 133 */     return this.offlineCountMap_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnline(String argDataSourceName) {
/* 143 */     boolean online = PersistenceManagerStatus.ONLINE.equals(getDataSourceStatus(argDataSourceName));
/* 144 */     FailoverException failover = null;
/*     */     
/* 146 */     if (!online) {
/* 147 */       return online;
/*     */     }
/*     */     
/* 150 */     if (isOnlineRefreshNecessary(argDataSourceName)) {
/*     */       
/* 152 */       DataSourceDescriptor datasource = DataSourceFactory.getInstance().getDataSourceDescriptor(argDataSourceName);
/*     */       
/* 154 */       if (!ping(datasource)) {
/* 155 */         logger_.warn("PING FAILED for datasource: " + datasource.getName());
/*     */         
/* 157 */         online = false;
/* 158 */         failover = FailoverException.getNewException("PING FAILED for datasource: " + datasource
/* 159 */             .getName() + " - this datasource is offline.", argDataSourceName);
/*     */       } 
/*     */ 
/*     */       
/* 163 */       onlineCheckOccurred(argDataSourceName);
/*     */     } 
/*     */     
/* 166 */     if (!online) {
/* 167 */       notifyOffline(argDataSourceName, failover);
/*     */     }
/*     */     
/* 170 */     return online;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyOffline(String argDataSourceName, FailoverException argCause) {
/* 180 */     PersistenceManagerStatus status = this.dataSourceStatusMap_.get(argDataSourceName);
/*     */     
/* 182 */     if (status == null) {
/* 183 */       logger_
/* 184 */         .warn("notifyOffline called with unknown datasource: " + argDataSourceName + " - no action taken.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 189 */     if (!PersistenceManagerStatus.OFFLINE.equals(status)) {
/* 190 */       DataSourceDescriptor dsd = DataSourceFactory.getInstance().getDataSourceDescriptor(argDataSourceName);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       this.dataSourceStatusMap_.put(argDataSourceName, PersistenceManagerStatus.OFFLINE);
/* 196 */       this.offlineCauseMap_.put(argDataSourceName, argCause);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       if (dsd.isOfflineVisible()) {
/* 203 */         Integer offlineCount = this.offlineCountMap_.get(dsd.getNetworkScope().toUpperCase());
/*     */         
/* 205 */         if (offlineCount == null) {
/* 206 */           offlineCount = Integer.valueOf(0);
/*     */         }
/* 208 */         offlineCount = Integer.valueOf(offlineCount.intValue() + 1);
/* 209 */         this.offlineCountMap_.put(dsd.getNetworkScope().toUpperCase(), offlineCount);
/*     */         
/* 211 */         notifyListeners(argDataSourceName, PersistenceManagerStatus.OFFLINE);
/*     */       } 
/*     */       
/* 214 */       logOffline(dsd, (Throwable)argCause);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 224 */       if (dsd.isHighAvailability()) {
/* 225 */         notifyOnline(dsd.getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyOnline(String argDataSourceName) {
/* 239 */     PersistenceManagerStatus status = this.dataSourceStatusMap_.get(argDataSourceName);
/*     */     
/* 241 */     if (status == null) {
/* 242 */       logger_
/* 243 */         .warn("notifyOnline called with unknown datasource: " + argDataSourceName + " - no action taken.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 248 */     if (!PersistenceManagerStatus.ONLINE.equals(status)) {
/* 249 */       DataSourceDescriptor dsd = DataSourceFactory.getInstance().getDataSourceDescriptor(argDataSourceName);
/* 250 */       this.dataSourceStatusMap_.put(argDataSourceName, PersistenceManagerStatus.ONLINE);
/*     */       
/* 252 */       if (dsd.isOfflineVisible()) {
/* 253 */         Integer offlineCount = this.offlineCountMap_.get(dsd.getNetworkScope().toUpperCase());
/* 254 */         if (offlineCount != null && offlineCount.intValue() > 0) {
/* 255 */           this.offlineCountMap_.put(dsd.getNetworkScope().toUpperCase(), 
/* 256 */               Integer.valueOf(offlineCount.intValue() - 1));
/*     */         }
/*     */         
/* 259 */         notifyListeners(argDataSourceName, PersistenceManagerStatus.ONLINE);
/*     */       } 
/*     */     } 
/* 262 */     this.offlineCauseMap_.remove(argDataSourceName);
/* 263 */     onlineCheckOccurred(argDataSourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshDbStatus() {
/* 270 */     for (IOfflineCountListener countListener : this.countListeners_) {
/* 271 */       countListener.notifyNewCount(this.offlineCountMap_);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOfflineCountListener(IOfflineCountListener argListener) {
/* 280 */     this.countListeners_.add(argListener);
/*     */     
/* 282 */     argListener.notifyNewCount(this.offlineCountMap_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerStatusListener(IDataSourceStatusListener argListener) {
/* 290 */     synchronized (this.statusListeners_) {
/* 291 */       this.statusListeners_.add(argListener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeStatusListener(IDataSourceStatusListener argListener) {
/* 301 */     synchronized (this.statusListeners_) {
/* 302 */       this.statusListeners_.remove(argListener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 311 */     this.dataSourceConnectionExecutor_.shutdownNow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getOfflineMessage(DataSourceDescriptor argDescriptor, Throwable argCause) {
/* 322 */     String msg = String.format("<Offline>\r  <DatasourceName>%s</DatasourceName>\r  <Cause>%s</Cause>\r  <Scope>%s</Scope>\r</Offline>\r", new Object[] {
/*     */ 
/*     */           
/* 325 */           XmlUtils.toXmlSafe(argDescriptor.getName()), XmlUtils.toXmlSafe(argCause.toString()), 
/* 326 */           XmlUtils.toXmlSafe(argDescriptor.getNetworkScope()) });
/* 327 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logOffline(DataSourceDescriptor argDescriptor, Throwable argCause) {
/* 338 */     logger_
/* 339 */       .warn(String.format("Datasource offline: [%s] EXPLANATION: %s", new Object[] { argDescriptor.getName(), argCause }));
/*     */     
/* 341 */     if (logger_.isInfoEnabled()) {
/* 342 */       logger_.info("Datasource failover stack trace.", argCause);
/*     */     }
/*     */     
/* 345 */     adminLogger_.warn(getOfflineMessage(argDescriptor, argCause));
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 349 */     this.dataSourceStatusMap_ = new HashMap<>(8);
/* 350 */     this.offlineCauseMap_ = new HashMap<>(8);
/*     */     
/* 352 */     this.statusListeners_ = new ArrayList<>(4);
/* 353 */     this.countListeners_ = new ArrayList<>(4);
/* 354 */     this.lastCheckMap_ = new HashMap<>(8);
/*     */     
/* 356 */     String tempInterval = System.getProperty("dtv.data.access.status.OfflineInterval", "60000");
/*     */     try {
/* 358 */       this.offlineInterval_ = Long.valueOf(tempInterval).longValue();
/*     */     }
/* 360 */     catch (NumberFormatException ex) {
/* 361 */       logger_.error("Could not parse system propery: dtv.data.access.status.OfflineInterval; Value: '" + tempInterval + "'", ex);
/*     */       
/* 363 */       this.offlineInterval_ = 60000L;
/*     */     } 
/*     */     
/* 366 */     if (this.offlineInterval_ < 50L) {
/* 367 */       this.offlineInterval_ = 50L;
/*     */     }
/*     */     
/* 370 */     Collection<DataSourceDescriptor> dss = DataSourceFactory.getInstance().getDataSourceDescriptors();
/*     */     
/* 372 */     for (DataSourceDescriptor descriptor : dss) {
/* 373 */       if (!descriptor.isEnabled()) {
/*     */         continue;
/*     */       }
/* 376 */       String name = descriptor.getName();
/* 377 */       this.dataSourceStatusMap_.put(name, PersistenceManagerStatus.ONLINE);
/*     */     } 
/*     */     
/* 380 */     if (this.dataSourceStatusMap_ == null) {
/* 381 */       this.dataSourceCount_ = 0;
/*     */     } else {
/*     */       
/* 384 */       this.dataSourceCount_ = this.dataSourceStatusMap_.size();
/*     */     } 
/* 386 */     this.offlineCountMap_ = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isOnlineRefreshNecessary(String argDataSourceName) {
/* 403 */     Long lastTimeObj = this.lastCheckMap_.get(argDataSourceName);
/* 404 */     if (lastTimeObj == null) {
/* 405 */       return true;
/*     */     }
/*     */     
/* 408 */     long lastRefresh = lastTimeObj.longValue();
/* 409 */     long now = System.currentTimeMillis();
/* 410 */     long elapsed = now - lastRefresh;
/*     */     
/* 412 */     return (elapsed >= this.offlineInterval_);
/*     */   }
/*     */   
/*     */   private void notifyListeners(String argDataSource, PersistenceManagerStatus argStatus) {
/* 416 */     synchronized (this.statusListeners_) {
/* 417 */       for (IDataSourceStatusListener listener : this.statusListeners_) {
/* 418 */         if (PersistenceManagerStatus.ONLINE.equals(argStatus)) {
/* 419 */           listener.notifyOnline(argDataSource); continue;
/*     */         } 
/* 421 */         if (PersistenceManagerStatus.OFFLINE.equals(argStatus)) {
/* 422 */           listener.notfiyOffline(argDataSource);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 427 */     for (IOfflineCountListener countListener : this.countListeners_) {
/* 428 */       countListener.notifyNewCount(this.offlineCountMap_);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onlineCheckOccurred(String argDataSourceName) {
/* 438 */     this.lastCheckMap_.put(argDataSourceName, Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ping(DataSourceDescriptor argDataSource) {
/* 449 */     boolean success = false;
/*     */     
/* 451 */     IPing ping = argDataSource.getPing();
/*     */     
/* 453 */     if (ping != null) {
/* 454 */       for (int i = 0; i < 5; i++) {
/* 455 */         if (ping.ping()) {
/* 456 */           success = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 462 */       success = true;
/*     */     } 
/*     */     
/* 465 */     return success;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class DatasourceConnectionTask
/*     */     implements Runnable
/*     */   {
/*     */     public void run() {
/* 488 */       Collection<DataSourceDescriptor> dsd = DataSourceFactory.getInstance().getDataSourceDescriptors();
/*     */       
/* 490 */       if (StatusMgr.logger_.isDebugEnabled()) {
/* 491 */         logDatasourcesToBePinged(dsd);
/*     */       }
/*     */       
/* 494 */       for (DataSourceDescriptor descriptor : dsd) {
/* 495 */         String name = "";
/*     */         try {
/* 497 */           name = descriptor.getName();
/*     */           
/* 499 */           if (descriptor.isEnabled()) {
/* 500 */             StatusMgr.logger_.debug("DatasourceConnectionTask: Attempting to ping datasource: " + descriptor.getName());
/*     */             
/* 502 */             if (!descriptor.isForcedOffline() && StatusMgr.this.ping(descriptor)) {
/* 503 */               StatusMgr.this.notifyOnline(name);
/*     */               continue;
/*     */             } 
/* 506 */             StatusMgr.this.notifyOffline(name, FailoverException.getNewException("Ping Failed", name));
/*     */           }
/*     */         
/*     */         }
/* 510 */         catch (Throwable e) {
/*     */           try {
/* 512 */             StatusMgr.logger_.error("Exception encountered while checking the availability of datasource: " + name, e);
/*     */           }
/* 514 */           catch (Throwable throwable) {}
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void logDatasourcesToBePinged(Collection<DataSourceDescriptor> argDsd) {
/* 522 */       StringBuffer message = new StringBuffer("The following datasources will be pinged: ");
/*     */       
/* 524 */       for (DataSourceDescriptor dsd : argDsd) {
/* 525 */         message.append((dsd != null && dsd.isEnabled()) ? (dsd.getName() + ", ") : "");
/*     */       }
/*     */       
/* 528 */       StatusMgr.logger_.debug(message.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\status\StatusMgr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */