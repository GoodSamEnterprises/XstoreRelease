/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.IQueryResult;
/*     */ import dtv.data2.access.IQueryResultList;
/*     */ import dtv.data2.access.QueryResultList;
/*     */ import dtv.data2.access.config.query.QueryDescriptor;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.data2.access.exception.FailoverException;
/*     */ import dtv.data2.access.impl.IPersistenceStrategy;
/*     */ import dtv.data2.access.impl.jdbc.DBConnection;
/*     */ import dtv.data2.access.impl.jdbc.JDBCDataSourceMgr;
/*     */ import dtv.data2.access.impl.jdbc.JDBCHelper;
/*     */ import dtv.util.DtvDate;
/*     */ import dtv.util.StringUtils;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlQueryExecutor
/*     */ {
/*  35 */   private static final Logger logger_ = LogManager.getLogger(SqlQueryExecutor.class);
/*  36 */   private static final boolean _debugLogging = logger_.isDebugEnabled();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IQueryResultList<?> execute(String argSqlStatement, List<?> argFinalizedParameters, List<String> argParamNames, Properties argProperties, QueryDescriptor argDescriptor, IPersistenceStrategy argStrategy, QueryToken argQueryToken) throws SQLException {
/*  56 */     return execute(argSqlStatement, argFinalizedParameters, argParamNames, argProperties, argDescriptor
/*  57 */         .getResultFields(), argDescriptor.getResultFieldTypes(), argDescriptor.getResultClass(), argStrategy, argQueryToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Object execute(String argSqlStatement, List<?> argFinalizedParameters, List<String> argParamNames, Properties argProperties, String[] argResultFields, String argSourceDescription, Class<?> argResultClass, IPersistenceStrategy argStrategy, QueryToken argQueryToken) throws SQLException {
/*  83 */     IQueryResultList<?> result = execute(argSqlStatement, argFinalizedParameters, argParamNames, argProperties, argResultFields, new String[0], argResultClass, argStrategy, argQueryToken);
/*     */     
/*  85 */     return new QueryResultWrapper<>(result, result.isQueryLimitReached(), result
/*  86 */         .getQueryLimit());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaxRecordValue(Properties argProperties) {
/*  98 */     int maxRows = 0;
/*  99 */     Object maxRowsObj = argProperties.get("MaxRows");
/* 100 */     if (maxRowsObj != null && maxRowsObj instanceof String) {
/* 101 */       String maxRowsString = (String)maxRowsObj;
/* 102 */       if (!StringUtils.isEmpty(maxRowsString)) {
/*     */         try {
/* 104 */           maxRows = Integer.parseInt(maxRowsString);
/*     */         }
/* 106 */         catch (NumberFormatException ex) {
/* 107 */           logger_.warn("A bad value was detected for a 'MaxRows' property for a query.  Bad Value: " + maxRowsString, ex);
/*     */           
/* 109 */           maxRows = 0;
/*     */         } 
/*     */       }
/*     */     } 
/* 113 */     return maxRows;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IQueryResultList<?> execute(String argSqlStatement, List<?> argFinalizedParameters, List<String> argParamNames, Properties argProperties, String[] argResultFields, String[] argResultFieldTypes, Class<?> argResultClass, IPersistenceStrategy argStrategy, QueryToken argQueryToken) throws SQLException {
/* 139 */     if (argSqlStatement == null) {
/* 140 */       throw new DtxException("SqlQueryExecutor execute was called with a null argSqlStatement.  This is invalid.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 145 */       String queryType = argProperties.getProperty("QueryType", "");
/* 146 */       if (queryType.equalsIgnoreCase("Procedure")) {
/* 147 */         return executeProcedure(argSqlStatement, argFinalizedParameters, argParamNames, argProperties, argResultFields, argResultClass, argStrategy, argQueryToken);
/*     */       }
/*     */ 
/*     */       
/* 151 */       return executeStatement(argSqlStatement, argFinalizedParameters, argParamNames, argProperties, argResultFields, argResultFieldTypes, argResultClass, argStrategy, argQueryToken);
/*     */ 
/*     */     
/*     */     }
/* 155 */     catch (SQLException|RuntimeException ee) {
/* 156 */       if (!FailoverException.isFailover(ee)) {
/* 157 */         logger_.error("Exception occurred while executing sql: [" + argSqlStatement + "] with parameters: " + argFinalizedParameters + " Will re-throw.", ee);
/*     */       }
/*     */       
/* 160 */       throw ee;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IQueryResultList<?> executeProcedure(String argSqlStatement, List<?> argFinalizedParameters, List<String> argParamNames, Properties argProperties, String[] argResultFields, Class<?> argResultClass, IPersistenceStrategy argStrategy, QueryToken argQueryToken) throws SQLException {
/* 170 */     DBConnection conn = JDBCDataSourceMgr.getInstance().getQueryConnection(argStrategy.getDataSourceName(), argQueryToken);
/* 171 */     try (CallableStatement callstmt = conn.prepareCall(argSqlStatement)) {
/*     */       IQueryResultList<?> resultList;
/* 173 */       boolean registerReturnValue = Boolean.valueOf(argProperties.getProperty("HasReturnValue")).booleanValue();
/*     */       
/* 175 */       int sqlIndex = registerReturnValue ? 2 : 1;
/*     */       
/* 177 */       if (argFinalizedParameters.size() != argParamNames.size()) {
/* 178 */         throw new DtxException((new StringBuilder(1024)).append("Numer of ")
/* 179 */             .append("parameters and number of parameter names do not match! Parameter count [")
/* 180 */             .append(argFinalizedParameters.size()).append("] != parameter names count [")
/* 181 */             .append(argParamNames.size()).append("] Parameters: [").append(argFinalizedParameters)
/* 182 */             .append("] Parameter names: [").append(argParamNames).append("] SQL Statement: [")
/* 183 */             .append(argSqlStatement).append("]").toString());
/*     */       }
/*     */       
/* 186 */       for (; sqlIndex <= argFinalizedParameters.size(); sqlIndex++) {
/* 187 */         callstmt.setObject(sqlIndex, argFinalizedParameters.get(sqlIndex - 1));
/*     */       }
/*     */ 
/*     */       
/* 191 */       String outParamsValue = argProperties.getProperty("OutputParameters");
/* 192 */       String[] outputParams = null;
/* 193 */       if (outParamsValue != null) {
/* 194 */         outputParams = outParamsValue.replace('\n', ' ').trim().split(",\\s*");
/*     */       }
/*     */       
/* 197 */       String outTypesValue = argProperties.getProperty("OutputDataTypes");
/* 198 */       String[] outputTypes = null;
/* 199 */       if (outTypesValue != null) {
/* 200 */         outputTypes = outTypesValue.replace('\n', ' ').trim().split(",\\s*");
/*     */       }
/*     */       
/* 203 */       if (outputParams != null) {
/* 204 */         for (int i = 0; i < outputParams.length; i++) {
/* 205 */           String typeName = (outputTypes.length > i) ? outputTypes[i] : "Object";
/* 206 */           callstmt.registerOutParameter(outputParams[i], JDBCHelper.getJDBCTypeForTypeName(typeName));
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 212 */       if (registerReturnValue) {
/* 213 */         callstmt.registerOutParameter(1, 4);
/*     */       }
/*     */ 
/*     */       
/* 217 */       callstmt.execute();
/*     */ 
/*     */ 
/*     */       
/* 221 */       int fieldCount = (registerReturnValue ? 1 : 0) + ((outputParams != null) ? outputParams.length : 0);
/* 222 */       Object[] results = new Object[fieldCount];
/* 223 */       int resultIndex = 0;
/*     */ 
/*     */       
/* 226 */       if (registerReturnValue) {
/* 227 */         results[resultIndex] = Integer.valueOf(callstmt.getInt(1));
/* 228 */         resultIndex++;
/*     */       } 
/* 230 */       if (outputParams != null) {
/* 231 */         for (String outputParam : outputParams) {
/* 232 */           results[resultIndex] = callstmt.getObject(outputParam);
/* 233 */           resultIndex++;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 240 */       if (argResultClass != null && IQueryResult.class.isAssignableFrom(argResultClass)) {
/*     */ 
/*     */         
/* 243 */         Class<? extends IQueryResult> resultClass = (Class)argResultClass;
/* 244 */         QueryResultHelper.DataMapping mapping = QueryResultHelper.getInstance().getMapping(resultClass);
/* 245 */         resultList = getProcedureResultObjects(results, mapping, argResultFields, resultClass, argStrategy
/* 246 */             .getDataSourceName(), resultIndex);
/*     */       } else {
/*     */         
/* 249 */         resultList = QueryResultList.makeList(results, Object[].class);
/*     */       } 
/*     */       
/* 252 */       return resultList;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IQueryResultList<?> executeStatement(String argSqlStatement, List<?> argFinalizedParameters, List<String> argParamNames, Properties argProperties, String[] argResultFields, String[] argResultFieldTypes, Class<?> argResultClass, IPersistenceStrategy argStrategy, QueryToken argQueryToken) throws SQLException {
/* 262 */     DBConnection conn = JDBCDataSourceMgr.getInstance().getQueryConnection(argStrategy.getDataSourceName(), argQueryToken);
/* 263 */     try (PreparedStatement statement = conn.prepareStatement(argSqlStatement)) {
/*     */ 
/*     */       
/* 266 */       List<? extends Object> parameters = (List)argFinalizedParameters;
/* 267 */       int sqlIndex = 1;
/* 268 */       for (Object value : parameters) {
/* 269 */         if (value instanceof DtvDate) {
/* 270 */           statement.setTimestamp(sqlIndex, (Timestamp)value);
/*     */         } else {
/*     */           
/* 273 */           statement.setObject(sqlIndex, value);
/*     */         } 
/* 275 */         sqlIndex++;
/*     */       } 
/*     */ 
/*     */       
/* 279 */       String maxRowsString = argProperties.getProperty("MaxRows");
/* 280 */       int maxRows = 0;
/* 281 */       if (!StringUtils.isEmpty(maxRowsString)) {
/*     */         try {
/* 283 */           maxRows = Integer.parseInt(maxRowsString);
/*     */         }
/* 285 */         catch (NumberFormatException ex) {
/* 286 */           logger_.warn("A bad value was detected for a 'MaxRows' property for a query.  Bad Value: " + maxRowsString, ex);
/*     */ 
/*     */           
/* 289 */           maxRows = 0;
/*     */         } 
/*     */       }
/* 292 */       if (maxRows != 0) {
/* 293 */         statement.setMaxRows(maxRows);
/*     */       }
/*     */ 
/*     */       
/* 297 */       logger_.debug("Starting execution of prepared statement...");
/* 298 */       boolean hasResults = statement.execute();
/* 299 */       logger_.debug("Finished execution of prepared statement.");
/*     */ 
/*     */       
/* 302 */       if (hasResults) {
/*     */         IQueryResultList<?> iQueryResultList;
/* 304 */         try (ResultSet results = statement.getResultSet()) {
/* 305 */           ResultSetMetaData data = results.getMetaData();
/* 306 */           int columnCount = data.getColumnCount();
/*     */           
/* 308 */           if (argResultFields != null && argResultFields.length > 0 && columnCount != argResultFields.length)
/*     */           {
/* 310 */             logger_.warn("A query generated a result with a different number of columns than what is specified in QueryConfig. Column Count produced: [{}] Columns anticipated for this query: [{}] Query properties: [{}] Sql string executed: [{}]", 
/*     */ 
/*     */ 
/*     */                 
/* 314 */                 Integer.valueOf(columnCount), Integer.valueOf(argResultFields.length), argProperties, argSqlStatement);
/*     */           }
/*     */           
/* 317 */           logger_.debug("Starting conversion of database result set.");
/* 318 */           if (argResultClass != null && IQueryResult.class.isAssignableFrom(argResultClass)) {
/*     */ 
/*     */             
/* 321 */             Class<? extends IQueryResult> resultClass = (Class)argResultClass;
/* 322 */             QueryResultHelper.DataMapping mapping = QueryResultHelper.getInstance().getMapping(resultClass);
/* 323 */             iQueryResultList = getQueryResultObjects(results, mapping, argResultFields, resultClass, argStrategy
/* 324 */                 .getDataSourceName(), columnCount, argResultFieldTypes, maxRows);
/*     */           }
/*     */           else {
/*     */             
/* 328 */             iQueryResultList = getQueryResultValues(results, columnCount, argResultFieldTypes, maxRows);
/*     */           } 
/* 330 */           logger_.debug("Finished conversion of database result set.");
/*     */         } 
/*     */ 
/*     */         
/* 334 */         if (iQueryResultList.size() > 0)
/*     */         {
/* 336 */           return iQueryResultList;
/*     */         }
/*     */ 
/*     */         
/* 340 */         results = null; return (IQueryResultList<?>)results;
/*     */       } 
/*     */ 
/*     */       
/* 344 */       if (argResultClass != null && IQueryResult.class.isAssignableFrom(argResultClass)) {
/*     */ 
/*     */         
/* 347 */         Class<? extends IQueryResult> resultClass = (Class)argResultClass;
/* 348 */         QueryResultHelper.DataMapping mapping = QueryResultHelper.getInstance().getMapping(resultClass);
/* 349 */         Object result = QueryResultBuilder.getInstance().buildResult(argResultFields, resultClass, argStrategy
/* 350 */             .getDataSourceName(), mapping, new Object[] { Integer.valueOf(statement.getUpdateCount()) });
/* 351 */         return QueryResultList.makeList(result, resultClass);
/*     */       } 
/*     */ 
/*     */       
/* 355 */       IQueryResultList<?> resultList = QueryResultList.makeList(new Object[] { Integer.valueOf(statement.getUpdateCount()) }, Object[].class); return resultList;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends IQueryResult> IQueryResultList<T> getProcedureResultObjects(Object[] argResult, QueryResultHelper.DataMapping argDataMapping, String[] argResultFields, Class<T> argResultClass, String argDatasourceName, int argColumnCount) {
/* 380 */     QueryResultList.Builder<T> builder = QueryResultList.newBuilder(argResultClass);
/*     */     
/* 382 */     T result = QueryResultBuilder.getInstance().buildResult(argResultFields, argResultClass, argDatasourceName, argDataMapping, argResult);
/*     */     
/* 384 */     builder.add(result);
/*     */     
/* 386 */     return (IQueryResultList<T>)builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends IQueryResult> IQueryResultList<T> getQueryResultObjects(ResultSet argResult, QueryResultHelper.DataMapping argDataMapping, String[] argResultFields, Class<T> argResultClass, String argDatasourceName, int argColumnCount, String[] argColumnTypes, int argMaxResults) throws SQLException {
/* 411 */     String[] columnDataTypes = argColumnTypes;
/* 412 */     if (columnDataTypes.length != argResultFields.length) {
/* 413 */       columnDataTypes = new String[argColumnCount];
/* 414 */       for (int i = 0; i < argResultFields.length; i++) {
/* 415 */         columnDataTypes[i] = argDataMapping.getSetterParameterTypeAsString(argResultFields[i]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 420 */     QueryResultList.Builder<T> builder = QueryResultList.newBuilder(argResultClass);
/* 421 */     Object[] rowBuffer = new Object[argColumnCount];
/* 422 */     int rowCount = 1;
/* 423 */     while (argResult.next()) {
/* 424 */       rowCount++;
/* 425 */       if (_debugLogging && rowCount % 100 == 0) {
/* 426 */         logger_.debug("Converted [" + rowCount + "] rows of result set to result objects.");
/*     */       }
/* 428 */       for (int i = 1; i <= argColumnCount; i++) {
/* 429 */         String type = (columnDataTypes.length > 0) ? columnDataTypes[i - 1] : null;
/* 430 */         rowBuffer[i - 1] = getValueForType(argResult, i, type);
/*     */       } 
/* 432 */       T result = QueryResultBuilder.getInstance().buildResult(argResultFields, argResultClass, argDatasourceName, argDataMapping, rowBuffer);
/*     */       
/* 434 */       builder.add(result);
/*     */     } 
/*     */ 
/*     */     
/* 438 */     boolean limitReached = (argMaxResults == 0) ? false : ((rowCount >= argMaxResults));
/* 439 */     return (IQueryResultList<T>)builder.setLimit(argMaxResults).setLimitReached(limitReached).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IQueryResultList<Object[]> getQueryResultValues(ResultSet argResult, int argColumnCount, String[] argColumnTypes, int argMaxResults) throws SQLException {
/* 456 */     QueryResultList.Builder<Object[]> builder = QueryResultList.newBuilder(Object[].class);
/* 457 */     int rowCount = 0;
/* 458 */     while (argResult.next()) {
/* 459 */       rowCount++;
/* 460 */       if (_debugLogging && rowCount % 100 == 0) {
/* 461 */         logger_.debug("Converted [" + rowCount + "] rows of result set to a list of arrays.");
/*     */       }
/* 463 */       Object[] row = new Object[argColumnCount];
/* 464 */       for (int i = 1; i <= argColumnCount; i++) {
/* 465 */         String type = (argColumnTypes.length > 0) ? argColumnTypes[i - 1] : null;
/* 466 */         row[i - 1] = getValueForType(argResult, i, type);
/*     */       } 
/* 468 */       builder.add(row);
/*     */     } 
/*     */ 
/*     */     
/* 472 */     boolean limitReached = (argMaxResults == 0) ? false : ((rowCount >= argMaxResults));
/* 473 */     return (IQueryResultList<Object[]>)builder.setLimit(argMaxResults).setLimitReached(limitReached).build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getValueForType(ResultSet resultSet, int argIndex, String argType) throws SQLException {
/* 479 */     if ("BigDecimal".equalsIgnoreCase(argType)) {
/* 480 */       return resultSet.getBigDecimal(argIndex);
/*     */     }
/* 482 */     if ("Byte".equalsIgnoreCase(argType)) {
/* 483 */       return Byte.valueOf(resultSet.getByte(argIndex));
/*     */     }
/* 485 */     if ("Bytes".equalsIgnoreCase(argType)) {
/* 486 */       byte[] temp = resultSet.getBytes(argIndex);
/* 487 */       if (temp == null) {
/* 488 */         return null;
/*     */       }
/*     */       
/* 491 */       return temp;
/*     */     } 
/*     */     
/* 494 */     if ("Date".equalsIgnoreCase(argType) || "Timestamp".equalsIgnoreCase(argType)) {
/* 495 */       Timestamp temp = resultSet.getTimestamp(argIndex);
/* 496 */       if (temp == null) {
/* 497 */         return null;
/*     */       }
/*     */       
/* 500 */       return new DtvDate(temp.getTime());
/*     */     } 
/*     */     
/* 503 */     if ("Integer".equalsIgnoreCase(argType) || "int".equalsIgnoreCase(argType)) {
/* 504 */       return Integer.valueOf(resultSet.getInt(argIndex));
/*     */     }
/* 506 */     if ("Long".equalsIgnoreCase(argType)) {
/* 507 */       return Long.valueOf(resultSet.getLong(argIndex));
/*     */     }
/* 509 */     if ("String".equalsIgnoreCase(argType)) {
/* 510 */       return resultSet.getString(argIndex);
/*     */     }
/* 512 */     if ("Boolean".equalsIgnoreCase(argType)) {
/* 513 */       return Boolean.valueOf(resultSet.getBoolean(argIndex));
/*     */     }
/*     */     
/* 516 */     if (argType == null || "Object".equalsIgnoreCase(argType)) {
/* 517 */       if (logger_.isDebugEnabled()) {
/* 518 */         logger_.debug("Reading field of argType [" + argType + "]");
/*     */       }
/*     */     } else {
/*     */       
/* 522 */       logger_.warn("Unknown result argType [" + argType + "]");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 534 */     int columnType = -1;
/* 535 */     Object oo = null;
/*     */     try {
/* 537 */       ResultSetMetaData metaData = resultSet.getMetaData();
/*     */       
/* 539 */       if (metaData != null) {
/* 540 */         columnType = metaData.getColumnType(argIndex);
/* 541 */         if (columnType == 91 || columnType == 93) {
/* 542 */           Timestamp temp = resultSet.getTimestamp(argIndex);
/* 543 */           if (temp != null) {
/* 544 */             oo = new DtvDate(temp.getTime());
/*     */           }
/*     */         } else {
/*     */           
/* 548 */           oo = resultSet.getObject(argIndex);
/*     */         } 
/*     */       } else {
/*     */         
/* 552 */         oo = resultSet.getObject(argIndex);
/*     */       }
/*     */     
/* 555 */     } catch (Exception ee) {
/* 556 */       if (logger_.isDebugEnabled()) {
/* 557 */         logger_.debug("Failed to determine column type from meta data.", ee);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 570 */     if (oo instanceof Clob) {
/* 571 */       Clob clob = (Clob)oo;
/* 572 */       oo = clob.getSubString(1L, (int)clob.length());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 579 */     else if (oo instanceof Blob) {
/* 580 */       Blob blob = (Blob)oo;
/* 581 */       oo = blob.getBytes(1L, (int)blob.length());
/*     */     } 
/*     */     
/* 584 */     return oo;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\SqlQueryExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */