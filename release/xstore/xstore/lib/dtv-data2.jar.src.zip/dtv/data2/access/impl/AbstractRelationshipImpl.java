/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.data2.access.IDataModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRelationshipImpl
/*    */   implements IDataModelRelationshipImpl
/*    */ {
/*    */   private final boolean useParentPm_;
/*    */   private final String identifier_;
/*    */   private final Class<? extends Object> child_;
/*    */   private IDataModelImpl parent_;
/*    */   private final boolean propertyRelationship_;
/*    */   private final boolean transientRelationship_;
/*    */   
/*    */   protected AbstractRelationshipImpl(String argIdentifier, Class<? extends Object> argChild, boolean argUseParentPm, boolean argPropertyRelationship, boolean argTransientRelationship) {
/* 36 */     this.identifier_ = argIdentifier;
/* 37 */     this.child_ = argChild;
/* 38 */     this.useParentPm_ = argUseParentPm;
/* 39 */     this.propertyRelationship_ = argPropertyRelationship;
/* 40 */     this.transientRelationship_ = argTransientRelationship;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<? extends Object> getChild() {
/* 50 */     return this.child_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getIdentifier() {
/* 60 */     return this.identifier_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IDataModel getParent() {
/* 66 */     return this.parent_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPropertyRelationship() {
/* 72 */     return this.propertyRelationship_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isTransientRelationship() {
/* 78 */     return this.transientRelationship_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isUseParentPm() {
/* 84 */     return this.useParentPm_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParent(IDataModel argOwner) {
/* 95 */     this.parent_ = (IDataModelImpl)argOwner;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\AbstractRelationshipImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */