/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.access.DataFactory;
/*     */ import dtv.data2.access.IQueryResult;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import dtv.util.NumberUtils;
/*     */ import dtv.util.ObjectUtils;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryResultBuilder
/*     */ {
/*  25 */   private static final Logger logger_ = Logger.getLogger(QueryResultBuilder.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   private static final QueryResultBuilder INSTANCE = new QueryResultBuilder();
/*     */   
/*     */   private static final String PUT_METHOD = "put";
/*     */   
/*     */   private static final String SETTER_PREFIX = "set";
/*     */   private static final String GETTER_PREFIX = "get";
/*     */   private static final String DOT_OPERATOR = ".";
/*     */   
/*     */   public static QueryResultBuilder getInstance() {
/*  43 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IQueryResult> T buildResult(String[] argFields, Class<T> argResultClass, String argDataSource, QueryResultHelper.DataMapping argMapping, Object[] argResultFields) {
/*     */     try {
/*  65 */       IQueryResult iQueryResult = (IQueryResult)argResultClass.newInstance();
/*     */       
/*  67 */       iQueryResult.setDataSource(argDataSource);
/*     */ 
/*     */       
/*  70 */       for (int index = 0; index < argFields.length; index++) {
/*  71 */         String fieldName = argFields[index];
/*  72 */         Object methodParameter = argResultFields[index];
/*     */ 
/*     */         
/*  75 */         if (methodParameter != null)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*  80 */           if (fieldName.indexOf(".") != -1) {
/*  81 */             setValueMethodChain(iQueryResult, fieldName, methodParameter);
/*     */           } else {
/*     */ 
/*     */             
/*     */             try {
/*  86 */               Method setterMethod = argMapping.getSetterForField(fieldName, methodParameter);
/*     */ 
/*     */               
/*  89 */               if (setterMethod != null && (setterMethod.getParameterTypes()).length == 1) {
/*  90 */                 invokeSetterForSingleArgumentMethod(iQueryResult, setterMethod, methodParameter);
/*     */               
/*     */               }
/*  93 */               else if ((setterMethod != null && (setterMethod.getParameterTypes()).length == 2) || setterMethod
/*  94 */                 .getName().equals("put")) {
/*  95 */                 setterMethod.invoke(iQueryResult, new Object[] { fieldName, methodParameter });
/*     */               }
/*     */               else {
/*     */                 
/*  99 */                 throw new DtxException("An unrecognized setter of [" + setterMethod.toString() + " was found for field " + fieldName + " but could not be used.");
/*     */               }
/*     */             
/*     */             }
/* 103 */             catch (Exception ee) {
/* 104 */               throw new DtxException("An exception occurred while setting field " + fieldName + ".  Could not successfully assign paramter of " + methodParameter + " [Type: " + methodParameter
/*     */                   
/* 106 */                   .getClass() + " Value: " + String.valueOf(methodParameter) + "].", ee);
/*     */             } 
/*     */           }  } 
/*     */       } 
/* 110 */       return (T)iQueryResult;
/*     */     }
/* 112 */     catch (Exception ex) {
/* 113 */       throw new DtxException("Could not instantiate query result class specified: " + argResultClass
/* 114 */           .getName(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IQueryResult[] buildResults(String argQueryKey, Object[][] argResults, String[] argFields, Class<?> argResultClass, String argDataSource) {
/* 136 */     checkForInputErrors(argQueryKey, argResults, argFields, argResultClass, argDataSource);
/*     */ 
/*     */ 
/*     */     
/* 140 */     Class<? extends IQueryResult> resultClass = (Class)argResultClass;
/*     */ 
/*     */     
/* 143 */     QueryResultHelper.DataMapping mapping = QueryResultHelper.getInstance().getMapping(argResultClass);
/* 144 */     IQueryResult[] returnModels = (IQueryResult[])Array.newInstance(argResultClass, argResults.length);
/* 145 */     for (int recordIndex = 0; recordIndex < argResults.length; recordIndex++) {
/* 146 */       returnModels[recordIndex] = 
/* 147 */         buildResult(argFields, (Class)resultClass, argDataSource, mapping, argResults[recordIndex]);
/*     */     }
/* 149 */     return returnModels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueMethodChain(Object argCurrentResultObject, String methodChain, Object argParameter) {
/*     */     try {
/* 163 */       if (argCurrentResultObject instanceof dtv.data2.access.IDataModel)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 170 */         StringTokenizer tokens = new StringTokenizer(methodChain, ".");
/* 171 */         Object lastObject = argCurrentResultObject;
/*     */         
/* 173 */         while (tokens.hasMoreTokens()) {
/* 174 */           String methodName = tokens.nextToken();
/*     */           
/* 176 */           if (tokens.hasMoreTokens()) {
/* 177 */             Object currentObject = ObjectUtils.invokeMethod(methodName, lastObject, null);
/*     */             
/* 179 */             if (currentObject == null) {
/*     */               
/* 181 */               Class<?> objectType = lastObject.getClass().getMethod(methodName, new Class[0]).getReturnType();
/* 182 */               currentObject = DataFactory.createObject(objectType);
/*     */ 
/*     */               
/* 185 */               String setterName = "set" + methodName.substring("get".length());
/* 186 */               ObjectUtils.invokeMethod(setterName, lastObject, new Class[] { objectType }, new Object[] { currentObject }, null);
/*     */             } 
/*     */             
/* 189 */             lastObject = currentObject;
/*     */             continue;
/*     */           } 
/* 192 */           ObjectUtils.invokeMethod(methodName, lastObject, new Class[] { argParameter.getClass() }, new Object[] { argParameter }, null);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 199 */         ObjectUtils.invokeMethodChain(methodChain, argCurrentResultObject, new Class[] { argParameter
/* 200 */               .getClass() }, new Object[] { argParameter }, null);
/*     */       }
/*     */     
/* 203 */     } catch (Exception ee) {
/* 204 */       throw new DtxException("An exception occurred while calling method chain " + methodChain + " on object of class: " + argCurrentResultObject
/*     */           
/* 206 */           .getClass().getName() + " with paramter: " + argParameter, ee);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeSetterForSingleArgumentMethod(IQueryResult argModelObject, Method argSetterMethod, Object argParameter) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
/* 224 */     Class<?> parameterClass = argParameter.getClass();
/* 225 */     Class<?> setterMethodParameterClass = argSetterMethod.getParameterTypes()[0];
/*     */ 
/*     */     
/* 228 */     if (setterMethodParameterClass.equals(parameterClass) || 
/* 229 */       ClassUtils.isAssignable(argSetterMethod.getParameterTypes()[0], parameterClass)) {
/* 230 */       argSetterMethod.invoke(argModelObject, new Object[] { argParameter });
/*     */ 
/*     */     
/*     */     }
/* 234 */     else if (argParameter instanceof Number && 
/* 235 */       ClassUtils.isAssignable(Number.class, setterMethodParameterClass)) {
/* 236 */       argSetterMethod.invoke(argModelObject, new Object[] {
/* 237 */             NumberUtils.getNumberFromOtherNumber((Number)argParameter, setterMethodParameterClass)
/*     */           });
/*     */     
/*     */     }
/* 241 */     else if (argParameter instanceof Number && 
/* 242 */       ClassUtils.isAssignable(Boolean.class, setterMethodParameterClass)) {
/* 243 */       argSetterMethod.invoke(argModelObject, new Object[] { Boolean.valueOf((((Number)argParameter).intValue() == 1)) });
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 248 */     else if (parameterClass.isArray() && ClassUtils.isAssignable(parameterClass.getComponentType(), setterMethodParameterClass
/* 249 */         .getComponentType())) {
/* 250 */       int arrayLength = Array.getLength(argParameter);
/* 251 */       Object targetArray = Array.newInstance(setterMethodParameterClass.getComponentType(), arrayLength);
/* 252 */       for (int arrayIndex = 0; arrayIndex < arrayLength; arrayIndex++) {
/* 253 */         Array.set(targetArray, arrayIndex, Array.get(argParameter, arrayIndex));
/*     */       }
/* 255 */       argSetterMethod.invoke(argModelObject, new Object[] { targetArray });
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 260 */       throw new DtxException("An exception occurred while calling [" + argSetterMethod.toString() + "].  Could not successfully assign paramter of " + argParameter + " [Type: " + parameterClass
/*     */           
/* 262 */           .toString() + "Value: " + String.valueOf(argParameter) + "].");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkForInputErrors(String argQueryKey, Object[][] argResults, String[] argFields, Class<?> argResultClass, String argDataSource) {
/* 277 */     if (argResults == null) {
/* 278 */       DtxException ex = new DtxException("buildResults was called with a NULL argResults array. This is an invalid call.");
/*     */       
/* 280 */       logQueryResultError(ex.getMessage(), argQueryKey, argResults, argFields, argResultClass, argDataSource, (Throwable)ex);
/*     */       
/* 282 */       throw ex;
/*     */     } 
/*     */     
/* 285 */     if (argFields == null) {
/* 286 */       DtxException ex = new DtxException("buildResults was called with a NULL argFields array. This is an invalid call.");
/*     */       
/* 288 */       logQueryResultError(ex.getMessage(), argQueryKey, argResults, argFields, argResultClass, argDataSource, (Throwable)ex);
/*     */       
/* 290 */       throw ex;
/*     */     } 
/*     */     
/* 293 */     if (argResultClass == null) {
/* 294 */       DtxException ex = new DtxException("buildResults was called with a NULL argResultClass. This is an invalid call.");
/*     */       
/* 296 */       logQueryResultError(ex.getMessage(), argQueryKey, argResults, argFields, argResultClass, argDataSource, (Throwable)ex);
/*     */       
/* 298 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logQueryResultError(String argMsg, String argQueryKey, Object[][] argResults, String[] argFields, Class<?> argResultClass, String argDataSource, Throwable argException) {
/* 306 */     String resultsString = "argResults: null";
/*     */     
/* 308 */     if (argResults != null) {
/* 309 */       resultsString = "argResults row length: " + argResults.length;
/* 310 */       resultsString = resultsString + " argResults values: ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 316 */       for (int ii = 0, n = Math.min(argResults.length, 5); ii < n; ii++) {
/*     */         
/* 318 */         resultsString = resultsString + "row idx " + ii + " column count: " + ((argResults[ii] != null) ? String.valueOf((argResults[ii]).length) : "null");
/*     */         
/* 320 */         resultsString = resultsString + " [";
/*     */         
/* 322 */         for (int jj = 0; jj < (argResults[ii]).length; jj++) {
/* 323 */           resultsString = resultsString + argResults[ii][jj];
/*     */           
/* 325 */           if (jj < (argResults[ii]).length - 1) {
/* 326 */             resultsString = resultsString + ", ";
/*     */           }
/*     */         } 
/* 329 */         resultsString = resultsString + "] ";
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 334 */     String argFieldsString = "argFields: null";
/*     */     
/* 336 */     if (argFields != null) {
/* 337 */       argFieldsString = "argFields length: " + argFields.length;
/* 338 */       argFieldsString = argFieldsString + " argFields values: ";
/*     */       
/* 340 */       for (int ii = 0; ii < argFields.length; ii++) {
/* 341 */         argFieldsString = argFieldsString + "[" + argFields[ii] + "]";
/*     */         
/* 343 */         if (ii < argFields.length - 1) {
/* 344 */           argFieldsString = argFieldsString + ", ";
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 351 */     String resultClassString = ("argResultClass: " + argResultClass != null) ? ObjectUtils.getClassName(argResultClass) : "null";
/*     */     
/* 353 */     String DIVIDER = " -- ";
/*     */     
/* 355 */     logger_.error(argMsg + " QUERY KEY: " + argQueryKey + " -- " + resultsString + " -- " + argFieldsString + " -- " + resultClassString + " -- " + "Datasource: " + argDataSource, (argException != null) ? argException : new Throwable("STACK TRACE"));
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\QueryResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */