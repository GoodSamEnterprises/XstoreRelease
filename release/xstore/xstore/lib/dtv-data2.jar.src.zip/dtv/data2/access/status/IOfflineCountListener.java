package dtv.data2.access.status;

import java.util.Map;

public interface IOfflineCountListener {
  void notifyNewCount(Map<String, Integer> paramMap);
}


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\status\IOfflineCountListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */