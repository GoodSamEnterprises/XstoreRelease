/*    */ package dtv.data2.access.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateNotEffectiveException
/*    */   extends SpecialActionException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public UpdateNotEffectiveException(String argMessage, String argDataSource) {
/* 25 */     super(argMessage, argDataSource);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ExceptionApplicableRule[] getApplicableRules() {
/* 33 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\exception\UpdateNotEffectiveException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */