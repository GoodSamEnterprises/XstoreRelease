/*    */ package dtv.data2.access.query;
/*    */ 
/*    */ import dtv.data2.access.impl.daogen.ConfigElementTables;
/*    */ import dtv.util.ClassPathUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigElementSqlDecorator
/*    */   extends AbstractTargetedDataSqlDecorator
/*    */ {
/*    */   public static final String PARAM_CONFIG_ELEMENT_LIST = "cOnFiGeLeMeNtLiSt";
/*    */   private static final String CONFIG_ELEMENT_COLUMN = "config_element";
/*    */   
/*    */   protected String getReplacementSql(String argTableName, Map<String, Object> argQueryParams) {
/* 37 */     List<String> configElements = new ArrayList<>();
/*    */     
/* 39 */     if (argQueryParams.containsKey("cOnFiGeLeMeNtLiSt")) {
/*    */ 
/*    */ 
/*    */       
/* 43 */       Collection<String> elementsParamValue = (Collection<String>)argQueryParams.get("cOnFiGeLeMeNtLiSt");
/* 44 */       configElements.addAll(elementsParamValue);
/*    */     }
/*    */     else {
/*    */       
/* 48 */       configElements.add("*");
/* 49 */       configElements.addAll(ClassPathUtils.getPrioritizedConfigPathElements().keySet());
/*    */     } 
/*    */     
/* 52 */     StringBuilder newSql = new StringBuilder();
/* 53 */     newSql.append("(SELECT * FROM ").append(argTableName).append(" WHERE /*UPPER*/config_element IN (");
/*    */ 
/*    */     
/* 56 */     String configElementArgs = SqlQueryBuilder.toSqlInClauseArgs(configElements, true);
/*    */     
/* 58 */     newSql.append(configElementArgs);
/* 59 */     newSql.append("))");
/*    */     
/* 61 */     return newSql.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Collection<String> getTablesToDecorate() {
/* 67 */     return ConfigElementTables.getTableNames();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isDecoratable(String argSqlStatement, Map<String, Object> argQueryParams) {
/* 73 */     boolean superIsDecoratable = super.isDecoratable(argSqlStatement, argQueryParams);
/*    */     
/* 75 */     boolean ignorePresent = (argQueryParams != null && argQueryParams.containsKey("IGNORE_CONFIG_ELEMENT_FILTERING"));
/* 76 */     return (superIsDecoratable && !ignorePresent);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\ConfigElementSqlDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */