/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import dtv.util.FileUtils;
/*     */ import java.io.File;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DAOGen
/*     */   implements Callable<Void>
/*     */ {
/*  25 */   private static final Logger logger_ = LogManager.getLogger(DAOGen.class);
/*     */ 
/*     */   
/*     */   private final Collection<? extends File> _baseDirs;
/*     */ 
/*     */   
/*     */   private final File _inDir;
/*     */ 
/*     */   
/*     */   private final File _outDir;
/*     */ 
/*     */   
/*     */   private final File _cleanbeanOutDir;
/*     */ 
/*     */   
/*     */   private final File _sourcesDir;
/*     */ 
/*     */   
/*     */   private final File _tempDir;
/*     */   
/*     */   private final boolean _overrideMode;
/*     */   
/*     */   private final String _overrideType;
/*     */   
/*     */   private final String _overrideExtends;
/*     */ 
/*     */   
/*     */   public DAOGen(Collection<? extends File> argBaseDirs, File inDir, File outDir, File cleanbeanOutDir, File sourcesDir, File tempDir, boolean argOverrideMode, String argOverrideType, String argOverrideExtends) {
/*  53 */     this._baseDirs = argBaseDirs;
/*  54 */     this._inDir = inDir;
/*  55 */     this._outDir = outDir;
/*  56 */     this._cleanbeanOutDir = cleanbeanOutDir;
/*  57 */     this._sourcesDir = sourcesDir;
/*  58 */     this._tempDir = tempDir;
/*  59 */     this._overrideMode = argOverrideMode;
/*  60 */     this._overrideType = argOverrideType;
/*  61 */     this._overrideExtends = argOverrideExtends;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DAOGen(File inDir, File outDir, File cleanbeanOutDir, File sourcesDir, File tempDir, boolean argOverrideMode) {
/*  76 */     this(null, inDir, outDir, cleanbeanOutDir, sourcesDir, tempDir, argOverrideMode, "", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DAOGen(File inDir, File outDir, File cleanbeanOutDir, File sourcesDir, File tempDir, boolean argOverrideMode, String argOverrideType, String argOverrideExtends) {
/*  93 */     this(null, inDir, outDir, cleanbeanOutDir, sourcesDir, tempDir, argOverrideMode, argOverrideType, argOverrideExtends);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws Exception {
/* 101 */     long startTime = System.currentTimeMillis();
/*     */     
/* 103 */     try (DaoGenHelper helper = DaoGenHelper.create()) {
/* 104 */       helper.setBaseInDirs(this._baseDirs);
/* 105 */       helper.setInDir(this._inDir);
/* 106 */       helper.setOutDir(this._outDir);
/* 107 */       helper.setCleanbeanOutDir(this._cleanbeanOutDir);
/* 108 */       helper.setSourcesDir(this._sourcesDir);
/* 109 */       helper.setTempDir(this._tempDir);
/* 110 */       helper.setOverrideMode(this._overrideMode);
/* 111 */       helper.setOverrideType(this._overrideType);
/* 112 */       helper.setOverrideExtends(this._overrideExtends);
/*     */       
/* 114 */       logger_.info("Input coming from '" + helper.getInPath() + "'");
/* 115 */       logger_.info("Output going to '" + helper.getOutPath() + "'");
/* 116 */       if (helper.getCleanbeanOutPath() != null) {
/* 117 */         logger_.info("Cleanbean output going to '" + helper.getCleanbeanOutPath() + "'");
/*     */       } else {
/*     */         
/* 120 */         logger_.info("Cleanbean generation not enabled.");
/*     */       } 
/*     */ 
/*     */       
/* 124 */       List<File> files = FileUtils.getFiles(helper.getInDir(), "dtx");
/*     */       
/* 126 */       helper.preLoad(files, true);
/*     */       
/* 128 */       for (File dir : helper.getBaseInDirs()) {
/* 129 */         List<File> baseFiles = FileUtils.getFiles(dir, "dtx");
/* 130 */         helper.preLoad(baseFiles, false);
/*     */       } 
/*     */       
/* 133 */       helper.load();
/*     */ 
/*     */       
/* 136 */       (new GenerateInterfaces(helper)).call();
/* 137 */       (new GenerateDaoAndDba(helper)).call();
/* 138 */       (new GenerateRelationships(helper)).call();
/* 139 */       (new GenerateIds(helper)).call();
/*     */ 
/*     */       
/* 142 */       helper.getWriter().flush();
/* 143 */       helper.precompile();
/*     */ 
/*     */ 
/*     */       
/* 147 */       GenerateOrgHierarchyTableList orgHierarchyTableList = GenerateOrgHierarchyTableList.createInstance(helper);
/* 148 */       orgHierarchyTableList.call();
/*     */       
/* 150 */       GenerateConfigElementTableList configElementTableList = GenerateConfigElementTableList.createInstance(helper);
/* 151 */       configElementTableList.call();
/*     */       
/* 153 */       (new GenerateXmlSchemas(helper)).call();
/* 154 */       if (helper.getCleanbeanOutPath() != null) {
/* 155 */         (new GenerateCleanbean(helper)).call();
/*     */       }
/* 157 */       GenerateJDBCMapping mapping = GenerateJDBCMapping.getInstance();
/* 158 */       mapping.setHelper(helper);
/* 159 */       mapping.call();
/*     */       
/* 161 */       (new GenerateModels(helper)).call();
/*     */       
/* 163 */       GenerateDataModelFactoryImpl modelFactory = GenerateDataModelFactoryImpl.getInstance();
/* 164 */       modelFactory.setHelper(helper);
/* 165 */       modelFactory.call();
/*     */     }
/* 167 */     catch (Exception ee) {
/*     */       
/* 169 */       logger_.error("Error: " + ee.getMessage(), ee);
/*     */       
/* 171 */       System.out.println("Error: " + ee.getMessage() + ee.getMessage());
/* 172 */       ee.printStackTrace();
/*     */       
/* 174 */       throw ee;
/*     */     } 
/*     */     
/* 177 */     long totalTime = System.currentTimeMillis() - startTime;
/* 178 */     logger_.info("DAO Generation completed in: " + totalTime + "ms");
/* 179 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\DAOGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */