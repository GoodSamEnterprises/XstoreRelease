/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import com.google.common.collect.LinkedListMultimap;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.XmlUtils;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateXmlSchemas
/*     */   implements Callable<Void>
/*     */ {
/*  27 */   private static final Logger logger_ = Logger.getLogger(GenerateXmlSchemas.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final DaoGenHelper helper_;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenerateXmlSchemas(DaoGenHelper argHelper) {
/*  37 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws Exception {
/*  45 */     logger_.info("Generating XML Schemas");
/*     */ 
/*     */     
/*  48 */     File dir = new File(this.helper_.getOutPath() + File.separator + "xml-schemas");
/*  49 */     dir.mkdirs();
/*     */     
/*  51 */     LinkedListMultimap<String, DtxDefinition> dtxByPkg = getDtxByPkg();
/*     */     
/*  53 */     for (String pkg : dtxByPkg.keySet()) {
/*     */       
/*  55 */       StringBuilder w = new StringBuilder(5120);
/*     */       
/*  57 */       List<DtxDefinition> definitions = dtxByPkg.get(pkg);
/*     */       
/*  59 */       List<String> requiredImportDomains = getRequiredImports(pkg, definitions);
/*     */       
/*  61 */       writeHeader(definitions.get(0), w, requiredImportDomains);
/*     */       
/*  63 */       for (DtxDefinition dtx : definitions) {
/*  64 */         writeElement(dtx, w);
/*  65 */         writeTypeHeader(dtx, w);
/*  66 */         writeTypeFields(dtx, w);
/*  67 */         writeTypeRelationships(dtx, w);
/*  68 */         writeTypeFooter(dtx, w);
/*     */       } 
/*     */       
/*  71 */       writeFooter(definitions.get(0), w);
/*  72 */       Exception badXml = null;
/*     */       
/*  74 */       String schema = null;
/*     */       
/*     */       try {
/*  77 */         schema = XmlUtils.getBeautifiedXml(w.toString());
/*     */       }
/*  79 */       catch (Exception ee) {
/*  80 */         badXml = ee;
/*  81 */         schema = w.toString();
/*     */       } 
/*     */ 
/*     */       
/*  85 */       File file = new File(this.helper_.getOutPath() + File.separator + "xml-schemas" + File.separator + StringUtils.ensureFirstUpperCase(((DtxDefinition)definitions.get(0)).getPackageDomain()) + ".xsd");
/*  86 */       this.helper_.getWriter().write(file, schema);
/*     */       
/*  88 */       if (badXml != null) {
/*  89 */         throw badXml;
/*     */       }
/*     */     } 
/*  92 */     return null;
/*     */   }
/*     */   
/*     */   private LinkedListMultimap<String, DtxDefinition> getDtxByPkg() {
/*  96 */     LinkedListMultimap<String, DtxDefinition> dtxByPkg = LinkedListMultimap.create();
/*  97 */     for (DtxDefinition dtx : this.helper_.getDtxDefinitions()) {
/*  98 */       dtxByPkg.put(dtx.getPackageRaw(), dtx);
/*     */     }
/*     */     
/* 101 */     return dtxByPkg;
/*     */   }
/*     */   
/*     */   private List<String> getRequiredImports(String argCurrentPackage, List<DtxDefinition> argDtxCurrentPkg) {
/* 105 */     String domain = ((DtxDefinition)argDtxCurrentPkg.get(0)).getPackageDomain();
/*     */     
/* 107 */     List<String> requiredImports = new ArrayList<>();
/*     */     
/* 109 */     for (DtxDefinition dtx : argDtxCurrentPkg) {
/* 110 */       for (DtxRelationship rel : dtx.getRelationships()) {
/* 111 */         if (!rel.getChild().getPackageDomain().equals(domain) && 
/* 112 */           !requiredImports.contains(rel.getChild().getPackageDomain()))
/*     */         {
/* 114 */           requiredImports.add(rel.getChild().getPackageDomain());
/*     */         }
/*     */       } 
/* 117 */       if (dtx.isExtended()) {
/* 118 */         if (!dtx.getExtends().getPackageDomain().equals(dtx.getPackageDomain()) && 
/* 119 */           !requiredImports.contains(dtx.getExtends().getPackageDomain()))
/*     */         {
/* 121 */           requiredImports.add(dtx.getExtends().getPackageDomain());
/*     */         }
/*     */         
/* 124 */         if (!dtx.getTopMostParent().getPackageDomain().equals(dtx.getPackageDomain()) && 
/* 125 */           !requiredImports.contains(dtx.getTopMostParent().getPackageDomain()))
/*     */         {
/* 127 */           requiredImports.add(dtx.getTopMostParent().getPackageDomain());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     return requiredImports;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDuplicateField(DtxDefinition.DtxDaoField argField, DtxDefinition argDtx) {
/* 138 */     if (!argDtx.isExtended()) {
/* 139 */       return false;
/*     */     }
/*     */     
/* 142 */     DtxDefinition.DtxDaoField[] fields = argDtx.getAllFields();
/*     */     
/* 144 */     int matches = 0;
/*     */     
/* 146 */     for (DtxDefinition.DtxDaoField field : fields) {
/* 147 */       if (field.getName().equals(argField.getName())) {
/* 148 */         matches++;
/*     */       }
/*     */     } 
/*     */     
/* 152 */     if (matches > 1) {
/* 153 */       return true;
/*     */     }
/*     */     
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isLowLevelField(String argFieldName) {
/* 161 */     return ("CreateDate".equals(argFieldName) || "CreateUserId".equals(argFieldName) || "UpdateDate"
/* 162 */       .equals(argFieldName) || "UpdateUserId".equals(argFieldName));
/*     */   }
/*     */   
/*     */   private void writeElement(DtxDefinition dtx, StringBuilder buf) {
/* 166 */     buf.append("  <!-- ********************************************************************** -->\n");
/* 167 */     buf.append("  <!-- " + dtx.getName() + " - corresponds to table: " + dtx.getTable() + " -->\n");
/* 168 */     buf.append("  <!-- ********************************************************************** -->\n");
/*     */     
/* 170 */     buf.append("<xs:element name=\"" + dtx.getName() + "\"");
/* 171 */     if (dtx.isExtended()) {
/* 172 */       String substitutionGroupName = dtx.getTopMostParent().getName();
/*     */       
/* 174 */       if (!dtx.getTopMostParent().getPackageDomain().equals(dtx.getPackageDomain())) {
/* 175 */         substitutionGroupName = StringUtils.ensureFirstUpperCase(dtx.getTopMostParent().getPackageDomain()) + ":" + substitutionGroupName;
/*     */       }
/*     */ 
/*     */       
/* 179 */       buf.append(" substitutionGroup=\"" + substitutionGroupName + "\"");
/*     */     } 
/* 181 */     buf.append(" type=\"" + dtx.getName() + "Model\"/>");
/*     */   }
/*     */   
/*     */   private void writeFooter(DtxDefinition dtx, StringBuilder buf) {
/* 185 */     buf.append("</xs:schema>");
/*     */   }
/*     */   
/*     */   private void writeHeader(DtxDefinition dtx, StringBuilder buf, List<String> argRequiredImports) {
/* 189 */     String ns = StringUtils.ensureFirstUpperCase(dtx.getPackageDomain());
/* 190 */     buf.append("<?xml version = \"1.0\" encoding = \"UTF-8\"?>");
/* 191 */     buf.append("<!-- ** AUTOGENERATED xml schema ** - do not manually edit. -->");
/* 192 */     buf.append("<xs:schema xmlns = \"http://xmlns.datavantagecorp.com/xstore/" + ns + "\" targetNamespace = \"http://xmlns.datavantagecorp.com/xstore/" + ns + "\" xmlns:xs = \"http://www.w3.org/2001/XMLSchema\" elementFormDefault = \"qualified\" attributeFormDefault = \"unqualified\"");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     for (String domain : argRequiredImports) {
/* 198 */       domain = StringUtils.ensureFirstUpperCase(domain);
/* 199 */       buf.append(" xmlns:" + domain + " = \"http://xmlns.datavantagecorp.com/xstore/" + domain + "\"");
/*     */     } 
/*     */     
/* 202 */     buf.append(">\n\n");
/*     */     
/* 204 */     for (String domain : argRequiredImports) {
/* 205 */       domain = StringUtils.ensureFirstUpperCase(domain);
/* 206 */       buf.append(" <xs:import namespace=\"http://xmlns.datavantagecorp.com/xstore/" + domain + "\" schemaLocation = \"" + domain + ".xsd\"/>");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeTypeFields(DtxDefinition dtx, StringBuilder buf) {
/* 212 */     for (DtxDefinition.DtxDaoField field : dtx.getFields()) {
/* 213 */       String fieldName = StringUtils.ensureFirstUpperCase(field.getName());
/* 214 */       String xmlType = DaoGenUtils.getXmlTypeForField(field);
/*     */       
/* 216 */       if (field.getExported() && !isLowLevelField(fieldName) && !isDuplicateField(field, dtx)) {
/* 217 */         buf.append("<xs:element name=\"" + fieldName + "\" type=\"xs:" + xmlType + "\" ");
/*     */         
/* 219 */         if (!field.isPrimaryKey()) {
/* 220 */           buf.append(" minOccurs=\"0\"");
/*     */         }
/*     */         
/* 223 */         buf.append("/>");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeTypeFooter(DtxDefinition dtx, StringBuilder buf) {
/* 229 */     buf.append("</xs:sequence>");
/*     */     
/* 231 */     if (dtx.isExtended()) {
/* 232 */       buf.append("            </xs:extension>         </xs:complexContent>");
/*     */     }
/*     */     
/* 235 */     buf.append("</xs:complexType>");
/*     */   }
/*     */   
/*     */   private void writeTypeHeader(DtxDefinition dtx, StringBuilder buf) {
/* 239 */     buf.append("<xs:complexType name=\"" + dtx.getName() + "Model\">");
/* 240 */     if (dtx.isExtended()) {
/* 241 */       String extendsName = dtx.getExtends().getName();
/*     */       
/* 243 */       if (!dtx.getExtends().getPackageDomain().equals(dtx.getPackageDomain()))
/*     */       {
/* 245 */         extendsName = StringUtils.ensureFirstUpperCase(dtx.getExtends().getPackageDomain()) + ":" + extendsName;
/*     */       }
/*     */       
/* 248 */       buf.append("        <xs:complexContent>            <xs:extension base=\"" + extendsName + "Model\">                <xs:sequence minOccurs=\"0\">");
/*     */     }
/*     */     else {
/*     */       
/* 252 */       buf.append("<xs:sequence>");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeTypeRelationships(DtxDefinition dtx, StringBuilder buf) {
/* 257 */     for (DtxRelationship rel : dtx.getRelationships()) {
/* 258 */       String relName = StringUtils.ensureFirstUpperCase(rel.getName());
/*     */       
/* 260 */       String childName = rel.getChildName();
/*     */       
/* 262 */       if (!rel.getChild().getPackageDomain().equals(dtx.getPackageDomain())) {
/* 263 */         childName = StringUtils.ensureFirstUpperCase(rel.getChild().getPackageDomain()) + ":" + childName;
/*     */       }
/*     */       
/* 266 */       buf.append("<xs:element name=\"" + relName + "\"  minOccurs=\"0\">   <xs:complexType>                                                    <xs:sequence>                                            ");
/*     */ 
/*     */ 
/*     */       
/* 270 */       buf.append("<xs:element ref=\"" + childName + "\" ");
/* 271 */       if (!rel.getType().equalsIgnoreCase(DtxRelationship.ONE_ONE)) {
/* 272 */         buf.append("maxOccurs=\"unbounded\"");
/*     */       }
/* 274 */       buf.append("/>");
/*     */       
/* 276 */       buf.append("                    </xs:sequence>                </xs:complexType>             </xs:element>         ");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateXmlSchemas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */