/*    */ package dtv.data2.access.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetryException
/*    */   extends SpecialActionException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   private static final ExceptionApplicableRule[] rules = new ExceptionApplicableRule[] { new ExceptionApplicableRule("rerun the transaction"), new ExceptionApplicableRule("all threads are blocked"), new ExceptionApplicableRule("ORA-00060") };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RetryException getNewException(String argMessage, Throwable argCause, String argDataSourceName) {
/* 36 */     if (argCause instanceof RetryException) {
/* 37 */       return (RetryException)argCause;
/*    */     }
/*    */     
/* 40 */     return new RetryException(argMessage, argCause, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RetryException getNewException(Throwable argCause, String argDataSourceName) {
/* 51 */     if (argCause instanceof RetryException) {
/* 52 */       return (RetryException)argCause;
/*    */     }
/*    */     
/* 55 */     return new RetryException(argCause, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isRetryException(Throwable ex) {
/* 65 */     return (new RetryException()).isApplicable(ex);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private RetryException() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private RetryException(String argMessage, Throwable argCause, String argDataSourceName) {
/* 77 */     super(argMessage, argCause, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private RetryException(Throwable argCause, String argDataSourceName) {
/* 84 */     super(argCause, argDataSourceName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ExceptionApplicableRule[] getApplicableRules() {
/* 91 */     return rules;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\exception\RetryException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */