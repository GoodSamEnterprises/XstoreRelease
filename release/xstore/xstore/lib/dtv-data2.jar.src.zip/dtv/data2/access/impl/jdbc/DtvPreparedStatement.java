/*     */ package dtv.data2.access.impl.jdbc;
/*     */ 
/*     */ import dtv.data2.security.DtvSecurityManager;
/*     */ import dtv.util.StringUtils;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DtvPreparedStatement<E extends Statement>
/*     */ {
/*  28 */   private static final Logger DEFAULT_LOG = Logger.getLogger(DtvPreparedStatement.class);
/*  29 */   private static final Logger INSERT_LOG = Logger.getLogger(DtvPreparedStatement.class.getName() + ".INSERT");
/*  30 */   private static final Logger UPDATE_LOG = Logger.getLogger(DtvPreparedStatement.class.getName() + ".UPDATE");
/*  31 */   private static final Logger SELECT_LOG = Logger.getLogger(DtvPreparedStatement.class.getName() + ".SELECT");
/*  32 */   private static final Logger DELETE_LOG = Logger.getLogger(DtvPreparedStatement.class.getName() + ".DELETE");
/*     */ 
/*     */   
/*     */   private static final String DEBUG_INCLUDES_STACKS_PROP = "dtv.data2.access.impl.jdbc.DtvPreparedStatement.StackTrace";
/*     */   
/*  37 */   private static final boolean REPORT_ILLEGAL_ACCESS = Boolean.getBoolean(DtvPreparedStatement.class.getName() + ".ReportIllegalAccess");
/*     */   
/*     */   private final Logger _logger;
/*     */   
/*     */   protected final E _statement;
/*     */   
/*     */   private final String _datasourceName;
/*     */   private final List<Object> _parameters;
/*     */   private final Level _logAtLevel;
/*     */   
/*     */   public static CallableStatement adaptCallableStatement(CallableStatement argStatement, String argSql, String argDatasourceName) {
/*  48 */     return new WrapperCallableStatement<>(argStatement, argSql, argDatasourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PreparedStatement adaptPreparedStatement(PreparedStatement argStatement, String argSql, String argDatasourceName) {
/*  61 */     return new WrapperPreparedStatement<>(argStatement, argSql, argDatasourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Statement adaptStatement(Statement argStatement, String argSql, String argDatasourceName) {
/*  72 */     return new WrapperStatement<>(argStatement, argSql, argDatasourceName);
/*     */   }
/*     */   
/*     */   private static Logger getLogger(String argSql) {
/*     */     try {
/*  77 */       switch (argSql.charAt(0)) {
/*     */         case 'I':
/*     */         case 'i':
/*  80 */           return INSERT_LOG;
/*     */         case 'U':
/*     */         case 'u':
/*  83 */           return UPDATE_LOG;
/*     */         case 'D':
/*     */         case 'd':
/*  86 */           return DELETE_LOG;
/*     */         case 'S':
/*     */         case 's':
/*  89 */           return SELECT_LOG;
/*     */       } 
/*     */     
/*  92 */     } catch (Exception ex) {
/*  93 */       DEFAULT_LOG.error("CAUGHT EXCEPTION", ex);
/*     */     } 
/*  95 */     return DEFAULT_LOG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private String _sql = "";
/* 105 */   private long _startTimeNanos = 0L;
/*     */   
/*     */   protected DtvPreparedStatement(E argStatement, String argSql, String argDatasourceName) {
/* 108 */     if (StringUtils.isEmpty(argSql)) {
/* 109 */       throw new IllegalArgumentException("SQL is required");
/*     */     }
/* 111 */     this._logger = getLogger(argSql);
/* 112 */     this._statement = argStatement;
/* 113 */     this._datasourceName = argDatasourceName;
/* 114 */     this._sql = argSql;
/* 115 */     this._logAtLevel = logAtLevel();
/* 116 */     this._parameters = Level.OFF.equals(this._logAtLevel) ? null : new ArrayList(6);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     ToStringBuilder tsb = new ToStringBuilder(this);
/* 122 */     tsb.append("sql", "\"" + getPrettySql() + "\"");
/* 123 */     return tsb.build();
/*     */   }
/*     */   
/*     */   protected void _clearParameters() {
/* 127 */     if (this._parameters != null) {
/* 128 */       this._parameters.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(boolean argBoolean) {
/* 133 */     if (this._parameters != null) {
/* 134 */       this._parameters.add(Boolean.valueOf(argBoolean));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(byte argByte) {
/* 139 */     if (this._parameters != null) {
/* 140 */       this._parameters.add(Byte.valueOf(argByte));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(char argChar) {
/* 145 */     if (this._parameters != null) {
/* 146 */       this._parameters.add(Character.valueOf(argChar));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(double argDouble) {
/* 151 */     if (this._parameters != null) {
/* 152 */       this._parameters.add(Double.valueOf(argDouble));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(float argFloat) {
/* 157 */     if (this._parameters != null) {
/* 158 */       this._parameters.add(Float.valueOf(argFloat));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(int argInt) {
/* 163 */     if (this._parameters != null) {
/* 164 */       this._parameters.add(Integer.valueOf(argInt));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(long argLong) {
/* 169 */     if (this._parameters != null) {
/* 170 */       this._parameters.add(Long.valueOf(argLong));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(Object argObj) {
/* 175 */     if (this._parameters != null) {
/* 176 */       this._parameters.add(argObj);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addParameter(short argShort) {
/* 181 */     if (this._parameters != null) {
/* 182 */       this._parameters.add(Short.valueOf(argShort));
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getPrettySql() {
/* 187 */     return PreparedStatementTranslator.getPrettySql(this._sql, this._parameters);
/*     */   }
/*     */   protected void log(String argDescription) {
/*     */     Throwable throwable;
/* 191 */     if (Level.OFF.equals(this._logAtLevel)) {
/*     */       return;
/*     */     }
/*     */     
/* 195 */     if (Level.DEBUG.equals(this._logAtLevel) && !Boolean.getBoolean("dtv.data2.access.impl.jdbc.DtvPreparedStatement.StackTrace")) {
/* 196 */       throwable = null;
/*     */     } else {
/*     */       
/* 199 */       throwable = new Throwable("STACK TRACE");
/*     */     } 
/*     */     
/* 202 */     double msElapsed = (System.nanoTime() - this._startTimeNanos) / 1000000.0D;
/* 203 */     String msg = String.format("%1$s [%2$7.3f ms %3$s] %4$s", new Object[] { argDescription, Double.valueOf(msElapsed), this._datasourceName, 
/* 204 */           PreparedStatementTranslator.getPrettySql(this._sql, this._parameters) });
/*     */     
/* 206 */     this._logger.log((Priority)this._logAtLevel, msg, throwable);
/*     */   }
/*     */   
/*     */   protected void startExecute(String... args) {
/* 210 */     if (args.length > 0) {
/* 211 */       this._sql = args[0];
/*     */     }
/* 213 */     if (this._logger.isDebugEnabled()) {
/* 214 */       this._startTimeNanos = System.nanoTime();
/*     */     }
/*     */   }
/*     */   
/*     */   private Level logAtLevel() {
/* 219 */     if (REPORT_ILLEGAL_ACCESS && 
/* 220 */       SwingUtilities.isEventDispatchThread() && 
/* 221 */       !DtvSecurityManager.getInstance().isAllowed("DbAccessFromUiThread")) {
/* 222 */       return Level.WARN;
/*     */     }
/* 224 */     if (this._logger.isDebugEnabled()) {
/* 225 */       return Level.DEBUG;
/*     */     }
/* 227 */     return Level.OFF;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\DtvPreparedStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */