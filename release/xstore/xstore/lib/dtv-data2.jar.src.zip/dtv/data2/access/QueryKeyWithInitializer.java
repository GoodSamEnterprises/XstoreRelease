/*    */ package dtv.data2.access;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryKeyWithInitializer<T extends IQueryResult>
/*    */   implements IQueryKey<T>
/*    */ {
/*    */   private final String name_;
/*    */   private final Class<T> resultClass_;
/*    */   private final Class<? extends IQueryResultInitializer<T>> initializerClass_;
/*    */   
/*    */   private static <T> Class<T> nonNull(Class<T> c) {
/* 18 */     return (c == null) ? (Class)Object.class : c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QueryKeyWithInitializer(String argName, Class<T> argResultClass, Class<? extends IQueryResultInitializer<T>> argInitializerClass) {
/* 36 */     this.name_ = argName.trim();
/* 37 */     this.resultClass_ = nonNull(argResultClass);
/* 38 */     this.initializerClass_ = argInitializerClass;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object argOther) {
/* 44 */     if (!(argOther instanceof IQueryKey)) {
/* 45 */       return false;
/*    */     }
/* 47 */     return this.name_.equals(((IQueryKey)argOther).getName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<? extends IQueryResultInitializer<T>> getInitializerClass() {
/* 58 */     return this.initializerClass_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 68 */     return this.name_;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<T> getResultClass() {
/* 78 */     return this.resultClass_;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 84 */     return this.name_.hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return this.name_;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\QueryKeyWithInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */