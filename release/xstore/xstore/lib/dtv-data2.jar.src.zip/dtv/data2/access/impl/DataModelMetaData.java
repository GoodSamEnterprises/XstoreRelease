/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.data2.access.IDataModelMetaData;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataModelMetaData
/*    */   implements IDataModelMetaData
/*    */ {
/*    */   private final IDataModelImpl _dataModel;
/* 20 */   private final Set<IDataModelImpl> _relatedDataModels = new HashSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataModelMetaData(IDataModelImpl argDataModel) {
/* 28 */     this._dataModel = argDataModel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRelatedDataModels(Collection<?> argRelatedDataModels) {
/* 34 */     if (argRelatedDataModels == null) {
/*    */       return;
/*    */     }
/*    */     
/* 38 */     for (Object element : argRelatedDataModels) {
/* 39 */       if (element instanceof IDataModelImpl) {
/* 40 */         this._relatedDataModels.add((IDataModelImpl)element);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IDataModelImpl getDataModel() {
/* 48 */     return this._dataModel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<IDataModelImpl> getRelatedDataModels() {
/* 54 */     return new ArrayList<>(this._relatedDataModels);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\DataModelMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */