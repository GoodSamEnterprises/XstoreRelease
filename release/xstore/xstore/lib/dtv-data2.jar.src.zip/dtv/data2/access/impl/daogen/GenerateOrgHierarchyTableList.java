/*     */ package dtv.data2.access.impl.daogen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateOrgHierarchyTableList
/*     */   implements Callable<Void>
/*     */ {
/*  21 */   private static final Logger logger_ = Logger.getLogger(GenerateOrgHierarchyTableList.class);
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_CLASS_NAME = "OrgHierarchyTableList";
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_FILE_NAME = "OrgHierarchyTableList.java";
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_DIRECTORY = "/dtv/xst/dao/";
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_PACKAGE = "dtv.xst.dao";
/*     */ 
/*     */   
/*     */   protected DaoGenHelper helper_;
/*     */ 
/*     */   
/*     */   public static GenerateOrgHierarchyTableList createInstance(DaoGenHelper argHelper) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
/*  40 */     String className = System.getProperty(GenerateOrgHierarchyTableList.class.getName(), GenerateOrgHierarchyTableList.class
/*  41 */         .getName());
/*     */     
/*  43 */     GenerateOrgHierarchyTableList instance = (GenerateOrgHierarchyTableList)Class.forName(className).newInstance();
/*  44 */     instance.setHelper(argHelper);
/*  45 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Void call() throws IOException {
/*  65 */     logger_.info("Generating Org Hierarchy Table List");
/*     */     
/*  67 */     Writer stringWriter = new StringWriter(10240);
/*     */     
/*  69 */     writePackageDeclaration(stringWriter);
/*  70 */     writeImportDeclaration(stringWriter);
/*     */     
/*  72 */     writeClassDeclaration(stringWriter);
/*  73 */     stringWriter.append("\n");
/*     */     
/*  75 */     writeVariableDeclaration(stringWriter);
/*  76 */     writeStaticDeclaration(stringWriter);
/*     */     
/*  78 */     writeAdditionalMethods(stringWriter);
/*     */     
/*  80 */     stringWriter.append("}\n\n");
/*     */     
/*  82 */     File f = new File(this.helper_.getOutPath() + "/dtv/xst/dao/" + getFileName());
/*     */     
/*  84 */     this.helper_.getWriter().write(f, stringWriter.toString());
/*     */     
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFileName() {
/*  95 */     return "OrgHierarchyTableList.java";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setHelper(DaoGenHelper argHelper) {
/* 104 */     this.helper_ = argHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeAdditionalMethods(Writer argW) throws IOException {
/* 115 */     writeAddTableMethod(argW);
/* 116 */     writeGetOrgHierarchyTablesMethod(argW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeClassDeclaration(Writer argW) throws IOException {
/* 127 */     argW.append(this.helper_.getClassCommentWithSuppressWarnings("An auto-generated list of tables whose rows are qualified by a node in the organizational hierarchy."));
/*     */     
/* 129 */     argW.append("public class ");
/* 130 */     argW.append("OrgHierarchyTableList");
/* 131 */     argW.append(" implements IHasOrgHierarchyTables {\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeImportDeclaration(Writer argW) throws IOException {
/* 142 */     argW.append("import java.util.ArrayList;\nimport java.util.List;\nimport dtv.data2.access.impl.daogen.IHasOrgHierarchyTables;\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writePackageDeclaration(Writer argW) throws IOException {
/* 155 */     if (argW == null) {
/*     */       return;
/*     */     }
/* 158 */     argW.append("package ");
/* 159 */     argW.append("dtv.xst.dao");
/* 160 */     argW.append(";\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeStaticDeclaration(Writer argW) throws IOException {
/* 171 */     Collection<String> orgTables = DaoGenOrgHierarchyHelper.getOrgHierarchyTables();
/* 172 */     if (orgTables == null || orgTables.isEmpty()) {
/*     */       return;
/*     */     }
/* 175 */     argW.append("  {\n");
/*     */     
/* 177 */     argW.append("    // populate org hierarchy table list\n");
/* 178 */     for (String table : orgTables) {
/* 179 */       argW.append("    addTable(\"" + table + "\");\n");
/*     */     }
/* 181 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeVariableDeclaration(Writer argW) throws IOException {
/* 193 */     argW.append("  private final List<String> _entries = new ArrayList<>();\n\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendOverrides(Writer argW) throws IOException {
/* 199 */     argW.append("  @Override\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAddTableMethod(Writer argW) throws IOException {
/* 204 */     argW.append("  protected void addTable(String argTable) {\n");
/* 205 */     argW.append("    _entries.add(argTable);\n");
/* 206 */     argW.append("  }\n\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetOrgHierarchyTablesMethod(Writer argW) throws IOException {
/* 211 */     appendOverrides(argW);
/* 212 */     argW.append("  public List<String> getOrgHierarchyTables() {\n");
/* 213 */     argW.append("    return _entries;\n");
/* 214 */     argW.append("  }\n\n");
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\daogen\GenerateOrgHierarchyTableList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */