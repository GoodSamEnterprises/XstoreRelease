/*     */ package dtv.data2.access.pm;
/*     */ 
/*     */ import dtv.data2.access.IPersistenceMgrType;
/*     */ import dtv.data2.access.exception.DtxException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceManagerType
/*     */   implements Comparable<IPersistenceMgrType>, Serializable, IPersistenceMgrType
/*     */ {
/*     */   public static final String PM_TYPE_PROPERTY = "dtv.data.access.PersistenceManagerType";
/*  26 */   private static final Logger logger_ = Logger.getLogger(PersistenceManagerType.class);
/*     */   
/*     */   private static final long serialVersionUID = -6279059104161422598L;
/*     */   private static Map<String, PersistenceManagerType> values_;
/*  30 */   private static PersistenceManagerType[] sortedInstances_ = null;
/*     */   
/*     */   static {
/*     */     try {
/*  34 */       String className = System.getProperty("dtv.data.access.PersistenceManagerType", PersistenceManagerType.class.getName());
/*  35 */       if (className == null) {
/*  36 */         logger_
/*  37 */           .error("No PersistenceManagerType implementation defined with property dtv.data.access.PersistenceManagerType");
/*     */       }
/*  39 */       PersistenceManagerType.class.getClassLoader().loadClass(className);
/*     */     }
/*  41 */     catch (Exception ex) {
/*  42 */       logger_.error("Unable to load persistence manager base type ", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name_;
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceManagerType forName(String argName) {
/*  53 */     if (argName == null) {
/*  54 */       throw new DtxException("PersistenceManagerType.forName(String) cannot accept null argName.  Please provide a PM type name. (e.g. \"TRANSACTION\", \"INVENTORY\", etc.");
/*     */     }
/*     */ 
/*     */     
/*  58 */     String name = argName.trim();
/*     */     
/*  60 */     if (values_ == null) {
/*  61 */       values_ = new HashMap<>();
/*     */     }
/*  63 */     PersistenceManagerType found = values_.get(name);
/*     */     
/*  65 */     if (found == null) {
/*  66 */       found = new PersistenceManagerType(name);
/*     */     }
/*  68 */     return found;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceManagerType[] getInstances() {
/*  77 */     if (sortedInstances_ == null) {
/*  78 */       PersistenceManagerType[] instances = new PersistenceManagerType[values_.size()];
/*  79 */       instances = (PersistenceManagerType[])values_.values().toArray((Object[])instances);
/*  80 */       Arrays.sort((Object[])instances);
/*  81 */       sortedInstances_ = instances;
/*     */     } 
/*  83 */     return sortedInstances_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PersistenceManagerType(String argName) {
/*  95 */     this.name_ = argName.trim();
/*  96 */     if (values_ == null) {
/*  97 */       values_ = new HashMap<>();
/*     */     }
/*  99 */     values_.put(this.name_, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(IPersistenceMgrType other) {
/* 105 */     return getName().compareTo(other.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 111 */     if (!(other instanceof PersistenceManagerType)) {
/* 112 */       return false;
/*     */     }
/* 114 */     return this.name_.equals(((PersistenceManagerType)other).getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 124 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 130 */     return this.name_.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return this.name_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object readResolve() {
/* 145 */     return forName(this.name_);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\pm\PersistenceManagerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */