/*    */ package dtv.data2.access.query;
/*    */ 
/*    */ import dtv.data2.access.impl.PersistenceConstants;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CaseHintProcessingSqlDecorator
/*    */   extends HintProcessingSqlDecorator
/*    */ {
/*    */   public CaseHintProcessingSqlDecorator(Map<String, String> argPatterns) {
/* 26 */     super(argPatterns);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CaseHintProcessingSqlDecorator(Map<String, String> argPatterns, String argHintBegin, String argHintEnd) {
/* 38 */     super(argPatterns, argHintBegin, argHintEnd);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String replaceHints(String argInput) {
/* 44 */     if (PersistenceConstants.MANAGE_CASE) {
/* 45 */       return super.replaceHints(argInput);
/*    */     }
/*    */     
/* 48 */     return argInput;
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\CaseHintProcessingSqlDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */