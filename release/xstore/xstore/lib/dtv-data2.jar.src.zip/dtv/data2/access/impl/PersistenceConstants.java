/*    */ package dtv.data2.access.impl;
/*    */ 
/*    */ import dtv.util.config.IPropertyConfigurationSource;
/*    */ import dtv.util.config.SystemPropertyConfigurationSource;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistenceConstants
/*    */ {
/*    */   public static final boolean MANAGE_CASE;
/*    */   
/*    */   static {
/* 22 */     IPropertyConfigurationSource propertySource = SystemPropertyConfigurationSource.getInstance();
/* 23 */     Properties properties = propertySource.getProperties();
/* 24 */     String caseProp = properties.getProperty(PersistenceConstants.class.getName() + ".manageCase", "true");
/* 25 */     MANAGE_CASE = Boolean.parseBoolean(caseProp);
/*    */   }
/*    */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\PersistenceConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */