/*     */ package dtv.data2.access.query;
/*     */ 
/*     */ import dtv.data2.IPersistenceDefaults;
/*     */ import dtv.data2.access.impl.daogen.OrgHierarchyTables;
/*     */ import dtv.util.CompositeObject;
/*     */ import dtv.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.inject.Inject;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrgHierarchySqlDecorator
/*     */   extends AbstractTargetedDataSqlDecorator
/*     */ {
/*     */   private static final String COL_ORG_CODE = "org_code";
/*     */   private static final String COL_ORG_VALUE = "org_value";
/*     */   private static final String NODE_FIELD_DELIM = "::";
/*     */   static final String NODE_FIELD_DELIM_EXT = ":";
/*     */   @Inject
/*     */   private IPersistenceDefaults _persistenceDefaults;
/*     */   
/*     */   protected final String getOrgHierarchyInArgs(List<CompositeObject.TwoPiece<String, String>> argOrgNodes) {
/*  50 */     String orgHierarchyInArgs = null;
/*     */     
/*  52 */     if (!argOrgNodes.isEmpty()) {
/*  53 */       List<String> orgHierPairs = new ArrayList<>(argOrgNodes.size());
/*     */       
/*  55 */       for (CompositeObject.TwoPiece<String, String> elem : argOrgNodes) {
/*  56 */         orgHierPairs.add((String)elem.a() + "::" + (String)elem.b());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  62 */       orgHierarchyInArgs = SqlQueryBuilder.toSqlInClauseArgs(orgHierPairs);
/*     */     } 
/*  64 */     return orgHierarchyInArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getReplacementSql(String argTableName, Map<String, Object> argQueryParams) {
/*  70 */     List<CompositeObject.TwoPiece<String, String>> requestNodes = getRequestOrgNodes(argQueryParams);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     List<CompositeObject.TwoPiece<String, String>> orgNodes = CollectionUtils.isNotEmpty(requestNodes) ? requestNodes : this._persistenceDefaults.getOrgHierarchyAncestry();
/*     */     
/*  80 */     String orgHierInArgs = getOrgHierarchyInArgs(orgNodes);
/*     */     
/*  82 */     if (StringUtils.isEmpty(orgHierInArgs)) {
/*  83 */       return argTableName;
/*     */     }
/*     */     
/*  86 */     StringBuilder newSql = new StringBuilder();
/*  87 */     newSql.append("(SELECT * FROM ").append(argTableName).append(" WHERE (org_code||'::'||org_value) IN (");
/*     */ 
/*     */     
/*  90 */     newSql.append(orgHierInArgs);
/*  91 */     newSql.append("))");
/*     */     
/*  93 */     return newSql.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<CompositeObject.TwoPiece<String, String>> getRequestOrgNodes(Map<String, Object> argParams) {
/* 105 */     if (argParams == null || argParams.isEmpty()) {
/* 106 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 109 */     String orgCode = null;
/* 110 */     String orgValue = null;
/* 111 */     List<CompositeObject.TwoPiece<String, String>> orgNodes = Collections.emptyList();
/*     */     
/* 113 */     for (String key : argParams.keySet()) {
/* 114 */       if (key.toLowerCase().contains("orgcode")) {
/* 115 */         orgCode = (String)argParams.get(key); continue;
/*     */       } 
/* 117 */       if (key.toLowerCase().contains("orgvalue")) {
/* 118 */         orgValue = (String)argParams.get(key); continue;
/*     */       } 
/* 120 */       if (key.toLowerCase().contains("orgnodes")) {
/* 121 */         orgNodes = (List<CompositeObject.TwoPiece<String, String>>)argParams.get(key); continue;
/*     */       } 
/* 123 */       if (key.toLowerCase().contains("orgnodelist")) {
/*     */ 
/*     */ 
/*     */         
/* 127 */         List<String> orgNodeList = (List<String>)argParams.get(key);
/* 128 */         if (!CollectionUtils.isEmpty(orgNodeList)) {
/* 129 */           orgNodes = new ArrayList<>(orgNodeList.size());
/*     */           
/* 131 */           for (String orgNodePair : orgNodeList) {
/* 132 */             String[] orgNodeSplit = orgNodePair.split(":");
/* 133 */             if (orgNodeSplit != null && orgNodeSplit.length == 2) {
/* 134 */               orgNodes.add(CompositeObject.make(orgNodeSplit[0], orgNodeSplit[1]));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 143 */     return (!StringUtils.isEmpty(orgCode) && !StringUtils.isEmpty(orgValue) && CollectionUtils.isEmpty(orgNodes)) ? 
/* 144 */       Collections.<CompositeObject.TwoPiece<String, String>>singletonList(CompositeObject.make(orgCode, orgValue)) : orgNodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<String> getTablesToDecorate() {
/* 151 */     return OrgHierarchyTables.getOrgHierarchyTables();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDecoratable(String argSqlStatement, Map<String, Object> argQueryParams) {
/* 161 */     boolean superIsDecoratable = super.isDecoratable(argSqlStatement, argQueryParams);
/*     */     
/* 163 */     boolean ignorePresent = (argQueryParams != null && argQueryParams.containsKey("IGNORE_ORG_HIERARCHY_FILTERING"));
/*     */     
/* 165 */     return (superIsDecoratable && !ignorePresent);
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\query\OrgHierarchySqlDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */