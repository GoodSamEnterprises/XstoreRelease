/*     */ package dtv.data2.access.impl.jdbc;
/*     */ 
/*     */ import dtv.data2.access.datasource.DataSourceDescriptor;
/*     */ import dtv.util.StringUtils;
/*     */ import dtv.util.config.ConfigUtils;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCConnectionTemplate
/*     */ {
/*  25 */   private static final Logger _logger = Logger.getLogger(JDBCConnectionTemplate.class);
/*     */   
/*     */   private static final int MIN_PREPARED_STATEMENT_CACHE_SIZE = 1;
/*     */   
/*     */   private static final int DEFAULT_15_MINUTES = 900;
/*     */   
/*     */   private static final String ORACLE_DATA_SOURCE = "oracle.jdbc.pool.OracleDataSource";
/*     */   
/*     */   @Deprecated
/*     */   public static final String PROP_DRIVER = "ConnectionDriverName";
/*     */   
/*     */   public static final String PROP_CONNECTION_FACTORY_CLASS = "ConnectionFactoryClassName";
/*     */   
/*     */   public static final String PROP_URL = "ConnectionURL";
/*     */   
/*     */   public static final String PROP_USER = "ConnectionUserName";
/*     */   
/*     */   public static final String PROP_PASSWORD = "ConnectionPassword";
/*     */   
/*     */   private static final String PROP_TRANS_ISOLATION = "TransactionIsolation";
/*     */   
/*     */   private static final String PROP_USE_PREPARED_STATEMENT_CACHE = "UsePreparedStatementCache";
/*     */   
/*     */   private static final String PROP_PREPARED_STATEMENT_MAX_SIZE = "PreparedStatementCacheMaxSize";
/*     */   
/*     */   private static final String CONNECTION_POOL_MIN_SIZE = "ConnectionPoolMinSize";
/*     */   
/*     */   private static final String CONNECTION_POOL_MAX_SIZE = "ConnectionPoolMaxSize";
/*     */   
/*     */   private static final String CONNECTION_POOL_MAX_IDLE_TIME = "MaxConnectionIdleTime";
/*     */   
/*     */   private static final String CONNECTION_POOL_MAX_REUSE = "MaxConnectionReuseCount";
/*     */   
/*     */   private static final String SQL_FOR_VALIDATE_CONNECTION = "SQLForValidateConnection";
/*     */   
/*     */   private static final String VALIDATE_CONNECTION_ON_BORROW = "ValidateConnectionOnBorrow";
/*     */   
/*     */   private static final String CONNECTION_WAIT_TIMEOUT = "ConnectionWaitTimeout";
/*     */   
/*     */   public static final String CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_LEVEL = "oracle.net.encryption_client";
/*     */   
/*     */   public static final String CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_TYPES = "oracle.net.encryption_types_client";
/*     */   
/*     */   public static final String CONNECTION_PROPERTY_THIN_NET_CHECKSUM_LEVEL = "oracle.net.crypto_checksum_client";
/*     */   
/*     */   public static final String CONNECTION_PROPERTY_THIN_NET_CHECKSUM_TYPES = "oracle.net.crypto_checksum_types_client";
/*     */   
/*     */   public static final String DEFAULT_THIN_NET_ENCRYPTION_LEVEL = "REQUESTED";
/*     */   
/*     */   public static final String DEFAULT_THIN_NET_CHECKSUM_LEVEL = "REQUESTED";
/*     */   
/*     */   public static final String DEFAULT_THIN_NET_ENCRYPTION_TYPES = "(AES256)";
/*     */   
/*     */   public static final String DEFAULT_THIN_NET_CHECKSUM_TYPES = "(SHA1)";
/*     */   
/*     */   public static final String DEFAULT_THIN_NET_LOCALHOST_ENCRYPTION_LEVEL = "ACCEPTED";
/*     */   
/*     */   public static final String DEFAULT_THIN_NET_LOCALHOST_CHECKSUM_LEVEL = "ACCEPTED";
/*     */   
/*     */   private final String _dataSourceName;
/*     */   
/*     */   private final String _connectionFactoryClassName;
/*     */   
/*     */   private final boolean _isOracle;
/*     */   
/*     */   private final boolean _isMSSQL;
/*     */   
/*     */   private final String _url;
/*     */   
/*     */   private final String _user;
/*     */   
/*     */   private final String _password;
/*     */   
/*     */   private final String _transactionIsolation;
/*     */   
/*     */   private final int _queryTimeout;
/*     */   private final int _preparedStatementCacheMaxSize;
/*     */   private final int _connectionPoolMinSize;
/*     */   private final int _connectionPoolMaxSize;
/*     */   private final int _connectionMaxIdleTime;
/*     */   private final int _connectionWaitTimeout;
/*     */   private final int _maxConnectionReuseCount;
/*     */   private final String _sqlForValidateConnection;
/*     */   private final boolean _validateConnectionOnBorrow;
/*     */   private final String _ojdbcThinClientEncryptionLevel;
/*     */   private final String _ojdbcThinClientEncryptionTypes;
/*     */   private final String _ojdbcThinClientChecksumLevel;
/*     */   private final String _ojdbcThinClientChecksumTypes;
/*     */   
/*     */   private static String readConnectionFactoryClassName(Properties dsdProps) {
/* 115 */     String clz = dsdProps.getProperty("ConnectionFactoryClassName");
/* 116 */     if (!StringUtils.isEmpty(clz)) {
/* 117 */       return translateDriverClass(clz, clz);
/*     */     }
/* 119 */     return translateDriverClass(dsdProps.getProperty("ConnectionDriverName"), "oracle.jdbc.pool.OracleDataSource");
/*     */   }
/*     */   
/*     */   private static int readPreparedStatementCacheMaxSize(Properties dsdProps) {
/* 123 */     if (ConfigUtils.asBool(dsdProps.getProperty("UsePreparedStatementCache", Boolean.TRUE.toString()))) {
/* 124 */       int value = ConfigUtils.asInt(dsdProps.getProperty("PreparedStatementCacheMaxSize", "64"));
/* 125 */       if (value > 1) {
/* 126 */         return value;
/*     */       }
/*     */     } 
/* 129 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean readValidateConnectionOnBorrow(Properties dsdProps, boolean argIsOracle, String argSqlForValidateConnection) {
/* 135 */     Boolean defaultSetting = Boolean.valueOf((argIsOracle || !StringUtils.isEmpty(argSqlForValidateConnection)));
/* 136 */     return ConfigUtils.asBool(dsdProps.getProperty("ValidateConnectionOnBorrow", defaultSetting.toString()));
/*     */   }
/*     */   
/*     */   private static String translateDriverClass(String argDriver, String argDefault) {
/* 140 */     if ("com.microsoft.sqlserver.jdbc.SQLServerDriver".equals(argDriver)) {
/* 141 */       return "com.microsoft.sqlserver.jdbc.SQLServerDataSource";
/*     */     }
/* 143 */     if ("org.h2.Driver".equals(argDriver)) {
/* 144 */       return "org.h2.jdbcx.JdbcDataSource";
/*     */     }
/* 146 */     if ("oracle.jdbc.driver.OracleDriver".equals(argDriver)) {
/* 147 */       return "oracle.jdbc.pool.OracleDataSource";
/*     */     }
/* 149 */     return argDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JDBCConnectionTemplate(DataSourceDescriptor argDescriptor) {
/* 182 */     this._dataSourceName = argDescriptor.getName();
/* 183 */     Properties dsdProps = argDescriptor.getProperties();
/*     */     
/* 185 */     this._connectionFactoryClassName = readConnectionFactoryClassName(dsdProps);
/* 186 */     this._isOracle = this._connectionFactoryClassName.startsWith("oracle.");
/* 187 */     this._isMSSQL = this._connectionFactoryClassName.startsWith("com.microsoft.sqlserver");
/* 188 */     this._url = dsdProps.getProperty("ConnectionURL");
/* 189 */     this._user = dsdProps.getProperty("ConnectionUserName");
/* 190 */     this._password = dsdProps.getProperty("ConnectionPassword");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (StringUtils.isEmpty(this._dataSourceName)) {
/* 197 */       throw new DBConnectionException("An attempt was made to register a datasource that does not have a name.  Each datasource must have a 'name' attribute associated with it.");
/*     */     }
/*     */ 
/*     */     
/* 201 */     if (StringUtils.isEmpty(this._connectionFactoryClassName)) {
/* 202 */       throw new DBConnectionException("Datasource: '" + this._dataSourceName + "' does not define a driver.  Property: '" + "ConnectionFactoryClassName" + "' is required. Make sure this entry is set up properly for JDBC");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 207 */     if (StringUtils.isEmpty(this._url)) {
/* 208 */       throw new DBConnectionException("Datasource: '" + this._dataSourceName + "' does not define a jdbc url.  Property: '" + "ConnectionURL" + "' is required. Make sure this entry is set up properly for JDBC");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this._preparedStatementCacheMaxSize = readPreparedStatementCacheMaxSize(dsdProps);
/* 217 */     this._connectionPoolMinSize = ConfigUtils.asInt(dsdProps.getProperty("ConnectionPoolMinSize"), 2);
/* 218 */     this._connectionPoolMaxSize = ConfigUtils.asInt(dsdProps.getProperty("ConnectionPoolMaxSize"), 8);
/* 219 */     this._connectionMaxIdleTime = ConfigUtils.asInt(dsdProps.getProperty("MaxConnectionIdleTime"), 900);
/* 220 */     this._connectionWaitTimeout = ConfigUtils.asInt(dsdProps.getProperty("ConnectionWaitTimeout"), 30);
/* 221 */     this._maxConnectionReuseCount = ConfigUtils.asInt(dsdProps.getProperty("MaxConnectionReuseCount"), 10);
/* 222 */     this
/* 223 */       ._sqlForValidateConnection = dsdProps.getProperty("SQLForValidateConnection", isForOracle() ? null : "SELECT 1;");
/* 224 */     this
/* 225 */       ._validateConnectionOnBorrow = readValidateConnectionOnBorrow(dsdProps, isForOracle(), this._sqlForValidateConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     this._transactionIsolation = dsdProps.getProperty("TransactionIsolation");
/*     */     
/* 232 */     this._queryTimeout = ConfigUtils.asInt(dsdProps.getProperty("QueryTimeout"), 300);
/*     */ 
/*     */     
/* 235 */     this._ojdbcThinClientEncryptionLevel = dsdProps.getProperty("OjdbcThinClientEncryptionLevel", null);
/* 236 */     this
/* 237 */       ._ojdbcThinClientEncryptionTypes = dsdProps.getProperty("OjdbcThinClientEncryptionTypes", "(AES256)");
/* 238 */     this._ojdbcThinClientChecksumLevel = dsdProps.getProperty("OjdbcThinClientChecksumLevel", null);
/* 239 */     this
/* 240 */       ._ojdbcThinClientChecksumTypes = dsdProps.getProperty("OjdbcThinClientChecksumTypes", "(SHA1)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionFactoryClassName() {
/* 249 */     return this._connectionFactoryClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectionMaxIdleTime() {
/* 258 */     return this._connectionMaxIdleTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectionPoolMaxSize() {
/* 267 */     return this._connectionPoolMaxSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectionPoolMinSize() {
/* 276 */     return this._connectionPoolMinSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectionWaitTimeout() {
/* 285 */     return this._connectionWaitTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 294 */     return this._dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxConnectionReuseCount() {
/* 303 */     return this._maxConnectionReuseCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOjdbcThinClientChecksumLevel() {
/* 311 */     return this._ojdbcThinClientChecksumLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOjdbcThinClientChecksumTypes() {
/* 319 */     return this._ojdbcThinClientChecksumTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOjdbcThinClientEncryptionLevel() {
/* 327 */     return this._ojdbcThinClientEncryptionLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOjdbcThinClientEncryptionTypes() {
/* 335 */     return this._ojdbcThinClientEncryptionTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 344 */     return this._password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPreparedStatementCacheMaxSize() {
/* 353 */     return this._preparedStatementCacheMaxSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getQueryTimeout() {
/* 362 */     return this._queryTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSqlForValidateConnection() {
/* 371 */     return this._sqlForValidateConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTransactionIsolation() {
/* 380 */     String transactionIsolation = this._transactionIsolation;
/* 381 */     if (transactionIsolation != null) {
/* 382 */       switch (transactionIsolation.toUpperCase()) {
/*     */         case "NONE":
/* 384 */           return 0;
/*     */         case "READ_COMMITTED":
/*     */         case "READ COMMITTED":
/* 387 */           return 2;
/*     */         case "REPEATABLE_READ":
/*     */         case "REPEATABLE READ":
/* 390 */           return 4;
/*     */         case "READ_UNCOMMITTED":
/*     */         case "READ UNCOMMITTED":
/* 393 */           return 1;
/*     */         case "SERIALIZABLE":
/* 395 */           return 8;
/*     */       } 
/* 397 */       _logger.warn("unexpected transaction isolation value [" + transactionIsolation + "]");
/*     */     } 
/*     */     
/* 400 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/* 409 */     return this._url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUser() {
/* 418 */     return this._user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getValidateConnectionOnBorrow() {
/* 427 */     return this._validateConnectionOnBorrow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isForMSSQL() {
/* 435 */     return this._isMSSQL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isForOracle() {
/* 443 */     return this._isOracle;
/*     */   }
/*     */ }


/* Location:              C:\WIP-Xstore_Delta-main\release\xstore\xstore\lib\dtv-data2.jar!\dtv\data2\access\impl\jdbc\JDBCConnectionTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */