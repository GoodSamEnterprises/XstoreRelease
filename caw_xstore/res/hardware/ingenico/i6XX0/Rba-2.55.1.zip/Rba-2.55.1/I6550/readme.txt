This is the release directory for the Retail Base Application. 
Ver label:   SA00616-2.5.5.1 
Device Name: i6xxx, i3070 and i9010 
OS:          3.6.4 
SSA:         2.8.0 
Release:     H:\SOFTWARE\SA\U32\SA00616-2.5.5.1 
Production:  I:\SOFTWARE\SA00616-2.5.5.1 
Banner:      Retail Base 
Eng:         avarma 


Notes:
	     2.5.5  INGECRYPT MSR encryption is not functional with this or prior releases.
		    It is recommended that this feature not be enabled.
		    Pen status in HealthStat is not functional with this or prior releases.
		    Added support for "21.", "23.", "24." and "27." messages 
		    when a form loaded with or without ".icg" extension.
		    "08." message now returns additional information: application ID, manufacture ID
		    and digitizer version.  With the addition of these data, the "08." message now
		    returns all of the data that is returned by the "07." and "22." messages.  The
		    addtional data is appended to the original "08." message response.
             2.5.4  Fixed the groupid issue on radio buttons. Now Radio buttons can be selected from 
	            different groups.
		    Added enhancement to allow on-demand messages to automatically
                    cancel any running on-demand message without the need to send
                    a 15.6 message.  This is controlled by a new parameter in
                    mainFlow.dat, '0007_0028', and is off by default.
                    Added a parameter, '0003_0013', to msr.dat to control the
                    extended encryption option for INGECRYPT.  Extended
                    encryption is only available when the encryption method
                    INGECRYPT is selected and is off by default.
                    Added enhancement to get version and initialization status of
                    an attached CPEM.  This information is available through the
                    get variable message (29.).  The version is variable ID 820
                    and is the version string returned by the CPEM device during
                    initialization.  The initialization status is variable ID 821
                    and is "0" if the device could not be initialized or is not
                    present or if parameter '0008_0001' in cpem.dat is set to "0"
                    and "1" if the device was initialized.
                    Non-ISO card track data handled better.  Non-ISO cards may be
                    rejected if they don't follow the ISO standard close enough.
                    But RBA will not crash.
                    Added encryption to on-demand card swipe and CPEM.
                    Added support for INGECRYPT batch encryption.
                    Batch encryption is controlled by a new parameter in msr.dat,
                    '0003_0014', and is off by default.  The new variable has
                    no effect unless INGECRYPT encryption is enabled.
                    New variables to get track1 batch PAN (492), track1 batch KSN
                    (493), track2 batch PAN(494) and track2 batch KSN (495).
	     2.5.3  Added pen status in HealthStat using new HealthStat library and SSA.
	     2.5.2  Fixed the bug for Orpak only which will display the third error swipe on
                    the new swipe2.icg. Another fix for Orpak was that after error swipe, 
                    no 19. message was sent.
             2.5.1  Fixed two bugs related with TC displays.
                    Added a new form for Orpak and a new animated gif for card insertion.
                    Added end to end encryption using the INGECRYPT algorithm.  This is currently disabled by default.
                      Encryption key for MagTek and INGECRYPT encryption set in msr.dat (0003_0006).
                      Encryption type set in msr.dat (0003_0012).
                      Adjusted meaning of variable 0005_0008 in stb.dat to also apply to the new INGECRYPT encryption.
                      Added variables 490 (Track 1) and 491 (Track 2) for retrieval of INGECRYPT DKPUT KSNs.

             2.5.0  Improved scrolling receipt review.
                    Added configuration settings for minimum (0006_0011) and
                      maximum (0006_0012) number of digit allowed for PIN
                      entry.
                    Added variables 480 - 489 to return DKPUT KSNs.
		    Added HealthStat support.
                    
             2.4.6  Added Orpak enhancement on menu selection, fixed the card
		            crash, tested Walgreen AARP.
		            
	     2.4.5  Added support on Walgreen AARP cards.

             2.4.4  Added option to not go online after an EFT download.

             2.4.3  Added option to review scrolling receipt.
                    Added support for Orpak (i9010) terminal.
                    Added minimum (0007_0026) and maximum (0007_0027) number
                      of digits for hand entry of account number.
                    Script files were not closed when run.  Caused error after
                      running 6 or 7 scripts.
                    Added support for check boxes to scripting.

             2.4.2  Added optional source flag to read card response message.

             2.4.1  Added identification of V1 vs. V3 devices.
                      I6xxxN = V1, I6xxxT = V3.
                    Enable contactless reader on read card message (23.).

             2.4.0  Added flag to indicate that a "50." is required before
                      sending the Authorization Request message (50.).
                    Signature request message (20.) cleared signature when
                      called from offline.
                    If no palette information is in a form, the trasition is
                      set to "2" using the background color of the form.
                    Increased form table to 40 entries.
                    Increased bin ranges to 30.
                    Added setting (0003_0009) to turn on MSR during display
                      of a MSR read error.
                    Added message to convert image files to internal format
                      (96.).
                    Added option (0003_0007) to sound a beep on good MSR read.
                    Clear text input screenS (21. and 27.) and MSR request
                      (23.) support extra buttons in forms.
                    Fixed problem where ads restarted at first ad in the list,
                      not the ad specified in the configuration.
                    Added option (0003_0008) to add track 3 to the response to
                      a card read request (23.).
                    Added support for ViVOtech contactless card reader.
                    Added ability to specify encryption key by card type.
                      (0011_0001 - 0011_0016).
                    Added message (70.) to update a text fields on the screen.
                    Added setting (0005_0007) telling Spin-the-BIN what to do
                      if no response is received.
                    Added support for check boxes and radio buttons to form
                      message (24.).
                    Added flag to BIN table that suppresses MSR encryption for
                      a given BIN range.
                    Option to disable payments that require a PIN encryption
                      but the required key is missing.
                    Added ability to hand enter card information.
                    Added option (0002_0013) to enter cash back amount in
                      dollars.
                    Added format for manual entry of cashback (0002_0014).
                    Scrolling of line item display is faster.
                    Added option to STB enable (0005_0002) to require an empty
                      19. message to set the STB request.
                    Added variables to check for existance of encryption keys.
                    Added setting (0005_0008) setting the minimum number of
                      leading digits of the account number must be real in the
                      Spin-the-BIN message when using MSR encryption.

             2.3.8  Added encryption for MSR information received by Account
                      Message (12.).
                    CPEM firware update didn't work if set to 9600 baud.

             2.3.7  Pressing clear too many times locked up the PIN entry
                      request message (31.).

             2.3.6  Added support for MSR track encryption.
                    Added options to Assumed Track (0003_0004) to globaly
                      require a specific track.
                    Added the ability to update the firmware in a CPEM.
                    Added option (0013_0011) to delay the sending of an ACK
                      until the message is ready to process.
                    Added option (0013_0012) to suppress sending a response
                      to Set Variable (28.) message.
                    If a parameter file or MSR key is missing, the device will
                      now go to offline state but will only download. Returns
                      "00.4000" to prohibited messages.
                    Replaced logos with new Ingenico logo.
                    Changed Accept key is signature forms to "A" to work around
                      problem in newer SSAs.

             2.3.5  Line display can de updated every x/10th of a second
                      rather than in real time.

             2.3.4  Unsupported keys locked up signature screens.

             2.3.3  Fixed problem displaying long strings.
                    Fixed problem with alpha input longer than 30 characters.

             2.3.2  15.6 was not canceling PIN on demand message (31.).
                    Soft reset (15.) of PIN did not follow the "On PIN entry
                      cancel" setting in the cards table.
                    Alpha input filtered out periods.

             2.3.1  Changes queue processing to increase keyboard priority.
                    PIN on demand (31.) always returned to slide card state.
                    PIN on demand (31.) sent while already running stopped
                      keyboard entry.

             2.3.0  Added support for custom palettes.
                    Added support for check boxes.
                    Hardware ID is requested from OS.
                    Added message (27.) to request alpha input.
                    Added message (31.) to request PIN input.
                    Added support for Store Pay version of Spin-the-BIN.
                    Added variable (305) to retrieve cashback selected by
                      customer.
                    Added ability to select ads by time and day of week.
                    Ad display time is now per ad, not global.
                    Increased the number of ads available from 12 to 20.
                    Changed flag that indicates it the screen should be cleared
                      between ads from a boolean to a duration. 0 = do not
                      clear.
                    Added a setting (0013_0008) to select if a transaction
                      should end or restart on a decline.
                    Changed CPEM to support Discover cards.
                    Added ability to hide "Accept" and "Decline" buttons until
                      the bottom of the screen.
                    Allow messages 20., 21., 23. 24., 25., 26., 27., 30., & 31.
                      to work when offline.
                    Added a flag (0013_0009) to allow the addition of a field
                      to the reset message that tells the POS why a reset was
                      sent.
                    Added maintenance application version to boot screen.
                    Added more information to the offline information screen.
                    Added signature threshold to card configuration table.

             2.24   Disable MSR when swipe card screen is interrupted.

             2.23   Fixed problem with formatted input message (21.).

             2.22   Add a flag to reset the device at the end of an approved
                      transaction.
                    Change flag that indicates if the results screen is
                      displayed to a timer.
                    Add flag to send a reset message (10.) when the transaction
                      is set to reset at the end of a transaction.

             2.21   Fixed a memory leak in form parser.

             2.20   WARNING!  There is a problem with communicating with
                      eN Concert Store and Signature Catcher in this version.

                    Added support for i6580.
                    Use common form parser.
                    Display number of images converted as �X of Y�.
                    Use text buttons for cash back amount buttons (requires SSA
                      2.43 or newer).
                    Select destination of �Cancel� button on PIN entry screen
                      per card not global.
                    Support proportional fonts.
                    Add display variable for card�s expiration date.
                    Move table of % display variables to application (out of
                      frame),
                    Modify signature to allow �X� and line (requires SSA 2.43
                      or newer)
                    Enable key mask (requires SSA 2.43 or newer).  
                    Improve look of default forms.
                    Add ability to define PIN entry form for each payment type.
                    Add option to display PIN size error as prompt for new PIN.
                    Improved speed of Terms & Conditions screen.  NOTE! The form
                      has changed!  Update to new form!
                    Separate text file for each language in Terms & Conditions
                      screen.
                    Add ability to reformat name field in track 1.  Field in
                      the format "last/first" is put in "first last".
                    Presign/postsign no longer global.  Now part of cards.dat
                    Put all default payments in pay1.icg.
                    Added flag to make signature on request save the state
                      rather than cancel the transaction.
                    Add a screen to display configured version as well as base
                      version off of offline screen.
                    Added run script command (26.).
                    Added option to allow STB response (19.) and force payment
                      type (04.) to specify a payment menu or a payment type.
                    Change "Show Payment type" (0007_0008) from boolean to time.
                      Display if not zero.  Value is time in 1/10th of second.
                    Added find file command (63.).
                    Put in work-around for problem with key beeps in SSA 2.40
                      and newer.
                    Added support for USB on i3070.
                    Combine all i6xxx and i3070 into one release package.
                    Added keycode translation to form.
                    Added ability to hide up buttons when at top of text and
                      down buttons when at bottom of form.

             2.12   Added French translations and buttons. Completed Spanish
                      translations and buttons.

             2.11   Fixed keyboard translation for payment menus on i3070.
                    Added flag to allow incomming message to be treated as an
                      ACK.  This is how the eT 1000 and eC 2100 work.
                    Fixed problem where PIN entry was skipped if cashback is
                      processed first & customer selected no cashback.

             2.10   Add support for a �Cashback� button on the total screen.
                    Add customer entered partial payment support.
                    Remove leading �$� in amount message (if found).
                    Add ability to specify a displayed character as it�s ASCII
                      number (\999 or \xFF).
                    Add support for formatted numeric input. (phone number,
                      dollars & cents, etc.)
                    Check card�s expiration date.
                    Add ability to set devices internal date and time and add
                      display variables to display date and time.
                    User defined display variables (%var01% - %var25%) with
                      ability to save to flash.
                    Add file download (62.) support.
                    Added a flag to put cashback before PIN entry, after PIN
                      entry or only from total screen.
                    Increased internal BIN ranges from 12 to 20 entries.
                    Added display variables for card type, customer name and
                      account number.
                    Added a flag to only allow terms and conditions screen to be
                      accepted after scrolling to the bottom.
                    Fixed USB support.
                    Added support for non-ISO track 3 (most Driver's License).
                    Added support for i3070.
                    Changed name of file "i6510pay.dat" to "pay.dat".
                    Ability to override displayed application name, part number
                      and version.

             2.02   Spin-the-BIN message (19.) was missing the last digit of
                      account number.

             2.01   Fixed compare of account number in STB response (19.).
                    Fixed problem where loyalty cards were verified via the
                      BIN table.

             2.00   Port from eN Touch 1000 / eN Crypt 2100 RBA 3.34.
                    Added system reset message (97.).
                    Added configuration read & write messages (60. & 61.).
                    Added support for forms.
                    Made same executable work on 6510, 6550, 6770 & 6780.
                    Added support for variables in strings (%xxx%).
                    Added Form input message (24.).
                    Added Terms & Conditions display (25.).
                    Added ethernet support.
                    Added support for eN Concert Store.
                      (BIN lookup and authorization)
                    Added screen saver option to offline screen.
                    Added support for Ingenico/OTI RFID reader.
                    Advertising supports .gif, .bmp or form files.
                    Added option to 30. message that selects a specific ad.
                    Added destination on PIN entry cancel.
                    Added support for forms on PIN and clear text entry.
                      (Requires SSA version 2.36 or newer.)

CRCs: 
